# Organic Traffic OS - SEO Submodule

Responsible for on-page SEO analysis, semantic expansion of articles, schema markup output, and internal contextual link mapping.

Uses:
- `agent-seo` (SEO Semantic Architect)
