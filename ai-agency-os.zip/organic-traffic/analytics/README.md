# Organic Traffic OS - Analytics Submodule

Responsible for aggregating Google Search Console CTR tables, attributing organic conversions, and rendering metrics dashboards.

Uses:
- `agent-analytics` (Search Performance Analyst)
