# Organic Traffic OS - Content Submodule

Responsible for multi-perspective outline drafting, brand voice copy editing, automated humanization, and markdown document output.

Uses:
- `agent-content` (Agentic Copywriter)
