# Organic Traffic OS - Workflows Submodule

Orchestrates sequential multi-agent operations:
1. `autonomous-blog-indexing`
2. `keyword-to-optimized-copywriting`
3. `seo-audit-and-schema-sync`
