# Organic Traffic OS - Research Submodule

Responsible for keyword discovery, semantic gaps identification, search trend mining, and competitor analysis.

Uses:
- `agent-research` (Keyword & Competitor Researcher)
