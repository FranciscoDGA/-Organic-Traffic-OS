# Organic Traffic OS - Knowledge Submodule

Responsible for fetching local knowledge vectors and syncing rules, tones, and personas specific to the blog content targets.
