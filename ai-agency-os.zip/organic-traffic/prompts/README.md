# Organic Traffic OS - Prompts Submodule

Centralized, structured system prompt structures, dynamic prompt expansion variables, and brand voice instructions.
