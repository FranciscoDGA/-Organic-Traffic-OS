import React, { useState, useEffect } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  FileText, 
  AlertTriangle, 
  PlusCircle, 
  CheckCircle2, 
  Layers, 
  Search, 
  HelpCircle, 
  RefreshCw, 
  Sliders, 
  Eye, 
  MousePointerClick, 
  Percent, 
  Clock, 
  ArrowUpRight, 
  Share2, 
  Download, 
  UserPlus, 
  Plus, 
  X, 
  ChevronRight,
  Sparkles,
  Zap,
  Info,
  ExternalLink,
  Flame,
  ListOrdered
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface PerformanceMetrics {
  visualizacoes: number;
  cliques: number;
  ctr: number;
  impressoes: number;
  tempo_medio_segundos: number;
  scroll_porcentagem: number;
  conversoes: number;
  downloads: number;
  leads: number;
  compartilhamentos: number;
}

interface TrendAnalysis {
  status: "alta" | "queda" | "estabilidade" | "mudanca_brusca";
  descricao: string;
  percentual_variacao_cliques: number;
  percentual_variacao_visualizacoes: number;
}

interface PerformanceRecommendation {
  id: string;
  tipo: string;
  titulo: string;
  descricao: string;
  urgencia: "critica" | "alta" | "media" | "baixa";
}

interface RefreshPriority {
  urgencia: number;
  impacto: number;
  roi_esperado: number;
  esforco: number;
  score_final: number;
}

interface PerformanceHistoryRecord {
  data: string;
  metrics: PerformanceMetrics;
}

interface ContentPerformance {
  content_id: string;
  titulo_conteudo: string;
  url: string;
  status: "ativo" | "revisar" | "em_revisao" | "atualizado";
  ultima_analise: string;
  ultima_atualizacao: string;
  metrics: PerformanceMetrics;
  history: PerformanceHistoryRecord[];
  trends: TrendAnalysis;
  recommendations: PerformanceRecommendation[];
  priority: RefreshPriority;
}

export default function OrganicPerformance() {
  const [performanceList, setPerformanceList] = useState<ContentPerformance[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTrend, setFilterTrend] = useState<string>("todos");
  const [activeSubTab, setActiveSubTab] = useState<"geral" | "tendencias" | "recomendacoes" | "prioridades">("geral");
  const [selectedContent, setSelectedContent] = useState<ContentPerformance | null>(null);
  
  // Registration Form States
  const [showModal, setShowModal] = useState(false);
  const [formError, setFormError] = useState("");
  const [formContentId, setFormContentId] = useState("");
  const [formTitle, setFormTitle] = useState("");
  const [formUrl, setFormUrl] = useState("");
  const [formStatus, setFormStatus] = useState<"ativo" | "revisar" | "em_revisao" | "atualizado">("ativo");
  
  // Metrics fields
  const [metricViews, setMetricViews] = useState(100);
  const [metricClicks, setMetricClicks] = useState(5);
  const [metricImpressions, setMetricImpressions] = useState(500);
  const [metricAvgTime, setMetricAvgTime] = useState(90);
  const [metricScroll, setMetricScroll] = useState(50);
  const [metricConversions, setMetricConversions] = useState(0);
  const [metricDownloads, setMetricDownloads] = useState(0);
  const [metricLeads, setMetricLeads] = useState(0);
  const [metricShares, setMetricShares] = useState(0);

  // Success Notification state
  const [notification, setNotification] = useState<string | null>(null);

  const fetchPerformance = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/organic-os/performance");
      if (res.ok) {
        const data = await res.json();
        setPerformanceList(data);
      } else {
        console.error("Erro ao carregar dados de performance");
      }
    } catch (err) {
      console.error("Erro de conexão com API de performance:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPerformance();
  }, []);

  const triggerNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const handleOpenRegister = (perf?: ContentPerformance) => {
    if (perf) {
      // Pre-populate for editing/updating metrics
      setFormContentId(perf.content_id);
      setFormTitle(perf.titulo_conteudo);
      setFormUrl(perf.url);
      setFormStatus(perf.status);
      setMetricViews(perf.metrics.visualizacoes);
      setMetricClicks(perf.metrics.cliques);
      setMetricImpressions(perf.metrics.impressoes);
      setMetricAvgTime(perf.metrics.tempo_medio_segundos);
      setMetricScroll(perf.metrics.scroll_porcentagem);
      setMetricConversions(perf.metrics.conversoes);
      setMetricDownloads(perf.metrics.downloads);
      setMetricLeads(perf.metrics.leads);
      setMetricShares(perf.metrics.compartilhamentos);
    } else {
      // Setup a fresh content item
      const nextId = `pub_manual_${Math.floor(Math.random() * 900) + 100}`;
      setFormContentId(nextId);
      setFormTitle("");
      setFormUrl("https://passacumaru.com.br/blog/artigo-");
      setFormStatus("ativo");
      setMetricViews(250);
      setMetricClicks(12);
      setMetricImpressions(600);
      setMetricAvgTime(110);
      setMetricScroll(60);
      setMetricConversions(4);
      setMetricDownloads(2);
      setMetricLeads(3);
      setMetricShares(1);
    }
    setFormError("");
    setShowModal(true);
  };

  const handleSubmitMetrics = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formContentId.trim()) {
      setFormError("O ID do conteúdo é obrigatório.");
      return;
    }
    if (!formTitle.trim()) {
      setFormError("O Título do conteúdo é obrigatório.");
      return;
    }
    if (!formUrl.trim() || !formUrl.startsWith("http")) {
      setFormError("Por favor, informe uma URL válida.");
      return;
    }

    if (metricClicks > metricImpressions) {
      setFormError("O número de Cliques não pode ser maior que o número de Impressões.");
      return;
    }

    const payload = {
      contentId: formContentId,
      tituloConteudo: formTitle,
      url: formUrl,
      status: formStatus,
      metrics: {
        visualizacoes: Number(metricViews),
        cliques: Number(metricClicks),
        ctr: 0, // calculado no backend
        impressoes: Number(metricImpressions),
        tempo_medio_segundos: Number(metricAvgTime),
        scroll_porcentagem: Number(metricScroll),
        conversoes: Number(metricConversions),
        downloads: Number(metricDownloads),
        leads: Number(metricLeads),
        compartilhamentos: Number(metricShares)
      }
    };

    try {
      const res = await fetch("/api/organic-os/performance/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        triggerNotification(`Métricas de "${formTitle}" salvas e reanalisadas com sucesso!`);
        setShowModal(false);
        fetchPerformance();
        
        // Se este conteúdo estiver aberto na lateral, atualiza o foco
        if (selectedContent && selectedContent.content_id === formContentId) {
          setSelectedContent(data.performance);
        }
      } else {
        const errData = await res.json();
        setFormError(errData.error || "Erro ao salvar métricas.");
      }
    } catch (err) {
      setFormError("Erro de comunicação com o servidor.");
    }
  };

  const handleDeletePerformance = async (id: string, name: string) => {
    if (!window.confirm(`Deseja realmente remover o monitoramento de performance de "${name}"?`)) {
      return;
    }

    try {
      const res = await fetch(`/api/organic-os/performance/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        triggerNotification(`Monitoramento de "${name}" removido.`);
        if (selectedContent?.content_id === id) {
          setSelectedContent(null);
        }
        fetchPerformance();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleResolveRecommendation = (recId: string, recTitle: string) => {
    triggerNotification(`Recomendação "${recTitle}" marcada como concluída! Ação adicionada ao histórico de otimização.`);
    // Otimização visual para simular resolução imediata no estado local
    if (selectedContent) {
      const updatedRecs = selectedContent.recommendations.filter(r => r.id !== recId);
      setSelectedContent({
        ...selectedContent,
        recommendations: updatedRecs
      });
      setPerformanceList(prev => prev.map(item => {
        if (item.content_id === selectedContent.content_id) {
          return { ...item, recommendations: updatedRecs };
        }
        return item;
      }));
    }
  };

  const getTrendBadge = (status: string) => {
    switch (status) {
      case "alta":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-2.5 rounded-full text-xs font-semibold bg-emerald-950/40 text-emerald-400 border border-emerald-800/60">
            <TrendingUp className="h-3 w-3" /> Alta
          </span>
        );
      case "queda":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-2.5 rounded-full text-xs font-semibold bg-rose-950/40 text-rose-400 border border-rose-800/60">
            <TrendingDown className="h-3 w-3" /> Queda
          </span>
        );
      case "mudanca_brusca":
        return (
          <span className="inline-flex items-center gap-1 py-1 px-2.5 rounded-full text-xs font-semibold bg-amber-950/40 text-amber-400 border border-amber-800/60">
            <Flame className="h-3 w-3" /> Mudança Brusca
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 py-1 px-2.5 rounded-full text-xs font-semibold bg-slate-800/60 text-slate-400 border border-slate-700/60">
            <Activity className="h-3 w-3" /> Estável
          </span>
        );
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ativo":
        return <span className="text-xs px-2 py-1 rounded bg-cyan-950/30 text-cyan-400 border border-cyan-850">Ativo</span>;
      case "revisar":
        return <span className="text-xs px-2 py-1 rounded bg-rose-950/30 text-rose-400 border border-rose-850">Revisar</span>;
      case "em_revisao":
        return <span className="text-xs px-2 py-1 rounded bg-amber-950/30 text-amber-400 border border-amber-850">Em Revisão</span>;
      case "atualizado":
        return <span className="text-xs px-2 py-1 rounded bg-emerald-950/30 text-emerald-400 border border-emerald-850">Otimizado</span>;
      default:
        return <span className="text-xs px-2 py-1 rounded bg-slate-800 text-slate-300">{status}</span>;
    }
  };

  const getRecommendationUrgencyBadge = (urg: string) => {
    switch (urg) {
      case "critica":
        return <span className="px-2 py-0.5 text-[10px] uppercase font-bold rounded bg-rose-900/60 text-rose-200 border border-rose-700">Crítica</span>;
      case "alta":
        return <span className="px-2 py-0.5 text-[10px] uppercase font-bold rounded bg-amber-900/60 text-amber-200 border border-amber-700">Alta</span>;
      case "media":
        return <span className="px-2 py-0.5 text-[10px] uppercase font-bold rounded bg-yellow-950/60 text-yellow-300 border border-yellow-700/60">Média</span>;
      default:
        return <span className="px-2 py-0.5 text-[10px] uppercase font-bold rounded bg-slate-800 text-slate-300 border border-slate-700">Baixa</span>;
    }
  };

  // Filter & Search Logic
  const filteredList = performanceList.filter(item => {
    const matchesSearch = item.titulo_conteudo.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.content_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.url.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filterTrend === "todos") return matchesSearch;
    return matchesSearch && item.trends.status === filterTrend;
  });

  // Calculate high-level totals
  const totalMonitored = performanceList.length;
  const growthCount = performanceList.filter(p => p.trends.status === "alta").length;
  const decayCount = performanceList.filter(p => p.trends.status === "queda").length;
  
  // Find top content (highest clicks)
  const topContent = performanceList.length > 0 
    ? [...performanceList].sort((a, b) => b.metrics.cliques - a.metrics.cliques)[0]
    : null;

  // Recommendations collected across all monitored content
  const allRecommendations = performanceList.reduce((acc, item) => {
    const itemRecs = item.recommendations.map(r => ({
      ...r,
      contentId: item.content_id,
      contentTitle: item.titulo_conteudo,
      url: item.url
    }));
    return [...acc, ...itemRecs];
  }, [] as Array<PerformanceRecommendation & { contentId: string; contentTitle: string; url: string }>);

  // Sorting priorities by Score Final
  const priorityQueue = [...performanceList].sort((a, b) => b.priority.score_final - a.priority.score_final);

  return (
    <div className="space-y-6">
      {/* Dynamic Success Toast */}
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 bg-slate-900 border border-emerald-500/80 text-emerald-300 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3"
          >
            <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            <span className="text-sm font-medium">{notification}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Header */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-40 bg-cyan-900/10 blur-3xl rounded-full -mr-20 -mt-20"></div>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative z-10">
          <div>
            <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase flex items-center gap-2">
              <Sparkles className="h-3 w-3" /> Sprint 25 — V1 Live
            </span>
            <h1 className="text-2xl font-display font-bold text-white tracking-tight mt-1">
              Motor de Performance de Conteúdo
            </h1>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Nenhum conteúdo publicado é definitivo. Acompanhe a saúde orgânica de cada publicação, 
              meça o engajamento e execute recomendações de refinamento em loop contínuo.
            </p>
          </div>
          
          <div className="flex gap-2.5">
            <button 
              onClick={fetchPerformance}
              className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg text-sm font-medium border border-slate-700 flex items-center gap-2 transition"
              title="Recarregar dados"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
              Sincronizar
            </button>
            <button 
              onClick={() => handleOpenRegister()}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 rounded-lg text-sm font-bold flex items-center gap-2 transition shadow-lg shadow-cyan-900/30"
            >
              <PlusCircle className="h-4 w-4 text-slate-950" />
              Manual Metrics Input
            </button>
          </div>
        </div>

        {/* High Level Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="h-10 w-10 rounded-lg bg-cyan-950/40 text-cyan-400 border border-cyan-800/40 flex items-center justify-center">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[11px] uppercase font-mono text-slate-500 tracking-wider">Conteúdos Monitorados</p>
              <h3 className="text-xl font-bold text-white mt-0.5">{totalMonitored} artigos</h3>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="h-10 w-10 rounded-lg bg-emerald-950/40 text-emerald-400 border border-emerald-800/40 flex items-center justify-center">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[11px] uppercase font-mono text-slate-500 tracking-wider">Tendência de Alta</p>
              <h3 className="text-xl font-bold text-emerald-400 mt-0.5">+{growthCount} crescendo</h3>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="h-10 w-10 rounded-lg bg-rose-950/40 text-rose-400 border border-rose-800/40 flex items-center justify-center">
              <TrendingDown className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[11px] uppercase font-mono text-slate-500 tracking-wider">Tendência de Queda</p>
              <h3 className="text-xl font-bold text-rose-400 mt-0.5">{decayCount} necessitam revisão</h3>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="h-10 w-10 rounded-lg bg-amber-950/40 text-amber-400 border border-amber-800/40 flex items-center justify-center">
              <Zap className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[11px] uppercase font-mono text-slate-500 tracking-wider">Mais Clicado (Top SERP)</p>
              <h3 className="text-xs font-bold text-white mt-1 truncate max-w-[170px]" title={topContent?.titulo_conteudo}>
                {topContent ? topContent.titulo_conteudo : "Carregando..."}
              </h3>
              <p className="text-[10px] font-mono text-slate-400">{topContent ? `${topContent.metrics.cliques} cliques` : ""}</p>
            </div>
          </div>
        </div>

        {/* GSC and GA4 Connectivity Banner (Sprint Requirement: Architecture Ready) */}
        <div className="mt-5 p-3.5 bg-cyan-950/10 border border-cyan-900/30 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <Info className="h-4 w-4 text-cyan-400 flex-shrink-0" />
            <span>
              <strong>Arquitetura Conectada:</strong> Os canais de recebimento estão prontos. Os conectores nativos para 
              Google Search Console (GSC) e Google Analytics (GA4) serão integrados na próxima fase.
            </span>
          </div>
          <span className="font-mono text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800/50 px-2 py-0.5 rounded uppercase font-semibold">
            API READY
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="border-b border-slate-800 flex flex-wrap gap-1">
        <button
          onClick={() => { setActiveSubTab("geral"); setSelectedContent(null); }}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition ${
            activeSubTab === "geral" 
              ? "border-cyan-400 text-cyan-400" 
              : "border-transparent text-slate-400 hover:text-slate-300"
          }`}
        >
          <span className="flex items-center gap-2">
            <Sliders className="h-4 w-4" /> Visão Geral de Métricas
          </span>
        </button>
        <button
          onClick={() => { setActiveSubTab("tendencias"); setSelectedContent(null); }}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition ${
            activeSubTab === "tendencias" 
              ? "border-cyan-400 text-cyan-400" 
              : "border-transparent text-slate-400 hover:text-slate-300"
          }`}
        >
          <span className="flex items-center gap-2">
            <Activity className="h-4 w-4" /> Análise de Tendências
          </span>
        </button>
        <button
          onClick={() => { setActiveSubTab("recomendacoes"); setSelectedContent(null); }}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition ${
            activeSubTab === "recomendacoes" 
              ? "border-cyan-400 text-cyan-400" 
              : "border-transparent text-slate-400 hover:text-slate-300"
          }`}
        >
          <span className="flex items-center gap-2">
            <Sparkles className="h-4 w-4" /> Recomendações ({allRecommendations.length})
          </span>
        </button>
        <button
          onClick={() => { setActiveSubTab("prioridades"); setSelectedContent(null); }}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition ${
            activeSubTab === "prioridades" 
              ? "border-cyan-400 text-cyan-400" 
              : "border-transparent text-slate-400 hover:text-slate-300"
          }`}
        >
          <span className="flex items-center gap-2">
            <ListOrdered className="h-4 w-4" /> Fila de Prioridades (ROI)
          </span>
        </button>
      </div>

      {/* Main Content Layout with optional Sidebar detail split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left main area (collapses when a row detail is active) */}
        <div className={`${selectedContent ? 'lg:col-span-7 xl:col-span-8' : 'lg:col-span-12'} space-y-6 transition-all duration-300`}>
          
          {/* SEARCH & FILTERS PANEL (Only shown in Geral & Tendencias tabs) */}
          {(activeSubTab === "geral" || activeSubTab === "tendencias") && (
            <div className="bg-slate-900/40 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row gap-3 justify-between items-center">
              <div className="relative w-full sm:max-w-md">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Buscar por ID, título ou URL de destino..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              <div className="flex gap-2 w-full sm:w-auto">
                <select
                  value={filterTrend}
                  onChange={(e) => setFilterTrend(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-cyan-500/50 w-full sm:w-auto"
                >
                  <option value="todos">Todas as Tendências</option>
                  <option value="alta">Tendência: Alta</option>
                  <option value="queda">Tendência: Queda</option>
                  <option value="estabilidade">Tendência: Estável</option>
                  <option value="mudanca_brusca">Tendência: Mudança Brusca</option>
                </select>
              </div>
            </div>
          )}

          {/* SUB-TAB 1: GERAL (LIST OF ALL MONITORED PAGES) */}
          {activeSubTab === "geral" && (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="p-4 border-b border-slate-800 bg-slate-900/30 flex justify-between items-center">
                <h2 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">Índice Geral de Conteúdos Publicados</h2>
                <span className="text-xs text-slate-400">Exibindo {filteredList.length} de {totalMonitored} páginas</span>
              </div>

              {filteredList.length === 0 ? (
                <div className="p-12 text-center text-slate-500">
                  <AlertTriangle className="h-8 w-8 text-slate-600 mx-auto mb-3" />
                  <p className="text-sm">Nenhum conteúdo monitorado encontrado com os filtros atuais.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-xs font-mono bg-slate-900/10">
                        <th className="p-4">Conteúdo / URL</th>
                        <th className="p-4">Status</th>
                        <th className="p-4">Cliques / Imp.</th>
                        <th className="p-4">CTR</th>
                        <th className="p-4">Urgência de Refino</th>
                        <th className="p-4 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-sm">
                      {filteredList.map((item) => {
                        const isSelected = selectedContent?.content_id === item.content_id;
                        return (
                          <tr 
                            key={item.content_id}
                            className={`hover:bg-slate-900/30 transition cursor-pointer ${
                              isSelected ? 'bg-cyan-950/10' : ''
                            }`}
                            onClick={() => setSelectedContent(item)}
                          >
                            <td className="p-4 max-w-[280px]">
                              <p className="font-semibold text-slate-200 truncate" title={item.titulo_conteudo}>
                                {item.titulo_conteudo}
                              </p>
                              <div className="flex items-center gap-1.5 mt-1 text-xs text-slate-400">
                                <span className="font-mono bg-slate-850 px-1 py-0.5 rounded text-[10px] text-cyan-400">
                                  {item.content_id}
                                </span>
                                <a 
                                  href={item.url} 
                                  target="_blank" 
                                  rel="noopener noreferrer" 
                                  className="hover:text-cyan-400 flex items-center gap-0.5 truncate max-w-[180px]"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  {item.url.replace("https://passacumaru.com.br", "")} 
                                  <ExternalLink className="h-3 w-3 inline" />
                                </a>
                              </div>
                            </td>
                            <td className="p-4">
                              {getStatusBadge(item.status)}
                            </td>
                            <td className="p-4 font-mono text-xs">
                              <span className="text-slate-200 font-bold">{item.metrics.cliques}</span>
                              <span className="text-slate-600"> / {item.metrics.impressoes}</span>
                            </td>
                            <td className="p-4 font-mono text-xs">
                              <div className="flex items-center gap-1.5">
                                <span className="text-cyan-400 font-bold">{item.metrics.ctr}%</span>
                                <span className="text-slate-500">({item.trends.status})</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                                  <div 
                                    className={`h-full rounded-full ${
                                      item.priority.score_final > 6 
                                        ? 'bg-rose-500' 
                                        : item.priority.score_final > 4 
                                        ? 'bg-amber-500' 
                                        : 'bg-emerald-500'
                                    }`}
                                    style={{ width: `${Math.min(100, item.priority.score_final * 10)}%` }}
                                  ></div>
                                </div>
                                <span className="text-xs font-mono font-bold text-slate-300">
                                  {item.priority.score_final}
                                </span>
                              </div>
                            </td>
                            <td className="p-4 text-right" onClick={(e) => e.stopPropagation()}>
                              <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => handleOpenRegister(item)}
                                  className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 rounded transition"
                                  title="Editar Métricas Manuais"
                                >
                                  <Sliders className="h-4 w-4" />
                                </button>
                                <button 
                                  onClick={() => handleDeletePerformance(item.content_id, item.titulo_conteudo)}
                                  className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-rose-400 rounded transition"
                                  title="Remover Monitoramento"
                                >
                                  <Trash2Icon className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* SUB-TAB 2: TENDÊNCIAS & MUDANÇAS BRUSCAS */}
          {activeSubTab === "tendencias" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Crescimento em Alta */}
              <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2 border-b border-slate-800 pb-3">
                  <TrendingUp className="h-5 w-5" /> Impulsionamento & Alta
                </h3>
                <div className="space-y-4 mt-4">
                  {filteredList.filter(p => p.trends.status === "alta" || (p.trends.status === "mudanca_brusca" && p.trends.percentual_variacao_cliques > 0)).length === 0 ? (
                    <p className="text-xs text-slate-500 py-4 text-center">Nenhum conteúdo disparando alta no momento.</p>
                  ) : (
                    filteredList
                      .filter(p => p.trends.status === "alta" || (p.trends.status === "mudanca_brusca" && p.trends.percentual_variacao_cliques > 0))
                      .map(p => (
                        <div 
                          key={p.content_id}
                          className="bg-slate-950 border border-slate-850 p-3 rounded-lg hover:border-cyan-500/30 cursor-pointer transition"
                          onClick={() => setSelectedContent(p)}
                        >
                          <div className="flex justify-between items-start">
                            <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">{p.titulo_conteudo}</h4>
                            <span className="text-xs font-mono font-bold text-emerald-400 ml-2 flex-shrink-0">
                              +{p.trends.percentual_variacao_cliques}% cliq.
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{p.trends.descricao}</p>
                          <div className="mt-2.5 flex justify-between items-center text-[10px] text-slate-500 font-mono">
                            <span>Views: {p.metrics.visualizacoes}</span>
                            <span>CTR: {p.metrics.ctr}%</span>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </div>

              {/* Perda e Desgaste (Decay) */}
              <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-2 border-b border-slate-800 pb-3">
                  <TrendingDown className="h-5 w-5" /> Depreciação & Queda (Decay)
                </h3>
                <div className="space-y-4 mt-4">
                  {filteredList.filter(p => p.trends.status === "queda" || (p.trends.status === "mudanca_brusca" && p.trends.percentual_variacao_cliques < 0)).length === 0 ? (
                    <p className="text-xs text-slate-500 py-4 text-center">Parabéns! Sem conteúdos com queda acentuada registrada.</p>
                  ) : (
                    filteredList
                      .filter(p => p.trends.status === "queda" || (p.trends.status === "mudanca_brusca" && p.trends.percentual_variacao_cliques < 0))
                      .map(p => (
                        <div 
                          key={p.content_id}
                          className="bg-slate-950 border border-slate-850 p-3 rounded-lg hover:border-cyan-500/30 cursor-pointer transition"
                          onClick={() => setSelectedContent(p)}
                        >
                          <div className="flex justify-between items-start">
                            <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">{p.titulo_conteudo}</h4>
                            <span className="text-xs font-mono font-bold text-rose-400 ml-2 flex-shrink-0">
                              {p.trends.percentual_variacao_cliques}% cliq.
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{p.trends.descricao}</p>
                          <div className="mt-2.5 flex justify-between items-center text-[10px] text-rose-400/80 font-mono">
                            <span>Urgência: {p.priority.urgencia}/10</span>
                            <span className="bg-rose-950/30 text-rose-300 px-1.5 py-0.5 rounded text-[9px] border border-rose-900/50">REVISAR</span>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </div>

            </div>
          )}

          {/* SUB-TAB 3: RECOMENDAÇÕES DE OTIMIZAÇÃO */}
          {activeSubTab === "recomendacoes" && (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden">
              <div className="p-4 border-b border-slate-800 bg-slate-900/30 flex justify-between items-center">
                <h2 className="text-sm font-semibold text-white uppercase tracking-wider font-mono">Fila Geral de Ações Recomendadas pelo Motor</h2>
                <span className="text-xs text-slate-400">{allRecommendations.length} pendentes</span>
              </div>

              {allRecommendations.length === 0 ? (
                <div className="p-12 text-center text-slate-500">
                  <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto mb-3" />
                  <p className="text-sm">Nenhuma recomendação gerada. Seus conteúdos estão com excelente desempenho.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-800">
                  {allRecommendations.map((rec) => (
                    <div 
                      key={rec.id}
                      className="p-5 hover:bg-slate-900/20 transition flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                    >
                      <div className="space-y-1 max-w-2xl">
                        <div className="flex items-center flex-wrap gap-2">
                          <span className="text-xs font-mono font-bold text-cyan-400 uppercase bg-cyan-950/40 border border-cyan-900/50 px-1.5 py-0.5 rounded">
                            {rec.tipo.replace("_", " ")}
                          </span>
                          {getRecommendationUrgencyBadge(rec.urgencia)}
                          <span className="text-xs text-slate-400 font-medium">
                            em: <strong className="text-slate-300 font-semibold">{rec.contentTitle}</strong>
                          </span>
                        </div>
                        <h3 className="text-sm font-bold text-slate-200 mt-1">{rec.titulo}</h3>
                        <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{rec.descricao}</p>
                        <div className="text-[10px] text-slate-500 mt-1 font-mono">
                          ID: {rec.id} | URL Vinculada: <a href={rec.url} target="_blank" rel="noreferrer" className="text-cyan-500 hover:underline">{rec.url}</a>
                        </div>
                      </div>

                      <div className="flex gap-2 w-full md:w-auto justify-end">
                        <button
                          onClick={() => {
                            const found = performanceList.find(p => p.content_id === rec.contentId);
                            if (found) setSelectedContent(found);
                          }}
                          className="px-2.5 py-1.5 bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800 rounded text-xs font-medium transition flex items-center gap-1"
                        >
                          Análise <ChevronRight className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => handleResolveRecommendation(rec.id, rec.titulo)}
                          className="px-3 py-1.5 bg-emerald-950/40 text-emerald-400 hover:bg-emerald-900/30 border border-emerald-800/50 rounded text-xs font-bold transition flex items-center gap-1"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" /> Resolver
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* SUB-TAB 4: PRIORITY QUEUE (ordered by Score Final) */}
          {activeSubTab === "prioridades" && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-3">
                <div className="h-9 w-9 rounded bg-cyan-950/50 text-cyan-400 border border-cyan-800/40 flex items-center justify-center flex-shrink-0">
                  <ListOrdered className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Algoritmo de Priorização Inteligente (ICE Score)</h3>
                  <p className="text-xs text-slate-400">
                    Calculado cruzando: <strong>(Urgência + Impacto + ROI esperado) em relação ao Esforço</strong> de engenharia/redação.
                  </p>
                </div>
              </div>

              <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-xl">
                <div className="p-4 border-b border-slate-800 bg-slate-900/30">
                  <h2 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">Fila de Prioridades de Otimização Orgânica</h2>
                </div>

                <div className="divide-y divide-slate-800/70">
                  {priorityQueue.map((item, idx) => (
                    <div 
                      key={item.content_id}
                      className="p-4 hover:bg-slate-900/20 transition flex flex-col md:flex-row justify-between items-start md:items-center gap-4 cursor-pointer"
                      onClick={() => setSelectedContent(item)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="h-7 w-7 rounded-full bg-slate-800 text-slate-300 font-mono text-xs flex items-center justify-center font-bold flex-shrink-0">
                          #{idx + 1}
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-slate-200">{item.titulo_conteudo}</h4>
                          <p className="text-xs text-slate-400 font-mono mt-0.5">{item.content_id} — {item.url.replace("https://passacumaru.com.br", "")}</p>
                          <div className="flex gap-2.5 mt-2">
                            <span className="text-[10px] text-slate-400 font-mono">CTR: {item.metrics.ctr}%</span>
                            <span className="text-[10px] text-slate-400 font-mono">Cliques: {item.metrics.cliques}</span>
                            <span className="text-[10px] text-slate-400 font-mono">Status: {getStatusBadge(item.status)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row items-end sm:items-center gap-4 w-full md:w-auto justify-end">
                        {/* Breakdown bar */}
                        <div className="grid grid-cols-4 gap-1.5 w-44 bg-slate-950 p-2 rounded border border-slate-850">
                          <div className="text-center">
                            <p className="text-[8px] text-slate-500 font-mono uppercase">Urg</p>
                            <span className="text-xs font-bold text-rose-400">{item.priority.urgencia}</span>
                          </div>
                          <div className="text-center">
                            <p className="text-[8px] text-slate-500 font-mono uppercase">Imp</p>
                            <span className="text-xs font-bold text-cyan-400">{item.priority.impacto}</span>
                          </div>
                          <div className="text-center">
                            <p className="text-[8px] text-slate-500 font-mono uppercase">Roi</p>
                            <span className="text-xs font-bold text-emerald-400">{item.priority.roi_esperado}</span>
                          </div>
                          <div className="text-center">
                            <p className="text-[8px] text-slate-500 font-mono uppercase">Esf</p>
                            <span className="text-xs font-bold text-amber-500">{item.priority.esforco}</span>
                          </div>
                        </div>

                        {/* Priority Score Shield */}
                        <div className="text-center bg-slate-900 border border-slate-750 px-3 py-2 rounded-lg flex-shrink-0 min-w-[70px]">
                          <p className="text-[8px] text-slate-500 font-mono uppercase tracking-wider">Score ICE</p>
                          <span className={`text-sm font-black ${
                            item.priority.score_final > 6 
                              ? 'text-rose-400' 
                              : item.priority.score_final > 4 
                              ? 'text-amber-400' 
                              : 'text-emerald-400'
                          }`}>
                            {item.priority.score_final}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* RIGHT SIDEBAR: DETAILED PERFORMANCE REPORT & HISTORY AUDIT */}
        {selectedContent && (
          <div className="lg:col-span-5 xl:col-span-4 bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-6 self-start">
            <div className="flex justify-between items-start border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                  Relatório Detalhado
                </span>
                <h3 className="text-sm font-bold text-white mt-1.5 truncate max-w-[210px]" title={selectedContent.titulo_conteudo}>
                  {selectedContent.titulo_conteudo}
                </h3>
                <p className="text-[10px] font-mono text-cyan-400 mt-0.5">{selectedContent.content_id}</p>
              </div>
              <button 
                onClick={() => setSelectedContent(null)}
                className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Quick Stats Grid */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3.5">
                <div className="bg-slate-950 border border-slate-850 p-2.5 rounded text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-500 text-[10px] font-mono uppercase">
                    <Eye className="h-3 w-3" /> Visitas
                  </div>
                  <span className="text-sm font-mono font-bold text-white block mt-0.5">
                    {selectedContent.metrics.visualizacoes}
                  </span>
                </div>
                <div className="bg-slate-950 border border-slate-850 p-2.5 rounded text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-500 text-[10px] font-mono uppercase">
                    <MousePointerClick className="h-3 w-3" /> Cliques
                  </div>
                  <span className="text-sm font-mono font-bold text-white block mt-0.5">
                    {selectedContent.metrics.cliques}
                  </span>
                </div>
                <div className="bg-slate-950 border border-slate-850 p-2.5 rounded text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-500 text-[10px] font-mono uppercase">
                    <Percent className="h-3 w-3" /> CTR SERP
                  </div>
                  <span className="text-sm font-mono font-bold text-cyan-400 block mt-0.5">
                    {selectedContent.metrics.ctr}%
                  </span>
                </div>
                <div className="bg-slate-950 border border-slate-850 p-2.5 rounded text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-500 text-[10px] font-mono uppercase">
                    <Clock className="h-3 w-3" /> Tm. Médio
                  </div>
                  <span className="text-sm font-mono font-bold text-white block mt-0.5">
                    {selectedContent.metrics.tempo_medio_segundos}s
                  </span>
                </div>
              </div>

              {/* Engagement metrics breakdown progress bars */}
              <div className="space-y-2.5 bg-slate-950 p-3 rounded-lg border border-slate-850">
                <h4 className="text-[10px] uppercase font-mono tracking-wider text-slate-500 border-b border-slate-850 pb-1.5">Funil de Interatividade</h4>
                
                {/* Scroll Depth */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Profundidade de Scroll:</span>
                    <span className="text-slate-300 font-bold">{selectedContent.metrics.scroll_porcentagem}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1">
                    <div className="bg-cyan-500 h-1 rounded-full" style={{ width: `${selectedContent.metrics.scroll_porcentagem}%` }}></div>
                  </div>
                </div>

                {/* Conversion Leads */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Contatos de Leads:</span>
                    <span className="text-slate-300 font-bold">{selectedContent.metrics.leads} leads</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1">
                    <div className="bg-emerald-500 h-1 rounded-full" style={{ width: `${Math.min(100, (selectedContent.metrics.leads / Math.max(1, selectedContent.metrics.visualizacoes)) * 1000)}%` }}></div>
                  </div>
                </div>

                {/* Sharing and Downloads */}
                <div className="flex justify-between text-xs font-mono text-slate-400 pt-1">
                  <span className="flex items-center gap-1"><Share2 className="h-3.5 w-3.5 text-slate-500" /> Shares: {selectedContent.metrics.compartilhamentos}</span>
                  <span className="flex items-center gap-1"><Download className="h-3.5 w-3.5 text-slate-500" /> Baixados: {selectedContent.metrics.downloads}</span>
                </div>
              </div>
            </div>

            {/* Trends Assessment Section */}
            <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-850 space-y-2">
              <h4 className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Tendência Identificada</h4>
              <div className="flex items-center gap-2 mt-1.5">
                {getTrendBadge(selectedContent.trends.status)}
                {selectedContent.trends.percentual_variacao_cliques !== 0 && (
                  <span className={`text-xs font-mono font-bold ${selectedContent.trends.percentual_variacao_cliques > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {selectedContent.trends.percentual_variacao_cliques > 0 ? '+' : ''}{selectedContent.trends.percentual_variacao_cliques}% cliques
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed mt-1">{selectedContent.trends.descricao}</p>
            </div>

            {/* Recommendations List for THIS Content */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Ações Sugeridas ({selectedContent.recommendations.length})</h4>
              {selectedContent.recommendations.length === 0 ? (
                <div className="p-3.5 bg-emerald-950/20 border border-emerald-900/50 rounded-lg text-xs text-emerald-400 flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Conteúdo totalmente otimizado de acordo com o edital de diretrizes.</span>
                </div>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {selectedContent.recommendations.map(rec => (
                    <div 
                      key={rec.id}
                      className="p-3 bg-slate-950 border border-slate-850 rounded-lg text-xs hover:border-cyan-500/30 transition flex flex-col justify-between gap-2"
                    >
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] uppercase font-mono font-bold bg-slate-800 text-cyan-400 px-1 py-0.5 rounded">
                            {rec.tipo.replace("_", " ")}
                          </span>
                          {getRecommendationUrgencyBadge(rec.urgencia)}
                        </div>
                        <h5 className="font-bold text-slate-200">{rec.titulo}</h5>
                        <p className="text-slate-400 leading-relaxed text-[11px]">{rec.descricao}</p>
                      </div>
                      <button
                        onClick={() => handleResolveRecommendation(rec.id, rec.titulo)}
                        className="w-full text-center py-1 bg-emerald-950/50 hover:bg-emerald-900/40 border border-emerald-800/40 text-emerald-400 rounded text-[10px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <CheckCircle2 className="h-3 w-3" /> Resolver
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* History logs (Sprint 25 History Requirement) */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Histórico de Metrificação</h4>
              {(!selectedContent.history || selectedContent.history.length === 0) ? (
                <p className="text-[11px] text-slate-500 italic">Sem registros históricos. As métricas atuais representam a primeira medição.</p>
              ) : (
                <div className="space-y-2 font-mono text-[11px]">
                  {selectedContent.history.map((hist, hIdx) => (
                    <div key={hIdx} className="bg-slate-950 p-2 rounded border border-slate-850 flex justify-between items-center text-slate-400">
                      <span>{new Date(hist.data).toLocaleDateString("pt-BR")}</span>
                      <span>Visitas: <strong>{hist.metrics.visualizacoes}</strong></span>
                      <span>Cliques: <strong className="text-cyan-400">{hist.metrics.cliques}</strong></span>
                    </div>
                  ))}
                  <div className="text-[10px] text-slate-500 text-right pt-1">
                    Última análise: {new Date(selectedContent.ultima_analise).toLocaleString("pt-BR")}
                  </div>
                </div>
              )}
            </div>

            {/* Quick triggers to run edits on this URL */}
            <div className="flex gap-2 border-t border-slate-800 pt-4">
              <button
                onClick={() => handleOpenRegister(selectedContent)}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-bold rounded-lg transition"
              >
                Atualizar Métricas
              </button>
            </div>
          </div>
        )}

      </div>

      {/* MODAL: MANUAL METRICS INPUT */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f172a] border border-slate-800 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-slate-800 bg-slate-900/30 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Sliders className="h-5 w-5 text-cyan-400" />
                  <h3 className="text-base font-bold text-white">Entrada Manual de Métricas de Desempenho</h3>
                </div>
                <button 
                  onClick={() => setShowModal(false)}
                  className="text-slate-400 hover:text-white transition p-1 hover:bg-slate-800 rounded-lg"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSubmitMetrics} className="p-6 space-y-5">
                {formError && (
                  <div className="p-3 bg-rose-950/30 border border-rose-800 rounded-lg text-xs text-rose-300 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* Content ID, Title, URL */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300 block">ID do Conteúdo Publicado</label>
                    <input 
                      type="text"
                      value={formContentId}
                      onChange={(e) => setFormContentId(e.target.value)}
                      placeholder="Ex: pub_direito_admin_101"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50 font-mono"
                    />
                    <p className="text-[10px] text-slate-500 font-mono">Use o mesmo ID de publicação do Sprint 24 para vincular.</p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300 block">Status de Monitoramento</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-cyan-500/50"
                    >
                      <option value="ativo">Ativo (Monitorando)</option>
                      <option value="revisar">Necessita de Revisão (Decay)</option>
                      <option value="em_revisao">Em Revisão Editorial</option>
                      <option value="atualizado">Otimizado / Atualizado</option>
                    </select>
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-xs font-semibold text-slate-300 block">Título do Conteúdo</label>
                    <input 
                      type="text"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      placeholder="Ex: Guia Prático de Redação para Concursos"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50"
                    />
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-xs font-semibold text-slate-300 block">URL de Publicação Destino</label>
                    <input 
                      type="text"
                      value={formUrl}
                      onChange={(e) => setFormUrl(e.target.value)}
                      placeholder="Ex: https://passacumaru.com.br/blog/redacao-concursos"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500/50 font-mono"
                    />
                  </div>
                </div>

                {/* Metric fields grid (3 columns) */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3.5">
                  <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider">Métricas de Tráfego & Engajamento Orgânico</h4>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
                    
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Visualizações</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricViews}
                        onChange={(e) => setMetricViews(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Cliques</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricClicks}
                        onChange={(e) => setMetricClicks(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Impressões</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricImpressions}
                        onChange={(e) => setMetricImpressions(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Tempo Médio (s)</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricAvgTime}
                        onChange={(e) => setMetricAvgTime(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Média Scroll (%)</label>
                      <input 
                        type="number" 
                        min="0"
                        max="100"
                        value={metricScroll}
                        onChange={(e) => setMetricScroll(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Leads Gerados</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricLeads}
                        onChange={(e) => setMetricLeads(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Conversões CTA</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricConversions}
                        onChange={(e) => setMetricConversions(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Downloads</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricDownloads}
                        onChange={(e) => setMetricDownloads(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-slate-400 block uppercase">Shares</label>
                      <input 
                        type="number" 
                        min="0"
                        value={metricShares}
                        onChange={(e) => setMetricShares(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white text-center font-mono focus:outline-none focus:border-cyan-500/40"
                      />
                    </div>

                  </div>
                </div>

                {/* Form Buttons */}
                <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-sm font-medium rounded-lg border border-slate-800 transition"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-bold text-sm rounded-lg shadow-lg shadow-cyan-950/45 transition"
                  >
                    Registrar e Executar Análise
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

// Inline trash icon to prevent missing import compile bugs
function Trash2Icon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 6h18" />
      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
    </svg>
  );
}
