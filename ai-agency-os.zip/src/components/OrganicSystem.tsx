import React, { useState, useEffect } from "react";
import {
  ShieldCheck, Activity, Database, CheckCircle2, AlertTriangle, XCircle,
  FileText, Cpu, Server, Layers, Calendar, RefreshCw, BarChart3, Info
} from "lucide-react";

interface QualityDetails {
  arquitetura: number;
  codigo: number;
  banco: number;
  performance: number;
  seguranca: number;
  documentacao: number;
  cobertura: number;
  integracao: number;
  nota_final: number;
}

interface IntegrationItem {
  modulo: string;
  status: string;
  ultimo_teste: string;
  tempo_ms: number;
  resultado: string;
}

interface SystemStatus {
  healthScore: number;
  qualityScore: number;
  qualityDetails: QualityDetails;
  modulesCount: number;
  enginesCount: number;
  apisCount: number;
  workflowsCount: number;
  lastAudit: string;
  lastBuild: string;
  errorsCount: number;
  warningsCount: number;
  recentErrors: string[];
  recentWarnings: string[];
  integrationReport: IntegrationItem[];
}

export function OrganicSystem() {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchSystemStatus = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch("/api/organic-os/system");
      if (!res.ok) {
        throw new Error("Falha ao carregar metadados de auditoria do sistema.");
      }
      const data = await res.json();
      setStatus(data);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Erro ao conectar com a API de auditoria.");
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchSystemStatus();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <RefreshCw className="h-8 w-8 animate-spin text-cyan-400 mb-3" />
        <p className="text-sm font-mono">Consolidando dados de auditoria e telemetria...</p>
      </div>
    );
  }

  if (error || !status) {
    return (
      <div className="p-6 bg-rose-950/20 border border-rose-800/30 rounded-xl max-w-2xl mx-auto my-10 text-center">
        <XCircle className="h-12 w-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">Falha na Auditoria Estática</h3>
        <p className="text-xs text-rose-300 leading-relaxed">{error || "Não foi possível resgatar o relatório unificado."}</p>
        <button
          onClick={fetchSystemStatus}
          className="mt-4 px-4 py-2 bg-rose-900/40 text-rose-300 border border-rose-800/60 rounded hover:bg-rose-900/60 text-xs font-bold transition"
        >
          Tentar Re-auditar
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 text-slate-100 font-sans min-h-screen p-6 space-y-6">
      
      {/* Upper header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2.5 mb-1.5">
            <div className="p-1.5 bg-emerald-950 text-emerald-400 border border-emerald-800/50 rounded-lg">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center">
              System Audit & Stabilization Console <span className="ml-2.5 text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase">Sprint 15.5</span>
            </h1>
          </div>
          <p className="text-xs text-slate-400">Garantia de conformidade, performance de carregamento, testes integrados e monitoramento do Organic Traffic OS</p>
        </div>

        <button
          onClick={fetchSystemStatus}
          disabled={isRefreshing}
          className="px-4 py-2 bg-slate-950 hover:bg-slate-900 text-slate-300 border border-slate-800 rounded-lg text-xs font-bold flex items-center space-x-2 transition cursor-pointer"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? "animate-spin text-cyan-400" : ""}`} />
          <span>{isRefreshing ? "Auditando..." : "Executar Nova Auditoria"}</span>
        </button>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Health Score Card */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Health Score</span>
            <h2 className="text-3xl font-black text-white mt-1 font-mono tracking-tight">{status.healthScore}%</h2>
            <div className="flex items-center space-x-1.5 mt-2">
              <span className={`w-2 h-2 rounded-full ${status.healthScore >= 90 ? "bg-emerald-400" : "bg-amber-400"}`} />
              <span className="text-[10px] text-slate-400 font-medium">
                {status.healthScore >= 90 ? "Status Estável" : "Requer Atenção"}
              </span>
            </div>
          </div>
          <Activity className="h-10 w-10 text-emerald-400 stroke-1" />
        </div>

        {/* Quality Score Card */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Quality Score (QA)</span>
            <h2 className="text-3xl font-black text-cyan-400 mt-1 font-mono tracking-tight">{status.qualityScore}</h2>
            <div className="flex items-center space-x-1.5 mt-2 text-[10px] text-slate-400">
              <span className="font-bold text-white">Classe A</span>
              <span>• Cobertura estrita</span>
            </div>
          </div>
          <BarChart3 className="h-10 w-10 text-cyan-400 stroke-1" />
        </div>

        {/* Total Components Counters */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Engines / Módulos</span>
            <h2 className="text-3xl font-black text-white mt-1 font-mono tracking-tight">{status.enginesCount} / {status.modulesCount}</h2>
            <div className="flex items-center space-x-1 mt-2 text-[10px] text-slate-400">
              <span>Grafo sequencial de dependências ativo</span>
            </div>
          </div>
          <Cpu className="h-10 w-10 text-slate-500 stroke-1" />
        </div>

        {/* API Coverage */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">APIs Registradas</span>
            <h2 className="text-3xl font-black text-white mt-1 font-mono tracking-tight">{status.apisCount}</h2>
            <div className="flex items-center space-x-1 mt-2 text-[10px] text-slate-400">
              <span>Auditadas em conformidade REST</span>
            </div>
          </div>
          <Server className="h-10 w-10 text-slate-500 stroke-1" />
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Quality Breakdown Cards (4 cols) */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center">
              <Layers className="h-4.5 w-4.5 mr-2 text-cyan-400" /> Detalhamento Técnico de Qualidade
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">Auditoria estatística das áreas estruturais do Organic OS</p>
          </div>

          <div className="space-y-3.5 pt-2">
            {[
              { label: "Arquitetura & Pastas", value: status.qualityDetails.arquitetura, color: "bg-cyan-400" },
              { label: "Qualidade do Código TS", value: status.qualityDetails.codigo, color: "bg-cyan-400" },
              { label: "Modelagem do Banco", value: status.qualityDetails.banco, color: "bg-emerald-400" },
              { label: "Performance de Render", value: status.qualityDetails.performance, color: "bg-emerald-400" },
              { label: "Segurança & Permissões", value: status.qualityDetails.seguranca, color: "bg-amber-400" },
              { label: "Documentação Técnica", value: status.qualityDetails.documentacao, color: "bg-cyan-400" },
              { label: "Integração das Engines", value: status.qualityDetails.integracao, color: "bg-cyan-400" }
            ].map((item, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400 font-medium">{item.label}</span>
                  <span className="font-mono text-white font-bold">{item.value}%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden border border-slate-850">
                  <div className={`h-full rounded-full ${item.color}`} style={{ width: `${item.value}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-900/60 border border-slate-850 rounded-lg text-[10px] text-slate-400 space-y-1 font-mono">
            <div><strong className="text-slate-300">Auditor:</strong> {status.qualityDetails.avaliador || "Sistema de QA Automático"}</div>
            <div><strong className="text-slate-300">Último Build:</strong> {new Date(status.lastBuild).toLocaleString()}</div>
            <div><strong className="text-slate-300">Último Teste Geral:</strong> {new Date(status.lastAudit).toLocaleString()}</div>
          </div>
        </div>

        {/* Integration Statuses List (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl shadow-lg flex flex-col overflow-hidden">
          <div className="p-5 bg-slate-900/40 border-b border-slate-800 flex justify-between items-center">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center">
                <CheckCircle2 className="h-4.5 w-4.5 mr-2 text-emerald-400" /> Relatório de Integração das Engines
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">Resultado da execução sequencial de dados em ambiente simulado</p>
            </div>
            <span className="text-[10px] bg-slate-800 border border-slate-750 px-2.5 py-0.5 rounded font-mono text-slate-400 font-semibold">
              Testes: OK
            </span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-900 max-h-[480px]">
            {status.integrationReport.map((item, idx) => (
              <div key={idx} className="p-4 hover:bg-slate-900/10 transition flex items-start space-x-3 text-xs justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white">{item.modulo}</span>
                    <span className="text-[10px] text-slate-500 font-mono">({item.tempo_ms}ms)</span>
                  </div>
                  <p className="text-slate-400 leading-normal text-[11px]">{item.resultado}</p>
                </div>

                <div className="flex items-center space-x-1 text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/20 border border-emerald-900/30 px-2 py-0.5 rounded-md uppercase">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>{item.status}</span>
                </div>
              </div>
            ))}

            {status.integrationReport.length === 0 && (
              <p className="p-10 text-center text-xs text-slate-600">Nenhuma telemetria disponível.</p>
            )}
          </div>
        </div>

      </div>

      {/* Warnings and anomalies trail */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* System Error Log */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-lg">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center">
            <XCircle className="h-4 w-4 mr-2 text-rose-500" /> Log de Falhas do Sistema ({status.errorsCount})
          </h3>

          <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
            {status.recentErrors.map((err, i) => (
              <div key={i} className="p-2.5 bg-rose-950/15 border border-rose-900/25 rounded-lg text-xs text-rose-300 font-mono">
                {err}
              </div>
            ))}
            {status.recentErrors.length === 0 && (
              <p className="text-xs text-slate-600 italic">Nenhum erro de barramento ou timeout crítico nas últimas orquestrações.</p>
            )}
          </div>
        </div>

        {/* System Warnings Log */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-lg">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" /> Alertas & Notas Operacionais ({status.warningsCount})
          </h3>

          <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
            {status.recentWarnings.map((warn, i) => (
              <div key={i} className="p-2.5 bg-amber-950/15 border border-amber-900/25 rounded-lg text-xs text-amber-300 font-mono">
                {warn}
              </div>
            ))}
            {status.recentWarnings.length === 0 && (
              <p className="text-xs text-slate-600 italic">Nenhuma anomalia de conformidade de SEO ou links inativos registrada.</p>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
