import React, { useState, useEffect } from "react";
import {
  Sparkles, Layers, Users, CheckCircle2, AlertTriangle, ArrowRight,
  ShieldCheck, RefreshCw, Cpu, Server, FileText, Compass, Target, Play,
  ExternalLink, ChevronRight, MessageSquare, Info, PlusCircle, Bookmark, XCircle
} from "lucide-react";

interface StrategyItem {
  id: string;
  objetivo: string;
  publico: string;
  persona: string;
  intencao: string;
  nivel_tecnico: "Iniciante" | "Intermediário" | "Avançado";
  tom: string;
  narrativa: string;
  cta: string;
  status: "Pendente" | "Aprovado" | "Rejeitado";
}

interface PersonaItem {
  id: string;
  nome: string;
  nivel_conhecimento: string;
  objetivos: string[];
  dores: string[];
  desejos: string[];
  objecoes: string[];
}

interface CtaItem {
  id: string;
  tipo: string;
  texto: string;
  momento: string;
  objetivo: string;
}

interface GoalDetail {
  id: string;
  nome: string;
  foco: string;
  tom_recomendado: string;
}

interface JourneyStage {
  nome: string;
  descricao: string;
  foco_conteudo: string;
  abordagem: string;
}

interface StrategyData {
  strategies: StrategyItem[];
  personas: PersonaItem[];
  ctas: CtaItem[];
  goals: Record<string, GoalDetail>;
  journey: {
    fases: Record<string, JourneyStage>;
  };
}

export function OrganicStrategy() {
  const [data, setData] = useState<StrategyData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form states for creating a new Strategy
  const [formBriefId, setFormBriefId] = useState("brief-prod-101");
  const [formKeyword, setFormKeyword] = useState("como evitar canibalizacao de SEO");
  const [formSearchIntent, setFormSearchIntent] = useState("Informativa");
  const [formCategory, setFormCategory] = useState("SEO Técnico");

  // Selection states for tabs inside the strategy console
  const [activeSubTab, setActiveSubTab] = useState<"strategies" | "personas" | "journey" | "ctas">("strategies");

  const fetchStrategyData = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/organic-os/strategy");
      if (!res.ok) {
        throw new Error("Erro ao carregar dados do motor de estratégia.");
      }
      const json = await res.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Erro de conexão.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStrategyData();
  }, []);

  const handleAutoGenerateStrategy = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/organic-os/strategy/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          generateAuto: true,
          briefId: formBriefId,
          keyword: formKeyword,
          searchIntent: formSearchIntent,
          primaryCategory: formCategory
        })
      });

      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.error || "Falha ao gerar recomendação estratégica.");
      }

      // Success
      await fetchStrategyData();
      // Reset form fields lightly
      setFormBriefId(`brief-prod-${Math.floor(Math.random() * 900) + 100}`);
    } catch (err: any) {
      alert(err.message || "Ocorreu um erro ao processar.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-slate-900 min-h-[400px]">
        <RefreshCw className="h-8 w-8 animate-spin text-cyan-400 mb-3" />
        <p className="text-sm font-mono">Carregando Diretrizes e Motor de Estratégia...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6 bg-rose-950/20 border border-rose-800/30 rounded-xl max-w-2xl mx-auto my-10 text-center bg-slate-900">
        <XCircle className="h-12 w-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">Falha de Integração Estratégica</h3>
        <p className="text-xs text-rose-300 leading-relaxed">{error || "Não foi possível carregar os dados."}</p>
        <button
          onClick={fetchStrategyData}
          className="mt-4 px-4 py-2 bg-rose-900/40 text-rose-300 border border-rose-800/60 rounded hover:bg-rose-900/60 text-xs font-bold transition"
        >
          Recarregar
        </button>
      </div>
    );
  }

  const journeyFases = data.journey?.fases || {};

  return (
    <div className="bg-slate-900 text-slate-100 font-sans min-h-screen p-6 space-y-6">
      
      {/* Upper header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2.5 mb-1.5">
            <div className="p-1.5 bg-cyan-950 text-cyan-400 border border-cyan-800/50 rounded-lg">
              <Compass className="h-5 w-5" />
            </div>
            <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center">
              Content Strategy Engine <span className="ml-2.5 text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase">Sprint 17</span>
            </h1>
          </div>
          <p className="text-xs text-slate-400">Modelagem e orquestração pré-redação: defina objetivos, personas, jornadas do leitor, tom de voz e CTAs integrados</p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={fetchStrategyData}
            className="p-2 bg-slate-950 hover:bg-slate-900 text-slate-300 border border-slate-800 rounded-lg text-xs font-bold transition cursor-pointer"
            title="Recarregar dados"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          
          <div className="text-[11px] bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-400 font-mono flex items-center space-x-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span>Motor de Decisão Ativo</span>
          </div>
        </div>
      </div>

      {/* Sub Navigation Tabs */}
      <div className="flex border-b border-slate-800">
        {[
          { id: "strategies", label: "Estratégias Ativas", count: data.strategies.length },
          { id: "personas", label: "Mapa de Personas", count: data.personas.length },
          { id: "journey", label: "Jornada do Leitor", count: Object.keys(journeyFases).length },
          { id: "ctas", label: "Táticas de CTA", count: data.ctas.length }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center space-x-2 ${
              activeSubTab === tab.id 
                ? "border-cyan-400 text-cyan-400 bg-cyan-950/10" 
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <span>{tab.label}</span>
            <span className="text-[9px] font-bold px-1.5 py-0.2 bg-slate-800 text-slate-400 rounded-full">{tab.count}</span>
          </button>
        ))}
      </div>

      {/* Dashboard Main Grid Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Active Panel Views (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* View: Strategies */}
          {activeSubTab === "strategies" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Estratégias Editoriais Homologadas ({data.strategies.length})
                </h3>
              </div>

              <div className="space-y-4">
                {data.strategies.map((strat) => {
                  const personaObj = data.personas.find(p => p.id === strat.persona);
                  const goalObj = data.goals[strat.objetivo];
                  const ctaObj = data.ctas.find(c => c.id === strat.cta);

                  return (
                    <div key={strat.id} className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-md hover:border-slate-750 transition-all space-y-4">
                      
                      {/* Header block of strategy */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-900 pb-3 gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-white tracking-tight">{strat.id.toUpperCase()}</span>
                            <span className="text-[9px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-900/50 px-2 py-0.5 rounded-md uppercase font-bold">
                              {strat.intencao}
                            </span>
                            <span className="text-[9px] font-mono bg-slate-900 text-slate-400 border border-slate-800 px-2 py-0.5 rounded-md">
                              Nível {strat.nivel_tecnico}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/20 border border-emerald-900/30 px-2 py-0.5 rounded-md uppercase">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span>{strat.status}</span>
                        </div>
                      </div>

                      {/* Descriptive narrative block */}
                      <div className="space-y-1.5">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 font-mono">Narrativa & Abordagem Principal</span>
                        <p className="text-xs text-slate-300 leading-relaxed font-serif italic">
                          "{strat.narrativa}"
                        </p>
                      </div>

                      {/* Detail attributes grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-900 text-xs">
                        
                        {/* Target Persona */}
                        <div className="space-y-1">
                          <div className="flex items-center space-x-1.5 text-slate-500">
                            <Users className="h-3.5 w-3.5" />
                            <span className="font-semibold text-[10px] uppercase font-mono">Persona Alvo</span>
                          </div>
                          <span className="text-white font-bold text-xs">{personaObj ? personaObj.nome : strat.persona}</span>
                          <p className="text-[10px] text-slate-400 mt-0.5">{strat.publico}</p>
                        </div>

                        {/* Strategic Goal */}
                        <div className="space-y-1">
                          <div className="flex items-center space-x-1.5 text-slate-500">
                            <Target className="h-3.5 w-3.5" />
                            <span className="font-semibold text-[10px] uppercase font-mono">Objetivo Editorial</span>
                          </div>
                          <span className="text-white font-bold text-xs">{goalObj ? goalObj.nome : strat.objetivo}</span>
                          <p className="text-[10px] text-slate-400 mt-0.5">{goalObj?.foco}</p>
                        </div>

                        {/* Selected CTA */}
                        <div className="space-y-1">
                          <div className="flex items-center space-x-1.5 text-slate-500">
                            <Play className="h-3.5 w-3.5" />
                            <span className="font-semibold text-[10px] uppercase font-mono">CTA de Conversão</span>
                          </div>
                          <span className="text-cyan-400 font-bold text-xs">{ctaObj ? ctaObj.texto : strat.cta}</span>
                          <p className="text-[10px] text-slate-400 mt-0.5">{ctaObj?.objetivo}</p>
                        </div>

                      </div>

                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* View: Personas */}
          {activeSubTab === "personas" && (
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Mapeamento Estrito de Persona & Perfil do Comprador ({data.personas.length})
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {data.personas.map((persona) => (
                  <div key={persona.id} className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-md space-y-4">
                    <div className="border-b border-slate-900 pb-3 flex justify-between items-start">
                      <div>
                        <h4 className="text-sm font-bold text-white">{persona.nome}</h4>
                        <span className="text-[10px] text-slate-500 font-mono">Nível Cognitivo: {persona.nivel_conhecimento}</span>
                      </div>
                      <span className="text-[9px] bg-cyan-950 text-cyan-400 border border-cyan-900/50 px-2 py-0.5 rounded font-mono font-bold uppercase">
                        {persona.id.replace("persona-", "")}
                      </span>
                    </div>

                    <div className="space-y-3.5 text-xs">
                      
                      {/* Objetivos */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">Objetivos Principais</span>
                        <ul className="space-y-1 text-slate-300">
                          {persona.objetivos.map((obj, i) => (
                            <li key={i} className="flex items-start space-x-1.5">
                              <span className="text-cyan-500">•</span>
                              <span>{obj}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Dores */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">Dores & Impedimentos</span>
                        <ul className="space-y-1 text-slate-300">
                          {persona.dores.map((dor, i) => (
                            <li key={i} className="flex items-start space-x-1.5 text-rose-300">
                              <span className="text-rose-500">•</span>
                              <span>{dor}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Objeções */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">Objeções Comuns</span>
                        <ul className="space-y-1 text-slate-300">
                          {persona.objecoes.map((objecao, i) => (
                            <li key={i} className="flex items-start space-x-1.5 text-amber-300">
                              <span className="text-amber-500">•</span>
                              <span>{objecao}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* View: User Journey */}
          {activeSubTab === "journey" && (
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Etapas de Consciência da Jornada do Comprador
              </h3>

              <div className="space-y-4">
                {(Object.entries(journeyFases) as [string, JourneyStage][]).map(([key, fase], idx) => (
                  <div key={key} className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-md flex flex-col md:flex-row gap-4 items-start md:items-center">
                    
                    {/* Index count */}
                    <div className="w-10 h-10 bg-cyan-950/40 border border-cyan-950 text-cyan-400 font-bold font-mono text-sm rounded-full flex items-center justify-center shrink-0">
                      0{idx + 1}
                    </div>

                    <div className="flex-1 space-y-2">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-xs font-bold text-white uppercase tracking-wide">{fase.nome}</h4>
                        <span className="text-[9px] bg-slate-900 border border-slate-800 px-2 py-0.5 rounded font-mono text-slate-400">
                          {key}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">{fase.descricao}</p>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] pt-1 font-mono">
                        <div>
                          <span className="text-slate-500 font-bold uppercase block">Foco de Conteúdo</span>
                          <span className="text-slate-300">{fase.foco_conteudo}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 font-bold uppercase block">Abordagem de Linguagem</span>
                          <span className="text-slate-300">{fase.abordagem}</span>
                        </div>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* View: CTAs */}
          {activeSubTab === "ctas" && (
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Táticas de Chamada para Ação (CTA) Homologadas ({data.ctas.length})
              </h3>

              <div className="space-y-4">
                {data.ctas.map((cta) => (
                  <div key={cta.id} className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-md flex items-center justify-between gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-black text-cyan-400">{cta.texto}</span>
                        <span className={`text-[8px] uppercase font-bold px-1.5 py-0.5 rounded ${
                          cta.tipo === "Principal" ? "bg-cyan-900/30 text-cyan-400 border border-cyan-800/20" : "bg-slate-800 text-slate-400 border border-slate-750"
                        }`}>
                          {cta.tipo}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-400">
                        <div>
                          <strong className="text-slate-500 block uppercase font-mono text-[9px] tracking-wider">Momento de Inserção</strong>
                          <span>{cta.momento}</span>
                        </div>
                        <div>
                          <strong className="text-slate-500 block uppercase font-mono text-[9px] tracking-wider">Objetivo de Marketing</strong>
                          <span>{cta.objetivo}</span>
                        </div>
                      </div>
                    </div>

                    <span className="text-[10px] bg-slate-900 border border-slate-850 px-2 py-1 rounded font-mono text-slate-500 select-none">
                      {cta.id}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Right Side: Simulator Generator Form (4 cols) */}
        <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-lg space-y-5">
          <div className="border-b border-slate-900 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-cyan-400" /> Auto-Gerador de Estratégia
            </h3>
            <p className="text-[10px] text-slate-500 mt-1 leading-normal">
              Simule o motor de estratégia do Organic OS gerando e validando diretrizes táticas pré-redação.
            </p>
          </div>

          <form onSubmit={handleAutoGenerateStrategy} className="space-y-4 text-xs">
            
            <div className="space-y-1">
              <label className="text-slate-400 font-bold uppercase font-mono text-[10px]">ID do Briefing correspondente</label>
              <input
                type="text"
                value={formBriefId}
                onChange={(e) => setFormBriefId(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 font-bold uppercase font-mono text-[10px]">Palavra-Chave Foco</label>
              <input
                type="text"
                value={formKeyword}
                onChange={(e) => setFormKeyword(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 font-bold uppercase font-mono text-[10px]">Intenção de Busca da SERP</label>
              <select
                value={formSearchIntent}
                onChange={(e) => setFormSearchIntent(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white cursor-pointer"
              >
                <option value="Informativa">Informativa (Educação, Guias)</option>
                <option value="Comparativa / Comercial">Comparativa / Comercial (Decisão)</option>
                <option value="Transacional">Transacional (Compra)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 font-bold uppercase font-mono text-[10px]">Categoria do Conteúdo</label>
              <input
                type="text"
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg transition-all flex items-center justify-center space-x-2 shadow cursor-pointer text-xs uppercase tracking-wide"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  <span>Configurando Estratégia...</span>
                </>
              ) : (
                <>
                  <PlusCircle className="h-4 w-4" />
                  <span>Gerar & Registrar Estratégia</span>
                </>
              )}
            </button>

          </form>

          {/* Goals Definitions info */}
          <div className="pt-4 border-t border-slate-900 space-y-2">
            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">Categorias de Objetivos Estratégicos</span>
            <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
              {(Object.entries(data.goals) as [string, GoalDetail][]).map(([key, goal]) => (
                <div key={key} className="p-2 bg-slate-900/60 border border-slate-850 rounded text-[11px] space-y-0.5">
                  <div className="flex justify-between items-center">
                    <strong className="text-white font-bold">{goal.nome}</strong>
                    <span className="text-[8px] font-mono text-slate-500">{key}</span>
                  </div>
                  <p className="text-slate-400 leading-normal text-[10px]">{goal.foco}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
