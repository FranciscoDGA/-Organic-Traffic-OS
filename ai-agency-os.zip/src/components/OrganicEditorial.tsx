import React, { useState, useEffect } from "react";
import {
  Users, CheckCircle2, AlertTriangle, ArrowRight, Clock, ShieldAlert,
  Play, FileText, ChevronRight, Layers, Activity, Info, XCircle, Sparkles
} from "lucide-react";

interface Agent {
  id: string;
  nome: string;
  funcao: string;
  descricao: string;
  capacidades: string[];
  regras: string[];
}

interface Contract {
  inputs: string[];
  outputs: string[];
  dependencies: string[];
  possible_errors: string[];
  expected_time_seconds: number;
}

interface WorkflowStep {
  pos: number;
  id: string;
  nome: string;
  tipo: string;
  agente_id?: string;
  descricao: string;
  saida: string;
}

interface Validation {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  executionPlan: string[];
}

interface TeamData {
  agents: Agent[];
  contracts: Record<string, Contract>;
}

interface WorkflowData {
  workflow: {
    nome: string;
    versao: string;
    descricao: string;
    fluxo_etapas: WorkflowStep[];
  };
  validation: Validation;
}

export function OrganicEditorial() {
  const [team, setTeam] = useState<TeamData | null>(null);
  const [workflow, setWorkflow] = useState<WorkflowData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeAgentId, setActiveAgentId] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [teamRes, workflowRes] = await Promise.all([
        fetch("/api/organic-os/editorial-team"),
        fetch("/api/organic-os/editorial-workflow")
      ]);

      if (!teamRes.ok || !workflowRes.ok) {
        throw new Error("Erro ao carregar dados da equipe editorial ou fluxo.");
      }

      const teamData = await teamRes.json();
      const workflowData = await workflowRes.json();

      setTeam(teamData);
      setWorkflow(workflowData);
      if (teamData.agents.length > 0) {
        setActiveAgentId(teamData.agents[0].id);
      }
      setError(null);
    } catch (err: any) {
      setError(err.message || "Erro ao conectar com a API de editorial.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-slate-900 min-h-[400px]">
        <Activity className="h-8 w-8 animate-spin text-cyan-400 mb-3" />
        <p className="text-sm font-mono">Carregando Redação Inteligente e Contratos de Fluxo...</p>
      </div>
    );
  }

  if (error || !team || !workflow) {
    return (
      <div className="p-6 bg-rose-950/20 border border-rose-800/30 rounded-xl max-w-2xl mx-auto my-10 text-center bg-slate-900">
        <XCircle className="h-12 w-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">Falha de Integração Editorial</h3>
        <p className="text-xs text-rose-300 leading-relaxed">{error || "Não foi possível carregar o ecossistema editorial."}</p>
        <button
          onClick={fetchData}
          className="mt-4 px-4 py-2 bg-rose-900/40 text-rose-300 border border-rose-800/60 rounded hover:bg-rose-900/60 text-xs font-bold transition"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  const selectedAgent = team.agents.find(a => a.id === activeAgentId);
  const selectedContract = selectedAgent ? team.contracts[selectedAgent.id] : null;

  return (
    <div className="bg-slate-900 text-slate-100 font-sans min-h-screen p-6 space-y-8">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2.5 mb-1.5">
            <div className="p-1.5 bg-cyan-950 text-cyan-400 border border-cyan-800/50 rounded-lg">
              <Users className="h-5 w-5" />
            </div>
            <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center">
              Intelligent Editorial Room <span className="ml-2.5 text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase">Sprint 16</span>
            </h1>
          </div>
          <p className="text-xs text-slate-400">Coordenação colaborativa de redação inteligente composta por 7 agentes autônomos semânticos e contratos estritos</p>
        </div>

        <div className="flex items-center space-x-2 text-[11px] bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-400 font-mono">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>Equipe Pronta para Produção</span>
        </div>
      </div>

      {/* Validation Banner */}
      <div className={`p-4 rounded-xl border ${workflow.validation.isValid ? "bg-emerald-950/20 border-emerald-800/30 text-emerald-300" : "bg-rose-950/20 border-rose-800/30 text-rose-300"} flex items-start space-x-3 shadow-md`}>
        {workflow.validation.isValid ? (
          <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
        ) : (
          <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
        )}
        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-extrabold uppercase tracking-wide">
              {workflow.validation.isValid ? "Integridade do Fluxo Editorial Homologada" : "Inconsistências no Fluxo Editorial"}
            </h4>
            <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md font-mono text-emerald-400">
              Ordem Topológica: OK
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            O validador dinâmico analisou todas as dependências lógicas, inputs e outputs da redação. Cada agente consegue receber insumos das fases anteriores perfeitamente.
          </p>
          {workflow.validation.errors.length > 0 && (
            <div className="mt-3 space-y-1">
              {workflow.validation.errors.map((err, i) => (
                <div key={i} className="text-[10px] font-mono text-rose-300 bg-rose-950/40 p-1.5 rounded border border-rose-900/30">
                  • {err}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: 7 Editorial Agents (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800/80 rounded-xl p-5 shadow-lg space-y-5">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
              Membros da Redação Inteligente ({team.agents.length})
            </h3>
            <p className="text-[11px] text-slate-500">Selecione um agente para ver as regras de negócio e o contrato operacional</p>
          </div>

          <div className="space-y-2.5">
            {team.agents.map((agent) => {
              const contract = team.contracts[agent.id];
              const isSelected = agent.id === activeAgentId;
              
              return (
                <div
                  key={agent.id}
                  onClick={() => setActiveAgentId(agent.id)}
                  className={`p-3.5 rounded-lg border transition-all cursor-pointer text-left ${
                    isSelected 
                      ? "bg-slate-900 border-cyan-500/60 shadow-md shadow-cyan-950/20" 
                      : "bg-slate-950 border-slate-900 hover:bg-slate-900/40 hover:border-slate-800"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className={`text-xs font-bold ${isSelected ? "text-cyan-400" : "text-white"}`}>
                        {agent.nome}
                      </h4>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-medium">{agent.funcao}</p>
                    </div>

                    <div className="flex items-center space-x-1.5 text-[9px] font-mono text-slate-500">
                      <Clock className="h-3 w-3 text-slate-600" />
                      <span>{contract?.expected_time_seconds}s</span>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 mt-2 line-clamp-1 leading-normal">
                    {agent.descricao}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: Contract Details (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {selectedAgent && selectedContract && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-lg space-y-5">
              
              {/* Agent Title block */}
              <div className="flex justify-between items-start border-b border-slate-850 pb-4">
                <div className="space-y-1">
                  <span className="text-[9px] bg-cyan-950 text-cyan-400 border border-cyan-900/50 px-2 py-0.5 rounded font-mono font-bold uppercase">
                    Contrato Operacional Ativo
                  </span>
                  <h3 className="text-base font-bold text-white tracking-tight">{selectedAgent.nome}</h3>
                  <p className="text-xs text-slate-400">{selectedAgent.descricao}</p>
                </div>
              </div>

              {/* Input / Output requirements */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="bg-slate-900/60 border border-slate-850 rounded-lg p-3.5 space-y-2">
                  <span className="text-[9px] uppercase font-bold tracking-wider text-emerald-400 font-mono flex items-center">
                    <CheckCircle2 className="h-3 w-3 mr-1 text-emerald-500" /> Entradas Obrigatórias
                  </span>
                  <div className="space-y-1">
                    {selectedContract.inputs.map((inp, idx) => (
                      <div key={idx} className="text-[10px] font-mono text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-900">
                        {inp}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-900/60 border border-slate-850 rounded-lg p-3.5 space-y-2">
                  <span className="text-[9px] uppercase font-bold tracking-wider text-cyan-400 font-mono flex items-center">
                    <Layers className="h-3 w-3 mr-1 text-cyan-500" /> Saídas Homologadas
                  </span>
                  <div className="space-y-1">
                    {selectedContract.outputs.map((out, idx) => (
                      <div key={idx} className="text-[10px] font-mono text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-900">
                        {out}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Agent capacities */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-bold text-slate-400 flex items-center">
                  <Sparkles className="h-3.5 w-3.5 mr-1.5 text-cyan-400" /> Capacidades do Agente de IA
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
                  {selectedAgent.capacidades.map((cap, i) => (
                    <div key={i} className="flex items-start space-x-1.5">
                      <span className="text-cyan-500 shrink-0 mt-0.5">•</span>
                      <span>{cap}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safety Regulations / Regras de Negócio */}
              <div className="space-y-2.5 border-t border-slate-850 pt-4">
                <h4 className="text-xs font-bold text-slate-400 flex items-center">
                  <ShieldAlert className="h-3.5 w-3.5 mr-1.5 text-amber-500" /> Regras de Negócio & Conformidade
                </h4>
                <div className="space-y-1.5 text-[11px] text-slate-300">
                  {selectedAgent.regras.map((reg, i) => (
                    <div key={i} className="p-2.5 bg-amber-950/10 border border-amber-900/20 rounded-lg flex items-start space-x-2 text-amber-200">
                      <span className="text-amber-500 shrink-0">⚠️</span>
                      <span className="leading-relaxed">{reg}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Possible Errors & Dependecies footer */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[10px] font-mono bg-slate-900 p-3 rounded-lg border border-slate-850">
                <div>
                  <span className="text-slate-500 font-bold">DEPENDÊNCIAS DIRETAS</span>
                  <div className="text-slate-300 mt-1">
                    {selectedContract.dependencies.length > 0 
                      ? selectedContract.dependencies.map(d => team.agents.find(a => a.id === d)?.nome || d).join(", ")
                      : "Sem dependência direta (Entrada do fluxo anterior)"
                    }
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 font-bold">FALHAS TRATADAS</span>
                  <div className="text-rose-400 mt-1">
                    {selectedContract.possible_errors.join(", ")}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>

      {/* Sequential Line-assembly flow of 12 steps */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-lg space-y-6">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center">
            <Layers className="h-4.5 w-4.5 mr-2 text-cyan-400" /> Esteira Editorial e de Engenharia Unificada
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">Mapeamento linear das 12 fases do pipeline do Organic OS</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {workflow.workflow.fluxo_etapas.map((step) => {
            const isAgent = step.tipo === "Editorial Agent";
            
            return (
              <div 
                key={step.id} 
                className={`p-3.5 rounded-xl border relative flex flex-col justify-between h-32 text-left ${
                  isAgent 
                    ? "bg-cyan-950/10 border-cyan-900/40 hover:border-cyan-800/60" 
                    : "bg-slate-900/40 border-slate-800 hover:border-slate-700/60"
                }`}
              >
                {/* Pos badge */}
                <span className="absolute top-2.5 right-2.5 text-[10px] font-black font-mono text-slate-600 bg-slate-950 border border-slate-800 w-5 h-5 rounded-full flex items-center justify-center">
                  {step.pos}
                </span>

                <div className="space-y-1">
                  <span className={`text-[8px] uppercase font-bold px-1.5 py-0.5 rounded ${
                    isAgent ? "bg-cyan-900/30 text-cyan-400 border border-cyan-800/20" : "bg-slate-800 text-slate-400 border border-slate-750"
                  }`}>
                    {step.tipo === "Editorial Agent" ? "AI Agent" : "Engine"}
                  </span>
                  
                  <h4 className="text-xs font-bold text-white line-clamp-1 pt-1">{step.nome}</h4>
                </div>

                <div className="space-y-1.5">
                  <p className="text-[9px] text-slate-400 leading-normal line-clamp-2">
                    {step.descricao}
                  </p>
                  
                  <div className="flex items-center space-x-1 border-t border-slate-850 pt-1 text-[8px] font-mono text-slate-500">
                    <span className="text-slate-600">Gera:</span>
                    <span className="text-slate-300 truncate max-w-[80px]">{step.saida}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
