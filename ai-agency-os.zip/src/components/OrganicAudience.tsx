import React, { useState, useEffect } from "react";
import { 
  Users, Target, Sparkles, BookOpen, AlertTriangle, CheckCircle2, 
  HelpCircle, Sliders, ArrowRight, RefreshCw, GitMerge, ChevronRight,
  Gauge, Award, FileText, Compass, TrendingUp, HelpCircle as HelpIcon, ChevronDown
} from "lucide-react";

interface Persona {
  id: string;
  nome: string;
  nivel_tecnico: string;
  tom_ideal: string;
  descricao: string;
  regras_foco: string[];
  exemplo_cenario: string;
}

interface DraftRecord {
  id: string;
  brief_id: string;
  blueprint_id: string;
  titulo: string;
  autor: string;
  data_criacao: string;
  versao: string;
}

interface RuleValidation {
  ruleId: string;
  nome: string;
  pass: boolean;
  feedback: string;
}

interface AdaptationReport {
  id: string;
  draft_id: string;
  persona: string;
  nivel_tecnico: string;
  tom_atual: string;
  tom_recomendado: string;
  clareza: number;
  didatica: number;
  score: number;
  status: "Adequado" | "Requer Adaptação" | "Pendente";
  observacoes: string;
  recomendacoes: string[];
  scores_detalhados: {
    adequacao_ao_publico: number;
    clareza: number;
    didatica: number;
    tom_de_voz: number;
    consistencia: number;
    engajamento_potencial: number;
  };
  regras_validadas: RuleValidation[];
  data: string;
}

interface ComparisonResult {
  report1: { id: string; score: number; status: string; data: string };
  report2: { id: string; score: number; status: string; data: string };
  differences: {
    score_geral: number;
    clareza: number;
    didatica: number;
    metrics: Record<string, number>;
  };
}

export function OrganicAudience() {
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [drafts, setDrafts] = useState<DraftRecord[]>([]);
  const [reports, setReports] = useState<AdaptationReport[]>([]);
  
  // Selection states
  const [selectedDraftId, setSelectedDraftId] = useState<string>("");
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>("concurseiro-iniciante");
  const [selectedReportId, setSelectedReportId] = useState<string>("");

  // Loading & Action states
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStep, setAnalysisStep] = useState<string>("");
  const [activeReport, setActiveReport] = useState<AdaptationReport | null>(null);

  // Comparison states
  const [compReport1Id, setCompReport1Id] = useState<string>("");
  const [compReport2Id, setCompReport2Id] = useState<string>("");
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [isComparing, setIsComparing] = useState<boolean>(false);

  // Tab inside component (Overview / Comparative)
  const [subTab, setSubTab] = useState<"analysis" | "compare">("analysis");

  // Error/Success banner
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Load baseline data on mount
  useEffect(() => {
    loadBaselineData();
  }, []);

  const loadBaselineData = async () => {
    try {
      // 1. Load Personas
      const personasRes = await fetch("/organic-traffic-os/audience-adaptation/personas/personas.json");
      if (personasRes.ok) {
        const data = await personasRes.json();
        setPersonas(data.personas || []);
      }

      // 2. Load Drafts
      const draftsRes = await fetch("/api/organic-os/drafts");
      if (draftsRes.ok) {
        const data = await draftsRes.json();
        setDrafts(data || []);
        if (data.length > 0) {
          setSelectedDraftId(data[0].id);
        }
      }

      // 3. Load Reports
      await fetchReports();
    } catch (e) {
      console.error("Erro ao carregar dados iniciais:", e);
    }
  };

  const fetchReports = async () => {
    try {
      const reportsRes = await fetch("/api/organic-os/audience/reports");
      if (reportsRes.ok) {
        const data = await reportsRes.json();
        setReports(data || []);
        if (data.length > 0) {
          setSelectedReportId(data[0].id);
          setActiveReport(data[0]);
        }
      }
    } catch (err) {
      console.error("Erro ao obter relatórios de adaptação:", err);
    }
  };

  // Trigger audience analysis
  const handleAnalyze = async () => {
    if (!selectedDraftId || !selectedPersonaId) {
      showFeedback("error", "Por favor, selecione um rascunho de artigo e uma persona.");
      return;
    }

    setIsAnalyzing(true);
    setAnalysisStep("Carregando Rascunho de Artigo...");
    
    // Simulate nice step transition for the engine execution
    await new Promise(r => setTimeout(r, 700));
    setAnalysisStep("Extraindo contexto do Knowledge Core...");
    await new Promise(r => setTimeout(r, 600));
    setAnalysisStep("Integrando diagnóstico do Quality Review (Sprint 19)...");
    await new Promise(r => setTimeout(r, 700));
    setAnalysisStep("Medindo jargões e nível de tecnicidade...");
    await new Promise(r => setTimeout(r, 600));
    setAnalysisStep("Executando Auditor de tom de voz via Gemini AI...");

    try {
      const res = await fetch("/api/organic-os/audience/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          draftId: selectedDraftId,
          personaId: selectedPersonaId
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.report) {
          showFeedback("success", "Análise de público-alvo gerada com absoluto sucesso!");
          await fetchReports();
          setActiveReport(data.report);
          setSelectedReportId(data.report.id);
        } else {
          showFeedback("error", "Houve um problema ao salvar o laudo.");
        }
      } else {
        const errData = await res.json();
        showFeedback("error", errData.error || "Erro ao conectar com o motor de análise.");
      }
    } catch (err) {
      showFeedback("error", "Erro ao disparar análise de Audience Adaptation.");
    } finally {
      setIsAnalyzing(false);
      setAnalysisStep("");
    }
  };

  // Handle version comparison
  const handleCompare = async () => {
    if (!compReport1Id || !compReport2Id) {
      showFeedback("error", "Por favor, selecione dois laudos para comparar.");
      return;
    }
    if (compReport1Id === compReport2Id) {
      showFeedback("error", "Selecione laudos de versões diferentes para comparar.");
      return;
    }

    setIsComparing(true);
    try {
      const res = await fetch("/api/organic-os/audience/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          report1Id: compReport1Id,
          report2Id: compReport2Id
        })
      });

      if (res.ok) {
        const data = await res.json();
        setComparison(data);
        showFeedback("success", "Comparativo de adequação calculado.");
      } else {
        const errData = await res.json();
        showFeedback("error", errData.error || "Erro ao comparar relatórios.");
      }
    } catch (err) {
      showFeedback("error", "Falha na requisição de comparação.");
    } finally {
      setIsComparing(false);
    }
  };

  const showFeedback = (type: "success" | "error", text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  const selectReport = (id: string) => {
    setSelectedReportId(id);
    const found = reports.find(r => r.id === id);
    if (found) {
      setActiveReport(found);
    }
  };

  return (
    <div className="space-y-6" id="audience-adaptation-engine-root">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-emerald-950/20 via-slate-900 to-cyan-950/20 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase font-mono px-2..5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
              Sprint 20 Core Engine
            </span>
            <span className="text-[10px] uppercase font-mono px-2.5 bg-cyan-500/10 text-cyan-400 rounded-full border border-cyan-500/20">
              Auditor Editorial
            </span>
          </div>
          <h2 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Users className="h-6 w-6 text-emerald-400" />
            Audience Adaptation Engine V1
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Motor responsável por analisar e guiar a adequação de linguajar, didática, profundidade e tom de voz dos rascunhos de artigos às personas cadastradas antes da fase final de humanização de conteúdo do <strong>PassaCumaru</strong>.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-center">
          <button 
            onClick={() => setSubTab("analysis")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all ${
              subTab === "analysis" 
                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-md" 
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300"
            }`}
          >
            Auditoria & Plano de Ação
          </button>
          <button 
            onClick={() => {
              setSubTab("compare");
              if (reports.length >= 2 && !compReport1Id && !compReport2Id) {
                setCompReport1Id(reports[reports.length - 1].id);
                setCompReport2Id(reports[0].id);
              }
            }}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all ${
              subTab === "compare" 
                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-md" 
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300"
            }`}
          >
            Comparativo de Versões
          </button>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-4 rounded-xl border animate-fade-in flex items-center gap-3 ${
          feedbackMsg.type === "success" 
            ? "bg-green-950/20 border-green-500/30 text-green-400" 
            : "bg-red-950/20 border-red-500/30 text-red-400"
        }`}>
          {feedbackMsg.type === "success" ? <CheckCircle2 className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
          <span className="text-sm font-medium">{feedbackMsg.text}</span>
        </div>
      )}

      {subTab === "analysis" ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Col 1: Inputs & Persona Directory */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Analyzer Console Card */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <h3 className="text-md font-display font-bold text-white mb-4 flex items-center gap-2 border-b border-slate-800/80 pb-3">
                <Sliders className="h-5 w-5 text-emerald-400" />
                Painel de Controle
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                    1. Selecionar Rascunho
                  </label>
                  <select 
                    value={selectedDraftId}
                    onChange={(e) => setSelectedDraftId(e.target.value)}
                    className="w-full bg-[#0b0f19] border border-slate-800 rounded-lg py-2.5 px-3 text-sm text-slate-300 focus:outline-none focus:border-emerald-500 font-medium transition-colors"
                  >
                    <option value="">-- Selecione um Rascunho --</option>
                    {drafts.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.titulo} (v{d.versao})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                    2. Persona Alvo
                  </label>
                  <div className="space-y-2">
                    {personas.map((p) => (
                      <label 
                        key={p.id}
                        onClick={() => setSelectedPersonaId(p.id)}
                        className={`flex flex-col p-3 rounded-lg border cursor-pointer transition-all ${
                          selectedPersonaId === p.id 
                            ? "bg-emerald-950/20 border-emerald-500/40 text-white" 
                            : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-850"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-sm text-white">{p.nome}</span>
                          <input 
                            type="radio" 
                            name="persona" 
                            checked={selectedPersonaId === p.id}
                            onChange={() => {}}
                            className="text-emerald-500 focus:ring-emerald-500 h-4 w-4"
                          />
                        </div>
                        <span className="text-[11px] text-slate-400 mt-1 line-clamp-1">{p.descricao}</span>
                        <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-500 font-mono">
                          <span>Nível: <strong className="text-slate-300">{p.nivel_tecnico}</strong></span>
                          <span>•</span>
                          <span>Tom: <strong className="text-slate-300">{p.tom_ideal}</strong></span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <button 
                  onClick={handleAnalyze}
                  disabled={isAnalyzing}
                  className="w-full mt-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-850 disabled:text-slate-500 text-slate-950 font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2.5 transition-all text-sm shadow-lg shadow-emerald-950/20"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin text-slate-500" />
                      <span>Processando Auditor...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      <span>Analisar Adequação ao Público</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Selected Persona Rules Guide */}
            {selectedPersonaId && personas.length > 0 && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                {(() => {
                  const p = personas.find(per => per.id === selectedPersonaId);
                  if (!p) return null;
                  return (
                    <>
                      <h3 className="text-md font-display font-bold text-white mb-2 flex items-center gap-2">
                        <Target className="h-5 w-5 text-emerald-400" />
                        Diretrizes de Audiência
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed mb-4">
                        Regras estritas aplicadas na triagem automática de texto para a persona <strong>{p.nome}</strong>:
                      </p>

                      <div className="space-y-3">
                        <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                          <span className="text-[10px] uppercase font-mono text-emerald-400 block font-semibold mb-1">
                            Linguagem & Vocabulário
                          </span>
                          <p className="text-xs text-slate-300">
                            {p.nivel_tecnico === "Baixo a Médio" || p.nivel_tecnico === "Baixo"
                              ? "Proibido latinismos e jargões. Explicar conceitos complexos com analogias didáticas."
                              : "Direto ao ponto, com embasamento técnico e jurisprudências específicas."}
                          </p>
                        </div>

                        <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                          <span className="text-[10px] uppercase font-mono text-emerald-400 block font-semibold mb-1">
                            Tom de Voz Requerido
                          </span>
                          <p className="text-xs text-slate-300">
                            Falar no tom <strong>{p.tom_ideal}</strong>. {p.id === "concurseiro-iniciante" ? "Evitar intimidação." : "Focado em resultado objetivo."}
                          </p>
                        </div>

                        <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                          <span className="text-[10px] uppercase font-mono text-emerald-400 block font-semibold mb-1">
                            Exemplo de Aplicação
                          </span>
                          <p className="text-xs text-slate-400 font-mono italic">
                            "{p.exemplo_cenario}"
                          </p>
                        </div>
                      </div>
                    </>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Col 2 & 3: Report & Dynamic Insights Dashboard */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Loading Progression Overlay */}
            {isAnalyzing && (
              <div className="bg-[#0f172a] border border-emerald-500/30 rounded-2xl p-12 shadow-2xl flex flex-col items-center justify-center text-center gap-6 min-h-[400px]">
                <div className="relative flex items-center justify-center">
                  <div className="absolute h-16 w-16 rounded-full border-4 border-emerald-500/10 border-t-emerald-400 animate-spin"></div>
                  <Users className="h-7 w-7 text-emerald-400 animate-pulse" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-white">Analisando Rascunho de Artigo</h3>
                  <p className="text-sm font-mono text-emerald-400 animate-pulse">{analysisStep}</p>
                </div>
                <p className="text-xs text-slate-400 max-w-sm mt-4 leading-relaxed">
                  O Gemini AI está mapeando parágrafos, medindo jargões locais de Cumaru e avaliando o plano didático do texto de acordo com as regras de redação.
                </p>
              </div>
            )}

            {/* Laudos de Auditoria Database Selector */}
            {!isAnalyzing && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-emerald-400" />
                  <span className="text-sm font-bold text-white">Laudo Editorial Ativo:</span>
                </div>
                <select
                  value={selectedReportId}
                  onChange={(e) => selectReport(e.target.value)}
                  className="bg-[#0b0f19] border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:border-emerald-500 font-medium transition-colors max-w-xs"
                >
                  {reports.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.id} - {r.persona === "concurseiro-iniciante" ? "Iniciante" : r.persona === "concurseiro-avancado" ? "Avançado" : "Cidadão"} ({new Date(r.data).toLocaleDateString()})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Main Insights Panel */}
            {!isAnalyzing && activeReport && (
              <div className="space-y-6">
                
                {/* Bento Grid: General Quality Gauge & Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Gauge Score Card */}
                  <div className="md:col-span-1 bg-[#0f172a] border border-slate-800 rounded-xl p-5 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-3 text-slate-700 pointer-events-none">
                      <Gauge className="h-16 w-16 opacity-10 rotate-12" />
                    </div>

                    <span className="text-xs font-mono text-slate-500 uppercase font-semibold mb-2">Score de Adequação</span>
                    
                    <div className="relative flex items-center justify-center my-2">
                      {/* Simulated Radial Gauge */}
                      <svg className="w-32 h-32 transform -rotate-90">
                        <circle
                          cx="64"
                          cy="64"
                          r="52"
                          stroke="currentColor"
                          strokeWidth="8"
                          className="text-slate-800"
                          fill="transparent"
                        />
                        <circle
                          cx="64"
                          cy="64"
                          r="52"
                          stroke="currentColor"
                          strokeWidth="8"
                          className={`${
                            activeReport.score >= 80 
                              ? "text-emerald-400" 
                              : activeReport.score >= 60 
                                ? "text-yellow-500" 
                                : "text-red-500"
                          }`}
                          fill="transparent"
                          strokeDasharray={326.7}
                          strokeDashoffset={326.7 - (326.7 * activeReport.score) / 100}
                        />
                      </svg>
                      <div className="absolute text-center">
                        <span className="text-3xl font-display font-black text-white">{activeReport.score}</span>
                        <span className="text-xs text-slate-500 block font-semibold mt-0.5">/ 100</span>
                      </div>
                    </div>

                    <div className="mt-3">
                      <span className={`text-xs uppercase font-bold px-3 py-1 rounded-full border ${
                        activeReport.status === "Adequado"
                          ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                          : "bg-red-500/10 border-red-500/30 text-red-400"
                      }`}>
                        {activeReport.status}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 mt-4 leading-relaxed font-medium">
                      Calculado com base no peso ponderado das dimensões do público.
                    </p>
                  </div>

                  {/* Bento Metrics Progress Bars */}
                  <div className="md:col-span-2 bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                    <h4 className="text-xs font-mono uppercase text-slate-400 font-bold mb-4 flex items-center gap-2">
                      <Sliders className="h-4 w-4 text-emerald-400" />
                      Dimensões de Performance de Audiência
                    </h4>

                    <div className="space-y-3">
                      {Object.entries(activeReport.scores_detalhados).map(([key, val]) => {
                        const scoreVal = val as number;
                        const labelMap: Record<string, string> = {
                          adequacao_ao_publico: "Adequação ao Público",
                          clareza: "Clareza Editorial",
                          didatica: "Pilar Didático & Explicação",
                          tom_de_voz: "Alinhamento do Tom de Voz",
                          consistencia: "Consistência de Complexidade",
                          engajamento_potencial: "Engajamento Estimado"
                        };

                        return (
                          <div key={key} className="space-y-1">
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-slate-300 font-medium">{labelMap[key] || key}</span>
                              <span className={`font-mono font-bold ${
                                scoreVal >= 80 ? "text-emerald-400" : scoreVal >= 60 ? "text-yellow-500" : "text-red-500"
                              }`}>{scoreVal}%</span>
                            </div>
                            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                              <div 
                                className={`h-full rounded-full transition-all duration-1000 ${
                                  scoreVal >= 80 ? "bg-emerald-400" : scoreVal >= 60 ? "bg-yellow-500" : "bg-red-500"
                                }`}
                                style={{ width: `${scoreVal}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>

                {/* Audit Context Box (Technical level & Tone details) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-sm flex items-start gap-3">
                    <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 text-slate-400">
                      <Target className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-mono text-slate-500 font-semibold block">Diagnóstico de Tom</span>
                      <div className="text-xs text-slate-200 mt-1">
                        <span className="text-slate-400 block mb-0.5">Detectado atualmente:</span>
                        <strong className="text-slate-100 font-semibold">{activeReport.tom_atual}</strong>
                        <span className="text-slate-400 block mt-1.5 mb-0.5">Alvo recomendado:</span>
                        <strong className="text-emerald-400 font-semibold">{activeReport.tom_recomendado}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-sm flex items-start gap-3">
                    <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 text-slate-400">
                      <Award className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-mono text-slate-500 font-semibold block">Nível Técnico e Vocabulário</span>
                      <div className="text-xs text-slate-200 mt-1">
                        <span className="text-slate-400 block mb-0.5">Nível estimado do rascunho:</span>
                        <strong className="text-slate-100 font-semibold">{activeReport.nivel_tecnico}</strong>
                        <span className="text-slate-400 block mt-1.5 mb-0.5">Explicatividade técnica:</span>
                        <strong className="text-cyan-400 font-semibold">{activeReport.clareza >= 80 ? "Alta (Muito explicativo)" : "Baixa (Requer jargões explicados)"}</strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Specific Rule Validations */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                  <h3 className="text-sm font-display font-bold text-white mb-4 flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                    Auditoria de Regras Estritas de Audiência
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeReport.regras_validadas?.map((rule) => (
                      <div 
                        key={rule.ruleId} 
                        className={`p-4 rounded-xl border flex gap-3 transition-colors ${
                          rule.pass 
                            ? "bg-green-950/10 border-green-500/20 text-slate-300" 
                            : "bg-red-950/10 border-red-500/20 text-slate-300"
                        }`}
                      >
                        <div className="mt-0.5">
                          {rule.pass ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertTriangle className="h-5 w-5 text-red-400 shrink-0" />
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-mono uppercase bg-slate-900 px-1.5 py-0.5 rounded text-slate-400 border border-slate-800">
                              {rule.ruleId}
                            </span>
                            <span className="text-xs font-bold text-white">{rule.nome}</span>
                          </div>
                          <p className="text-xs text-slate-400 leading-relaxed font-medium">
                            {rule.feedback}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Plan & Observations */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Action Plan */}
                  <div className="bg-gradient-to-br from-[#0f172a] to-emerald-950/10 border border-slate-800 rounded-xl p-5 shadow-xl">
                    <h3 className="text-sm font-display font-bold text-white mb-3 flex items-center gap-2 text-emerald-400">
                      <Sparkles className="h-5 w-5" />
                      Plano de Adaptação (Próximos Passos)
                    </h3>
                    <p className="text-xs text-slate-400 mb-4 leading-relaxed font-medium">
                      Diretrizes práticas sugeridas pelo auditor de audiência para otimizar o rascunho de artigo antes de seguir para a fase final de Humanização:
                    </p>

                    <div className="space-y-2.5">
                      {activeReport.recomendacoes.map((rec, i) => (
                        <div key={i} className="flex gap-2.5 text-xs text-slate-300">
                          <span className="text-emerald-400 font-bold font-mono">0{i+1}.</span>
                          <span className="leading-relaxed font-medium">{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Editorial Diagnosis */}
                  <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-display font-bold text-white mb-2 flex items-center gap-2">
                        <BookOpen className="h-5 w-5 text-slate-400" />
                        Diagnóstico Geral do Auditor
                      </h3>
                      <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 leading-relaxed font-mono whitespace-pre-wrap select-text">
                        {activeReport.observacoes}
                      </div>
                    </div>

                    <div className="border-t border-slate-800/80 pt-3 mt-4 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                      <span>Laudo ID: {activeReport.id}</span>
                      <span>Gerado em: {new Date(activeReport.data).toLocaleDateString()}</span>
                    </div>
                  </div>

                </div>

              </div>
            )}
          </div>

        </div>
      ) : (
        /* Version Comparative sub-tab view */
        <div className="space-y-6">
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
            <h3 className="text-md font-display font-bold text-white mb-2 flex items-center gap-2">
              <GitMerge className="h-5 w-5 text-emerald-400" />
              Comparador de Progresso de Adaptação
            </h3>
            <p className="text-sm text-slate-400 mb-6">
              Compare o score geral e as notas dimensionais de duas auditorias diferentes (ex: uma versão antiga antes da adaptação e uma versão corrigida).
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end border-b border-slate-800/80 pb-6 mb-6">
              <div>
                <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                  Laudo Versão Anterior (A)
                </label>
                <select 
                  value={compReport1Id}
                  onChange={(e) => setCompReport1Id(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-slate-800 rounded-lg py-2.5 px-3 text-sm text-slate-300 focus:outline-none focus:border-emerald-500 font-medium"
                >
                  <option value="">-- Selecione o Laudo A --</option>
                  {reports.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.id} - {r.persona === "concurseiro-iniciante" ? "Iniciante" : r.persona === "concurseiro-avancado" ? "Avançado" : "Cidadão"} ({new Date(r.data).toLocaleDateString()}) - Score: {r.score}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                  Laudo Versão Mais Recente (B)
                </label>
                <select 
                  value={compReport2Id}
                  onChange={(e) => setCompReport2Id(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-slate-800 rounded-lg py-2.5 px-3 text-sm text-slate-300 focus:outline-none focus:border-emerald-500 font-medium"
                >
                  <option value="">-- Selecione o Laudo B --</option>
                  {reports.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.id} - {r.persona === "concurseiro-iniciante" ? "Iniciante" : r.persona === "concurseiro-avancado" ? "Avançado" : "Cidadão"} ({new Date(r.data).toLocaleDateString()}) - Score: {r.score}
                    </option>
                  ))}
                </select>
              </div>

              <button 
                onClick={handleCompare}
                disabled={isComparing}
                className="bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-all text-sm h-[42px]"
              >
                {isComparing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <GitMerge className="h-4 w-4" />}
                <span>Calcular Comparativo</span>
              </button>
            </div>

            {/* Comparison Dashboard Results */}
            {comparison ? (
              <div className="space-y-6">
                
                {/* Score Progression Overview Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center">
                    <span className="text-xs font-mono text-slate-500 uppercase font-semibold block mb-1">Versão Anterior (Laudo A)</span>
                    <span className="text-xs font-mono text-slate-400 block mb-2">{comparison.report1.id} ({new Date(comparison.report1.data).toLocaleDateString()})</span>
                    <div className="text-3xl font-black text-slate-400">{comparison.report1.score}</div>
                    <span className="text-xs uppercase font-bold text-slate-500 px-2.5 py-0.5 rounded bg-slate-950/40 border border-slate-800 block mt-3 max-w-[max-content] mx-auto">
                      {comparison.report1.status}
                    </span>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center">
                    <span className="text-xs font-mono text-slate-500 uppercase font-semibold block mb-1">Versão Mais Recente (Laudo B)</span>
                    <span className="text-xs font-mono text-slate-400 block mb-2">{comparison.report2.id} ({new Date(comparison.report2.data).toLocaleDateString()})</span>
                    <div className="text-3xl font-black text-emerald-400">{comparison.report2.score}</div>
                    <span className="text-xs uppercase font-bold text-emerald-400 px-2.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 block mt-3 max-w-[max-content] mx-auto">
                      {comparison.report2.status}
                    </span>
                  </div>

                  <div className="bg-gradient-to-br from-emerald-950/20 to-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col items-center justify-center text-center">
                    <span className="text-xs font-mono text-emerald-400 uppercase font-semibold block mb-2">Progresso do Público-Alvo</span>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-6 w-6 text-emerald-400" />
                      <span className={`text-4xl font-display font-black ${
                        comparison.differences.score_geral >= 0 ? "text-emerald-400" : "text-red-400"
                      }`}>
                        {comparison.differences.score_geral >= 0 ? "+" : ""}{comparison.differences.score_geral}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-3 font-medium">
                      O artigo evoluiu positivamente em relação ao alinhamento com a persona desejada.
                    </p>
                  </div>

                </div>

                {/* Metrics Differences */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                  <h3 className="text-sm font-display font-bold text-white mb-4 flex items-center gap-2">
                    <Sliders className="h-5 w-5 text-emerald-400" />
                    Comparação de Dimensões Editoriais
                  </h3>

                  <div className="space-y-4">
                    {Object.entries(comparison.differences.metrics).map(([key, rawVal]) => {
                      const diffVal = rawVal as number;
                      const labelMap: Record<string, string> = {
                        adequacao_ao_publico: "Adequação ao Público",
                        clareza: "Clareza Editorial",
                        didatica: "Pilar Didático & Explicação",
                        tom_de_voz: "Alinhamento do Tom de Voz",
                        consistencia: "Consistência de Complexidade",
                        engajamento_potencial: "Engajamento Estimado"
                      };

                      return (
                        <div key={key} className="flex items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-800 text-xs">
                          <span className="font-bold text-slate-300">{labelMap[key] || key}</span>
                          <div className="flex items-center gap-3">
                            <span className={`font-mono font-bold px-2 py-0.5 rounded ${
                              diffVal > 0 
                                ? "bg-green-500/10 text-green-400" 
                                : diffVal < 0 
                                  ? "bg-red-500/10 text-red-400" 
                                  : "bg-slate-950 text-slate-500"
                            }`}>
                              {diffVal > 0 ? "+" : ""}{diffVal}%
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            ) : (
              <div className="text-center p-12 bg-slate-900 border border-slate-800 rounded-xl text-slate-500 text-xs">
                Por favor, selecione as duas auditorias de versões diferentes para calcular a evolução do artigo.
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
