import React, { useState, useEffect } from "react";
import { 
  FileText, Sparkles, CheckCircle2, AlertTriangle, ExternalLink, 
  History, Edit3, Save, RotateCcw, HelpCircle, ArrowRight, Gauge, 
  BookOpen, Plus, Trash, Check, Loader2, List, Shield, Search
} from "lucide-react";
import { ContentBlueprint } from "../../organic-traffic-os/content-architecture/models/blueprint-models";
import { ResearchPack, ResearchFact, ResearchQuestion } from "../../organic-traffic-os/research-pack/models/research-models";

export function OrganicResearch() {
  const [blueprints, setBlueprints] = useState<ContentBlueprint[]>([]);
  const [researchPacks, setResearchPacks] = useState<ResearchPack[]>([]);
  const [selectedPack, setSelectedPack] = useState<ResearchPack | null>(null);
  const [selectedBlueprint, setSelectedBlueprint] = useState<ContentBlueprint | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Edit states
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editContext, setEditContext] = useState<string>("");
  const [editObservacoes, setEditObservacoes] = useState<string>("");
  const [editFacts, setEditFacts] = useState<ResearchFact[]>([]);
  const [editQuestions, setEditQuestions] = useState<ResearchQuestion[]>([]);
  const [editEntidades, setEditEntidades] = useState<string[]>([]);
  const [newFactDesc, setNewFactDesc] = useState<string>("");
  const [newFactOrigin, setNewFactOrigin] = useState<string>("");
  const [newFactConfidence, setNewFactConfidence] = useState<string>("alta");
  const [newQuestionStr, setNewQuestionStr] = useState<string>("");
  const [newQuestionType, setNewQuestionType] = useState<string>("principal");
  const [newEntityStr, setNewEntityStr] = useState<string>("");

  // Search filter
  const [searchQuery, setSearchQuery] = useState<string>("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [bpRes, rpRes] = await Promise.all([
        fetch("/api/organic-os/blueprints"),
        fetch("/api/organic-os/research-packs")
      ]);

      if (!bpRes.ok || !rpRes.ok) {
        throw new Error("Falha ao recuperar dados da API.");
      }

      const bpData = await bpRes.json();
      const rpData = await rpRes.json();

      setBlueprints(bpData);
      setResearchPacks(rpData);

      // Select first pack by default if available
      if (rpData.length > 0) {
        setSelectedPack(rpData[0]);
        // find matching blueprint
        const bp = bpData.find((b: any) => b.id === rpData[0].blueprint_id);
        if (bp) setSelectedBlueprint(bp);
      } else if (bpData.length > 0) {
        // Fallback to select first blueprint to enable creation
        setSelectedBlueprint(bpData[0]);
      }
    } catch (err: any) {
      setError(err.message || "Erro desconhecido ao carregar dados.");
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePack = async (blueprintId: string) => {
    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const res = await fetch("/api/organic-os/research-packs/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ blueprintId })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Falha ao gerar o Dossiê de Pesquisa.");
      }

      const data = await res.json();
      setSuccessMsg("Dossiê de Pesquisa (Research Pack) gerado com sucesso!");
      
      // Refresh list
      const rpRes = await fetch("/api/organic-os/research-packs");
      const rpData = await rpRes.json();
      setResearchPacks(rpData);

      // Find and select the newly created pack
      const newPack = rpData.find((p: any) => p.blueprint_id === blueprintId);
      if (newPack) {
        setSelectedPack(newPack);
        const bp = blueprints.find(b => b.id === blueprintId);
        if (bp) setSelectedBlueprint(bp);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdatePack = async () => {
    if (!selectedPack) return;
    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const updatedData = {
        contexto: editContext,
        observacoes: editObservacoes,
        fatos: editFacts,
        perguntas: editQuestions,
        entidades: editEntidades
      };

      const res = await fetch(`/api/organic-os/research-packs/${selectedPack.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          updatedData,
          autor: "Editor de Pesquisa (UI)"
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Falha ao salvar as modificações.");
      }

      const data = await res.json();
      setSuccessMsg(`Versão v${data.pack.versao} salva com sucesso no histórico de auditoria!`);
      setIsEditing(false);

      // Refresh list
      const rpRes = await fetch("/api/organic-os/research-packs");
      const rpData = await rpRes.json();
      setResearchPacks(rpData);

      // Select updated pack
      const updated = rpData.find((p: any) => p.id === selectedPack.id);
      if (updated) setSelectedPack(updated);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const startEdit = () => {
    if (!selectedPack) return;
    setEditContext(selectedPack.contexto);
    setEditObservacoes(selectedPack.observacoes);
    setEditFacts([...selectedPack.fatos]);
    setEditQuestions([...selectedPack.perguntas]);
    setEditEntidades([...selectedPack.entidades]);
    setIsEditing(true);
  };

  const handleRestoreVersion = async (snapshot: any) => {
    if (!selectedPack) return;
    if (!window.confirm("Deseja realmente reverter este Dossiê de Pesquisa para esta versão histórica?")) return;

    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const res = await fetch(`/api/organic-os/research-packs/${selectedPack.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          updatedData: {
            contexto: snapshot.contexto,
            entidades: snapshot.entidades,
            perguntas: snapshot.perguntas,
            topicos: snapshot.topicos,
            fontes: snapshot.fontes,
            fatos: snapshot.fatos,
            observacoes: snapshot.observacoes
          },
          autor: "Restaurador de Histórico"
        })
      });

      if (!res.ok) {
        throw new Error("Erro ao restaurar versão.");
      }

      const data = await res.json();
      setSuccessMsg(`Restaurado com sucesso para a versão correspondente! Nova versão: v${data.pack.versao}`);
      
      // Refresh list
      const rpRes = await fetch("/api/organic-os/research-packs");
      const rpData = await rpRes.json();
      setResearchPacks(rpData);

      const updated = rpData.find((p: any) => p.id === selectedPack.id);
      if (updated) setSelectedPack(updated);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Edit helpers for lists
  const addFact = () => {
    if (!newFactDesc.trim()) return;
    setEditFacts([
      ...editFacts,
      {
        descricao: newFactDesc,
        origem: newFactOrigin || "Manual",
        nivel_confianca: newFactConfidence,
        necessita_validacao: false
      }
    ]);
    setNewFactDesc("");
    setNewFactOrigin("");
  };

  const removeFact = (index: number) => {
    setEditFacts(editFacts.filter((_, i) => i !== index));
  };

  const addQuestion = () => {
    if (!newQuestionStr.trim()) return;
    setEditQuestions([
      ...editQuestions,
      {
        pergunta: newQuestionStr,
        tipo: newQuestionType,
        origem: "Manual"
      }
    ]);
    setNewQuestionStr("");
  };

  const removeQuestion = (index: number) => {
    setEditQuestions(editQuestions.filter((_, i) => i !== index));
  };

  const addEntity = () => {
    if (!newEntityStr.trim()) return;
    if (!editEntidades.includes(newEntityStr.trim())) {
      setEditEntidades([...editEntidades, newEntityStr.trim()]);
    }
    setNewEntityStr("");
  };

  const removeEntity = (entity: string) => {
    setEditEntidades(editEntidades.filter(e => e !== entity));
  };

  const filteredPacks = researchPacks.filter(pack => {
    const text = (pack.titulo + " " + pack.contexto + " " + pack.id).toLowerCase();
    return text.includes(searchQuery.toLowerCase());
  });

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-400 border-emerald-500/30 bg-emerald-500/10";
    if (score >= 70) return "text-cyan-400 border-cyan-500/30 bg-cyan-500/10";
    if (score >= 50) return "text-yellow-400 border-yellow-500/30 bg-yellow-500/10";
    return "text-rose-400 border-rose-500/30 bg-rose-500/10";
  };

  const getScoreProgressBg = (score: number) => {
    if (score >= 90) return "bg-emerald-500";
    if (score >= 70) return "bg-cyan-500";
    if (score >= 50) return "bg-yellow-500";
    return "bg-rose-500";
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-[#0f172a] border border-slate-800 rounded-xl">
        <Loader2 className="h-10 w-10 text-cyan-400 animate-spin mb-4" />
        <p className="text-sm text-slate-400 font-mono">Carregando Dossiês de Pesquisa e Blueprints...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Banner / Header */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono px-2.5 py-1 rounded-full uppercase tracking-wider">
              Sprint 12 — Motor de Pesquisa
            </span>
          </div>
          <h2 className="text-2xl font-display font-bold text-white mb-1 flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-cyan-400" />
            Research Composer Engine V1
          </h2>
          <p className="text-sm text-slate-400 max-w-3xl">
            Este motor consolida toda a pesquisa de suporte a um conteúdo antes da escrita. Unifica entidades de interesse, as dúvidas da SERP, fatos oficiais incontestáveis e referências normativas em um dossiê imutável e auditado.
          </p>
        </div>
      </div>

      {/* Alert states */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="text-sm text-rose-300">
            <strong className="font-semibold block mb-0.5">Erro no Motor de Pesquisa:</strong>
            {error}
          </div>
        </div>
      )}

      {successMsg && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 flex items-start gap-3">
          <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-sm text-emerald-300">
            <strong className="font-semibold block mb-0.5">Sucesso:</strong>
            {successMsg}
          </div>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Explorer & Generator */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Section: Generate New Pack */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
            <h3 className="text-sm font-display font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Plus className="h-4 w-4 text-cyan-400" />
              Compor Novo Dossiê
            </h3>
            
            <p className="text-xs text-slate-400">
              Selecione uma Arquitetura de Conteúdo (Blueprint) aprovada que ainda não possua pesquisa compilada para disparar o motor.
            </p>

            <div className="space-y-3">
              <label className="block text-xs font-mono uppercase text-slate-400">Blueprint Editorial</label>
              <select 
                value={selectedBlueprint?.id || ""}
                onChange={(e) => {
                  const bp = blueprints.find(b => b.id === e.target.value);
                  if (bp) setSelectedBlueprint(bp);
                }}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value="">Selecione um Blueprint...</option>
                {blueprints.map(bp => {
                  const hasPack = researchPacks.some(p => p.blueprint_id === bp.id);
                  return (
                    <option key={bp.id} value={bp.id}>
                      {hasPack ? "✓ " : "⚡ "} {bp.titulo} ({bp.tipo_de_conteudo})
                    </option>
                  );
                })}
              </select>

              {selectedBlueprint && (
                <div className="p-3 bg-[#1e293b]/50 border border-slate-700/50 rounded-lg space-y-2">
                  <div className="flex justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Silo/Cluster:</span>
                    <span className="text-cyan-400">{selectedBlueprint.cluster}</span>
                  </div>
                  <div className="flex justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Tamanho Est.:</span>
                    <span className="text-slate-300">{selectedBlueprint.tamanho_estimado}</span>
                  </div>
                  <div className="flex justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Dossiê Existente:</span>
                    <span className={researchPacks.some(p => p.blueprint_id === selectedBlueprint.id) ? "text-emerald-400 font-bold" : "text-yellow-400"}>
                      {researchPacks.some(p => p.blueprint_id === selectedBlueprint.id) ? "Composto" : "Pendente"}
                    </span>
                  </div>
                </div>
              )}

              <button
                type="button"
                disabled={!selectedBlueprint || actionLoading}
                onClick={() => selectedBlueprint && handleCreatePack(selectedBlueprint.id)}
                className="w-full py-2 px-4 bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 disabled:hover:bg-cyan-500 text-slate-950 font-semibold rounded-lg text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-cyan-500/10 cursor-pointer"
              >
                {actionLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Consultando SERP & Bases...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Compor Pesquisa (Gemini V1)
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Section: Packs Explorer */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
            <h3 className="text-sm font-display font-semibold text-slate-200 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-cyan-400" />
                Dossiês Disponíveis
              </span>
              <span className="text-[11px] bg-slate-800 border border-slate-700 text-slate-400 font-mono px-2 py-0.5 rounded-full">
                {filteredPacks.length}
              </span>
            </h3>

            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input 
                type="text"
                placeholder="Filtrar dossiês..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {filteredPacks.length === 0 ? (
                <p className="text-xs text-slate-500 italic text-center py-6">Nenhum dossiê de pesquisa encontrado.</p>
              ) : (
                filteredPacks.map(p => {
                  const isSelected = selectedPack?.id === p.id;
                  return (
                    <div
                      key={p.id}
                      onClick={() => {
                        setSelectedPack(p);
                        setIsEditing(false);
                        const bp = blueprints.find(b => b.id === p.blueprint_id);
                        if (bp) setSelectedBlueprint(bp);
                      }}
                      className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                        isSelected 
                          ? "bg-cyan-950/20 border-cyan-500/50" 
                          : "bg-[#1e293b]/30 border-slate-800/80 hover:bg-[#1e293b]/50 hover:border-slate-700"
                      }`}
                    >
                      <h4 className="text-xs font-semibold text-white truncate mb-1">{p.titulo.replace("Dossiê de Pesquisa: ", "")}</h4>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-slate-400 font-mono">Versão: v{p.versao}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${getScoreColor(p.score.geral)}`}>
                          Geral: {p.score.geral}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: In-Depth Report & Auditor */}
        <div className="lg:col-span-8 space-y-6">
          {selectedPack ? (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl shadow-xl overflow-hidden">
              
              {/* Pack Header */}
              <div className="bg-[#1e293b]/30 border-b border-slate-800 p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="text-lg font-display font-bold text-white mb-1 flex items-center gap-2">
                    <FileText className="h-5 w-5 text-cyan-400" />
                    {selectedPack.titulo}
                  </h3>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-400 font-mono">
                    <span>ID: <strong className="text-slate-300">{selectedPack.id}</strong></span>
                    <span>Blueprint: <strong className="text-slate-300">{selectedPack.blueprint_id}</strong></span>
                    <span>Versão: <strong className="text-cyan-400">v{selectedPack.versao}</strong></span>
                  </div>
                </div>

                <div className="flex gap-2">
                  {!isEditing ? (
                    <button
                      type="button"
                      onClick={startEdit}
                      className="py-1.5 px-3 bg-[#1e293b] hover:bg-[#2d3748] border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Edit3 className="h-3.5 w-3.5 text-cyan-400" />
                      Editar Dossiê
                    </button>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setIsEditing(false)}
                        className="py-1.5 px-3 bg-[#1e293b] hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-slate-300 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        Cancelar
                      </button>
                      <button
                        type="button"
                        onClick={handleUpdatePack}
                        disabled={actionLoading}
                        className="py-1.5 px-3 bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Save className="h-3.5 w-3.5" />
                        Salvar Nova Versão
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Quality Audit Dashboard Row */}
              <div className="grid grid-cols-1 md:grid-cols-12 border-b border-slate-800 bg-[#0e1423]">
                
                {/* Score Chart */}
                <div className="md:col-span-4 p-5 border-b md:border-b-0 md:border-r border-slate-800 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
                      <Gauge className="h-4 w-4 text-cyan-400" />
                      Research Score
                    </h4>
                    <div className="flex items-baseline gap-2 mb-4">
                      <span className="text-4xl font-display font-black text-white">{selectedPack.score.geral}</span>
                      <span className="text-xs text-slate-500 font-mono">/ 100</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded border ml-auto font-mono ${getScoreColor(selectedPack.score.geral)}`}>
                        {selectedPack.score.geral >= 90 ? "Excelente" : selectedPack.score.geral >= 70 ? "Bom" : "Razoável"}
                      </span>
                    </div>
                  </div>

                  {/* Progressive Micro-meters */}
                  <div className="space-y-2 text-[10px] font-mono">
                    <div>
                      <div className="flex justify-between text-slate-400 mb-0.5">
                        <span>Cobertura:</span>
                        <span>{selectedPack.score.cobertura}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div className={`h-full ${getScoreProgressBg(selectedPack.score.cobertura)}`} style={{ width: `${selectedPack.score.cobertura}%` }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-slate-400 mb-0.5">
                        <span>Quantidade Fontes:</span>
                        <span>{selectedPack.score.quantidade_fontes}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div className={`h-full ${getScoreProgressBg(selectedPack.score.quantidade_fontes)}`} style={{ width: `${selectedPack.score.quantidade_fontes}%` }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-slate-400 mb-0.5">
                        <span>Diversidade Fontes:</span>
                        <span>{selectedPack.score.diversidade_fontes}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div className={`h-full ${getScoreProgressBg(selectedPack.score.diversidade_fontes)}`} style={{ width: `${selectedPack.score.diversidade_fontes}%` }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-slate-400 mb-0.5">
                        <span>Entidades:</span>
                        <span>{selectedPack.score.entidades}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div className={`h-full ${getScoreProgressBg(selectedPack.score.entidades)}`} style={{ width: `${selectedPack.score.entidades}%` }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-slate-400 mb-0.5">
                        <span>Perguntas:</span>
                        <span>{selectedPack.score.perguntas}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div className={`h-full ${getScoreProgressBg(selectedPack.score.perguntas)}`} style={{ width: `${selectedPack.score.perguntas}%` }}></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Validation Audit Logs */}
                <div className="md:col-span-8 p-5 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                      <Shield className="h-4 w-4 text-cyan-400" />
                      Auditoria de Integridade (Validator)
                    </h4>
                    
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                        selectedPack.validation.isValid 
                          ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" 
                          : "bg-rose-500/10 border-rose-500/30 text-rose-400"
                      }`}>
                        {selectedPack.validation.isValid ? "✓ VÁLIDO (Passou)" : "⚠ REPAROS REQUERIDOS"}
                      </span>
                    </div>

                    <div className="space-y-1.5 max-h-[140px] overflow-y-auto text-xs font-mono pr-1">
                      {selectedPack.validation.errors.map((err, idx) => (
                        <div key={idx} className="flex items-start gap-1.5 text-rose-400 bg-rose-950/20 border border-rose-900/30 p-1.5 rounded">
                          <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-rose-400" />
                          <span>{err}</span>
                        </div>
                      ))}
                      {selectedPack.validation.warnings.map((warn, idx) => (
                        <div key={idx} className="flex items-start gap-1.5 text-yellow-400 bg-yellow-950/20 border border-yellow-900/30 p-1.5 rounded">
                          <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-yellow-400" />
                          <span>{warn}</span>
                        </div>
                      ))}
                      {selectedPack.validation.errors.length === 0 && selectedPack.validation.warnings.length === 0 && (
                        <div className="flex items-center gap-1.5 text-emerald-400 bg-emerald-950/20 border border-emerald-900/30 p-2 rounded">
                          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                          <span>Pristino! Nenhuma pendência ou aviso estrutural encontrado no dossiê.</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-[10px] text-slate-500 italic mt-3">
                    * O validador fiscaliza links formatados, dados duplicados e obrigatoriedades para garantir segurança editorial completa.
                  </div>
                </div>
              </div>

              {/* Dossier Tabs / Content Areas */}
              <div className="p-6 space-y-6">
                
                {/* 1. Context Synthesis */}
                <div className="space-y-2">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <BookOpen className="h-4 w-4 text-cyan-400" />
                    Síntese do Contexto de Pesquisa
                  </h4>
                  {isEditing ? (
                    <textarea
                      value={editContext}
                      onChange={(e) => setEditContext(e.target.value)}
                      rows={5}
                      className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans"
                      placeholder="Cole ou redija o contexto consolidado de pesquisa..."
                    />
                  ) : (
                    <div className="bg-[#131d31] border border-slate-800 rounded-lg p-4 text-sm text-slate-300 leading-relaxed font-sans whitespace-pre-wrap">
                      {selectedPack.contexto}
                    </div>
                  )}
                </div>

                {/* 2. Entities & Questions */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Entities Column */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <List className="h-4 w-4 text-cyan-400" />
                      Entidades Obrigatórias
                    </h4>

                    {isEditing ? (
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <input 
                            type="text"
                            placeholder="Adicionar entidade obrigatória..."
                            value={newEntityStr}
                            onChange={(e) => setNewEntityStr(e.target.value)}
                            onKeyDown={(e) => e.key === "Enter" && addEntity()}
                            className="flex-1 bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                          />
                          <button 
                            type="button" 
                            onClick={addEntity}
                            className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-1.5 max-h-[140px] overflow-y-auto pr-1">
                          {editEntidades.map((ent, idx) => (
                            <span key={idx} className="inline-flex items-center gap-1 text-xs bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-full font-mono">
                              {ent}
                              <button type="button" onClick={() => removeEntity(ent)} className="text-rose-400 hover:text-rose-300 ml-1">×</button>
                            </span>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-1.5 max-h-[160px] overflow-y-auto pr-1">
                        {selectedPack.entidades.map((ent, idx) => (
                          <span key={idx} className="bg-slate-850 border border-slate-800 text-cyan-300 px-3 py-1 rounded-lg text-xs font-mono shadow-sm">
                            {ent}
                          </span>
                        ))}
                        {selectedPack.entidades.length === 0 && (
                          <p className="text-xs text-slate-500 italic">Nenhuma entidade obrigatória listada.</p>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Questions Column */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <HelpCircle className="h-4 w-4 text-cyan-400" />
                      Perguntas Chave de SEO (SERP/PAA)
                    </h4>

                    {isEditing ? (
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <input 
                            type="text"
                            placeholder="Pergunta..."
                            value={newQuestionStr}
                            onChange={(e) => setNewQuestionStr(e.target.value)}
                            className="flex-1 bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                          />
                          <select 
                            value={newQuestionType}
                            onChange={(e) => setNewQuestionType(e.target.value)}
                            className="bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                          >
                            <option value="principal">Principal</option>
                            <option value="secundária">Secundária</option>
                            <option value="relacionada">Relacionada</option>
                          </select>
                          <button 
                            type="button" 
                            onClick={addQuestion}
                            className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                        <div className="space-y-1 max-h-[140px] overflow-y-auto pr-1">
                          {editQuestions.map((q, idx) => (
                            <div key={idx} className="flex justify-between items-center text-xs bg-slate-800/50 border border-slate-800 p-2 rounded">
                              <div className="truncate pr-2">
                                <span className={`mr-1 px-1 py-0.2 rounded border font-mono text-[9px] uppercase ${
                                  q.tipo === "principal" ? "border-cyan-500 text-cyan-400" : q.tipo === "secundária" ? "border-yellow-500 text-yellow-400" : "border-slate-500 text-slate-400"
                                }`}>{q.tipo}</span>
                                <span className="text-slate-300 font-mono">{q.pergunta}</span>
                              </div>
                              <button type="button" onClick={() => removeQuestion(idx)} className="text-rose-400 hover:text-rose-300 shrink-0">
                                <Trash className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                        {selectedPack.perguntas.map((q, idx) => (
                          <div key={idx} className="flex items-start gap-2 bg-[#131d31]/50 border border-slate-850 p-2 rounded-lg">
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase shrink-0 ${
                              q.tipo === "principal" 
                                ? "bg-cyan-500/10 border border-cyan-500/20 text-cyan-400" 
                                : q.tipo === "secundária" 
                                ? "bg-yellow-500/10 border border-yellow-500/20 text-yellow-400" 
                                : "bg-slate-850 border border-slate-800 text-slate-400"
                            }`}>
                              {q.tipo}
                            </span>
                            <div className="text-xs">
                              <p className="text-slate-300 font-sans leading-relaxed">{q.pergunta}</p>
                              <span className="text-[10px] text-slate-500 font-mono">Origem: {q.origem}</span>
                            </div>
                          </div>
                        ))}
                        {selectedPack.perguntas.length === 0 && (
                          <p className="text-xs text-slate-500 italic">Nenhuma pergunta mapeada.</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* 3. Verified Facts */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Shield className="h-4 w-4 text-cyan-400" />
                    Fatos Técnicos Verificados (Fatos Confiáveis)
                  </h4>

                  {isEditing ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                        <input 
                          type="text"
                          placeholder="Fato técnico / regulamento / prazo..."
                          value={newFactDesc}
                          onChange={(e) => setNewFactDesc(e.target.value)}
                          className="sm:col-span-6 bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                        <input 
                          type="text"
                          placeholder="Origem do fato (Ex: CLT Art. 477)..."
                          value={newFactOrigin}
                          onChange={(e) => setNewFactOrigin(e.target.value)}
                          className="sm:col-span-3 bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                        <select 
                          value={newFactConfidence}
                          onChange={(e) => setNewFactConfidence(e.target.value)}
                          className="sm:col-span-2 bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                        >
                          <option value="alta">Confiança Alta</option>
                          <option value="média">Confiança Média</option>
                          <option value="baixa">Confiança Baixa</option>
                        </select>
                        <button 
                          type="button" 
                          onClick={addFact}
                          className="sm:col-span-1 p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg flex items-center justify-center"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      
                      <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                        {editFacts.map((f, idx) => (
                          <div key={idx} className="flex justify-between items-start text-xs bg-slate-800/50 border border-slate-800 p-2.5 rounded-lg gap-2">
                            <div className="space-y-1">
                              <p className="text-slate-300 font-mono">{f.descricao}</p>
                              <p className="text-[10px] text-slate-500 font-mono">
                                Origem: <span className="text-cyan-400">{f.origem}</span> | Confiança: {f.nivel_confianca}
                              </p>
                            </div>
                            <button type="button" onClick={() => removeFact(idx)} className="text-rose-400 hover:text-rose-300 shrink-0">
                              <Trash className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {selectedPack.fatos.map((f, idx) => (
                        <div key={idx} className="bg-[#111827] border border-slate-850 rounded-lg p-3.5 space-y-2">
                          <p className="text-xs text-slate-300 font-mono leading-relaxed">“{f.descricao}”</p>
                          <div className="flex justify-between items-center text-[10px] font-mono border-t border-slate-800/50 pt-2 text-slate-500">
                            <span>Origem: <strong className="text-slate-400">{f.origem}</strong></span>
                            <span className={`px-1.5 py-0.2 rounded border font-bold uppercase text-[8px] ${
                              f.nivel_confianca === "alta" ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/5" : "border-yellow-500/30 text-yellow-400 bg-yellow-500/5"
                            }`}>
                              Confiança: {f.nivel_confianca}
                            </span>
                          </div>
                        </div>
                      ))}
                      {selectedPack.fatos.length === 0 && (
                        <p className="text-xs text-slate-500 italic col-span-2 text-center py-4">Nenhum fato cadastrado.</p>
                      )}
                    </div>
                  )}
                </div>

                {/* 4. Official Sources (Fontes) */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <ExternalLink className="h-4 w-4 text-cyan-400" />
                    Fontes Oficiais & Documentação Mapeadas
                  </h4>
                  <div className="border border-slate-850 rounded-lg overflow-hidden bg-[#111827]/50">
                    <table className="w-full text-xs text-left text-slate-300 font-sans border-collapse">
                      <thead>
                        <tr className="bg-slate-900 border-b border-slate-850 text-slate-400 font-mono text-[10px] uppercase">
                          <th className="p-3">Nome da Fonte</th>
                          <th className="p-3">Tipo</th>
                          <th className="p-3">Observações</th>
                          <th className="p-3 text-right">Ação</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850">
                        {selectedPack.fontes.map((f, idx) => (
                          <tr key={idx} className="hover:bg-[#1e293b]/20">
                            <td className="p-3 font-semibold text-slate-200">{f.nome}</td>
                            <td className="p-3">
                              <span className="bg-slate-800 border border-slate-700 text-slate-400 px-2 py-0.5 rounded font-mono text-[9px] uppercase">
                                {f.tipo}
                              </span>
                            </td>
                            <td className="p-3 text-slate-400 text-xs italic">{f.observacoes || "Nenhuma observação informada."}</td>
                            <td className="p-3 text-right">
                              <a 
                                href={f.url} 
                                target="_blank" 
                                rel="noreferrer" 
                                className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-semibold"
                              >
                                Visitar
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            </td>
                          </tr>
                        ))}
                        {selectedPack.fontes.length === 0 && (
                          <tr>
                            <td colSpan={4} className="p-4 text-center text-slate-500 italic">Nenhuma fonte mapeada neste dossiê.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 5. structural Topics Mapping */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <List className="h-4 w-4 text-cyan-400" />
                    Diretrizes de Pesquisa para Tópicos Estruturais (Blueprint)
                  </h4>
                  <div className="space-y-2">
                    {selectedPack.topicos.map((top, idx) => (
                      <div key={idx} className="bg-[#111827] border border-slate-850 rounded-lg p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="bg-slate-800 border border-slate-700 text-slate-300 px-1.5 py-0.2 rounded font-mono text-[10px]">
                              {top.secao}
                            </span>
                            <span className="font-semibold text-slate-200 text-sm font-sans">{top.titulo}</span>
                          </div>
                          <p className="text-xs text-slate-400 font-sans leading-relaxed">{top.instrucoes_de_pesquisa}</p>
                        </div>
                        {top.fontes_recomendadas && top.fontes_recomendadas.length > 0 && (
                          <div className="shrink-0">
                            <a 
                              href={top.fontes_recomendadas[0]} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-[11px] font-mono text-cyan-400 bg-cyan-950/20 border border-cyan-800/20 px-2.5 py-1 rounded-full flex items-center gap-1 hover:bg-cyan-950/30"
                            >
                              Link de Respaldo
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* 6. Version snapshots list */}
                {selectedPack.versions && selectedPack.versions.length > 0 && (
                  <div className="space-y-3 border-t border-slate-800 pt-6">
                    <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <History className="h-4 w-4 text-cyan-400" />
                      Histórico de Versões do Dossiê (Snapshots)
                    </h4>
                    <div className="space-y-2">
                      {selectedPack.versions.map((v, idx) => (
                        <div key={idx} className="bg-slate-900/40 border border-slate-850 rounded-lg p-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white font-mono">Versão v{v.versao}</span>
                              <span className="text-[10px] text-slate-500 font-mono">Snapshot em {new Date(v.data_snapshot).toLocaleString()}</span>
                            </div>
                            <p className="text-xs text-slate-400 italic">{v.mudancas}</p>
                            <span className="text-[10px] text-slate-500 font-mono block">Autor: <strong className="text-slate-400">{v.autor}</strong></span>
                          </div>
                          <button
                            type="button"
                            disabled={actionLoading}
                            onClick={() => handleRestoreVersion(v.pack_snapshot)}
                            className="py-1 px-3 bg-[#1e293b] hover:bg-slate-800 border border-slate-700 hover:text-cyan-400 text-slate-400 text-xs font-semibold rounded-lg flex items-center gap-1 transition-all cursor-pointer shrink-0"
                          >
                            <RotateCcw className="h-3 w-3" />
                            Reverter para v{v.versao}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>

            </div>
          ) : (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-12 text-center shadow-xl flex flex-col items-center justify-center space-y-4">
              <FileText className="h-16 w-16 text-slate-600 stroke-1" />
              <div className="space-y-1">
                <h3 className="text-lg font-display font-semibold text-white">Selecione ou Componha um Dossiê</h3>
                <p className="text-sm text-slate-400 max-w-md">
                  Nenhum Dossiê de Pesquisa (Research Pack) está selecionado atualmente. Escolha um dossiê no explorador à esquerda ou gere um novo a partir do Blueprint editorial selecionado.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
