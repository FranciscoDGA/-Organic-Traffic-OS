import React, { useState, useEffect } from "react";
import { 
  Sparkles, RefreshCw, Cpu, Database, Award, 
  BarChart2, ShieldAlert, List, ArrowRight, CheckCircle2, 
  Clock, Flame, HelpCircle, Layers, FileText, Search, AlertTriangle, Play
} from "lucide-react";

interface Opportunity {
  id: string;
  titulo: string;
  categoria: string;
  cluster: string;
  entidade: string;
  tipo: string;
  intencao: string;
  prioridade: string;
  score: number;
  origem: string;
  motivo: string;
  status: string;
  criado_em: string;
}

interface EngineLog {
  timestamp: string;
  duracaoMs: number;
  fontesConsultadas: string[];
  totalOportunidadesGeradas: number;
  motivosResumo: Record<string, number>;
  errosRegistrados: string[];
  ausenciaDeDados: string[];
}

export function OrganicOpportunities() {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [logs, setLogs] = useState<EngineLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterPriority, setFilterPriority] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [showWorkflow, setShowWorkflow] = useState(true);

  const loadData = async () => {
    try {
      const res = await fetch("/api/organic-os/opportunities");
      if (res.ok) {
        const data = await res.json();
        setOpportunities(data.opportunities || []);
        setLogs(data.logs || []);
        
        // Selecionar o primeiro item por padrão se disponível e nenhum selecionado
        if (data.opportunities && data.opportunities.length > 0 && !selectedOpportunity) {
          setSelectedOpportunity(data.opportunities[0]);
        }
      }
    } catch (err) {
      console.error("Erro ao carregar oportunidades:", err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleGenerate = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/organic-os/opportunities/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (res.ok) {
        const data = await res.json();
        setOpportunities(data.opportunities || []);
        if (data.latestLog) {
          setLogs(prev => [data.latestLog, ...prev]);
        }
        if (data.opportunities && data.opportunities.length > 0) {
          setSelectedOpportunity(data.opportunities[0]);
        }
        alert(`Sucesso! ${data.opportunities.length} oportunidades geradas através do cruzamento estratégico.`);
      } else {
        alert("Falha ao rodar o motor de descoberta de oportunidades.");
      }
    } catch (err) {
      console.error("Erro ao gerar oportunidades:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Cálculos de Métricas
  const totalCount = opportunities.length;
  const averageScore = totalCount > 0 
    ? Math.round(opportunities.reduce((sum, o) => sum + o.score, 0) / totalCount) 
    : 0;

  const priorityCounts = opportunities.reduce((acc, o) => {
    acc[o.prioridade] = (acc[o.prioridade] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const categoryCounts = opportunities.reduce((acc, o) => {
    acc[o.categoria] = (acc[o.categoria] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const originCounts = opportunities.reduce((acc, o) => {
    acc[o.origem] = (acc[o.origem] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const clusterCounts = opportunities.reduce((acc, o) => {
    acc[o.cluster] = (acc[o.cluster] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Filtragem e Busca
  const filteredOpps = opportunities.filter(o => {
    const matchesSearch = o.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          o.cluster.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          o.motivo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPriority = filterPriority === "all" || o.prioridade === filterPriority;
    const matchesCategory = filterCategory === "all" || o.categoria === filterCategory;
    return matchesSearch && matchesPriority && matchesCategory;
  });

  // Exibir somente as Top 20 ordenadas por score decrescente
  const top20Opportunities = filteredOpps.slice(0, 20);

  // Lista única de categorias para filtro
  const uniqueCategories = Array.from(new Set(opportunities.map(o => o.categoria)));

  return (
    <div className="space-y-6">
      {/* Banner de Introdução */}
      <div className="bg-[#111827] border border-cyan-500/20 rounded-xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl -z-10" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-mono px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded uppercase tracking-wider border border-cyan-500/20">
                Sprint 08 — Discovery Engine
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-xs text-slate-400">Inteligência Estratégica & Gaps de SERP</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
              <Flame className="h-6 w-6 text-cyan-400" />
              Opportunity Discovery Engine <span className="text-slate-500 font-light">V1</span>
            </h2>
            <p className="text-sm text-slate-400 mt-2 max-w-3xl leading-relaxed">
              Primeiro motor autônomo de decisão do Organic Traffic OS. A engine analisa simultaneamente o Knowledge Core, 
              Inventory de artigos, Inteligência de Competidores, SERP e os Coletores para ranquear as melhores oportunidades editoriais de forma unificada.
            </p>
          </div>
          <div className="flex gap-3 shrink-0">
            <button 
              onClick={() => setShowWorkflow(!showWorkflow)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm font-semibold border border-slate-700 transition"
            >
              {showWorkflow ? "Ocultar Fluxo" : "Exibir Fluxo"}
            </button>
            <button 
              disabled={isLoading}
              onClick={handleGenerate}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold border transition ${
                isLoading 
                  ? "bg-cyan-500/10 text-cyan-500 border-cyan-500/20 cursor-not-allowed" 
                  : "bg-cyan-500 hover:bg-cyan-600 text-slate-950 border-cyan-400 shadow-lg shadow-cyan-500/15"
              }`}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Rodando Motor...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 fill-slate-950" />
                  Mapear Oportunidades
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Visualização de Workflow de Ingestão Inteligente */}
      {showWorkflow && (
        <div className="bg-[#0b0f19] border border-cyan-500/10 rounded-xl p-5 shadow-inner">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-4 flex items-center gap-1.5 font-mono">
            <Cpu className="h-4 w-4 text-cyan-400" />
            Workflow Estratégico de Decisão Autônoma
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-9 gap-3 items-center text-center">
            {[
              { label: "Knowledge", sub: "Core", icon: <Database className="h-4 w-4 text-purple-400" /> },
              { label: "Content", sub: "Inventory", icon: <FileText className="h-4 w-4 text-cyan-400" /> },
              { label: "Competitors", sub: "Intelligence", icon: <Layers className="h-4 w-4 text-amber-400" /> },
              { label: "SERP", sub: "Intelligence", icon: <Award className="h-4 w-4 text-indigo-400" /> },
              { label: "Keywords", sub: "Database", icon: <BarChart2 className="h-4 w-4 text-emerald-400" /> },
              { label: "Research", sub: "Collectors", icon: <Cpu className="h-4 w-4 text-red-400" /> },
              { label: "Opportunity", sub: "Engine", icon: <Flame className="h-4 w-4 text-cyan-400" /> },
              { label: "Opportunity", sub: "Ranking", icon: <Sparkles className="h-4 w-4 text-pink-400" /> },
              { label: "Editorial", sub: "Dashboard", icon: <CheckCircle2 className="h-4 w-4 text-green-400" /> }
            ].map((step, idx) => (
              <React.Fragment key={idx}>
                <div className="bg-[#111827] border border-slate-800 rounded-lg p-3 flex flex-col items-center justify-center relative hover:border-cyan-500/35 transition group">
                  <div className="mb-1.5 p-1.5 bg-slate-900 rounded border border-slate-800 group-hover:bg-cyan-950/20 group-hover:border-cyan-500/20 transition">
                    {step.icon}
                  </div>
                  <span className="text-[11px] font-bold text-white block truncate w-full">{step.label}</span>
                  <span className="text-[9px] text-slate-500 block">{step.sub}</span>
                </div>
                {idx < 8 && (
                  <div className="hidden md:flex justify-center text-slate-700">
                    <ArrowRight className="h-4 w-4 animate-pulse text-cyan-500/30" />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      )}

      {/* Grid de Métricas Consolidadas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Oportunidades</span>
            <Flame className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">{totalCount}</h3>
            <p className="text-xs text-slate-500 mt-1">Identificadas e processadas</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Score Estratégico Médio</span>
            <Award className="h-4 w-4 text-purple-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">{averageScore}%</h3>
            <p className="text-xs text-slate-500 mt-1">Nível de alinhamento com o blog</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Prioridades Críticas / Altas</span>
            <ShieldAlert className="h-4 w-4 text-red-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">
              {(priorityCounts["critica"] || 0) + (priorityCounts["alta"] || 0)}
            </h3>
            <p className="text-xs text-slate-500 mt-1">Exigem produção imediata</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Clusters Mapeados</span>
            <Layers className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">
              {Object.keys(clusterCounts).length}
            </h3>
            <p className="text-xs text-slate-500 mt-1">Grupos semânticos cobertos</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Lado Esquerdo: Distribuições de Dados */}
        <div className="space-y-6">
          
          {/* Distribuição por Prioridade */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-4 font-mono">Distribuição por Prioridade</h3>
            <div className="space-y-3.5">
              {[
                { key: "critica", label: "Crítica", color: "bg-red-500 text-red-400 border-red-500/20" },
                { key: "alta", label: "Alta", color: "bg-amber-500 text-amber-400 border-amber-500/20" },
                { key: "media", label: "Média", color: "bg-cyan-500 text-cyan-400 border-cyan-500/20" },
                { key: "baixa", label: "Baixa", color: "bg-slate-500 text-slate-400 border-slate-500/20" }
              ].map((p) => {
                const count = priorityCounts[p.key] || 0;
                const pct = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
                return (
                  <div key={p.key} className="space-y-1">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-300">{p.label}</span>
                      <span className="font-mono text-slate-400">{count} ({pct}%)</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800/50">
                      <div className={`h-full ${p.color.split(" ")[0]}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Distribuição por Origem de Descoberta */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-4 font-mono">Fontes de Entrada cruzadas</h3>
            <div className="space-y-3.5">
              {[
                { key: "concorrentes", label: "Competitors Intelligence", color: "bg-amber-500/20 text-amber-400" },
                { key: "keywords", label: "Keywords Intelligence", color: "bg-emerald-500/20 text-emerald-400" },
                { key: "serp", label: "SERP Intelligence", color: "bg-indigo-500/20 text-indigo-400" },
                { key: "collectors", label: "Research Collectors", color: "bg-red-500/20 text-red-400" }
              ].map((o) => {
                const count = originCounts[o.key] || 0;
                const pct = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
                return (
                  <div key={o.key} className="flex justify-between items-center text-xs border-b border-slate-800/50 pb-2.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${o.color}`}>{o.label}</span>
                    <span className="font-mono text-white font-bold">{count} items ({pct}%)</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Categorias Principais */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-4 font-mono">Principais Categorias</h3>
            <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
              {Object.keys(categoryCounts).length === 0 ? (
                <p className="text-xs text-slate-500 italic text-center py-2">Sem categorias indexadas.</p>
              ) : (
                Object.entries(categoryCounts)
                  .sort((a, b) => (b[1] as number) - (a[1] as number))
                  .map(([cat, count]) => {
                    const pct = totalCount > 0 ? Math.round(((count as number) / totalCount) * 100) : 0;
                    return (
                      <div key={cat} className="space-y-1">
                        <div className="flex justify-between items-center text-xs text-slate-400">
                          <span className="truncate max-w-[180px] font-medium text-slate-300">{cat}</span>
                          <span className="font-mono">{count} ({pct}%)</span>
                        </div>
                        <div className="h-1 w-full bg-slate-900 rounded-full overflow-hidden">
                          <div className="h-full bg-cyan-400" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })
              )}
            </div>
          </div>

        </div>

        {/* Lado Direito: Grid de Oportunidades & Visualizador Expandido */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
              <h3 className="text-md font-bold text-white flex items-center gap-2">
                <List className="h-5 w-5 text-cyan-400" />
                Mapeamento Editorial: Top 20 Oportunidades
              </h3>
              
              {/* Barra de Busca Rápida */}
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
                <input 
                  type="text"
                  placeholder="Buscar título, cluster, motivo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-[#030712] border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 w-full md:w-[220px]"
                />
              </div>
            </div>

            {/* Filtros rápidos de Linha */}
            <div className="flex flex-wrap gap-2 mb-4 pb-3 border-b border-slate-800/60">
              <div className="flex items-center gap-1.5 bg-[#030712] border border-slate-800/80 px-2 py-1 rounded-lg">
                <span className="text-[10px] font-mono text-slate-500">Prioridade:</span>
                <select 
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="bg-transparent text-xs text-slate-300 focus:outline-none"
                >
                  <option value="all">Todas</option>
                  <option value="critica">Crítica</option>
                  <option value="alta">Alta</option>
                  <option value="media">Média</option>
                  <option value="baixa">Baixa</option>
                </select>
              </div>

              <div className="flex items-center gap-1.5 bg-[#030712] border border-slate-800/80 px-2 py-1 rounded-lg">
                <span className="text-[10px] font-mono text-slate-500">Categoria:</span>
                <select 
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="bg-transparent text-xs text-slate-300 focus:outline-none max-w-[150px]"
                >
                  <option value="all">Todas</option>
                  {uniqueCategories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Lista Scrollável */}
            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {top20Opportunities.length === 0 ? (
                <div className="text-center py-10">
                  <Flame className="h-10 w-10 text-slate-700 animate-pulse mx-auto mb-2" />
                  <p className="text-xs text-slate-500 italic">Nenhuma oportunidade localizada para os filtros inseridos.</p>
                </div>
              ) : (
                top20Opportunities.map((o) => {
                  let badgeColor = "bg-slate-800 text-slate-400";
                  if (o.prioridade === "critica") badgeColor = "bg-red-500/10 text-red-400 border-red-500/15";
                  if (o.prioridade === "alta") badgeColor = "bg-amber-500/10 text-amber-400 border-amber-500/15";
                  if (o.prioridade === "media") badgeColor = "bg-cyan-500/10 text-cyan-400 border-cyan-500/15";

                  return (
                    <div 
                      key={o.id}
                      onClick={() => setSelectedOpportunity(o)}
                      className={`p-3 border rounded-xl cursor-pointer transition flex items-center justify-between gap-4 ${
                        selectedOpportunity?.id === o.id 
                          ? "bg-cyan-500/5 border-cyan-500/30" 
                          : "bg-[#1f2937]/10 border-slate-800/80 hover:bg-[#1f2937]/20"
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${badgeColor}`}>
                            {o.prioridade.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">Score: <span className="text-cyan-400 font-bold">{o.score}%</span></span>
                          <span className="text-slate-600">•</span>
                          <span className="text-[10px] text-slate-400 font-mono truncate max-w-[120px]">{o.categoria}</span>
                        </div>
                        <h4 className="text-xs font-semibold text-white truncate max-w-[350px]">
                          {o.titulo}
                        </h4>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 text-right">
                        <div>
                          <span className="text-[10px] font-mono text-slate-500 block">Tipo</span>
                          <span className="text-[10px] text-slate-300 font-mono font-medium">
                            {o.tipo === "novo_artigo" ? "Novo Artigo" : o.tipo === "reforco_pilar" ? "Reforço Pilar" : "Otimização"}
                          </span>
                        </div>
                        <ArrowRight className="h-4 w-4 text-slate-600" />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Painel do Resultado Expandido de Oportunidade e Logs de Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Painel de Ficha Técnica Expandida */}
        <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-4 font-mono">Ficha de Oportunidade Editorial</h3>
          
          {selectedOpportunity ? (
            <div className="space-y-4">
              <div className="flex justify-between items-start gap-4 pb-3 border-b border-slate-800/60">
                <div>
                  <h4 className="text-base font-bold text-white tracking-tight leading-snug">{selectedOpportunity.titulo}</h4>
                  <p className="text-[10px] font-mono text-cyan-400 mt-1 uppercase">ID: {selectedOpportunity.id} | Criado em: {new Date(selectedOpportunity.criado_em).toLocaleDateString()}</p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] font-mono text-slate-500 block uppercase">Score Geral</span>
                  <span className="text-2xl font-black text-cyan-400 font-mono">{selectedOpportunity.score}%</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-[#030712] rounded-lg p-3 border border-slate-800/80 text-xs">
                  <span className="text-slate-500 font-mono block mb-1">Grupo Semântico:</span>
                  <span className="text-white font-semibold block truncate">{selectedOpportunity.cluster}</span>
                </div>
                <div className="bg-[#030712] rounded-lg p-3 border border-slate-800/80 text-xs">
                  <span className="text-slate-500 font-mono block mb-1">Intenção de Busca:</span>
                  <span className="text-white font-semibold block">{selectedOpportunity.intencao}</span>
                </div>
                <div className="bg-[#030712] rounded-lg p-3 border border-slate-800/80 text-xs">
                  <span className="text-slate-500 font-mono block mb-1">Entidade Principal:</span>
                  <span className="text-white font-semibold block truncate">{selectedOpportunity.entidade || "Geral"}</span>
                </div>
              </div>

              <div className="bg-[#0b0f19] border border-cyan-500/10 rounded-lg p-4 space-y-2">
                <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold tracking-wider block">Motivo e Justificativa de Decisão:</span>
                <p className="text-xs text-slate-300 leading-relaxed font-mono">
                  {selectedOpportunity.motivo}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/60 flex justify-between items-center text-[11px] text-slate-500 font-mono">
                <div>
                  Origem da descoberta: <span className="text-cyan-400 font-bold uppercase">{selectedOpportunity.origem}</span>
                </div>
                <div className="flex gap-2">
                  <span className="text-slate-400">Status atual:</span>
                  <span className="text-white font-bold uppercase px-1.5 bg-slate-800 rounded border border-slate-700">{selectedOpportunity.status}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500 text-xs space-y-2.5">
              <FileText className="h-10 w-10 text-slate-700 animate-pulse mx-auto" />
              <p className="font-semibold text-slate-400">Nenhum item selecionado</p>
              <p className="text-[11px] max-w-[280px] mx-auto">Selecione uma oportunidade na tabela acima para analisar seus dados e justificativa.</p>
            </div>
          )}
        </div>

        {/* Console de Auditoria de Decisões */}
        <div className="lg:col-span-5 bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest mb-3 font-mono">Console de Auditoria (Logs)</h3>
            
            <div className="bg-[#030712] rounded-lg p-3.5 h-[230px] overflow-y-auto font-mono text-[10px] space-y-2 border border-slate-800/80">
              {logs.length === 0 ? (
                <p className="text-slate-600 italic">Nenhum log de motor disponível.</p>
              ) : (
                logs.map((log, idx) => {
                  return (
                    <div key={idx} className="leading-relaxed border-b border-slate-800/40 pb-2 space-y-1">
                      <div className="flex gap-1 items-start justify-between text-slate-500">
                        <span>[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                        <span className="text-cyan-400 font-bold">Engine Run</span>
                      </div>
                      <div className="text-slate-300">
                        • Tempo de Execução: <span className="text-white font-bold">{log.duracaoMs}ms</span>
                      </div>
                      <div className="text-slate-300">
                        • Oportunidades Mapeadas: <span className="text-white font-bold">{log.totalOportunidadesGeradas}</span>
                      </div>
                      <div className="text-slate-300">
                        • Fontes consultadas: <span className="text-emerald-400">{log.fontesConsultadas.join(", ")}</span>
                      </div>
                      {log.ausenciaDeDados.length > 0 && (
                        <div className="text-amber-400">
                          ⚠ Dados ausentes: <span className="font-semibold text-amber-500/90">{log.ausenciaDeDados.join(", ")}</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
            <span>Rastreabilidade de origem SEO</span>
            <span className="text-cyan-500/80">Auditado por IA Agency</span>
          </div>
        </div>

      </div>

    </div>
  );
}
export default OrganicOpportunities;
