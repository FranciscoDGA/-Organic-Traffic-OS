import React, { useEffect, useState } from "react";
import { 
  Database, CheckCircle, AlertTriangle, RefreshCw, FileText, 
  Users, BookOpen, ShoppingBag, Eye, Scale, Search, PenTool, LayoutGrid, Calendar, MapPin
} from "lucide-react";

interface OrganicKnowledge {
  blog: {
    id: string;
    nome: string;
    slug: string;
    dominio: string;
    descricao: string;
    missao: string;
    historia: string;
    cidade: string;
    estado: string;
    pais: string;
    idioma: string;
    data_criacao: string;
    status: string;
  } | null;
  publico: any[];
  editorial: any;
  categorias: any[];
  produtos: any[];
  regras: any;
  writingStyle: any;
  seo: any;
  metadata: {
    isValid: boolean;
    errors: string[];
    lastUpdated: string;
    fileCount: number;
    blogId: string;
  };
}

export function OrganicKnowledgeCore() {
  const [data, setData] = useState<OrganicKnowledge | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedProfile, setSelectedProfile] = useState<number>(0);
  const [activeSection, setActiveSection] = useState<'overview' | 'audience' | 'categories' | 'products' | 'editorial'>('overview');

  const fetchKnowledge = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/organic-os/knowledge");
      if (!res.ok) {
        throw new Error(`Failed to load knowledge core api: status ${res.status}`);
      }
      const json = await res.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load knowledge data");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchKnowledge();
  }, []);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <RefreshCw className="h-10 w-10 animate-spin text-cyan-400 mb-4" />
        <p className="font-mono text-sm">Orchestrating Knowledge Core registers...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6 bg-red-950/20 border border-red-500/20 rounded-xl text-center my-6">
        <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-3 animate-bounce" />
        <h4 className="text-lg font-bold text-white mb-2">Error Loading Knowledge Core</h4>
        <p className="text-sm text-slate-300 max-w-md mx-auto mb-4">{error || "No data returned from backend runtime."}</p>
        <button 
          onClick={fetchKnowledge}
          className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 border border-red-500/30 rounded-lg text-xs font-semibold font-mono"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const { blog, publico, editorial, categorias, produtos, regras, writingStyle, seo, metadata } = data;

  return (
    <div className="space-y-6">
      
      {/* Upper Status Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        
        {/* Core Validity Status Card */}
        <div className={`p-5 rounded-xl border ${metadata.isValid ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-400" : "bg-red-950/20 border-red-500/30 text-red-400"} col-span-1 lg:col-span-2 flex flex-col justify-between`}>
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-widest text-slate-400">Validation Status</span>
              {metadata.isValid ? (
                <span className="flex items-center gap-1 bg-emerald-500/10 text-emerald-400 text-[10px] px-2.5 py-0.5 rounded border border-emerald-500/20 uppercase font-bold font-mono">
                  <CheckCircle className="h-3.5 w-3.5" /> Validated
                </span>
              ) : (
                <span className="flex items-center gap-1 bg-red-500/10 text-red-400 text-[10px] px-2.5 py-0.5 rounded border border-red-500/20 uppercase font-bold font-mono">
                  <AlertTriangle className="h-3.5 w-3.5" /> Corrupted
                </span>
              )}
            </div>
            
            <h3 className="text-xl font-bold text-white font-display">
              {metadata.isValid ? "Knowledge Core Fully Compliant" : "Knowledge Integrity Violated"}
            </h3>
            
            {metadata.errors.length > 0 ? (
              <ul className="mt-2 text-xs text-red-300 space-y-1 list-disc list-inside bg-red-950/40 p-3 rounded-lg border border-red-500/20 font-mono max-h-[100px] overflow-y-auto">
                {metadata.errors.map((err, i) => <li key={i}>{err}</li>)}
              </ul>
            ) : (
              <p className="text-xs text-slate-300 mt-2">
                All 09 mandatory schema JSON structures loaded, parsed, and validated cleanly. Shared agents will consult this profile before execution.
              </p>
            )}
          </div>
          
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 mt-4 pt-3 border-t border-slate-800">
            <span>Core Version: 1.0.0</span>
            <span>Target: {metadata.blogId}</span>
          </div>
        </div>

        {/* Total files Card */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-slate-400">Core Architecture</span>
            <h3 className="text-3xl font-extrabold text-white mt-1 font-mono">{metadata.fileCount}/9</h3>
            <p className="text-xs text-slate-400 mt-1">Structured profile files indexed dynamically in memory.</p>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyan-400 mt-3 pt-3 border-t border-slate-800">
            <FileText className="h-3.5 w-3.5" />
            <span>09-knowledge-index.json</span>
          </div>
        </div>

        {/* Last updated Card */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-slate-400">Last Synced</span>
            <h3 className="text-lg font-bold text-white mt-2 font-mono">
              {new Date(metadata.lastUpdated).toLocaleTimeString()}
            </h3>
            <p className="text-xs text-slate-400 mt-1">Real-time validation check has run on hot-load of files.</p>
          </div>
          <button 
            onClick={fetchKnowledge}
            className="flex items-center justify-center gap-1 w-full mt-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-mono"
          >
            <RefreshCw className="h-3 w-3" /> Re-Scan Core Files
          </button>
        </div>

      </div>

      {/* Main Grid: Info Section */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Navigation panel */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 h-fit space-y-1">
          <span className="block text-[10px] font-mono uppercase text-slate-500 tracking-wider px-3 mb-2">Knowledge Core Sections</span>
          <button 
            onClick={() => setActiveSection('overview')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeSection === 'overview' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <BookOpen className="h-4 w-4" />
            01. Blog Profile Info
          </button>
          <button 
            onClick={() => setActiveSection('audience')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeSection === 'audience' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <Users className="h-4 w-4" />
            02. Target Personas ({publico?.length || 0})
          </button>
          <button 
            onClick={() => setActiveSection('categories')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeSection === 'categories' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <LayoutGrid className="h-4 w-4" />
            03. Categories Schema ({categorias?.length || 0})
          </button>
          <button 
            onClick={() => setActiveSection('products')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeSection === 'products' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <ShoppingBag className="h-4 w-4" />
            04. Product Structures ({produtos?.length || 0})
          </button>
          <button 
            onClick={() => setActiveSection('editorial')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeSection === 'editorial' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <Scale className="h-4 w-4" />
            05. Editorial & SEO Rules
          </button>
        </div>

        {/* Details Display Area */}
        <div className="lg:col-span-3 bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl">
          
          {/* Section: Overview */}
          {activeSection === 'overview' && blog && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <span className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20 text-cyan-400 font-bold font-mono">
                    PROFILE
                  </span>
                  <div>
                    <h4 className="text-xl font-bold text-white font-display">{blog.nome}</h4>
                    <p className="text-xs font-mono text-cyan-400">URL: <a href={`https://${blog.dominio}`} target="_blank" rel="noreferrer" className="underline">{blog.dominio}</a></p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <span className="text-xs font-mono uppercase text-slate-500 block">About / Descrição</span>
                  <p className="text-sm text-slate-300 mt-1 leading-relaxed">{blog.descricao}</p>
                </div>
                <div>
                  <span className="text-xs font-mono uppercase text-slate-500 block">Mission / Missão</span>
                  <p className="text-sm text-slate-300 mt-1 leading-relaxed">{blog.missao}</p>
                </div>
                <div className="md:col-span-2">
                  <span className="text-xs font-mono uppercase text-slate-500 block">History / Origem</span>
                  <p className="text-sm text-slate-300 mt-1 leading-relaxed bg-[#0b0f19] p-4 rounded-lg border border-slate-800">{blog.historia}</p>
                </div>
              </div>

              <div className="border-t border-slate-800 pt-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
                <div>
                  <span className="text-slate-500 uppercase block text-[10px]">Location / Cidade</span>
                  <div className="flex items-center gap-1 text-white mt-1">
                    <MapPin className="h-3.5 w-3.5 text-slate-400" />
                    <span>{blog.cidade}, {blog.estado}</span>
                  </div>
                </div>
                <div>
                  <span className="text-slate-500 uppercase block text-[10px]">Language / Idioma</span>
                  <span className="text-white block mt-1">{blog.idioma}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase block text-[10px]">Created At</span>
                  <div className="flex items-center gap-1 text-white mt-1">
                    <Calendar className="h-3.5 w-3.5 text-slate-400" />
                    <span>{new Date(blog.data_criacao).toLocaleDateString()}</span>
                  </div>
                </div>
                <div>
                  <span className="text-slate-500 uppercase block text-[10px]">Status</span>
                  <span className="text-emerald-400 block mt-1 uppercase font-bold">{blog.status}</span>
                </div>
              </div>
            </div>
          )}

          {/* Section: Audience */}
          {activeSection === 'audience' && publico && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h4 className="text-lg font-bold text-white font-display">Target Audience Personas</h4>
                <p className="text-xs text-slate-400">Detailed mapping of our audience segments, motivations, pain-points, and recommended tones.</p>
              </div>

              {/* Persona tabs selectors */}
              <div className="flex flex-wrap gap-2">
                {publico.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedProfile(idx)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono border transition-all ${selectedProfile === idx ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/30" : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"}`}
                  >
                    {p.perfil}
                  </button>
                ))}
              </div>

              {/* Selected Persona detail display */}
              {publico[selectedProfile] && (
                <div className="bg-[#0b0f19] border border-slate-800 rounded-lg p-5 space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b border-slate-800/60">
                    <h5 className="font-bold text-white text-md">{publico[selectedProfile].perfil}</h5>
                    <span className="text-xs font-mono text-cyan-400 bg-cyan-500/5 border border-cyan-500/10 px-2.5 py-0.5 rounded">
                      Average Age: {publico[selectedProfile].idade_media}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed">
                    <div>
                      <span className="text-cyan-400 font-semibold block mb-1">🎯 Objectives / Objetivos:</span>
                      <ul className="list-disc list-inside space-y-1 text-slate-300">
                        {publico[selectedProfile].objetivos?.map((obj: string, i: number) => <li key={i}>{obj}</li>)}
                      </ul>
                    </div>
                    <div>
                      <span className="text-amber-400 font-semibold block mb-1">⚡ Pain Points / Dores:</span>
                      <ul className="list-disc list-inside space-y-1 text-slate-300">
                        {publico[selectedProfile].dores?.map((dor: string, i: number) => <li key={i}>{dor}</li>)}
                      </ul>
                    </div>
                    <div>
                      <span className="text-red-400 font-semibold block mb-1">⚠️ Fears / Medos:</span>
                      <ul className="list-disc list-inside space-y-1 text-slate-300">
                        {publico[selectedProfile].medos?.map((m: string, i: number) => <li key={i}>{m}</li>)}
                      </ul>
                    </div>
                    <div>
                      <span className="text-purple-400 font-semibold block mb-1">🛠️ Difficulties / Dificuldades:</span>
                      <ul className="list-disc list-inside space-y-1 text-slate-300">
                        {publico[selectedProfile].dificuldades?.map((dif: string, i: number) => <li key={i}>{dif}</li>)}
                      </ul>
                    </div>
                  </div>

                  <div className="border-t border-slate-800/60 pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                    <div>
                      <span className="text-slate-500 uppercase block text-[10px]">Knowledge Level</span>
                      <span className="text-white block mt-0.5 capitalize">{publico[selectedProfile].nivel_de_conhecimento}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase block text-[10px]">Recommended Tone</span>
                      <span className="text-white block mt-0.5">{publico[selectedProfile].tom_recomendado}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase block text-[10px]">Recommended Language</span>
                      <span className="text-white block mt-0.5">{publico[selectedProfile].linguagem_rec_comendada || publico[selectedProfile].linguagem_recomendada || "Didática padrão"}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Section: Categories */}
          {activeSection === 'categories' && categorias && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
                <div>
                  <h4 className="text-lg font-bold text-white font-display">Sitemap & Categories Directory</h4>
                  <p className="text-xs text-slate-400">Pre-registered empty categories structured for organizing articles seamlessly.</p>
                </div>
                <span className="text-xs font-mono px-2.5 py-1 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg">
                  {categorias.length} Categories
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {categorias.map((cat, idx) => (
                  <div key={idx} className="p-3 bg-[#0b0f19] border border-slate-800 hover:border-slate-700 rounded-lg transition-all">
                    <span className="text-[10px] font-mono text-cyan-400 block mb-1">slug: /{cat.slug}</span>
                    <h5 className="font-bold text-white text-xs">{cat.nome}</h5>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">{cat.descricao}</p>
                    <div className="mt-2 text-[10px] font-mono text-slate-600">
                      Articles Count: <span className="font-bold text-slate-400">{cat.artigos_count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section: Products */}
          {activeSection === 'products' && produtos && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
                <div>
                  <h4 className="text-lg font-bold text-white font-display">Monetization & Lead Products</h4>
                  <p className="text-xs text-slate-400">Digital assets, guides, simulators, and courses offered to readers.</p>
                </div>
                <span className="text-xs font-mono px-2.5 py-1 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg">
                  {produtos.length} Products
                </span>
              </div>

              <div className="space-y-4">
                {produtos.map((prod, idx) => (
                  <div key={idx} className="p-4 bg-[#0b0f19] border border-slate-800 rounded-lg flex flex-col md:flex-row justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded uppercase">
                          {prod.categoria}
                        </span>
                        {prod.status === "ativo" ? (
                          <span className="text-[9px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-0.2 rounded uppercase font-bold">
                            Active
                          </span>
                        ) : (
                          <span className="text-[9px] font-mono bg-amber-500/10 text-amber-400 px-2 py-0.2 rounded uppercase font-bold">
                            Coming Soon
                          </span>
                        )}
                      </div>
                      <h5 className="font-bold text-white text-sm mt-1">{prod.nome}</h5>
                      <p className="text-xs text-slate-400 leading-relaxed max-w-xl">{prod.descricao}</p>
                    </div>

                    <div className="bg-[#0f172a] border border-slate-800 p-3 rounded-lg md:max-w-xs shrink-0 flex flex-col justify-between">
                      <span className="text-[9px] font-mono text-slate-500 uppercase block">Default CTA / Call-To-Action</span>
                      <p className="text-[10px] text-slate-300 italic mt-1 line-clamp-3">"{prod.cta_padrao}"</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section: Editorial & SEO */}
          {activeSection === 'editorial' && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h4 className="text-lg font-bold text-white font-display">Editorial Guidelines & SEO Rules</h4>
                <p className="text-xs text-slate-400">Strict formatting directives, SEO standards, and content writing guidelines enforced by the system runtime.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Editorial Details */}
                {editorial && (
                  <div className="space-y-4 bg-[#0b0f19] border border-slate-800 p-5 rounded-lg">
                    <h5 className="font-bold text-white text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
                      <PenTool className="h-4 w-4 text-cyan-400" />
                      Editorial & Copywriting Rules
                    </h5>
                    <div className="space-y-3 text-xs">
                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block">TOM DE VOZ</span>
                        <p className="text-slate-300 mt-0.5">{editorial.tom_de_voz}</p>
                      </div>
                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block">NÍVEL TÉCNICO</span>
                        <p className="text-slate-300 mt-0.5">{editorial.nivel_tecnico}</p>
                      </div>
                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block">PROHIBITED CONTENT / CONTEÚDOS PROIBIDOS</span>
                        <ul className="list-disc list-inside space-y-1 text-slate-300 mt-1 max-h-[100px] overflow-y-auto">
                          {editorial.conteudos_proibidos?.map((item: string, i: number) => <li key={i}>{item}</li>)}
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {/* Content Rules Details */}
                {regras && (
                  <div className="space-y-4 bg-[#0b0f19] border border-slate-800 p-5 rounded-lg">
                    <h5 className="font-bold text-white text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
                      <Scale className="h-4 w-4 text-cyan-400" />
                      Integrity Content Rules
                    </h5>
                    <div className="space-y-3.5 text-xs max-h-[250px] overflow-y-auto pr-1">
                      {regras.regras_editoriais?.map((reg: any, i: number) => (
                        <div key={i}>
                          <span className="text-cyan-400 font-bold block">{reg.regra}</span>
                          <p className="text-slate-400 text-[11px] mt-0.5">{reg.descricao}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Writing Style details */}
                {writingStyle && (
                  <div className="space-y-4 bg-[#0b0f19] border border-slate-800 p-5 rounded-lg">
                    <h5 className="font-bold text-white text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
                      <FileText className="h-4 w-4 text-cyan-400" />
                      Writing Layout & Sizing
                    </h5>
                    <div className="space-y-3.5 text-xs">
                      <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                        <div>
                          <span className="text-slate-500">Min Words</span>
                          <span className="text-white block font-bold text-sm">{writingStyle.quantidade_palavras?.minima}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Max Words</span>
                          <span className="text-white block font-bold text-sm">{writingStyle.quantidade_palavras?.maxima}</span>
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block uppercase">Standard Hierarchy / Estrutura H1-H3</span>
                        <div className="mt-1 space-y-2 max-h-[160px] overflow-y-auto pr-1 font-mono text-[10px] text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800">
                          <div><span className="text-cyan-400">H1:</span> {writingStyle.estrutura_padrao?.h1}</div>
                          <div><span className="text-cyan-400">Intro:</span> {writingStyle.estrutura_padrao?.introducao}</div>
                          <div><span className="text-cyan-400">H2:</span> {writingStyle.estrutura_padrao?.h2_desenvolvimento}</div>
                          <div><span className="text-cyan-400">H3:</span> {writingStyle.estrutura_padrao?.h3_detalhes}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* SEO Rules details */}
                {seo && (
                  <div className="space-y-4 bg-[#0b0f19] border border-slate-800 p-5 rounded-lg">
                    <h5 className="font-bold text-white text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
                      <Search className="h-4 w-4 text-cyan-400" />
                      SEO Optimization Standards
                    </h5>
                    <div className="space-y-3 text-xs max-h-[250px] overflow-y-auto pr-1">
                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block uppercase">Meta Title Rules</span>
                        <ul className="list-disc list-inside space-y-1 text-slate-300 mt-1">
                          {seo.meta_title?.regras?.map((reg: string, i: number) => <li key={i} className="text-[11px]">{reg}</li>)}
                        </ul>
                      </div>
                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block uppercase">Meta Description Rules</span>
                        <ul className="list-disc list-inside space-y-1 text-slate-300 mt-1">
                          {seo.meta_description?.regras?.map((reg: string, i: number) => <li key={i} className="text-[11px]">{reg}</li>)}
                        </ul>
                      </div>
                      <div>
                        <span className="text-slate-500 font-mono text-[10px] block uppercase">Internal Links</span>
                        <p className="text-slate-400 text-[11px] mt-0.5">{seo.links_internos?.regras?.join(" ")}</p>
                      </div>
                    </div>
                  </div>
                )}

              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
