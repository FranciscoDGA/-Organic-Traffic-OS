import React, { useState, useEffect } from "react";
import {
  BookOpen, Globe, Link2, Shield, Calendar, Activity, Database, Sparkles,
  Plus, Search, Filter, Loader2, AlertTriangle, CheckCircle2, XCircle,
  HelpCircle, Trash2, ArrowUpRight, History, FileText, Check, ChevronRight, BarChart4
} from "lucide-react";
import { Source, SourceType, SourceHistoryEntry, SourceRelation, SourceRule } from "../../organic-traffic-os/sources/models/source-models";

export function OrganicSources() {
  const [sources, setSources] = useState<Source[]>([]);
  const [categories, setCategories] = useState<SourceType[]>([]);
  const [rules, setRules] = useState<SourceRule[]>([]);
  const [history, setHistory] = useState<SourceHistoryEntry[]>([]);
  const [relations, setRelations] = useState<SourceRelation[]>([]);
  const [selectedSource, setSelectedSource] = useState<Source | null>(null);

  // Search & Filtering
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [minAuthority, setMinAuthority] = useState<number>(0);

  // UI state managers
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Edit fields
  const [isEditing, setIsEditing] = useState(false);
  const [editNome, setEditNome] = useState("");
  const [editUrl, setEditUrl] = useState("");
  const [editTipo, setEditTipo] = useState("");
  const [editCategoria, setEditCategoria] = useState("");
  const [editStatus, setEditStatus] = useState("");
  const [editObservacoes, setEditObservacoes] = useState("");

  // Creation fields
  const [showAddForm, setShowAddForm] = useState(false);
  const [newNome, setNewNome] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newTipo, setNewTipo] = useState("Site Oficial");
  const [newCategoria, setNewCategoria] = useState("Oficial");
  const [newIdioma, setNewIdioma] = useState("pt-BR");
  const [newPais, setNewPais] = useState("BR");
  const [newObservacoes, setNewObservacoes] = useState("");

  // Relational Creation fields
  const [newRelationTargetType, setNewRelationTargetType] = useState("fato");
  const [newRelationTargetId, setNewRelationTargetId] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [sourcesRes, catsRes, rulesRes, histRes, relsRes] = await Promise.all([
        fetch("/api/organic-os/sources"),
        fetch("/api/organic-os/sources/categories"),
        fetch("/api/organic-os/sources/rules"),
        fetch("/api/organic-os/sources/history"),
        fetch("/api/organic-os/sources/relations")
      ]);

      if (!sourcesRes.ok || !catsRes.ok || !rulesRes.ok || !histRes.ok || !relsRes.ok) {
        throw new Error("Falha ao sincronizar dados com o Source Engine.");
      }

      const sourcesData = await sourcesRes.json();
      const catsData = await catsRes.json();
      const rulesData = await rulesRes.json();
      const histData = await histRes.json();
      const relsData = await relsRes.json();

      setSources(sourcesData);
      setCategories(catsData);
      setRules(rulesData);
      setHistory(histData);
      setRelations(relsData);

      if (sourcesData.length > 0 && !selectedSource) {
        setSelectedSource(sourcesData[0]);
      } else if (selectedSource) {
        // keep updated selection
        const fresh = sourcesData.find((s: Source) => s.id === selectedSource.id);
        if (fresh) setSelectedSource(fresh);
      }
    } catch (err: any) {
      setError(err.message || "Erro desconhecido ao obter bibliotecas.");
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNome.trim() || !newUrl.trim()) {
      setError("Por favor, declare o nome e a URL completa da fonte.");
      return;
    }

    setActionLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch("/api/organic-os/sources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceData: {
            nome: newNome,
            url: newUrl,
            tipo: newTipo,
            categoria: newCategoria,
            idioma: newIdioma,
            pais: newPais,
            observacoes: newObservacoes || "Cadastrado manualmente no painel."
          },
          autor: "Diretor Editorial (UI)"
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Erro de validação ou duplicidade de URL.");
      }

      setSuccess("Fonte registrada e catalogada com sucesso na Biblioteca Inteligente.");
      setShowAddForm(false);
      // Reset
      setNewNome("");
      setNewUrl("");
      setNewObservacoes("");

      await fetchData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const startEditing = () => {
    if (!selectedSource) return;
    setEditNome(selectedSource.nome);
    setEditUrl(selectedSource.url);
    setEditTipo(selectedSource.tipo);
    setEditCategoria(selectedSource.categoria);
    setEditStatus(selectedSource.status);
    setEditObservacoes(selectedSource.observacoes);
    setIsEditing(true);
  };

  const handleSaveUpdate = async () => {
    if (!selectedSource) return;
    setActionLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch(`/api/organic-os/sources/${selectedSource.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          updatedData: {
            nome: editNome,
            url: editUrl,
            tipo: editTipo,
            categoria: editCategoria,
            status: editStatus,
            observacoes: editObservacoes,
            ultima_verificacao: new Date().toISOString()
          },
          autor: "Editor Chefe",
          alteracao: "Ajuste manual de parâmetros e recálculo dinâmico de autoridade."
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Erro ao salvar edições.");
      }

      setSuccess("Propriedades da fonte atualizadas e pontuação recalculada.");
      setIsEditing(false);
      await fetchData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleVerifyStatus = async () => {
    if (!selectedSource) return;
    setActionLoading(true);
    setError(null);
    setSuccess(null);

    // Simulated network uptime checker
    const fakeSuccess = Math.random() > 0.15; // 85% success simulation
    const nextStatus = fakeSuccess ? "ativo" : "indisponível";
    const details = fakeSuccess 
      ? "Uptime verificado via cabeçalhos HTTP. Status 200 OK seguro."
      : "Falha na conexão de teste DNS. Timeout de socket excedido.";

    try {
      const res = await fetch(`/api/organic-os/sources/${selectedSource.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          updatedData: {
            status: nextStatus,
            ultima_verificacao: new Date().toISOString()
          },
          autor: "Monitor de Integridade (Robô)",
          alteracao: `Verificação técnica periódica concluída. Resultado: ${details}`
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Erro ao rodar monitoramento.");
      }

      setSuccess(`Monitoramento executado! Status da fonte: '${nextStatus.toUpperCase()}'.`);
      await fetchData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleCreateRelation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSource || !newRelationTargetId.trim()) return;

    setActionLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch("/api/organic-os/sources/relations/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceId: selectedSource.id,
          targetType: newRelationTargetType,
          targetId: newRelationTargetId.trim()
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Falha ao vincular relação.");
      }

      setSuccess(`Vínculo criado! Esta fonte agora está associada à entidade '${newRelationTargetType}' (${newRelationTargetId}).`);
      setNewRelationTargetId("");
      await fetchData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Live validator checks specifically for local display
  const runLiveValidation = (src: Source) => {
    const errs: string[] = [];
    const warns: string[] = [];

    if (!src.nome.trim()) errs.push("O nome descritivo está em branco.");
    if (src.nome.length < 8) warns.push("Nome curto diletante. Recomendamos usar o nome oficial do documento ou órgão.");
    
    if (!src.url.trim()) {
      errs.push("Nenhuma URL declarada.");
    } else {
      if (!src.url.startsWith("https://") && !src.url.startsWith("http://")) {
        errs.push("A URL deve conter protocolo HTTP ou HTTPS.");
      }
      if (!src.url.startsWith("https://")) {
        warns.push("Conexão insegura HTTP identificada. Sugere-se migrar para HTTPS.");
      }
    }

    // Check classification against gov
    const lowerName = src.nome.toLowerCase();
    const lowerUrl = src.url.toLowerCase();
    if ((lowerUrl.includes(".gov.br") || lowerName.includes("diário oficial") || lowerName.includes("lei") || lowerName.includes("ministério") || lowerName.includes("governo")) && src.categoria !== "Oficial") {
      warns.push("Esta fonte aparenta ser um canal ou documento oficial, mas está listada em outra categoria.");
    }

    if (src.status === "indisponível") {
      errs.push("A URL está inacessível ou fora do ar. Verifique a URL.");
    }

    return { errs, warns };
  };

  // Filters logic
  const filteredSources = sources.filter(s => {
    const matchesSearch = s.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.dominio.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "all" || s.tipo.toLowerCase() === selectedType.toLowerCase();
    const matchesStatus = selectedStatus === "all" || s.status.toLowerCase() === selectedStatus.toLowerCase();
    const matchesAuth = s.autoridade >= minAuthority;

    return matchesSearch && matchesType && matchesStatus && matchesAuth;
  });

  // Math metrics
  const avgAuthority = sources.length > 0
    ? Math.round(sources.reduce((acc, s) => acc + s.autoridade, 0) / sources.length)
    : 0;

  const countActive = sources.filter(s => s.status === "ativo").length;
  const countOffline = sources.filter(s => s.status === "indisponível").length;
  const countReview = sources.filter(s => s.status === "revisão").length;

  return (
    <div className="flex flex-col min-h-screen bg-slate-900 text-slate-100 font-sans">
      {/* Top Header Panel */}
      <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-20 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-cyan-950 text-cyan-400 border border-cyan-800 rounded-lg shadow-inner">
            <BookOpen className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center">
              Source Intelligence Engine <span className="ml-2 text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded font-mono">Sprint 14</span>
            </h1>
            <p className="text-xs text-slate-400">Camada de Confiança de Dados e Biblioteca de Fontes Autoritárias do Organic Traffic OS</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-cyan-500 text-slate-950 hover:bg-cyan-400 rounded-lg text-xs font-bold transition flex items-center shadow-lg"
          >
            <Plus className="h-4 w-4 mr-1.5" /> Nova Fonte Regulamentar
          </button>
        </div>
      </header>

      {/* Metrics Row */}
      <section className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 bg-slate-950/40 border-b border-slate-800">
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Fontes Catalogadas</span>
            <div className="text-2xl font-black mt-1 text-white">{sources.length}</div>
          </div>
          <div className="p-3 bg-slate-900 text-cyan-400 border border-slate-800 rounded-lg">
            <Database className="h-5 w-5" />
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Autoridade Média</span>
            <div className="flex items-baseline mt-1 space-x-1">
              <span className="text-2xl font-black text-white">{avgAuthority}</span>
              <span className="text-xs text-emerald-400 font-bold font-mono">/100</span>
            </div>
          </div>
          <div className="p-3 bg-slate-900 text-emerald-400 border border-slate-800 rounded-lg">
            <BarChart4 className="h-5 w-5" />
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Status Ativo</span>
            <div className="text-2xl font-black mt-1 text-cyan-400">{countActive}</div>
          </div>
          <div className="p-3 bg-slate-900 text-cyan-500 border border-slate-800 rounded-lg">
            <Activity className="h-5 w-5 animate-pulse" />
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Fora do Ar / Inativas</span>
            <div className="text-2xl font-black mt-1 text-rose-500">{countOffline}</div>
          </div>
          <div className="p-3 bg-slate-900 text-rose-500 border border-slate-800 rounded-lg">
            <AlertTriangle className="h-5 w-5" />
          </div>
        </div>
      </section>

      {/* Dynamic Alerts */}
      {error && (
        <div className="mx-6 mt-4 p-4 bg-rose-950/40 border border-rose-800/60 text-rose-300 rounded-lg text-sm flex items-center space-x-2">
          <XCircle className="h-5 w-5 flex-shrink-0 text-rose-500" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="mx-6 mt-4 p-4 bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 rounded-lg text-sm flex items-center space-x-2">
          <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-emerald-500" />
          <span>{success}</span>
        </div>
      )}

      {/* Modal / Form overlay mock for Adding New Source */}
      {showAddForm && (
        <div className="mx-6 mt-4 p-6 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl relative">
          <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-800">
            <h3 className="font-bold text-white flex items-center text-sm uppercase tracking-wider">
              <Plus className="h-4 w-4 text-cyan-400 mr-2" /> Catalogar Nova Fonte de Informação Oficial
            </h3>
            <button onClick={() => setShowAddForm(false)} className="text-slate-500 hover:text-slate-300 text-xs">
              Fechar [x]
            </button>
          </div>
          <form onSubmit={handleRegisterSource} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Nome Descritivo Oficial / Documento</label>
              <input
                type="text"
                placeholder="Ex: Regulamento de Benefícios Trabalhistas Previdenciários - INSS Portaria 143"
                value={newNome}
                onChange={(e) => setNewNome(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white focus:ring-1 focus:ring-cyan-500 outline-none"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">URL Completa de Comprovação Técnica</label>
              <input
                type="text"
                placeholder="Ex: https://www.gov.br/inss/pt-br/assuntos/portarias/portaria-143"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white focus:ring-1 focus:ring-cyan-500 outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Tipo de Fonte</label>
              <select
                value={newTipo}
                onChange={(e) => setNewTipo(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white focus:ring-1 focus:ring-cyan-500 outline-none"
              >
                {categories.map(c => (
                  <option key={c.nome} value={c.nome}>{c.nome}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Classificação Macrocategoria</label>
              <select
                value={newCategoria}
                onChange={(e) => setNewCategoria(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white focus:ring-1 focus:ring-cyan-500 outline-none"
              >
                <option value="Oficial">Oficial / Governamental</option>
                <option value="Imprensa">Imprensa / Notícias</option>
                <option value="Acadêmico">Acadêmico / Ciência</option>
                <option value="Técnico">Técnico / Corporativo</option>
                <option value="Outro">Outro / Geral</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Idioma Primário</label>
              <input
                type="text"
                value={newIdioma}
                onChange={(e) => setNewIdioma(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">País de Origem</label>
              <input
                type="text"
                value={newPais}
                onChange={(e) => setNewPais(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white outline-none"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Notas e Observações Internas</label>
              <textarea
                placeholder="Descreva a vigência, finalidade ou notas operacionais para os agentes editores..."
                value={newObservacoes}
                onChange={(e) => setNewObservacoes(e.target.value)}
                rows={2}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white focus:ring-1 focus:ring-cyan-500 outline-none"
              />
            </div>

            <div className="col-span-2 flex justify-end space-x-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded text-xs font-bold"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={actionLoading}
                className="px-4 py-1.5 bg-cyan-500 text-slate-950 hover:bg-cyan-400 rounded text-xs font-bold flex items-center"
              >
                {actionLoading && <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />}
                Calcular Autoridade & Gravar Fonte
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Split Workspace Layout */}
      <div className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Directory Panel (5 cols) */}
        <aside className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-xl shadow-lg flex flex-col overflow-hidden max-h-[800px]">
          {/* Filtering Header */}
          <div className="p-4 bg-slate-900/60 border-b border-slate-800 flex flex-col space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="Filtrar por nome, URL ou domínio..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-1.5 text-slate-300 focus:outline-none"
                >
                  <option value="all">Tipos ({categories.length})</option>
                  {categories.map(c => (
                    <option key={c.nome} value={c.nome}>{c.nome}</option>
                  ))}
                </select>
              </div>
              <div>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-1.5 text-slate-300 focus:outline-none"
                >
                  <option value="all">Qualquer Status</option>
                  <option value="ativo">Ativo</option>
                  <option value="indisponível">Fora do Ar</option>
                  <option value="revisão">Em Revisão</option>
                </select>
              </div>
            </div>

            {/* Authority threshold slider */}
            <div className="pt-1">
              <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                <span>Autoridade Mínima:</span>
                <span className="font-mono font-bold text-cyan-400">{minAuthority} / 100</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={minAuthority}
                onChange={(e) => setMinAuthority(Number(e.target.value))}
                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
            </div>
          </div>

          {/* List content */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-900">
            {filteredSources.map(s => {
              const { errs } = runLiveValidation(s);
              const isSelected = selectedSource?.id === s.id;

              return (
                <div
                  key={s.id}
                  onClick={() => {
                    setSelectedSource(s);
                    setIsEditing(false);
                  }}
                  className={`p-4 cursor-pointer hover:bg-slate-900 transition flex items-start justify-between space-x-3 ${
                    isSelected ? "bg-cyan-950/20 border-l-4 border-cyan-500" : ""
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center space-x-2 mb-1.5">
                      <span className="px-2 py-0.5 bg-slate-900 border border-slate-800 text-slate-400 rounded text-[9px] uppercase tracking-wider font-semibold">
                        {s.tipo}
                      </span>
                      {errs.length > 0 && (
                        <span className="px-1.5 py-0.5 bg-rose-500/15 border border-rose-500/30 text-rose-400 rounded text-[9px] font-bold">
                          Aviso
                        </span>
                      )}
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                        s.status === "ativo" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                        s.status === "indisponível" ? "bg-rose-500/10 text-rose-400 border border-rose-500/20" :
                        "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}>
                        {s.status}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-white leading-relaxed line-clamp-1 mb-1">
                      {s.nome}
                    </h4>

                    <p className="text-[10px] text-slate-500 truncate font-mono">
                      {s.dominio}
                    </p>
                  </div>

                  <div className="flex flex-col items-end justify-between self-stretch">
                    <span className="text-[10px] font-mono text-slate-400">
                      ID: {s.id.substr(0, 8)}
                    </span>
                    <div className="bg-slate-900 border border-slate-800 px-2 py-0.5 rounded flex items-center space-x-1">
                      <span className="text-[9px] uppercase text-slate-500 font-bold">Aut:</span>
                      <span className="text-xs font-mono font-bold text-cyan-400">{s.autoridade}</span>
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredSources.length === 0 && (
              <div className="p-12 text-center text-slate-500 flex flex-col items-center">
                <AlertTriangle className="h-10 w-10 mb-2 stroke-1 text-slate-600" />
                <p className="text-xs">Nenhuma fonte corresponde aos filtros.</p>
              </div>
            )}
          </div>

          <div className="p-3 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center">
            <span>Sincronizado com acervo json</span>
            <span>Ativos: {countActive} / {sources.length}</span>
          </div>
        </aside>

        {/* Right Detail Workspace (7 cols) */}
        <main className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl shadow-lg flex flex-col overflow-hidden max-h-[800px]">
          {selectedSource ? (
            <div className="flex-1 flex flex-col overflow-y-auto">
              
              {/* Workspace Header */}
              <div className="p-6 border-b border-slate-800 bg-slate-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center space-x-2 mb-1.5">
                    <span className="px-2 py-0.5 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded text-[10px] uppercase font-mono font-bold">
                      {selectedSource.categoria}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">ID: {selectedSource.id}</span>
                  </div>
                  <h2 className="text-base font-bold text-white tracking-tight">
                    Auditoria de Fonte Autoritária
                  </h2>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleVerifyStatus}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-bold flex items-center transition"
                    title="Checar ping real-time e Uptime da URL"
                  >
                    <Activity className="h-3.5 w-3.5 mr-1" /> Testar Conexão
                  </button>

                  {!isEditing ? (
                    <button
                      onClick={startEditing}
                      className="px-3 py-1.5 bg-cyan-500 text-slate-950 hover:bg-cyan-400 rounded text-xs font-bold transition flex items-center"
                    >
                      Editar Fonte
                    </button>
                  ) : (
                    <div className="flex space-x-1">
                      <button
                        onClick={() => setIsEditing(false)}
                        className="px-2.5 py-1.5 bg-slate-800 text-slate-300 rounded text-xs font-bold"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={handleSaveUpdate}
                        className="px-3 py-1.5 bg-emerald-500 text-slate-950 rounded text-xs font-bold"
                      >
                        Salvar
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Editing form fields */}
              {isEditing ? (
                <div className="p-6 bg-slate-900/30 border-b border-slate-800 space-y-4">
                  <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wide flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-1 text-amber-500" /> Edição de Registro (Rastreamento Histórico Ativado)
                  </h3>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Nome Descritivo</label>
                    <input
                      type="text"
                      value={editNome}
                      onChange={(e) => setEditNome(e.target.value)}
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-2 text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">URL Completa</label>
                    <input
                      type="text"
                      value={editUrl}
                      onChange={(e) => setEditUrl(e.target.value)}
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-2 text-white outline-none font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Tipo</label>
                      <select
                        value={editTipo}
                        onChange={(e) => setEditTipo(e.target.value)}
                        className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-2 text-white"
                      >
                        {categories.map(c => (
                          <option key={c.nome} value={c.nome}>{c.nome}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Categoria</label>
                      <select
                        value={editCategoria}
                        onChange={(e) => setEditCategoria(e.target.value)}
                        className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-2 text-white"
                      >
                        <option value="Oficial">Oficial</option>
                        <option value="Imprensa">Imprensa</option>
                        <option value="Acadêmico">Acadêmico</option>
                        <option value="Técnico">Técnico</option>
                        <option value="Outro">Outro</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Status</label>
                      <select
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value)}
                        className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-2 text-white"
                      >
                        <option value="ativo">Ativo</option>
                        <option value="indisponível">Fora do Ar</option>
                        <option value="revisão">Em Revisão</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Observações Operacionais</label>
                    <textarea
                      value={editObservacoes}
                      onChange={(e) => setEditObservacoes(e.target.value)}
                      rows={2}
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-2 text-white outline-none"
                    />
                  </div>
                </div>
              ) : (
                <div className="p-6 border-b border-slate-800">
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                    <h3 className="text-sm font-bold text-white mb-2">{selectedSource.nome}</h3>
                    <div className="flex items-center space-x-1 text-xs text-cyan-400 font-mono select-all">
                      <Link2 className="h-3.5 w-3.5 text-slate-500" />
                      <a href={selectedSource.url} target="_blank" rel="noreferrer" className="hover:underline flex items-center">
                        {selectedSource.url} <ArrowUpRight className="h-3 w-3 ml-1" />
                      </a>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
                    <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-900">
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Domínio Principal</span>
                      <p className="text-xs font-mono font-bold text-slate-300 mt-0.5">{selectedSource.dominio}</p>
                    </div>
                    <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-900">
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Idioma / País</span>
                      <p className="text-xs font-bold text-slate-300 mt-0.5">{selectedSource.idioma} / {selectedSource.pais}</p>
                    </div>
                    <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-900">
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Nível Autoridade</span>
                      <p className="text-xs font-bold text-cyan-400 font-mono mt-0.5">{selectedSource.autoridade} %</p>
                    </div>
                    <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-900">
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Último Teste</span>
                      <p className="text-[10px] text-slate-400 mt-0.5" title={selectedSource.ultima_verificacao}>
                        {new Date(selectedSource.ultima_verificacao).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {selectedSource.observacoes && (
                    <div className="mt-4 text-xs text-slate-400 bg-slate-900/30 p-3 rounded-lg border border-slate-900/60 leading-relaxed">
                      <strong>Notas:</strong> {selectedSource.observacoes}
                    </div>
                  )}
                </div>
              )}

              {/* Live Validator Checks */}
              <div className="p-6 border-b border-slate-800">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center">
                  <Shield className="h-4 w-4 mr-1 text-cyan-400" /> Relatório de Auditoria da URL (Live Validator)
                </h3>

                {(() => {
                  const { errs, warns } = runLiveValidation(selectedSource);
                  const isClean = errs.length === 0;

                  return (
                    <div className="space-y-2">
                      <div className={`p-3 rounded-lg border flex items-center space-x-2 ${
                        isClean 
                          ? "bg-emerald-950/20 border-emerald-800/40 text-emerald-400" 
                          : "bg-rose-950/20 border-rose-800/40 text-rose-400"
                      }`}>
                        {isClean ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                        <span className="text-xs font-bold">
                          {isClean 
                            ? "Fonte em conformidade estrita com todos os critérios de estrutura."
                            : "Alerta de inconformidades estruturais ou de conectividade!"
                          }
                        </span>
                      </div>

                      {errs.map((e, idx) => (
                        <div key={idx} className="p-2.5 bg-rose-950/10 border border-rose-900/30 text-rose-300 rounded text-xs flex items-center space-x-2">
                          <XCircle className="h-3.5 w-3.5 text-rose-500 flex-shrink-0" />
                          <span><strong>Restrição:</strong> {e}</span>
                        </div>
                      ))}

                      {warns.map((w, idx) => (
                        <div key={idx} className="p-2.5 bg-amber-950/10 border border-amber-900/30 text-amber-300 rounded text-xs flex items-center space-x-2">
                          <AlertTriangle className="h-3.5 w-3.5 text-amber-500 flex-shrink-0" />
                          <span><strong>Melhoria recomendada:</strong> {w}</span>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>

              {/* Linked Claims & Entities (Relations) */}
              <div className="p-6 border-b border-slate-800">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center justify-between">
                  <span className="flex items-center"><FileText className="h-4 w-4 mr-1.5 text-cyan-400" /> Entidades Relacionadas</span>
                  <span className="text-[10px] font-mono font-bold text-slate-500">Mapeamento Cruzado</span>
                </h3>

                {/* List of current relationships */}
                <div className="space-y-2 mb-4">
                  {(() => {
                    const currentRels = relations.filter(r => r.sourceId === selectedSource.id);
                    if (currentRels.length === 0) {
                      return (
                        <div className="p-4 bg-slate-900/30 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
                          Nenhuma entidade vinculada ainda. Crie uma relação abaixo para auditabilidade.
                        </div>
                      );
                    }

                    return currentRels.map(r => (
                      <div key={r.id} className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                        <div className="flex items-center space-x-2.5">
                          <span className="px-1.5 py-0.5 bg-slate-800 text-[10px] text-cyan-400 font-mono font-bold rounded uppercase">
                            {r.targetType}
                          </span>
                          <span className="text-xs text-white font-mono">{r.targetId}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          Vinculado: {new Date(r.criado_em).toLocaleDateString()}
                        </div>
                      </div>
                    ));
                  })()}
                </div>

                {/* Relation Form Creator */}
                <form onSubmit={handleCreateRelation} className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                  <div>
                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Vincular para Tipo</label>
                    <select
                      value={newRelationTargetType}
                      onChange={(e) => setNewRelationTargetType(e.target.value)}
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-1.5 text-white"
                    >
                      <option value="fato">Fato Técnico</option>
                      <option value="brief">Editorial Brief</option>
                      <option value="blueprint">Page Blueprint</option>
                      <option value="research-pack">Research Pack</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Identificador Alvo (ID)</label>
                    <input
                      type="text"
                      placeholder="Ex: fact-clt-477"
                      value={newRelationTargetId}
                      onChange={(e) => setNewRelationTargetId(e.target.value)}
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded p-1.5 text-white outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 rounded text-xs font-bold transition"
                  >
                    Vincular Entidade
                  </button>
                </form>
              </div>

              {/* History Trail */}
              <div className="p-6">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center">
                  <History className="h-4 w-4 mr-1.5 text-cyan-400" /> Registro de Alterações (Audit Trail)
                </h3>

                <div className="space-y-3 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
                  {(() => {
                    const sourceHistory = history.filter(h => h.sourceId === selectedSource.id);
                    if (sourceHistory.length === 0) {
                      return (
                        <p className="text-xs text-slate-500 italic pl-6">Nenhum histórico registrado para esta fonte.</p>
                      );
                    }

                    // Sort newest first
                    const sorted = [...sourceHistory].sort((a,b) => new Date(b.data).getTime() - new Date(a.data).getTime());

                    return sorted.map(h => (
                      <div key={h.id} className="flex items-start space-x-3 relative pl-1">
                        <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black z-10 ${
                          h.tipo_evento === "registro" ? "bg-cyan-500 text-slate-950" :
                          h.tipo_evento === "inatividade" ? "bg-rose-500 text-white" :
                          h.tipo_evento === "alteracao_url" ? "bg-amber-500 text-slate-950" :
                          "bg-slate-700 text-slate-300"
                        }`}>
                          •
                        </div>
                        <div className="text-xs">
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-white uppercase text-[10px]">{h.tipo_evento}</span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {new Date(h.data).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-slate-300 mt-1">{h.detalhes}</p>
                          <span className="text-[10px] text-slate-500 font-mono">Autor: {h.autor}</span>
                        </div>
                      </div>
                    ));
                  })()}
                </div>
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-12 text-slate-500">
              <BookOpen className="h-12 w-12 text-slate-700 mb-3 stroke-1" />
              <h3 className="font-bold text-slate-400">Nenhuma fonte selecionada</h3>
              <p className="text-xs max-w-sm mt-1">
                Selecione uma fonte técnica ou governamental ao lado para realizar testes de Uptime, conferir o histórico de alterações ou registrar associações de fatos.
              </p>
            </div>
          )}
        </main>
      </div>

      {/* Rules Bottom Display Panel */}
      <footer className="mx-6 mb-6 p-6 bg-slate-950 border border-slate-800 rounded-xl grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center">
            <Shield className="h-4 w-4 mr-1.5 text-cyan-400" /> Regras de Operações e Integridade
          </h3>
          <div className="space-y-2.5">
            {rules.map(r => (
              <div key={r.id} className="p-2.5 bg-slate-900/50 border border-slate-900 rounded-lg flex items-start space-x-2">
                <span className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${r.obrigatoria ? "bg-cyan-400" : "bg-slate-500"}`} />
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center">
                    {r.regra}
                    {r.obrigatoria && (
                      <span className="ml-1.5 text-[8px] bg-cyan-400/10 text-cyan-400 border border-cyan-400/20 px-1 rounded uppercase font-mono">
                        Mandatória
                      </span>
                    )}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{r.descricao}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center">
            <Globe className="h-4 w-4 mr-1.5 text-cyan-400" /> Pesos Básicos por Classificação
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[300px] overflow-y-auto pr-1">
            {categories.map(c => (
              <div key={c.nome} className="p-2 bg-slate-900/40 border border-slate-900 rounded flex justify-between items-center text-xs">
                <div>
                  <span className="font-bold text-slate-200">{c.nome}</span>
                  <p className="text-[9px] text-slate-500 truncate max-w-[140px]">{c.descricao}</p>
                </div>
                <span className="bg-cyan-500/10 text-cyan-400 font-mono font-bold text-[10px] px-1.5 py-0.5 rounded border border-cyan-500/20">
                  Base: {c.peso_base_autoridade}
                </span>
              </div>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
