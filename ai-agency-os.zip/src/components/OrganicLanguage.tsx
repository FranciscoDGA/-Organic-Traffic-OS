import React, { useState, useEffect } from "react";
import { 
  Sparkles, AlignLeft, RefreshCw, CheckCircle2, AlertTriangle, 
  BookOpen, Sliders, Play, FileText, BarChart3, HelpCircle, 
  ArrowRight, ChevronRight, Check, History, Layout, Eye, 
  Code, EyeOff, Award, TrendingUp, Info, Scale
} from "lucide-react";

interface DraftRecord {
  id: string;
  brief_id: string;
  blueprint_id: string;
  titulo: string;
  autor: string;
  data_criacao: string;
  versao: string;
}

interface LanguageRule {
  id: string;
  nome: string;
  descricao: string;
  severidade: string;
  obrigatorio: boolean;
}

interface LanguagePattern {
  nome?: string;
  exemplo?: string;
  tipo?: string;
  de?: string;
  para?: string;
  contexto?: string;
  pergunta?: string;
}

interface LanguageDimension {
  id: string;
  nome: string;
  peso: number;
  descricao: string;
}

interface RefineReport {
  id: string;
  draft_id: string;
  versao: string;
  score_antes: number;
  score_depois: number;
  alteracoes: Array<{
    tipo: string;
    de: string;
    para: string;
    motivo: string;
  }>;
  status: "Excelente" | "Lapidado" | "Requer Revisão Manual";
  observacoes: string;
  scores_detalhados: {
    naturalidade: number;
    fluidez: number;
    legibilidade: number;
    consistencia: number;
    variedade: number;
    experiencia: number;
  };
  regras_validadas: Array<{
    ruleId: string;
    nome: string;
    pass: boolean;
    feedback: string;
  }>;
  refined_title: string;
  refined_content: string;
  data: string;
}

interface ComparisonResult {
  report1: { id: string; score_depois: number; status: string; data: string };
  report2: { id: string; score_depois: number; status: string; data: string };
  differences: {
    score_geral: number;
    naturalidade: number;
    fluidez: number;
    metrics: Record<string, number>;
  };
}

export function OrganicLanguage() {
  const [drafts, setDrafts] = useState<DraftRecord[]>([]);
  const [reports, setReports] = useState<RefineReport[]>([]);
  const [rules, setRules] = useState<LanguageRule[]>([]);
  const [patterns, setPatterns] = useState<Record<string, LanguagePattern[]>>({});
  const [dimensions, setDimensions] = useState<LanguageDimension[]>([]);

  // Selection states
  const [selectedDraftId, setSelectedDraftId] = useState<string>("");
  const [selectedReportId, setSelectedReportId] = useState<string>("");
  const [activeReport, setActiveReport] = useState<RefineReport | null>(null);

  // Compare states
  const [compReport1Id, setCompReport1Id] = useState<string>("");
  const [compReport2Id, setCompReport2Id] = useState<string>("");
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [isComparing, setIsComparing] = useState<boolean>(false);

  // Engine processing states
  const [isRefining, setIsRefining] = useState<boolean>(false);
  const [refineStep, setRefineStep] = useState<string>("");

  // Sub Tab inside Natural Language Engine component
  const [subTab, setSubTab] = useState<"refine" | "compare" | "knowledge">("refine");
  const [textPreviewTab, setTextPreviewTab] = useState<"original" | "refined" | "split">("split");

  // Feedback notifications
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    loadBaselineData();
  }, []);

  const loadBaselineData = async () => {
    try {
      // 1. Fetch Drafts
      const draftsRes = await fetch("/api/organic-os/drafts");
      if (draftsRes.ok) {
        const data = await draftsRes.json();
        setDrafts(data || []);
        if (data.length > 0) {
          setSelectedDraftId(data[0].id);
        }
      }

      // 2. Fetch Rules & Static configurations from engine specs
      const rulesRes = await fetch("/organic-traffic-os/natural-language/rules/language-rules.json");
      if (rulesRes.ok) {
        const data = await rulesRes.json();
        setRules(data.rules || []);
      }

      const patternsRes = await fetch("/organic-traffic-os/natural-language/patterns/language-patterns.json");
      if (patternsRes.ok) {
        const data = await patternsRes.json();
        setPatterns(data.patterns || {});
      }

      const scoresRes = await fetch("/organic-traffic-os/natural-language/rules/language-score.json");
      if (scoresRes.ok) {
        const data = await scoresRes.json();
        setDimensions(data.dimensions || []);
      }

      // 3. Load refinement reports
      await fetchReports();
    } catch (e) {
      console.error("Erro ao carregar configurações de linguagem natural:", e);
    }
  };

  const fetchReports = async () => {
    try {
      const res = await fetch("/api/organic-os/natural-language/reports");
      if (res.ok) {
        const data = await res.json();
        setReports(data || []);
        if (data.length > 0) {
          setSelectedReportId(data[0].id);
          setActiveReport(data[0]);
        }
      }
    } catch (e) {
      console.error("Erro ao obter relatórios de linguagem:", e);
    }
  };

  const showFeedback = (type: "success" | "error", text: string) => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 5000);
  };

  const handleRefine = async () => {
    if (!selectedDraftId) {
      showFeedback("error", "Selecione um rascunho de artigo para refinar.");
      return;
    }

    setIsRefining(true);
    setRefineStep("Carregando o Rascunho...");
    await new Promise(r => setTimeout(r, 600));
    setRefineStep("Carregando Diretrizes de Qualidade da Sprint 19...");
    await new Promise(r => setTimeout(r, 600));
    setRefineStep("Injetando Diagnóstico de Audiência da Sprint 20...");
    await new Promise(r => setTimeout(r, 700));
    setRefineStep("Mapeando clichês de IA e construções artificiais...");
    await new Promise(r => setTimeout(r, 600));
    setRefineStep("Invocando o Redator Humano do Gemini AI...");

    try {
      const res = await fetch("/api/organic-os/natural-language/refine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          draftId: selectedDraftId,
          autor: "Linguista Sênior"
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.report) {
          showFeedback("success", "Refinamento de linguagem concluído e salvo com sucesso!");
          await fetchReports();
          setActiveReport(data.report);
          setSelectedReportId(data.report.id);
        } else {
          showFeedback("error", "Falha ao compilar laudo de refinamento.");
        }
      } else {
        const errData = await res.json();
        showFeedback("error", errData.error || "Erro de servidor ao processar.");
      }
    } catch (e) {
      showFeedback("error", "Erro ao conectar com a API de refinamento.");
    } finally {
      setIsRefining(false);
      setRefineStep("");
    }
  };

  const handleCompare = async () => {
    if (!compReport1Id || !compReport2Id) {
      showFeedback("error", "Selecione duas versões de auditoria para calcular o comparativo.");
      return;
    }
    if (compReport1Id === compReport2Id) {
      showFeedback("error", "Selecione laudos distintos para fins comparativos.");
      return;
    }

    setIsComparing(true);
    try {
      const res = await fetch("/api/organic-os/natural-language/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          report1Id: compReport1Id,
          report2Id: compReport2Id
        })
      });

      if (res.ok) {
        const data = await res.json();
        setComparison(data);
        showFeedback("success", "Comparativo de naturalidade calculado.");
      } else {
        const errData = await res.json();
        showFeedback("error", errData.error || "Erro ao comparar relatórios.");
      }
    } catch (e) {
      showFeedback("error", "Falha de rede ao requisitar comparação.");
    } finally {
      setIsComparing(false);
    }
  };

  const selectReport = (id: string) => {
    setSelectedReportId(id);
    const found = reports.find(r => r.id === id);
    if (found) {
      setActiveReport(found);
    }
  };

  // Find the draft for the active report to get original title/content
  const activeReportDraft = drafts.find(d => d.id === activeReport?.draft_id);

  return (
    <div className="space-y-6" id="natural-language-engine-root">
      
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-cyan-950/20 via-slate-900 to-indigo-950/20 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase font-mono px-2.5 bg-cyan-500/10 text-cyan-400 rounded-full border border-cyan-500/20">
              Sprint 21 Engine
            </span>
            <span className="text-[10px] uppercase font-mono px-2.5 bg-indigo-500/10 text-indigo-400 rounded-full border border-indigo-500/20">
              Copydoc Auditor
            </span>
          </div>
          <h2 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-cyan-400 animate-pulse" />
            Natural Language Engine V1
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Lapidação de estilo, fluidez, ritmo, naturalidade de transições e remoção sistemática de clichês de inteligência artificial. <strong>Fatos, estrutura estratégica e CTAs originais permanecem 100% inalterados.</strong>
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-center">
          <button 
            onClick={() => setSubTab("refine")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all ${
              subTab === "refine" 
                ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-400 shadow-md" 
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300"
            }`}
          >
            Refinamento Ativo
          </button>
          <button 
            onClick={() => {
              setSubTab("compare");
              if (reports.length >= 2 && !compReport1Id && !compReport2Id) {
                setCompReport1Id(reports[reports.length - 1].id);
                setCompReport2Id(reports[0].id);
              }
            }}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all ${
              subTab === "compare" 
                ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-400 shadow-md" 
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300"
            }`}
          >
            Comparar Versões
          </button>
          <button 
            onClick={() => setSubTab("knowledge")}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all ${
              subTab === "knowledge" 
                ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-400 shadow-md" 
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300"
            }`}
          >
            Base de Regras (Core)
          </button>
        </div>
      </div>

      {/* Notifications banner */}
      {feedback && (
        <div className={`p-4 rounded-xl border animate-fade-in flex items-center gap-3 ${
          feedback.type === "success" 
            ? "bg-green-950/20 border-green-500/30 text-green-400" 
            : "bg-red-950/20 border-red-500/30 text-red-400"
        }`}>
          {feedback.type === "success" ? <CheckCircle2 className="h-5 w-5 text-emerald-400" /> : <AlertTriangle className="h-5 w-5 text-red-400" />}
          <span className="text-sm font-medium">{feedback.text}</span>
        </div>
      )}

      {subTab === "refine" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Column 1: Selection & Trigger Console */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <h3 className="text-md font-display font-bold text-white mb-4 flex items-center gap-2 border-b border-slate-800/80 pb-3">
                <Sliders className="h-5 w-5 text-cyan-400" />
                Console de Execução
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                    Selecionar Rascunho de Artigo
                  </label>
                  <select
                    value={selectedDraftId}
                    onChange={(e) => setSelectedDraftId(e.target.value)}
                    className="w-full bg-[#0b0f19] border border-slate-800 rounded-lg py-2.5 px-3 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 font-medium transition-colors"
                  >
                    <option value="">-- Selecione o Rascunho --</option>
                    {drafts.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.titulo} (v{d.versao})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg text-xs text-slate-400 space-y-2.5">
                  <div className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-cyan-400" />
                    <span>Injeta feedback de qualidade (Sprint 19)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-cyan-400" />
                    <span>Injeta requisitos de audiência (Sprint 20)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-cyan-400" />
                    <span>Aplica regras de ritmo e transição</span>
                  </div>
                </div>

                <button
                  onClick={handleRefine}
                  disabled={isRefining}
                  className="w-full mt-2 bg-gradient-to-r from-cyan-500 to-indigo-500 hover:from-cyan-600 hover:to-indigo-600 disabled:from-slate-850 disabled:to-slate-850 disabled:text-slate-500 text-slate-950 font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-all text-sm shadow-lg shadow-cyan-950/20"
                >
                  {isRefining ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin text-slate-500" />
                      <span>Processando Refinador...</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 fill-current" />
                      <span>Executar Refinamento Natural</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Micro Knowledge Card */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <h4 className="text-xs uppercase font-mono text-cyan-400 font-bold mb-3 flex items-center gap-2">
                <Info className="h-4 w-4" />
                Foco do Refinamento
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                O motor se concentra puramente na <strong>estética linguística</strong>. Ele melhora a legibilidade, varia o vocabulário técnico para evitar repetições bobas e cria ganchos agradáveis entre parágrafos, sem que o texto original perca sua densidade informativa ou direcionamento do CTA.
              </p>
              <div className="mt-4 border-t border-slate-800/80 pt-3">
                <span className="text-[10px] uppercase font-mono text-slate-500 block">Padrão de Qualidade:</span>
                <span className="text-xs text-slate-300 font-bold">Fórmula de Legibilidade Flesch-Kincaid Adaptada</span>
              </div>
            </div>
          </div>

          {/* Column 2 & 3: Outputs, Comparative Diff, and History */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Loading Animation Overlay */}
            {isRefining && (
              <div className="bg-[#0f172a] border border-cyan-500/30 rounded-2xl p-12 shadow-2xl flex flex-col items-center justify-center text-center gap-6 min-h-[450px]">
                <div className="relative flex items-center justify-center">
                  <div className="absolute h-16 w-16 rounded-full border-4 border-cyan-500/10 border-t-cyan-400 animate-spin"></div>
                  <Sparkles className="h-7 w-7 text-cyan-400 animate-pulse" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-white">Refinando Linguagem e Fluidez</h3>
                  <p className="text-sm font-mono text-cyan-400 animate-pulse">{refineStep}</p>
                </div>
                <p className="text-xs text-slate-400 max-w-sm mt-4 leading-relaxed">
                  Lapidando o rascunho de artigo sem alterar leis, dados reais ou as diretrizes comerciais. O editor está polindo a harmonia do texto.
                </p>
              </div>
            )}

            {/* Select active report */}
            {!isRefining && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-cyan-400" />
                  <span className="text-sm font-bold text-white">Relatório de Refinamento Ativo:</span>
                </div>
                <select
                  value={selectedReportId}
                  onChange={(e) => selectReport(e.target.value)}
                  className="bg-[#0b0f19] border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 font-medium max-w-xs transition-colors"
                >
                  {reports.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.id} - Rascunho {r.draft_id} (Score: {r.score_depois}%)
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Report Content Panel */}
            {!isRefining && activeReport && (
              <div className="space-y-6">
                
                {/* Score Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Before vs After comparison */}
                  <div className="bg-gradient-to-br from-[#0f172a] to-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between shadow-xl">
                    <span className="text-xs font-mono text-slate-500 uppercase font-semibold">Score de Naturalidade</span>
                    
                    <div className="flex items-center justify-around my-4">
                      <div className="text-center">
                        <span className="text-2xl font-black text-slate-500">{activeReport.score_antes}%</span>
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Antes</span>
                      </div>
                      <ArrowRight className="h-5 w-5 text-slate-600" />
                      <div className="text-center">
                        <span className="text-4xl font-display font-black text-cyan-400">{activeReport.score_depois}%</span>
                        <span className="text-[10px] text-cyan-400 block uppercase font-mono">Depois</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-1">
                      <TrendingUp className="h-4 w-4 text-emerald-400" />
                      <span className="text-xs font-bold text-emerald-400">
                        +{activeReport.score_depois - activeReport.score_antes}% Evolução
                      </span>
                    </div>
                  </div>

                  {/* Dimensions bars */}
                  <div className="md:col-span-2 bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                    <h4 className="text-xs font-mono uppercase text-slate-400 font-bold mb-3 flex items-center gap-2">
                      <BarChart3 className="h-4 w-4 text-cyan-400" />
                      Indicadores de Linguagem
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3">
                      {Object.entries(activeReport.scores_detalhados).map(([key, val]) => {
                        const scoreVal = val as number;
                        const labelMap: Record<string, string> = {
                          naturalidade: "Naturalidade Geral",
                          fluidez: "Conexões e Fluidez",
                          legibilidade: "Legibilidade (Flesch)",
                          consistencia: "Consistência de Tom",
                          variedade: "Vocabulário/Sinônimos",
                          experiencia: "Experiência de Leitura"
                        };

                        return (
                          <div key={key} className="space-y-1">
                            <div className="flex justify-between items-center text-[11px]">
                              <span className="text-slate-300 font-medium">{labelMap[key] || key}</span>
                              <span className="font-mono text-cyan-400 font-bold">{scoreVal}%</span>
                            </div>
                            <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800">
                              <div 
                                className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full transition-all duration-1000"
                                style={{ width: `${scoreVal}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>

                {/* Text Split Screen Comparison Block */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-xl">
                  <div className="bg-slate-900 border-b border-slate-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-cyan-400" />
                      <h4 className="text-sm font-bold text-white">Visualização de Texto Lapidado</h4>
                    </div>

                    <div className="flex bg-[#0b0f19] border border-slate-800 rounded-lg p-1">
                      <button
                        onClick={() => setTextPreviewTab("original")}
                        className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                          textPreviewTab === "original" ? "bg-slate-800 text-slate-200" : "text-slate-500 hover:text-slate-400"
                        }`}
                      >
                        Original (Rascunho)
                      </button>
                      <button
                        onClick={() => setTextPreviewTab("refined")}
                        className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                          textPreviewTab === "refined" ? "bg-slate-800 text-cyan-400" : "text-slate-500 hover:text-slate-400"
                        }`}
                      >
                        Linguagem Refinada
                      </button>
                      <button
                        onClick={() => setTextPreviewTab("split")}
                        className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                          textPreviewTab === "split" ? "bg-slate-800 text-cyan-400" : "text-slate-500 hover:text-slate-400"
                        }`}
                      >
                        Lado a Lado
                      </button>
                    </div>
                  </div>

                  <div className="p-4 bg-[#0b0f19] min-h-[300px] max-h-[500px] overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed select-text">
                    
                    {textPreviewTab === "original" && (
                      <div className="space-y-4">
                        <h5 className="font-bold text-slate-200 text-sm border-b border-slate-850 pb-2">Título: {activeReportDraft?.titulo || "Carregando original..."}</h5>
                        <p className="whitespace-pre-wrap">{activeReportDraft?.id ? "Conteúdo extraído do Rascunho original. Veja abaixo o corpo inteiro..." : "Original não carregado."}</p>
                        <p className="whitespace-pre-wrap text-slate-400 italic">Nota: Para fins de visualização unificada, use a opção 'Lado a Lado' ou 'Linguagem Refinada'.</p>
                      </div>
                    )}

                    {textPreviewTab === "refined" && (
                      <div className="space-y-4">
                        <h5 className="font-bold text-cyan-400 text-sm border-b border-slate-850 pb-2">Título Refinado: {activeReport.refined_title}</h5>
                        <div className="whitespace-pre-wrap p-3 bg-[#0a0d16] border border-cyan-950/40 rounded-lg text-slate-200 leading-relaxed">
                          {activeReport.refined_content}
                        </div>
                      </div>
                    )}

                    {textPreviewTab === "split" && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-3 bg-slate-950 rounded-lg border border-slate-850 space-y-3">
                          <span className="text-[10px] font-mono uppercase text-slate-500 block border-b border-slate-850 pb-1 font-bold">Rascunho Inicial</span>
                          <h6 className="font-bold text-slate-400">{activeReportDraft?.titulo || "Rascunho Original"}</h6>
                          <p className="text-[11px] text-slate-500 italic mt-2">Corpo do rascunho antes da lapidação de fluidez.</p>
                          <div className="text-[11px] text-slate-400 h-64 overflow-y-auto whitespace-pre-wrap leading-relaxed pr-2">
                            {activeReport.refined_content ? "Veja à direita a versão lapidada com clichês limpos, transições suaves, sinônimos rebuscados e CTAs intactos." : "Nenhum dado."}
                          </div>
                        </div>

                        <div className="p-3 bg-cyan-950/10 rounded-lg border border-cyan-500/20 space-y-3">
                          <span className="text-[10px] font-mono uppercase text-cyan-400 block border-b border-cyan-500/20 pb-1 font-bold">Versão Refinada (Gemini AI)</span>
                          <h6 className="font-bold text-cyan-200">{activeReport.refined_title}</h6>
                          <div className="text-[11px] text-slate-200 h-64 overflow-y-auto whitespace-pre-wrap leading-relaxed pr-2 font-sans">
                            {activeReport.refined_content}
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                </div>

                {/* Staggered changes log list */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                  <h3 className="text-sm font-display font-bold text-white mb-4 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-cyan-400" />
                    Melhorias Editoriais Detalhadas (Lapidações)
                  </h3>

                  <div className="space-y-3">
                    {activeReport.alteracoes.map((alt, i) => (
                      <div key={i} className="bg-slate-900 border border-slate-850 p-4 rounded-lg space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded text-[10px] font-mono uppercase font-bold border border-cyan-500/20">
                            {alt.tipo}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500 font-semibold">Modificação #{i+1}</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                          <div className="text-slate-400 line-through bg-red-950/10 border border-red-500/10 p-2 rounded">
                            "{alt.de}"
                          </div>
                          <div className="text-emerald-300 font-medium bg-emerald-950/10 border border-emerald-500/10 p-2 rounded">
                            "{alt.para}"
                          </div>
                        </div>
                        <p className="text-[11px] text-slate-400 italic font-mono pt-1">
                          <strong>Motivo:</strong> {alt.motivo}
                        </p>
                      </div>
                    ))}
                    {activeReport.alteracoes.length === 0 && (
                      <p className="text-center text-xs text-slate-500 py-4">Nenhuma alteração pontual detalhada registrada.</p>
                    )}
                  </div>
                </div>

                {/* Rule Validation Checklist */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
                  <h3 className="text-sm font-display font-bold text-white mb-4 flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-cyan-400" />
                    Validações Estritas de Redação Natural
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeReport.regras_validadas.map(rule => (
                      <div 
                        key={rule.ruleId} 
                        className={`p-3.5 rounded-lg border flex gap-3 transition-colors ${
                          rule.pass 
                            ? "bg-emerald-950/10 border-emerald-500/20 text-slate-300" 
                            : "bg-red-950/10 border-red-500/20 text-slate-300"
                        }`}
                      >
                        <div className="mt-0.5">
                          {rule.pass ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertTriangle className="h-5 w-5 text-red-400 shrink-0" />
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-mono uppercase bg-slate-900 px-1.5 py-0.5 rounded text-slate-500 border border-slate-800 font-bold">
                              {rule.ruleId}
                            </span>
                            <span className="text-xs font-bold text-white">{rule.nome}</span>
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
                            {rule.feedback}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Historico & General diagnostic box */}
                <div className="bg-gradient-to-br from-[#0f172a] to-cyan-950/10 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-display font-bold text-white mb-2 flex items-center gap-2">
                      <Scale className="h-5 w-5 text-cyan-400" />
                      Diagnóstico Geral do Revisor
                    </h3>
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 leading-relaxed font-mono whitespace-pre-wrap select-text">
                      {activeReport.observacoes}
                    </div>
                  </div>

                  <div className="border-t border-slate-800/80 pt-3 mt-4 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>Laudo ID: {activeReport.id}</span>
                    <span>Versão: {activeReport.versao}</span>
                    <span>Lapidado em: {new Date(activeReport.data).toLocaleDateString()}</span>
                  </div>
                </div>

              </div>
            )}
          </div>

        </div>
      )}

      {subTab === "compare" && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-6">
          <div>
            <h3 className="text-md font-display font-bold text-white mb-1 flex items-center gap-2">
              <History className="h-5 w-5 text-cyan-400" />
              Comparador de Versões e Naturalidade
            </h3>
            <p className="text-xs text-slate-400">
              Analise detalhadamente as melhorias e notas ao carregar duas execuções de refinamento linguístico do PassaCumaru.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end border-b border-slate-800/80 pb-6">
            <div>
              <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                Laudo de Versão Anterior (A)
              </label>
              <select
                value={compReport1Id}
                onChange={(e) => setCompReport1Id(e.target.value)}
                className="w-full bg-[#0b0f19] border border-slate-800 rounded-lg py-2.5 px-3 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 font-medium"
              >
                <option value="">-- Selecione o Laudo A --</option>
                {reports.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.id} - Rascunho {r.draft_id} (Score: {r.score_depois}%)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs uppercase font-mono text-slate-400 block mb-1.5 font-semibold">
                Laudo de Versão Recente (B)
              </label>
              <select
                value={compReport2Id}
                onChange={(e) => setCompReport2Id(e.target.value)}
                className="w-full bg-[#0b0f19] border border-slate-800 rounded-lg py-2.5 px-3 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 font-medium"
              >
                <option value="">-- Selecione o Laudo B --</option>
                {reports.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.id} - Rascunho {r.draft_id} (Score: {r.score_depois}%)
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleCompare}
              disabled={isComparing}
              className="bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-all text-sm h-[42px] shadow-lg shadow-cyan-950/20"
            >
              {isComparing ? <RefreshCw className="h-4 w-4 animate-spin text-slate-500" /> : <History className="h-4 w-4" />}
              <span>Calcular Comparativo</span>
            </button>
          </div>

          {comparison ? (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center">
                  <span className="text-[10px] uppercase font-mono text-slate-500 font-bold block mb-1">Versão Anterior (Laudo A)</span>
                  <span className="text-[11px] font-mono text-slate-400 block mb-3">{comparison.report1.id}</span>
                  <div className="text-3xl font-black text-slate-400">{comparison.report1.score_depois}%</div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 px-2.5 py-0.5 rounded bg-slate-950 border border-slate-850 inline-block mt-3">
                    {comparison.report1.status}
                  </span>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center">
                  <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold block mb-1">Versão Recente (Laudo B)</span>
                  <span className="text-[11px] font-mono text-slate-400 block mb-3">{comparison.report2.id}</span>
                  <div className="text-3xl font-black text-cyan-400">{comparison.report2.score_depois}%</div>
                  <span className="text-[10px] uppercase font-bold text-cyan-400 px-2.5 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20 inline-block mt-3">
                    {comparison.report2.status}
                  </span>
                </div>

                <div className="bg-gradient-to-br from-cyan-950/20 to-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col items-center justify-center text-center">
                  <span className="text-[10px] uppercase font-mono text-indigo-400 font-bold block mb-2">Evolução do Ritmo</span>
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className="h-6 w-6 text-emerald-400 animate-pulse" />
                    <span className={`text-4xl font-display font-black ${
                      comparison.differences.score_geral >= 0 ? "text-emerald-400" : "text-red-400"
                    }`}>
                      {comparison.differences.score_geral >= 0 ? "+" : ""}{comparison.differences.score_geral}%
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-2 font-medium">
                    Aperfeiçoamento na fluidez e naturalidade sintática.
                  </p>
                </div>

              </div>

              {/* Specific dimension differences */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                <h4 className="text-xs uppercase font-mono text-slate-400 font-bold mb-4 flex items-center gap-2">
                  <Sliders className="h-4 w-4 text-cyan-400" />
                  Evolução por Dimensões Linguísticas
                </h4>

                <div className="space-y-3.5">
                  {Object.entries(comparison.differences.metrics).map(([key, rawDiff]) => {
                    const diffVal = rawDiff as number;
                    const labelMap: Record<string, string> = {
                      naturalidade: "Naturalidade Geral",
                      fluidez: "Conexões e Fluidez",
                      legibilidade: "Legibilidade (Flesch)",
                      consistencia: "Consistência de Tom",
                      variedade: "Vocabulário/Sinônimos",
                      experiencia: "Experiência de Leitura"
                    };

                    return (
                      <div key={key} className="flex items-center justify-between p-3 bg-[#0b0f19] rounded-lg border border-slate-850 text-xs">
                        <span className="font-bold text-slate-300">{labelMap[key] || key}</span>
                        <span className={`font-mono font-bold px-2.5 py-0.5 rounded text-[11px] ${
                          diffVal > 0 
                            ? "bg-emerald-500/10 text-emerald-400" 
                            : diffVal < 0 
                              ? "bg-red-500/10 text-red-400" 
                              : "bg-slate-950 text-slate-500"
                        }`}>
                          {diffVal > 0 ? "+" : ""}{diffVal}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          ) : (
            <div className="text-center p-12 bg-slate-900/60 border border-slate-850 rounded-xl text-slate-500 text-xs">
              Selecione dois relatórios acima para avaliar a evolução de legibilidade e ritmo.
            </div>
          )}

        </div>
      )}

      {subTab === "knowledge" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Rules list */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-sm font-display font-bold text-white flex items-center gap-2">
                <Scale className="h-5 w-5 text-cyan-400" />
                Regras de Escrita Natural (language-rules.json)
              </h3>
              <p className="text-xs text-slate-400 mt-1">Diretrizes estritas seguidas pelo motor em cada refinamento.</p>
            </div>

            <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
              {rules.map((rule) => (
                <div key={rule.id} className="p-3.5 bg-slate-900 border border-slate-850 rounded-lg space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase bg-slate-950 px-2 py-0.5 border border-slate-800 rounded text-cyan-400 font-bold">
                      {rule.id}
                    </span>
                    <span className={`text-[9px] uppercase font-mono px-2 py-0.5 rounded font-bold ${
                      rule.severidade === "Critica" 
                        ? "bg-red-500/10 text-red-400 border border-red-500/20" 
                        : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                    }`}>
                      {rule.severidade}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">{rule.nome}</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-medium">{rule.descricao}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Model and patterns list */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-sm font-display font-bold text-white flex items-center gap-2">
                <Layout className="h-5 w-5 text-cyan-400" />
                Padrões e Conectivos Recomendados (language-patterns.json)
              </h3>
              <p className="text-xs text-slate-400 mt-1">Biblioteca sintática humana aplicada para polimento.</p>
            </div>

            <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
              {patterns.aberturas && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold block">Aberturas de Alto Impacto</span>
                  {patterns.aberturas.map((ab, i) => (
                    <div key={i} className="p-3 bg-slate-900 border border-slate-850 rounded-lg text-xs space-y-1">
                      <div className="flex justify-between text-[10px] font-mono text-slate-500">
                        <span>Modelo: <strong>{ab.nome}</strong></span>
                        <span className="text-cyan-400">{ab.tipo}</span>
                      </div>
                      <p className="italic text-slate-300 font-mono">"{ab.exemplo}"</p>
                    </div>
                  ))}
                </div>
              )}

              {patterns.transicoes && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold block">Conectivos & Transições Substitutas</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {patterns.transicoes.map((tr, i) => (
                      <div key={i} className="p-3 bg-slate-900 border border-slate-850 rounded-lg text-xs space-y-1">
                        <div className="flex items-center gap-2 text-[10px] font-mono">
                          <span className="text-red-400 line-through">{tr.de}</span>
                          <ArrowRight className="h-3 w-3 text-slate-500" />
                          <span className="text-emerald-400 font-bold">{tr.para}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-normal">{tr.contexto}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {patterns.blocos_explicativos && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold block">Analogias e Didática</span>
                  {patterns.blocos_explicativos.map((bl, i) => (
                    <div key={i} className="p-3 bg-slate-900 border border-slate-850 rounded-lg text-xs space-y-1">
                      <div className="flex justify-between text-[10px] font-mono text-slate-500">
                        <span>Foco: <strong>{bl.nome}</strong></span>
                        <span className="text-cyan-400">{bl.tipo}</span>
                      </div>
                      <p className="italic text-slate-300 font-mono">"{bl.exemplo}"</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
