import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Search, 
  Award, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  RefreshCw, 
  HelpCircle, 
  History, 
  User, 
  Calendar, 
  ChevronRight, 
  Sparkles, 
  Link, 
  BookOpen, 
  Save, 
  Edit3, 
  ArrowLeft,
  XCircle,
  Hash,
  PenTool
} from "lucide-react";
import { EditorialBrief, BriefScore } from "../../organic-traffic-os/briefs/models/brief-models";
import { EditorialItem } from "../../organic-traffic-os/editorial/models/editorial-models";

export function OrganicBriefs() {
  const [briefs, setBriefs] = useState<EditorialBrief[]>([]);
  const [editorialItems, setEditorialItems] = useState<EditorialItem[]>([]);
  const [selectedBrief, setSelectedBrief] = useState<EditorialBrief | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [genLoadingId, setGenLoadingId] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<"geral" | "intent" | "seo" | "outline" | "entities" | "links" | "rules">("geral");
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [filterCluster, setFilterCluster] = useState<string>("Todos");
  const [filterCategory, setFilterCategory] = useState<string>("Todos");

  // Form states for editing
  const [editTitle, setEditTitle] = useState("");
  const [editObjective, setEditObjective] = useState("");
  const [editPrimaryIntent, setEditPrimaryIntent] = useState("");
  const [editMetaTitle, setEditMetaTitle] = useState("");
  const [editMetaDesc, setEditMetaDesc] = useState("");
  const [editSlug, setEditSlug] = useState("");
  const [editPrimaryKw, setEditPrimaryKw] = useState("");
  const [editSecKws, setEditSecKws] = useState("");
  const [editEntities, setEditEntities] = useState("");
  const [editQuestions, setEditQuestions] = useState("");
  const [editAuthor, setEditAuthor] = useState("Editor-Chefe Engine");

  // Load briefs and planned items
  const loadData = async () => {
    setLoading(true);
    try {
      const resBriefs = await fetch("/api/organic-os/briefs");
      const dataBriefs = await resBriefs.json();
      setBriefs(Array.isArray(dataBriefs) ? dataBriefs : []);

      const resEditorial = await fetch("/api/organic-os/editorial");
      const dataEditorial = await resEditorial.json();
      setEditorialItems(Array.isArray(dataEditorial.items) ? dataEditorial.items : []);
    } catch (e) {
      console.error("Erro ao carregar dados dos Briefings:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Update form values when selected brief changes
  useEffect(() => {
    if (selectedBrief) {
      setEditTitle(selectedBrief.titulo);
      setEditObjective(selectedBrief.objetivo);
      setEditPrimaryIntent(selectedBrief.search_intent?.intencao_principal || "");
      setEditMetaTitle(selectedBrief.seo?.meta_title || "");
      setEditMetaDesc(selectedBrief.seo?.meta_description || "");
      setEditSlug(selectedBrief.seo?.slug || "");
      setEditPrimaryKw(selectedBrief.seo?.keyword_principal || "");
      setEditSecKws((selectedBrief.seo?.keywords_secundarias || []).join(", "));
      setEditEntities((selectedBrief.entities?.entidades_obrigatorias || []).join(", "));
      setEditQuestions((selectedBrief.questions?.perguntas_obrigatorias || []).join("\n"));
      setEditAuthor(selectedBrief.autor || "Editor-Chefe Engine");
    }
  }, [selectedBrief]);

  // Generate a new brief
  const handleGenerateBrief = async (itemId: string) => {
    setGenLoadingId(itemId);
    try {
      const res = await fetch("/api/organic-os/briefs/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ editorialItemId: itemId })
      });
      const data = await res.json();
      if (data.success && data.brief) {
        setBriefs(prev => [data.brief, ...prev]);
        setSelectedBrief(data.brief);
        setActiveSubTab("geral");
        // Reload planning items to refresh statuses if needed
        const resEditorial = await fetch("/api/organic-os/editorial");
        const dataEditorial = await resEditorial.json();
        setEditorialItems(Array.isArray(dataEditorial.items) ? dataEditorial.items : []);
      } else {
        alert("Erro ao gerar brief: " + (data.error || "Erro desconhecido"));
      }
    } catch (err: any) {
      alert("Erro ao comunicar com o servidor: " + err.message);
    } finally {
      setGenLoadingId(null);
    }
  };

  // Save / Update & Version Brief
  const handleSaveBrief = async () => {
    if (!selectedBrief) return;

    setLoading(true);
    try {
      const updatedData: Partial<EditorialBrief> = {
        titulo: editTitle,
        objetivo: editObjective,
        search_intent: {
          ...(selectedBrief.search_intent || {}),
          intencao_principal: editPrimaryIntent
        },
        seo: {
          ...(selectedBrief.seo || {}),
          meta_title: editMetaTitle,
          meta_description: editMetaDesc,
          slug: editSlug,
          keyword_principal: editPrimaryKw,
          keywords_secundarias: editSecKws.split(",").map(x => x.trim()).filter(Boolean)
        },
        entities: {
          ...(selectedBrief.entities || {}),
          entidades_obrigatorias: editEntities.split(",").map(x => x.trim()).filter(Boolean)
        },
        questions: {
          ...(selectedBrief.questions || {}),
          perguntas_obrigatorias: editQuestions.split("\n").map(x => x.trim()).filter(Boolean)
        }
      };

      const res = await fetch(`/api/organic-os/briefs/${selectedBrief.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          updatedData,
          autor: editAuthor || "Co-Pilot Editor"
        })
      });

      const data = await res.json();
      if (data.success && data.brief) {
        // Replace in briefs array
        setBriefs(prev => prev.map(b => b.id === data.brief.id ? data.brief : b));
        setSelectedBrief(data.brief);
        setIsEditing(false);
      } else {
        alert("Erro ao atualizar brief: " + (data.error || "Erro desconhecido"));
      }
    } catch (e: any) {
      alert("Erro ao salvar o briefing: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  // Get distinct clusters and categories for filtering
  const clusters = ["Todos", ...Array.from(new Set(editorialItems.map(item => item.cluster)))];
  const categories = ["Todos", ...Array.from(new Set(editorialItems.map(item => item.categoria)))];

  // Filtering planned items
  const filteredPlanned = editorialItems.filter(item => {
    const hasBrief = briefs.some(b => b.id === `brief-${item.id}`);
    const matchesCluster = filterCluster === "Todos" || item.cluster === filterCluster;
    const matchesCategory = filterCategory === "Todos" || item.categoria === filterCategory;
    return !hasBrief && matchesCluster && matchesCategory;
  });

  const filteredBriefs = briefs.filter(brief => {
    const matchesCluster = filterCluster === "Todos" || brief.cluster === filterCluster;
    const matchesCategory = filterCategory === "Todos" || brief.categoria === filterCategory;
    return matchesCluster && matchesCategory;
  });

  // Calculate Average Score
  const averageScore = filteredBriefs.length > 0
    ? Math.round(filteredBriefs.reduce((sum, b) => sum + (b.score?.geral || 0), 0) / filteredBriefs.length)
    : 0;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <PenTool className="h-6 w-6 text-cyan-400" />
            Brief Intelligence Engine V1
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Editor-Chefe: Geração inteligente, auditoria de SEO, score de conteúdo e versionamento inviolável para o futuro Agente Escritor.
          </p>
        </div>
        <button
          onClick={loadData}
          disabled={loading}
          className="flex items-center gap-2 bg-slate-900 border border-slate-800 text-slate-300 px-4 py-2 rounded-lg text-sm hover:bg-slate-800 transition disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin text-cyan-400" : ""}`} />
          Recarregar Painel
        </button>
      </div>

      {/* Aggregate Metrics Dashboard */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-cyan-950/40 rounded-lg border border-cyan-800/30">
            <FileText className="h-5 w-5 text-cyan-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-200">{briefs.length}</div>
            <div className="text-xs text-slate-500 uppercase tracking-wider font-medium">Briefings Premium</div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-yellow-950/40 rounded-lg border border-yellow-800/30">
            <Plus className="h-5 w-5 text-yellow-500 animate-pulse" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-200">{filteredPlanned.length}</div>
            <div className="text-xs text-slate-500 uppercase tracking-wider font-medium">Aguardando Brief</div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-emerald-950/40 rounded-lg border border-emerald-800/30">
            <Award className="h-5 w-5 text-emerald-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-200">
              {filteredBriefs.filter(b => b.score?.geral >= 80).length}
            </div>
            <div className="text-xs text-slate-500 uppercase tracking-wider font-medium">Briefs Excelentes (Score ≥ 80)</div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-purple-950/40 rounded-lg border border-purple-800/30">
            <Hash className="h-5 w-5 text-purple-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-200">{averageScore}%</div>
            <div className="text-xs text-slate-500 uppercase tracking-wider font-medium">Média de Content Score</div>
          </div>
        </div>
      </div>

      {/* Quick Filter Section */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <label className="block text-xs font-mono text-slate-500 uppercase mb-1.5">Silo / Cluster Semântico</label>
          <select
            value={filterCluster}
            onChange={(e) => setFilterCluster(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500"
          >
            {clusters.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div className="flex-1">
          <label className="block text-xs font-mono text-slate-500 uppercase mb-1.5">Categoria Editorial</label>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-lg py-2 px-3 text-sm focus:outline-none focus:border-cyan-500"
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Layout Area */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left Hand Lists (Ready Briefs & Backlog) */}
        <div className="xl:col-span-5 space-y-6">
          
          {/* Section: Premium Briefs List */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
            <div className="bg-slate-900/60 px-4 py-3 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="h-4 w-4" />
                Briefings Prontos ({filteredBriefs.length})
              </h3>
              <span className="text-[10px] bg-cyan-950/50 border border-cyan-800/40 text-cyan-400 px-2 py-0.5 rounded-full font-mono">
                Editoria
              </span>
            </div>
            
            <div className="divide-y divide-slate-800/60 max-h-[350px] overflow-y-auto">
              {filteredBriefs.length === 0 ? (
                <div className="p-6 text-center text-slate-500 text-sm">
                  Nenhum briefing gerado com estes filtros.
                </div>
              ) : (
                filteredBriefs.map(brief => {
                  const scoreGeral = brief.score?.geral || 0;
                  const isSelected = selectedBrief?.id === brief.id;
                  
                  return (
                    <div
                      key={brief.id}
                      onClick={() => {
                        setSelectedBrief(brief);
                        setIsEditing(false);
                      }}
                      className={`p-4 transition cursor-pointer flex justify-between items-center gap-3 ${
                        isSelected 
                          ? "bg-cyan-950/20 border-l-4 border-cyan-400" 
                          : "hover:bg-slate-900/40"
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase ${
                            brief.tipo === "pilar" 
                              ? "bg-purple-950/40 border border-purple-800/30 text-purple-400" 
                              : "bg-slate-800 text-slate-300"
                          }`}>
                            {brief.tipo}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">v{brief.versao}</span>
                        </div>
                        <h4 className="font-semibold text-sm text-slate-200 mt-1 truncate">{brief.titulo}</h4>
                        <p className="text-xs text-slate-500 truncate mt-0.5">{brief.cluster}</p>
                      </div>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <span className={`text-xs font-bold font-mono px-2 py-1 rounded border ${
                          scoreGeral >= 80 
                            ? "bg-emerald-950/20 border-emerald-800/40 text-emerald-400" 
                            : scoreGeral >= 60 
                            ? "bg-yellow-950/20 border-yellow-800/40 text-yellow-400"
                            : "bg-red-950/20 border-red-800/40 text-red-400"
                        }`}>
                          {scoreGeral}%
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">Score</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Section: Awaiting Brief (Planned backlog items) */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
            <div className="bg-slate-900/60 px-4 py-3 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-xs font-mono font-bold text-yellow-500 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="h-4 w-4" />
                Planejados sem Briefing ({filteredPlanned.length})
              </h3>
              <span className="text-[10px] bg-yellow-950/50 border border-yellow-800/40 text-yellow-500 px-2 py-0.5 rounded-full font-mono">
                Backlog
              </span>
            </div>

            <div className="divide-y divide-slate-800/60 max-h-[350px] overflow-y-auto">
              {filteredPlanned.length === 0 ? (
                <div className="p-6 text-center text-slate-500 text-sm">
                  Tudo planejado já possui briefing! Pronto para escrever.
                </div>
              ) : (
                filteredPlanned.map(item => {
                  const isGenerating = genLoadingId === item.id;
                  
                  return (
                    <div key={item.id} className="p-4 hover:bg-slate-900/30 transition flex justify-between items-center gap-4">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold uppercase ${
                            item.tipo === "pilar" 
                              ? "bg-purple-950/30 text-purple-400 border border-purple-900/30" 
                              : "bg-slate-800 text-slate-300"
                          }`}>
                            {item.tipo}
                          </span>
                          <span className="text-[10px] text-slate-500">{item.categoria}</span>
                        </div>
                        <h4 className="font-semibold text-sm text-slate-300 mt-1 truncate">{item.titulo}</h4>
                        <p className="text-xs text-slate-500 truncate mt-0.5">Silo: {item.cluster}</p>
                      </div>
                      <button
                        onClick={() => handleGenerateBrief(item.id)}
                        disabled={isGenerating || genLoadingId !== null}
                        className="shrink-0 flex items-center gap-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 px-3 py-1.5 rounded-lg text-xs font-bold shadow-lg shadow-cyan-500/10 transition disabled:opacity-50"
                      >
                        {isGenerating ? (
                          <>
                            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                            Engine...
                          </>
                        ) : (
                          <>
                            <Sparkles className="h-3.5 w-3.5" />
                            Briefing
                          </>
                        )}
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>

        {/* Right Hand Detailed View or Editing View */}
        <div className="xl:col-span-7">
          
          {selectedBrief ? (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-xl flex flex-col min-h-[600px]">
              
              {/* Header of Detailed View */}
              <div className="p-6 border-b border-slate-800 bg-slate-900/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/50 px-2 py-0.5 rounded uppercase">
                        {selectedBrief.tipo}
                      </span>
                      <span className="text-xs text-slate-500 font-mono">v{selectedBrief.versao}</span>
                      <span className="text-xs text-slate-500 font-mono">• {selectedBrief.cluster}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-slate-100 mt-2">
                      {isEditing ? "Editar Briefing Editorial" : selectedBrief.titulo}
                    </h3>
                  </div>

                  <div className="flex gap-2 self-start sm:self-center">
                    {isEditing ? (
                      <>
                        <button
                          onClick={() => setIsEditing(false)}
                          className="px-4 py-2 border border-slate-800 hover:bg-slate-900 text-slate-400 text-xs font-semibold rounded-lg transition"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={handleSaveBrief}
                          className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 text-xs font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500 shadow-md shadow-cyan-500/10 transition"
                        >
                          <Save className="h-3.5 w-3.5" />
                          Salvar Versão (v{selectedBrief.versao + 1})
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => setIsEditing(true)}
                        className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-400 px-4 py-2 rounded-lg text-xs font-bold transition"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                        Editar Briefing
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {isEditing ? (
                /* ----------------- EDITING MODE FORM ----------------- */
                <div className="p-6 space-y-5 flex-1 max-h-[600px] overflow-y-auto">
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold text-slate-400 uppercase mb-1.5">Título do Conteúdo</label>
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold text-slate-400 uppercase mb-1.5">Meta Autor</label>
                      <input
                        type="text"
                        value={editAuthor}
                        onChange={(e) => setEditAuthor(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 uppercase mb-1.5">Objetivo Editorial Principal</label>
                    <textarea
                      rows={2}
                      value={editObjective}
                      onChange={(e) => setEditObjective(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 uppercase mb-1.5">Intenção de Busca Principal</label>
                    <textarea
                      rows={2}
                      value={editPrimaryIntent}
                      onChange={(e) => setEditPrimaryIntent(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="border-t border-slate-800/60 pt-4">
                    <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest mb-3">SEO & Metadata</h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-mono text-slate-500 uppercase mb-1">Slug URL</label>
                        <input
                          type="text"
                          value={editSlug}
                          onChange={(e) => setEditSlug(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-xs font-mono text-slate-500 uppercase mb-1">Meta Title</label>
                        <input
                          type="text"
                          value={editMetaTitle}
                          onChange={(e) => setEditMetaTitle(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="block text-xs font-mono text-slate-500 uppercase mb-1">Meta Description</label>
                      <input
                        type="text"
                        value={editMetaDesc}
                        onChange={(e) => setEditMetaDesc(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-mono text-slate-500 uppercase mb-1">Keyword Principal</label>
                        <input
                          type="text"
                          value={editPrimaryKw}
                          onChange={(e) => setEditPrimaryKw(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-slate-500 uppercase mb-1">Keywords Secundárias (separadas por vírgula)</label>
                        <input
                          type="text"
                          value={editSecKws}
                          onChange={(e) => setEditSecKws(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-slate-800/60 pt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold text-slate-400 uppercase mb-1.5">Entidades Obrigatórias (separadas por vírgula)</label>
                      <textarea
                        rows={3}
                        value={editEntities}
                        onChange={(e) => setEditEntities(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono font-bold text-slate-400 uppercase mb-1.5">Perguntas Obrigatórias (uma por linha)</label>
                      <textarea
                        rows={3}
                        value={editQuestions}
                        onChange={(e) => setEditQuestions(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 font-sans"
                      />
                    </div>
                  </div>

                </div>
              ) : (
                /* ----------------- READ-ONLY MODE DETAILS ----------------- */
                <div className="flex-1 flex flex-col">
                  
                  {/* Detailed Tabs bar */}
                  <div className="flex border-b border-slate-800 bg-slate-900/10 px-4 overflow-x-auto whitespace-nowrap">
                    {[
                      { id: "geral", label: "Visão Geral & Score" },
                      { id: "intent", label: "Intenção de Busca" },
                      { id: "seo", label: "SEO & Meta" },
                      { id: "outline", label: "Tópicos (Outline)" },
                      { id: "entities", label: "Entidades & FAQs" },
                      { id: "links", label: "Links & Fontes" },
                      { id: "rules", label: "Guia & Histórico" }
                    ].map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveSubTab(tab.id as any)}
                        className={`py-3 px-4 text-xs font-semibold border-b-2 transition ${
                          activeSubTab === tab.id
                            ? "border-cyan-400 text-cyan-400 bg-cyan-950/5"
                            : "border-transparent text-slate-400 hover:text-slate-200"
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  {/* Tab Body */}
                  <div className="p-6 flex-1 max-h-[500px] overflow-y-auto">
                    
                    {/* SUBTAB: GERAL & SCORE */}
                    {activeSubTab === "geral" && (
                      <div className="space-y-6">
                        {/* Dynamic Score Ring Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-900/20 border border-slate-800/80 p-4 rounded-xl">
                          <div className="text-center p-2">
                            <div className="text-xl font-bold font-mono text-cyan-400">{selectedBrief.score?.completude}%</div>
                            <div className="text-[10px] text-slate-500 uppercase tracking-wider mt-1">Completude</div>
                          </div>
                          <div className="text-center p-2 border-l border-slate-800/40">
                            <div className="text-xl font-bold font-mono text-yellow-500">{selectedBrief.score?.seo}%</div>
                            <div className="text-[10px] text-slate-500 uppercase tracking-wider mt-1">Otimização SEO</div>
                          </div>
                          <div className="text-center p-2 border-l border-slate-800/40">
                            <div className="text-xl font-bold font-mono text-purple-400">{selectedBrief.score?.knowledge}%</div>
                            <div className="text-[10px] text-slate-500 uppercase tracking-wider mt-1">Conhecimento</div>
                          </div>
                          <div className="text-center p-2 border-l border-slate-800/40">
                            <div className="text-xl font-bold font-mono text-emerald-400">{selectedBrief.score?.entidades}%</div>
                            <div className="text-[10px] text-slate-500 uppercase tracking-wider mt-1">Cobertura</div>
                          </div>
                        </div>

                        {/* Audit / Compliance Check results */}
                        <div className="space-y-3">
                          <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">Auditoria e Conformidade</h4>
                          
                          {selectedBrief.audit?.isValid ? (
                            <div className="flex items-center gap-2 p-3 bg-emerald-950/20 border border-emerald-900/30 text-emerald-400 rounded-lg text-sm">
                              <CheckCircle2 className="h-4 w-4 shrink-0" />
                              <span>O briefing passou em todas as checagens rígidas do Editor-Chefe! Status: Pronto para Escrita.</span>
                            </div>
                          ) : (
                            <div className="flex items-start gap-2 p-3 bg-red-950/20 border border-red-900/30 text-red-400 rounded-lg text-sm">
                              <XCircle className="h-4 w-4 shrink-0 mt-0.5" />
                              <div>
                                <span className="font-bold block">Erros de Conformidade impeditivos:</span>
                                <ul className="list-disc pl-4 mt-1 space-y-1">
                                  {selectedBrief.audit?.errors.map((err, i) => (
                                    <li key={i}>{err}</li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          )}

                          {selectedBrief.audit?.warnings && selectedBrief.audit.warnings.length > 0 && (
                            <div className="flex items-start gap-2 p-3 bg-yellow-950/20 border border-yellow-900/30 text-yellow-400 rounded-lg text-sm">
                              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                              <div>
                                <span className="font-bold block">Alertas / Sugestões de Melhoria:</span>
                                <ul className="list-disc pl-4 mt-1 space-y-1">
                                  {selectedBrief.audit.warnings.map((warn, i) => (
                                    <li key={i}>{warn}</li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* General description */}
                        <div className="space-y-2">
                          <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">Objetivo do Conteúdo</h4>
                          <p className="text-sm text-slate-300 bg-slate-900/30 p-4 border border-slate-800 rounded-xl leading-relaxed">
                            {selectedBrief.objetivo}
                          </p>
                        </div>

                        {/* Metadata blocks */}
                        <div className="grid grid-cols-2 gap-4 text-xs font-mono text-slate-500">
                          <div>Autor: <span className="text-slate-300">{selectedBrief.autor}</span></div>
                          <div>Criado em: <span className="text-slate-300">{new Date(selectedBrief.criado_em).toLocaleDateString()}</span></div>
                        </div>
                      </div>
                    )}

                    {/* SUBTAB: SEARCH INTENT */}
                    {activeSubTab === "intent" && (
                      <div className="space-y-6">
                        <div>
                          <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest mb-2">Intenção de Busca Principal</h4>
                          <p className="text-sm text-slate-200 bg-cyan-950/10 border border-cyan-800/20 p-4 rounded-xl">
                            {selectedBrief.search_intent?.intencao_principal}
                          </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Intenções Secundárias</h5>
                            <ul className="list-disc pl-4 text-xs text-slate-300 space-y-2">
                              {selectedBrief.search_intent?.intencoes_secundarias?.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Problemas / Dores Resolvidos</h5>
                            <ul className="list-disc pl-4 text-xs text-slate-300 space-y-2">
                              {selectedBrief.search_intent?.problemas?.map((item, i) => (
                                <li key={i}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                          <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Objetivos a Alcançar</h5>
                          <ul className="list-disc pl-4 text-xs text-slate-300 space-y-2">
                            {selectedBrief.search_intent?.objetivos?.map((item, i) => (
                              <li key={i}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* SUBTAB: SEO & METADATA */}
                    {activeSubTab === "seo" && (
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-slate-900/30 border border-slate-800 p-3 rounded-xl col-span-2">
                            <div className="text-[10px] font-mono text-slate-500 uppercase">Meta Title</div>
                            <div className="text-sm font-semibold text-slate-200 mt-1">{selectedBrief.seo?.meta_title}</div>
                          </div>
                          <div className="bg-slate-900/30 border border-slate-800 p-3 rounded-xl">
                            <div className="text-[10px] font-mono text-slate-500 uppercase">Slug URL</div>
                            <div className="text-sm font-mono text-cyan-400 mt-1">/{selectedBrief.seo?.slug}</div>
                          </div>
                        </div>

                        <div className="bg-slate-900/30 border border-slate-800 p-3 rounded-xl">
                          <div className="text-[10px] font-mono text-slate-500 uppercase">Meta Description</div>
                          <div className="text-sm text-slate-300 mt-1">{selectedBrief.seo?.meta_description}</div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Keyword Principal</h5>
                            <span className="inline-block bg-cyan-950/40 border border-cyan-800/40 text-cyan-400 font-mono text-sm font-bold px-3 py-1 rounded-lg">
                              {selectedBrief.seo?.keyword_principal}
                            </span>
                          </div>

                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Keywords Secundárias</h5>
                            <div className="flex flex-wrap gap-1.5">
                              {selectedBrief.seo?.keywords_secundarias?.map((kw, i) => (
                                <span key={i} className="bg-slate-850 text-slate-300 font-mono text-xs px-2.5 py-1 rounded-md border border-slate-850">
                                  {kw}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                          <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Schemas de Dados Estruturados Recomendados</h5>
                          <div className="flex gap-2">
                            {selectedBrief.seo?.schema_recomendado?.map((schema, i) => (
                              <span key={i} className="bg-purple-950/30 border border-purple-800/30 text-purple-400 font-mono text-xs px-3 py-1 rounded">
                                JSON-LD: {schema}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUBTAB: CONTENT OUTLINE */}
                    {activeSubTab === "outline" && (
                      <div className="space-y-6">
                        <div className="border-l-2 border-cyan-400 pl-4 py-1">
                          <div className="text-[10px] font-mono text-slate-500 uppercase">Tag H1 do Artigo</div>
                          <h4 className="text-lg font-bold text-slate-100">{selectedBrief.outline?.H1}</h4>
                        </div>

                        <div>
                          <div className="text-[10px] font-mono text-slate-500 uppercase mb-1">Foco de Introdução</div>
                          <p className="text-sm text-slate-400 leading-relaxed bg-slate-900/30 p-3 rounded-lg border border-slate-800/60">
                            {selectedBrief.outline?.introducao}
                          </p>
                        </div>

                        {/* Hierarchical Seções */}
                        <div className="space-y-4">
                          <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">Estrutura de Heading Tags</h5>
                          
                          <div className="space-y-3">
                            {selectedBrief.outline?.secoes?.map((sec, i) => (
                              <div key={i} className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl space-y-2">
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-mono font-bold bg-slate-800 border border-slate-700 px-2 py-0.5 rounded text-slate-400">
                                    {sec.nivel}
                                  </span>
                                  <h6 className="font-semibold text-sm text-slate-200">{sec.titulo}</h6>
                                </div>
                                <p className="text-xs text-slate-400 pl-14 leading-relaxed">{sec.diretrizes}</p>
                                
                                {sec.subsecoes && sec.subsecoes.length > 0 && (
                                  <div className="pl-14 pt-2 space-y-2 border-t border-slate-800/40 mt-2">
                                    {sec.subsecoes.map((subsec, j) => (
                                      <div key={j} className="space-y-1">
                                        <div className="flex items-center gap-2">
                                          <span className="text-[9px] font-mono font-bold bg-slate-800 px-1.5 py-0.2 rounded text-slate-500">
                                            {subsec.nivel}
                                          </span>
                                          <span className="font-medium text-xs text-slate-300">{subsec.titulo}</span>
                                        </div>
                                        <p className="text-[11px] text-slate-400 pl-10 leading-relaxed">{subsec.diretrizes}</p>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* FAQ and CTA */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-400 uppercase mb-2">FAQs Mapeadas</h5>
                            <div className="space-y-3">
                              {selectedBrief.outline?.FAQ?.map((faq, i) => (
                                <div key={i} className="space-y-1 text-xs">
                                  <div className="font-semibold text-slate-200">Q: {faq.pergunta}</div>
                                  <div className="text-slate-400">A: {faq.resposta}</div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
                            <div>
                              <h5 className="text-xs font-mono font-bold text-slate-400 uppercase mb-2">Chamada Para Ação (CTA)</h5>
                              <p className="text-xs text-slate-300">{selectedBrief.outline?.CTA}</p>
                            </div>
                            <span className="text-[10px] text-cyan-400 font-mono mt-4 uppercase">Injetado automaticamente no encerramento</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUBTAB: ENTITIES */}
                    {activeSubTab === "entities" && (
                      <div className="space-y-6">
                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                          <h5 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider mb-3">Entidades Obrigatórias (Silo PassaCumaru)</h5>
                          <div className="flex flex-wrap gap-2">
                            {selectedBrief.entities?.entidades_obrigatorias?.map((ent, i) => (
                              <span key={i} className="bg-slate-950 border border-slate-800 text-slate-300 px-3 py-1 rounded font-mono text-xs flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                                {ent}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                          <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-3">Perguntas Obrigatórias do Setor</h5>
                          <div className="space-y-2">
                            {selectedBrief.questions?.perguntas_obrigatorias?.map((q, i) => (
                              <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                                <span className="text-cyan-400 font-bold shrink-0">?</span>
                                <span>{q}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider mb-2">Perguntas Complementares</h5>
                            <div className="space-y-2">
                              {selectedBrief.questions?.perguntas_complementares?.map((q, i) => (
                                <div key={i} className="text-xs text-slate-400">
                                  • {q}
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                            <h5 className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider mb-2">Perguntas Relacionadas (Google PAA)</h5>
                            <div className="space-y-2">
                              {selectedBrief.questions?.perguntas_relacionadas?.map((q, i) => (
                                <div key={i} className="text-xs text-slate-400">
                                  • {q}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUBTAB: LINKS & REFERENCES */}
                    {activeSubTab === "links" && (
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl space-y-3">
                            <h5 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                              <Link className="h-4 w-4" />
                              Recomendações de Links Internos
                            </h5>
                            
                            <div className="space-y-2.5">
                              {selectedBrief.internal_links?.paginas_recomendadas?.map((l, i) => (
                                <div key={i} className="text-xs bg-slate-950 p-2.5 rounded border border-slate-850">
                                  <div className="text-slate-500">Texto-Âncora: <span className="text-cyan-400 font-bold">"{l.anchor}"</span></div>
                                  <div className="font-mono text-[10px] text-slate-400 mt-1">URL: {l.url}</div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl space-y-3">
                            <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                              <BookOpen className="h-4 w-4" />
                              Artigos Relacionados para Lincar
                            </h5>

                            <div className="space-y-2.5">
                              {selectedBrief.internal_links?.artigos_relacionados?.map((l, i) => (
                                <div key={i} className="text-xs bg-slate-950 p-2.5 rounded border border-slate-850">
                                  <div className="text-slate-500">Texto-Âncora: <span className="text-slate-300">"{l.anchor}"</span></div>
                                  <div className="font-mono text-[10px] text-slate-400 mt-1">URL: {l.url}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* References block */}
                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl space-y-3">
                          <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">Fontes Oficiais e Legislação de Apoio</h5>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div>
                              <span className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Fontes Oficiais</span>
                              <ul className="list-disc pl-4 text-slate-300 space-y-1">
                                {selectedBrief.references?.fontes?.map((f, i) => <li key={i}>{f}</li>)}
                              </ul>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Links Governamentais</span>
                              <ul className="list-disc pl-4 text-slate-300 space-y-1">
                                {selectedBrief.references?.links_oficiais?.map((l, i) => <li key={i} className="underline text-cyan-400">{l}</li>)}
                              </ul>
                            </div>
                          </div>

                          {selectedBrief.references?.observacoes && (
                            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 text-xs text-slate-400 leading-relaxed">
                              <span className="font-bold text-slate-300">Observação Crítica do Editor:</span> {selectedBrief.references.observacoes}
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* SUBTAB: WRITING GUIDELINES & VERSION HISTORY */}
                    {activeSubTab === "rules" && (
                      <div className="space-y-6">
                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                          <h5 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider mb-3">Diretrizes de Escrita Premium</h5>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div className="space-y-2">
                              <div><span className="text-slate-500">Tom de Voz:</span> <span className="text-slate-200 font-semibold">{selectedBrief.writing_guidelines?.tom}</span></div>
                              <div><span className="text-slate-500">Público-Alvo:</span> <span className="text-slate-200 font-semibold">{selectedBrief.writing_guidelines?.publico}</span></div>
                              <div><span className="text-slate-500">Meta/Objetivo:</span> <span className="text-slate-200 font-semibold">{selectedBrief.writing_guidelines?.objetivo}</span></div>
                            </div>
                            <div className="space-y-2 border-l border-slate-800/40 pl-4">
                              <div><span className="text-slate-500">Nível Técnico:</span> <span className="text-slate-200 font-semibold">{selectedBrief.writing_guidelines?.nivel_tecnico}</span></div>
                              <div><span className="text-slate-500">Tamanho Sugerido:</span> <span className="text-slate-200 font-semibold">{selectedBrief.writing_guidelines?.tamanho_esperado}</span></div>
                              <div><span className="text-slate-500">Formato:</span> <span className="text-slate-200 font-semibold">{selectedBrief.writing_guidelines?.formato}</span></div>
                            </div>
                          </div>
                        </div>

                        {/* Versioning log history */}
                        <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-xl">
                          <h5 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                            <History className="h-4 w-4" />
                            Histórico de Versões do Briefing
                          </h5>

                          <div className="space-y-3">
                            <div className="flex justify-between items-center text-xs bg-cyan-950/20 border border-cyan-800/20 p-2.5 rounded-lg">
                              <div>
                                <span className="font-bold text-slate-200">Versão v{selectedBrief.versao} (Atual)</span>
                                <p className="text-[10px] text-slate-500 mt-0.5">Autor: {selectedBrief.autor}</p>
                              </div>
                              <span className="text-[10px] text-cyan-400 font-mono">Versão Ativa</span>
                            </div>

                            {selectedBrief.versions && selectedBrief.versions.length > 0 ? (
                              selectedBrief.versions.map((ver, i) => (
                                <div key={i} className="flex justify-between items-start text-xs bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                                  <div>
                                    <span className="font-bold text-slate-400">Versão v{ver.versao}</span>
                                    <p className="text-[11px] text-slate-500 mt-1">{ver.mudancas}</p>
                                    <p className="text-[9px] text-slate-600 mt-0.5">Data: {new Date(ver.data_snapshot).toLocaleString()} • Autor: {ver.autor}</p>
                                  </div>
                                </div>
                              ))
                            ) : (
                              <div className="text-[11px] text-slate-500 italic text-center py-2">
                                Nenhuma versão histórica registrada. O briefing está na versão inicial.
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              )}

            </div>
          ) : (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-12 text-center flex flex-col items-center justify-center min-h-[600px] shadow-xl">
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-full text-slate-500 mb-4">
                <FileText className="h-10 w-10 text-cyan-500 animate-pulse" />
              </div>
              <h3 className="text-lg font-bold text-slate-200">Nenhum Briefing Selecionado</h3>
              <p className="text-sm text-slate-500 max-w-sm mt-1">
                Selecione um briefing pronto à esquerda para inspecionar, ou gere um briefing a partir do planejamento editorial.
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
