import React, { useState, useEffect } from "react";
import { 
  Database, RefreshCw, Play, ShieldAlert, Cpu, 
  ToggleLeft, ToggleRight, Trash2, Clock, CheckCircle, 
  XCircle, AlertTriangle, FileJson, List, ArrowRight,
  Sparkles, ExternalLink, Globe, HardDrive, Wifi, Rss, Radio, Search
} from "lucide-react";

interface CollectorStatus {
  id: string;
  nome: string;
  versao: string;
  fonte: string;
  status: "ativo" | "inativo";
  totalColetas: number;
  ultimaExecucao: string;
  tempoMedioMs: number;
  falhas: number;
  cacheAtivo: boolean;
  tipo: string;
}

interface QueueItem {
  id: string;
  collectorId: string;
  status: "pendente" | "executando" | "sucesso" | "falha" | "cancelado";
  tipoExecucao: "manual" | "agendada";
  dataAgendada: string;
  dataExecucao?: string;
  duracaoMs?: number;
  erro?: string;
  tentativas: number;
}

interface CacheEntry {
  key: string;
  createdAt: string;
  expiresAt: string | null;
  isExpired: boolean;
  sizeBytes: number;
}

interface CollectorLog {
  id: string;
  collectorId: string;
  data: string;
  tipo: "info" | "sucesso" | "erro" | "alerta";
  mensagem: string;
  duracaoMs?: number;
}

interface CollectorResult {
  id: string;
  collector: string;
  origem: string;
  data_coleta: string;
  tipo: string;
  conteudo: any;
  confiabilidade: number;
  status: "sucesso" | "falha" | "alerta";
  observacoes?: string;
}

export function OrganicCollectors() {
  const [collectors, setCollectors] = useState<CollectorStatus[]>([]);
  const [logs, setLogs] = useState<CollectorLog[]>([]);
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [cache, setCache] = useState<CacheEntry[]>([]);
  const [results, setResults] = useState<CollectorResult[]>([]);
  const [metrics, setMetrics] = useState({
    totalCollected: 0,
    totalFailures: 0,
    activeCacheCount: 0,
    lastUpdated: ""
  });

  const [isLoading, setIsLoading] = useState(false);
  const [runningId, setRunningId] = useState<string | null>(null);
  const [selectedResult, setSelectedResult] = useState<CollectorResult | null>(null);
  const [rssUrl, setRssUrl] = useState("https://g1.globo.com/rn/rio-grande-do-norte/rss/g1.xml");
  const [manualTitle, setManualTitle] = useState("");
  const [manualDesc, setManualDesc] = useState("");
  const [manualCat, setManualCat] = useState("Concurso");

  const [filterType, setFilterType] = useState<string>("all");

  const loadData = async () => {
    try {
      const res = await fetch("/api/organic-os/collectors/status");
      if (!res.ok) throw new Error("Erro de resposta do servidor");
      const data = await res.json();
      setCollectors(data.collectors || []);
      setLogs(data.logs || []);
      setQueue(data.queue || []);
      setCache(data.cache || []);
      setMetrics(data.metrics || { totalCollected: 0, totalFailures: 0, activeCacheCount: 0, lastUpdated: "" });

      // Carregar os resultados salvos reais deresults.json
      const resultsRes = await fetch("/api/organic-os/collectors");
      if (resultsRes.ok) {
        // Como o endpoint /api/organic-os/collectors retorna o histórico de resultados, vamos ler diretamente dele
        const resultsData = await fetch("/organic-traffic-os/collectors/cache/results.json")
          .then(r => r.ok ? r.json() : [])
          .catch(() => []);
        setResults(resultsData);
      }
    } catch (err) {
      console.error("Erro ao carregar dados dos collectors:", err);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 3000); // Polling frequente para atualizar progresso de coletas
    return () => clearInterval(interval);
  }, []);

  const handleRunCollector = async (id: string) => {
    setRunningId(id);
    setIsLoading(true);
    try {
      let params: any = {};
      if (id === "rss-collector") {
        params = { url: rssUrl };
      } else if (id === "manual-collector") {
        if (!manualTitle.trim()) {
          alert("Por favor, preencha o título da entrada manual.");
          setRunningId(null);
          setIsLoading(false);
          return;
        }
        params = {
          titulo: manualTitle,
          descricao: manualDesc,
          categoria: manualCat,
          data_observada: new Date().toISOString()
        };
      }

      const res = await fetch("/api/organic-os/collectors/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, params })
      });

      if (res.ok) {
        // Resetar campos manuais
        if (id === "manual-collector") {
          setManualTitle("");
          setManualDesc("");
        }
        await loadData();
      } else {
        const errData = await res.json();
        alert(`Falha ao executar coletor: ${errData.error || "Erro desconhecido"}`);
      }
    } catch (err) {
      console.error("Erro ao executar coletor:", err);
    } finally {
      setRunningId(null);
      setIsLoading(false);
    }
  };

  const handleToggleCollector = async (id: string, currentStatus: "ativo" | "inativo") => {
    try {
      const nextStatus = currentStatus === "ativo" ? "inativo" : "ativo";
      const res = await fetch("/api/organic-os/collectors/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: nextStatus })
      });
      if (res.ok) {
        await loadData();
      }
    } catch (err) {
      console.error("Erro ao alternar status do coletor:", err);
    }
  };

  const handleQueueAction = async (id: string, action: "cancel" | "retry") => {
    try {
      const res = await fetch("/api/organic-os/collectors/queue/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action })
      });
      if (res.ok) {
        await loadData();
      }
    } catch (err) {
      console.error("Erro ao processar ação na fila:", err);
    }
  };

  const handleClearCacheAndLogs = async () => {
    if (!confirm("Tem certeza que deseja limpar todo o cache, histórico de fila e logs dos coletores?")) return;
    try {
      const res = await fetch("/api/organic-os/collectors/cache/clear", {
        method: "POST"
      });
      if (res.ok) {
        setSelectedResult(null);
        setResults([]);
        await loadData();
      }
    } catch (err) {
      console.error("Erro ao limpar dados:", err);
    }
  };

  // Filtrar resultados exibidos
  const filteredResults = results.filter(res => {
    if (filterType === "all") return true;
    return res.tipo === filterType || res.collector === filterType;
  });

  return (
    <div className="space-y-6">
      {/* Banner de Introdução */}
      <div className="bg-[#111827] border border-cyan-500/20 rounded-xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl -z-10" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-mono px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded uppercase tracking-wider border border-cyan-500/20">
                Sprint 07 — Data Layer
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-xs text-slate-400">Desacoplamento de Acesso Externo</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
              <Cpu className="h-6 w-6 text-cyan-400" />
              Research Collectors Engine <span className="text-slate-500 font-light">V1</span>
            </h2>
            <p className="text-sm text-slate-400 mt-2 max-w-3xl leading-relaxed">
              Camada oficial de coleta e ingestão de dados para o Organic Traffic OS. Todos os agentes da agência SEO 
              utilizam coletores padronizados para garantir normalização, integridade, e rastreabilidade de origem antes da produção de conteúdo.
            </p>
          </div>
          <button 
            onClick={loadData}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-sm font-semibold border border-slate-700 transition"
          >
            <RefreshCw className="h-4 w-4" />
            Sincronizar Painel
          </button>
        </div>
      </div>

      {/* Grid de Métricas Consolidadas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Itens Ingeridos</span>
            <Database className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">{metrics.totalCollected}</h3>
            <p className="text-xs text-slate-500 mt-1">Registros persistidos e tratados</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Cache do Motor</span>
            <HardDrive className="h-4 w-4 text-purple-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">{cache.length} chaves</h3>
            <p className="text-xs text-slate-500 mt-1">{metrics.activeCacheCount} coletores ativos no cache</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Erros do Processo</span>
            <ShieldAlert className="h-4 w-4 text-red-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">{metrics.totalFailures}</h3>
            <p className="text-xs text-slate-500 mt-1">Falhas monitoradas e logadas</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 font-semibold uppercase font-mono tracking-wider">Origens Ativas</span>
            <Wifi className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-white font-mono">
              {collectors.filter(c => c.status === "ativo").length} / {collectors.length}
            </h3>
            <p className="text-xs text-slate-500 mt-1">Módulos coletores funcionais</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Lado Esquerdo: Coletores Cadastrados */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <h3 className="text-md font-bold text-white mb-4 flex items-center gap-2">
              <Radio className="h-5 w-5 text-cyan-400" />
              Gerenciador de Coletores Ativos
            </h3>

            <div className="space-y-4">
              {collectors.map((c) => {
                const isFunctional = ["manual-collector", "rss-collector"].includes(c.id);
                return (
                  <div 
                    key={c.id} 
                    className={`border rounded-xl p-4 transition-all ${
                      c.status === "ativo" 
                        ? "bg-[#1f2937]/30 border-slate-700/80" 
                        : "bg-[#111827]/60 border-slate-800/80 opacity-70 hover:opacity-100"
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Metadados Básicos */}
                      <div className="flex items-start gap-3">
                        <div className={`p-2.5 rounded-lg border ${
                          isFunctional 
                            ? "bg-cyan-500/5 border-cyan-500/20 text-cyan-400" 
                            : "bg-slate-800/50 border-slate-700 text-slate-500"
                        }`}>
                          {c.id === "rss-collector" ? <Rss className="h-5 w-5" /> : <Database className="h-5 w-5" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-semibold text-white">{c.nome}</h4>
                            <span className="text-[10px] font-mono bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded">v{c.versao}</span>
                            {!isFunctional && (
                              <span className="text-[9px] font-mono bg-amber-500/10 text-amber-400 px-1 rounded border border-amber-500/15 uppercase">
                                Placeholder
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">Fonte: <span className="font-mono text-slate-300">{c.fonte}</span></p>
                          
                          {/* Mini Métricas por Coletor */}
                          <div className="flex flex-wrap gap-4 mt-2.5 text-[11px] font-mono text-slate-400">
                            <div>Coletas: <span className="text-white">{c.totalColetas}</span></div>
                            <div>Tempo Médio: <span className="text-white">{c.tempoMedioMs}ms</span></div>
                            <div>Falhas: <span className={`${c.falhas > 0 ? "text-red-400 font-bold" : "text-slate-500"}`}>{c.falhas}</span></div>
                            <div>Última: <span className="text-slate-400">{c.ultimaExecucao !== "Nunca executado" ? new Date(c.ultimaExecucao).toLocaleTimeString() : "Nunca"}</span></div>
                          </div>
                        </div>
                      </div>

                      {/* Ações e Controles */}
                      <div className="flex items-center gap-3 self-end md:self-center">
                        <button
                          onClick={() => handleToggleCollector(c.id, c.status)}
                          className={`p-1 rounded-lg transition ${
                            c.status === "ativo" ? "text-cyan-400 hover:text-cyan-300" : "text-slate-600 hover:text-slate-500"
                          }`}
                          title={c.status === "ativo" ? "Desabilitar Coletor" : "Habilitar Coletor"}
                        >
                          {c.status === "ativo" ? <ToggleRight className="h-7 w-7" /> : <ToggleLeft className="h-7 w-7" />}
                        </button>

                        <button
                          disabled={c.status === "inativo" || runningId === c.id}
                          onClick={() => handleRunCollector(c.id)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                            c.status === "inativo"
                              ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-transparent"
                              : "bg-cyan-500 hover:bg-cyan-600 text-slate-950 shadow-md font-bold"
                          }`}
                        >
                          {runningId === c.id ? (
                            <>
                              <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                              Ingerindo...
                            </>
                          ) : (
                            <>
                              <Play className="h-3.5 w-3.5 fill-slate-950" />
                              Executar
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Área de Parâmetros Dinâmicos de Teste */}
                    {c.status === "ativo" && c.id === "rss-collector" && (
                      <div className="mt-3.5 pt-3.5 border-t border-slate-800/50 flex flex-col md:flex-row gap-3 items-center">
                        <label className="text-[11px] font-mono text-slate-400 uppercase shrink-0">RSS Feed URL:</label>
                        <input 
                          type="text"
                          value={rssUrl}
                          onChange={(e) => setRssUrl(e.target.value)}
                          className="w-full bg-[#111827] border border-slate-700/80 rounded-lg p-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                    )}

                    {c.status === "ativo" && c.id === "manual-collector" && (
                      <div className="mt-3.5 pt-3.5 border-t border-slate-800/50 space-y-3">
                        <span className="text-[11px] font-mono text-slate-400 uppercase block">Campos de Entrada Manual:</span>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <input 
                            type="text"
                            placeholder="Título da Notícia..."
                            value={manualTitle}
                            onChange={(e) => setManualTitle(e.target.value)}
                            className="bg-[#111827] border border-slate-700/80 rounded-lg p-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                          />
                          <input 
                            type="text"
                            placeholder="Descrição / Detalhes..."
                            value={manualDesc}
                            onChange={(e) => setManualDesc(e.target.value)}
                            className="bg-[#111827] border border-slate-700/80 rounded-lg p-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                          />
                          <select
                            value={manualCat}
                            onChange={(e) => setManualCat(e.target.value)}
                            className="bg-[#111827] border border-slate-700/80 rounded-lg p-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                          >
                            <option value="Concurso">Categoria: Concurso</option>
                            <option value="Edital">Categoria: Edital</option>
                            <option value="Região Agreste">Categoria: Região Agreste</option>
                            <option value="Vagas Saúde">Categoria: Vagas Saúde</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Lado Direito: Histórico de Fila e Logs */}
        <div className="space-y-6">
          {/* Fila de Execução / Queue */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Clock className="h-4.5 w-4.5 text-cyan-400" />
              Fila de Execução tática ({queue.length})
            </h3>

            <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
              {queue.length === 0 ? (
                <p className="text-xs text-slate-500 italic p-2 text-center">Fila de agendamentos vazia.</p>
              ) : (
                queue.map((q) => {
                  let badgeColor = "bg-slate-800 text-slate-400";
                  if (q.status === "executando") badgeColor = "bg-amber-500/10 text-amber-400 animate-pulse";
                  if (q.status === "sucesso") badgeColor = "bg-green-500/10 text-green-400";
                  if (q.status === "falha") badgeColor = "bg-red-500/10 text-red-400";
                  if (q.status === "cancelado") badgeColor = "bg-slate-800 text-slate-500";

                  return (
                    <div key={q.id} className="p-2.5 bg-slate-900/50 rounded-lg border border-slate-800/80 flex items-center justify-between gap-2 text-xs">
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-cyan-400 font-mono font-medium truncate max-w-[120px]">{q.collectorId}</span>
                          <span className={`text-[9px] font-bold px-1 py-0.2 rounded uppercase ${badgeColor}`}>
                            {q.status}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 mt-1 font-mono">
                          {new Date(q.dataAgendada).toLocaleTimeString()}
                        </p>
                      </div>

                      <div className="flex gap-1.5 shrink-0">
                        {q.status === "pendente" && (
                          <button 
                            onClick={() => handleQueueAction(q.id, "cancel")}
                            className="p-1 text-slate-500 hover:text-red-400"
                            title="Cancelar Agendamento"
                          >
                            <XCircle className="h-4.5 w-4.5" />
                          </button>
                        )}
                        {(q.status === "falha" || q.status === "sucesso" || q.status === "cancelado") && (
                          <button 
                            onClick={() => handleQueueAction(q.id, "retry")}
                            className="p-1 text-slate-500 hover:text-cyan-400"
                            title="Re-executar tarefa"
                          >
                            <Play className="h-4 w-4 fill-slate-500" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Terminal Logs */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <List className="h-4.5 w-4.5 text-cyan-400" />
                Console de Coleta
              </h3>
              <button 
                onClick={handleClearCacheAndLogs}
                className="text-[10px] text-red-400 hover:text-red-300 font-mono tracking-tight flex items-center gap-1 bg-red-500/5 border border-red-500/10 px-2 py-0.5 rounded"
              >
                <Trash2 className="h-3 w-3" />
                Resetar Engine
              </button>
            </div>

            <div className="bg-[#030712] rounded-lg p-3.5 h-[230px] overflow-y-auto font-mono text-[10px] space-y-2 border border-slate-800/80">
              {logs.length === 0 ? (
                <p className="text-slate-600 italic">Nenhum log de console disponível.</p>
              ) : (
                logs.map((log) => {
                  let col = "text-slate-400";
                  if (log.tipo === "sucesso") col = "text-green-400";
                  if (log.tipo === "erro") col = "text-red-400 font-semibold";
                  if (log.tipo === "alerta") col = "text-amber-400";

                  return (
                    <div key={log.id} className="leading-relaxed flex gap-1 items-start">
                      <span className="text-slate-600 shrink-0">[{new Date(log.data).toLocaleTimeString()}]</span>
                      <span className="text-cyan-400 shrink-0 uppercase">[{log.collectorId.replace("-collector", "")}]</span>
                      <span className={col}>{log.mensagem}</span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Seção Inferior: Visualizador de Resultados Normalizados */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-4 border-b border-slate-800/60">
          <div>
            <h3 className="text-md font-bold text-white flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-cyan-400" />
              Dados Normalizados Ingeridos
            </h3>
            <p className="text-xs text-slate-400 mt-1">Explorador de dados prontos para consumo por agentes e cronogramas editoriais</p>
          </div>

          {/* Filtros de Visualização */}
          <div className="flex gap-2">
            <button 
              onClick={() => setFilterType("all")}
              className={`px-3 py-1 text-xs rounded-lg border font-medium transition ${
                filterType === "all" ? "bg-cyan-500/15 text-cyan-400 border-cyan-500/20" : "bg-slate-800 text-slate-400 border-transparent hover:text-slate-300"
              }`}
            >
              Todos ({results.length})
            </button>
            <button 
              onClick={() => setFilterType("rss")}
              className={`px-3 py-1 text-xs rounded-lg border font-medium transition ${
                filterType === "rss" ? "bg-cyan-500/15 text-cyan-400 border-cyan-500/20" : "bg-slate-800 text-slate-400 border-transparent hover:text-slate-300"
              }`}
            >
              RSS ({results.filter(r => r.tipo === "rss").length})
            </button>
            <button 
              onClick={() => setFilterType("manual")}
              className={`px-3 py-1 text-xs rounded-lg border font-medium transition ${
                filterType === "manual" ? "bg-cyan-500/15 text-cyan-400 border-cyan-500/20" : "bg-slate-800 text-slate-400 border-transparent hover:text-slate-300"
              }`}
            >
              Manuais ({results.filter(r => r.tipo === "manual").length})
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Tabela de Resultados */}
          <div className="lg:col-span-7 space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
            {filteredResults.length === 0 ? (
              <p className="text-xs text-slate-500 italic p-6 text-center">Nenhum dado normalizado localizado no banco local.</p>
            ) : (
              filteredResults.map((r) => (
                <div 
                  key={r.id}
                  onClick={() => setSelectedResult(r)}
                  className={`p-3.5 border rounded-xl cursor-pointer transition flex items-center justify-between gap-4 ${
                    selectedResult?.id === r.id 
                      ? "bg-cyan-500/5 border-cyan-500/30" 
                      : "bg-[#1f2937]/10 border-slate-800/80 hover:bg-[#1f2937]/20"
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                        r.tipo === "rss" ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/15" : "bg-purple-500/10 text-purple-400 border-purple-500/15"
                      }`}>
                        {r.tipo.toUpperCase()}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">{new Date(r.data_coleta).toLocaleString()}</span>
                    </div>
                    <h4 className="text-xs font-semibold text-white truncate max-w-[400px]">
                      {r.tipo === "rss" 
                        ? (r.conteudo?.itens?.[0]?.titulo || r.conteudo?.nomeFeed || "Canal de Notícias")
                        : (r.conteudo?.titulo || "Entrada Manual")
                      }
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-1 truncate max-w-[400px]">
                      Origem: <span className="font-mono text-slate-300">{r.origem}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-right">
                      <span className="text-[10px] font-mono text-slate-500 block">Confiança</span>
                      <span className="text-xs font-bold text-cyan-400 font-mono">{r.confiabilidade}%</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-600 shrink-0" />
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Painel do Resultado Expandido */}
          <div className="lg:col-span-5 bg-[#0b0f19] border border-slate-800 rounded-xl p-4.5 h-[350px] flex flex-col justify-between">
            {selectedResult ? (
              <div className="flex flex-col justify-between h-full min-h-0">
                <div className="min-h-0 overflow-y-auto space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-sm font-bold text-white tracking-tight">Registro de Coleta Unificado</h4>
                      <p className="text-[10px] font-mono text-cyan-400 mt-0.5">{selectedResult.id}</p>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      selectedResult.status === "sucesso" ? "bg-green-500/10 text-green-400" : "bg-amber-500/10 text-amber-400"
                    }`}>
                      {selectedResult.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="text-xs space-y-2 text-slate-300 bg-slate-900/40 p-3 rounded-lg border border-slate-800/80 font-mono">
                    <div><span className="text-slate-500">Coletor:</span> {selectedResult.collector}</div>
                    <div><span className="text-slate-500">Origem:</span> <a href={selectedResult.origem} target="_blank" rel="noreferrer" className="text-cyan-400 hover:underline inline-flex items-center gap-1">{selectedResult.origem.substring(0, 40)}... <ExternalLink className="h-3 w-3" /></a></div>
                    <div><span className="text-slate-500">Data Coleta:</span> {new Date(selectedResult.data_coleta).toLocaleString()}</div>
                    <div><span className="text-slate-500">Confiabilidade:</span> <span className="text-white font-bold">{selectedResult.confiabilidade}/100</span></div>
                    {selectedResult.observacoes && <div><span className="text-slate-500">OBS:</span> <span className="text-slate-400 italic">{selectedResult.observacoes}</span></div>}
                  </div>

                  {/* Corpo do Conteúdo Normalizado */}
                  <div>
                    <span className="text-[11px] font-mono text-slate-500 uppercase block mb-1.5">Conteúdo Ingerido Tratado:</span>
                    <div className="bg-[#030712] rounded-lg p-3 max-h-[140px] overflow-y-auto border border-slate-800 text-xs text-slate-300 leading-relaxed font-mono whitespace-pre-wrap">
                      {JSON.stringify(selectedResult.conteudo, null, 2)}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex justify-between items-center text-[10px] text-slate-500 font-mono">
                  <span>Normalizado e pronto para agentes</span>
                  <button 
                    onClick={() => {
                      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(selectedResult, null, 2));
                      const downloadAnchor = document.createElement('a');
                      downloadAnchor.setAttribute("href", dataStr);
                      downloadAnchor.setAttribute("download", `coleta-${selectedResult.id}.json`);
                      document.body.appendChild(downloadAnchor);
                      downloadAnchor.click();
                      downloadAnchor.remove();
                    }}
                    className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold"
                  >
                    <FileJson className="h-3.5 w-3.5" /> Exportar JSON
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-500 text-xs text-center space-y-2.5">
                <FileJson className="h-10 w-10 text-slate-700 animate-pulse" />
                <div>
                  <p className="font-semibold text-slate-400">Nenhum item selecionado</p>
                  <p className="text-[11px] mt-1 max-w-[250px]">Clique em um dos registros na lista de dados normalizados para inspecionar os detalhes.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
export default OrganicCollectors;
