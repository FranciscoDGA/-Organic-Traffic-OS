import React, { useState, useEffect } from "react";
import { 
  GitMerge, Server, Database, BrainCircuit, Users, Shuffle, Activity, 
  Settings, RefreshCw, CheckCircle, AlertTriangle, Play, FileText, 
  Terminal, ShieldCheck, Cpu, ArrowDown, Sparkles
} from "lucide-react";

interface ComponentItem {
  id: string;
  name: string;
  version: string;
  steps?: string[];
}

interface LogEntry {
  timestamp: string;
  severity: string;
  layer: string;
  sourceId: string;
  message: string;
  meta?: any;
}

interface ArchitectureData {
  success: boolean;
  architectureVersion: string;
  healthScore: number;
  connectors: ComponentItem[];
  knowledgeProviders: ComponentItem[];
  engines: ComponentItem[];
  agents: ComponentItem[];
  workflows: ComponentItem[];
  logs: LogEntry[];
}

export function OrganicArchitecture() {
  const [data, setData] = useState<ArchitectureData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [executingWf, setExecutingWf] = useState<boolean>(false);
  const [wfResult, setWfResult] = useState<any | null>(null);
  const [activeLayerTab, setActiveLayerTab] = useState<number>(0);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/organic-os/architecture");
      if (!res.ok) throw new Error("Falha ao comunicar com o servidor.");
      const json = await res.ok ? await res.json() : null;
      if (json && json.success) {
        setData(json);
        setError(null);
      } else {
        setError("Não foi possível carregar os dados de telemetria arquitetural.");
      }
    } catch (err: any) {
      console.error(err);
      setError("Erro ao se conectar ao servidor da plataforma.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // Auto refresh logs every 8 seconds
    const interval = setInterval(() => {
      loadData();
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const handleRunWorkflow = async (workflowId: string) => {
    try {
      setExecutingWf(true);
      setWfResult(null);
      const res = await fetch("/api/organic-os/architecture/run-workflow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workflowId })
      });
      const result = await res.json();
      setWfResult(result);
      loadData(); // refresh to get new logs
    } catch (err: any) {
      console.error(err);
      alert("Erro ao disparar simulação de Workflow.");
    } finally {
      setExecutingWf(false);
    }
  };

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center p-12 space-y-4">
        <RefreshCw className="h-8 w-8 text-cyan-400 animate-spin" />
        <p className="text-sm text-slate-400 font-mono">Carregando telemetria das 5 camadas do EPIC 03...</p>
      </div>
    );
  }

  // Fallbacks
  const connectors = data?.connectors || [];
  const knowledge = data?.knowledgeProviders || [];
  const engines = data?.engines || [];
  const agents = data?.agents || [];
  const workflows = data?.workflows || [];
  const logs = data?.logs || [];
  const healthScore = data?.healthScore || 0;
  const version = data?.architectureVersion || "3.0.0-Alpha";

  const totalComponents = connectors.length + knowledge.length + engines.length + agents.length + workflows.length;

  return (
    <div className="space-y-6">
      {/* Title & Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Banner principal */}
        <div className="lg:col-span-2 bg-[#0f172a] border border-slate-800 p-6 rounded-xl shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400">
              <GitMerge className="h-6 w-6" />
              <span className="text-xs uppercase font-mono tracking-widest bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40">EPIC 03 — FASE 01</span>
            </div>
            <h2 className="text-xl font-display font-bold text-white mt-2">
              Autonomous Content Operations Architecture
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Painel de governança e telemetria da arquitetura de 5 camadas do Organic Traffic OS.
            </p>
          </div>

          <div className="flex gap-4 pt-2">
            <button
              onClick={loadData}
              className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800 hover:bg-slate-750 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            >
              <RefreshCw className="h-3 w-3" />
              Recarregar Telemetria
            </button>
            <a 
              href="#logs-console"
              className="flex items-center gap-2 text-xs text-slate-400 hover:text-white px-3 py-1.5 transition-colors"
            >
              <Terminal className="h-3 w-3" />
              Ver Console de Logs
            </a>
          </div>
        </div>

        {/* Health Score */}
        <div className="bg-[#0f172a] border border-slate-800 p-6 rounded-xl shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-slate-500 text-xs font-mono uppercase">Health Score</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl font-extrabold text-emerald-400">{healthScore}%</span>
              <span className="text-xs text-slate-400">Excelente</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-950/20 px-3 py-2 rounded-lg border border-emerald-900/30">
            <ShieldCheck className="h-4 w-4 shrink-0" />
            <span>Infraestrutura 100% Semeada e Coerente</span>
          </div>
        </div>

        {/* Versão e Contadores */}
        <div className="bg-[#0f172a] border border-slate-800 p-6 rounded-xl shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-slate-500 text-xs font-mono uppercase">Versão do Core</span>
            <div className="text-xl font-bold text-cyan-400 mt-1">{version}</div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono text-slate-400">
            <div className="p-2 bg-slate-900/50 rounded border border-slate-800">
              <span className="text-white block text-sm font-bold">{totalComponents}</span>
              Componentes
            </div>
            <div className="p-2 bg-slate-900/50 rounded border border-slate-800">
              <span className="text-emerald-400 block text-sm font-bold">5 / 5</span>
              Layers Ativos
            </div>
          </div>
        </div>

      </div>

      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-3 text-red-400 text-sm">
          <AlertTriangle className="h-5 w-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Layer Interactive Map */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl shadow-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/20">
          <div>
            <h3 className="font-display font-bold text-white text-md flex items-center gap-2">
              <Cpu className="h-5 w-5 text-cyan-400" />
              Mapeamento de Fluxo de Dependências entre Layers
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Explore as definições e contratos instanciados em cada uma das cinco camadas arquiteturais.</p>
          </div>
          <div className="flex gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
            {["Connectors", "Knowledge", "Engines", "Agents", "Workflows"].map((layer, idx) => (
              <button
                key={layer}
                onClick={() => setActiveLayerTab(idx)}
                className={`px-3 py-1 text-xs font-mono rounded ${
                  activeLayerTab === idx ? "bg-cyan-950 text-cyan-400 border border-cyan-800/50 font-bold" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                L{idx + 1}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Details Column */}
          <div className="lg:col-span-1 space-y-4">
            {activeLayerTab === 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded">Layer 1</span>
                  <h4 className="font-bold text-white">Connectors Layer</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Isola totalmente APIs externas da lógica de negócio. Realiza handshakes, armazena chaves com segurança e normaliza respostas de provedores sob contratos rigorosos.
                </p>
                <div className="bg-slate-950/60 p-4 rounded-lg border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold block">Classes de Infraestrutura</span>
                  <ul className="text-xs font-mono text-slate-400 space-y-1 list-disc list-inside">
                    <li>BaseConnector</li>
                    <li>ConnectorRegistry</li>
                    <li>ConnectorManager</li>
                    <li>ConnectorFactory</li>
                  </ul>
                </div>
              </div>
            )}

            {activeLayerTab === 1 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded">Layer 2</span>
                  <h4 className="font-bold text-white">Knowledge Layer</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Gerencia a integridade factual da plataforma. Indexa relatórios, editais, históricos locais e provê uma cache temporária de 10 minutos para buscas semânticas frequentes.
                </p>
                <div className="bg-slate-950/60 p-4 rounded-lg border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold block">Classes de Infraestrutura</span>
                  <ul className="text-xs font-mono text-slate-400 space-y-1 list-disc list-inside">
                    <li>KnowledgeProvider</li>
                    <li>KnowledgeRegistry</li>
                    <li>KnowledgeLoader</li>
                    <li>KnowledgeCache</li>
                  </ul>
                </div>
              </div>
            )}

            {activeLayerTab === 2 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded">Layer 3</span>
                  <h4 className="font-bold text-white">Engines Layer</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Abstração direta de LLMs (Gemini Pro/Flash) e algoritmos de regras estáticas. Controla temperatura de geração, limites de tokens e calcula estimativas de custo em USD.
                </p>
                <div className="bg-slate-950/60 p-4 rounded-lg border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold block">Classes de Infraestrutura</span>
                  <ul className="text-xs font-mono text-slate-400 space-y-1 list-disc list-inside">
                    <li>BaseEngine</li>
                    <li>EngineRegistry</li>
                    <li>EngineManager</li>
                    <li>EngineFactory</li>
                  </ul>
                </div>
              </div>
            )}

            {activeLayerTab === 3 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded">Layer 4</span>
                  <h4 className="font-bold text-white">Agents Layer</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Entidades de decisão lógica baseadas em personas e metas específicas. Capazes de rodar loops autônomos complexos para auditar, reescrever e revisar materiais.
                </p>
                <div className="bg-slate-950/60 p-4 rounded-lg border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold block">Classes de Infraestrutura</span>
                  <ul className="text-xs font-mono text-slate-400 space-y-1 list-disc list-inside">
                    <li>BaseAgent</li>
                    <li>AgentRegistry</li>
                    <li>AgentManager</li>
                    <li>AgentFactory</li>
                  </ul>
                </div>
              </div>
            )}

            {activeLayerTab === 4 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded">Layer 5</span>
                  <h4 className="font-bold text-white">Workflows Layer</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  A camada superior. Controla máquinas de estados rígidas sequenciadas para automatizar Sprints completas do Organic Traffic OS com salvamento de estado de variáveis de progresso.
                </p>
                <div className="bg-slate-950/60 p-4 rounded-lg border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold block">Classes de Infraestrutura</span>
                  <ul className="text-xs font-mono text-slate-400 space-y-1 list-disc list-inside">
                    <li>BaseWorkflow</li>
                    <li>WorkflowRegistry</li>
                    <li>WorkflowExecutor</li>
                    <li>WorkflowState</li>
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Components Grid Column */}
          <div className="lg:col-span-2 bg-[#0b0f19]/80 border border-slate-800 p-6 rounded-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-slate-400 uppercase font-bold">Componentes Ativos no Registro Oficial</span>
              <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded">Ativo</span>
            </div>

            {activeLayerTab === 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {connectors.map(c => (
                  <div key={c.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex flex-col justify-between">
                    <div>
                      <h5 className="text-xs font-bold text-white font-mono">{c.name}</h5>
                      <span className="text-[10px] font-mono text-slate-500 block mt-0.5">ID: {c.id}</span>
                    </div>
                    <div className="flex items-center justify-between mt-3 text-[10px] font-mono text-slate-400">
                      <span>Versão {c.version}</span>
                      <span className="text-emerald-400">● Pronto</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeLayerTab === 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {knowledge.map(k => (
                  <div key={k.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex flex-col justify-between">
                    <div>
                      <h5 className="text-xs font-bold text-white font-mono">{k.name}</h5>
                      <span className="text-[10px] font-mono text-slate-500 block mt-0.5">ID: {k.id}</span>
                    </div>
                    <div className="flex items-center justify-between mt-3 text-[10px] font-mono text-slate-400">
                      <span>Versão {k.version}</span>
                      <span className="text-emerald-400">● Carregado</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeLayerTab === 2 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {engines.map(e => (
                  <div key={e.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex flex-col justify-between">
                    <div>
                      <h5 className="text-xs font-bold text-white font-mono">{e.name}</h5>
                      <span className="text-[10px] font-mono text-slate-500 block mt-0.5">ID: {e.id}</span>
                    </div>
                    <div className="flex items-center justify-between mt-3 text-[10px] font-mono text-slate-400">
                      <span>Versão {e.version}</span>
                      <span className="text-cyan-400">● Inicializado</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeLayerTab === 3 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {agents.map(a => (
                  <div key={a.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex flex-col justify-between">
                    <div>
                      <h5 className="text-xs font-bold text-white font-mono">{a.name}</h5>
                      <span className="text-[10px] font-mono text-slate-500 block mt-0.5">ID: {a.id}</span>
                    </div>
                    <div className="flex items-center justify-between mt-3 text-[10px] font-mono text-slate-400">
                      <span>Versão {a.version}</span>
                      <span className="text-purple-400">● Ocioso (Idle)</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeLayerTab === 4 && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  {workflows.map(w => (
                    <div key={w.id} className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h5 className="text-xs font-bold text-white font-mono">{w.name}</h5>
                          <span className="text-[10px] font-mono text-slate-500">ID: {w.id} (v{w.version})</span>
                        </div>
                        <button
                          onClick={() => handleRunWorkflow(w.id)}
                          disabled={executingWf}
                          className="flex items-center gap-1.5 px-3 py-1 bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-800 text-slate-950 text-xs font-bold rounded-md transition-colors"
                        >
                          {executingWf ? (
                            <>
                              <RefreshCw className="h-3 w-3 animate-spin" />
                              Executando...
                            </>
                          ) : (
                            <>
                              <Play className="h-3 w-3" />
                              Testar Workflow
                            </>
                          )}
                        </button>
                      </div>

                      <div className="bg-slate-950/40 p-3 rounded border border-slate-800/80 space-y-1.5">
                        <span className="text-[10px] font-mono text-slate-500 uppercase font-semibold">Etapas Sequenciais de Execução (Steps)</span>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10px] font-mono text-slate-400">
                          {w.steps?.map((step, stepIdx) => (
                            <div key={step} className="flex items-center gap-1.5 p-1 bg-slate-900/50 rounded border border-slate-800">
                              <span className="text-cyan-400 font-bold">#{stepIdx + 1}</span>
                              <span className="truncate">{step}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Simulated Run output results */}
                {wfResult && (
                  <div className="p-4 bg-cyan-950/10 border border-cyan-800/30 rounded-lg space-y-2.5">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-mono text-cyan-400 font-bold flex items-center gap-1">
                        <Sparkles className="h-4 w-4 animate-pulse" />
                        Resultado do Teste de Sanidade
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">Execução: {wfResult.executionId}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono text-slate-400">
                      <div className="p-2 bg-slate-900 rounded border border-slate-800">
                        <span className="block text-slate-500 uppercase">Status</span>
                        <span className={wfResult.success ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
                          {wfResult.success ? "SUCESSO" : "FALHA"}
                        </span>
                      </div>
                      <div className="p-2 bg-slate-900 rounded border border-slate-800">
                        <span className="block text-slate-500 uppercase">Duração</span>
                        <span className="text-white font-bold">{wfResult.durationMs}ms</span>
                      </div>
                      <div className="p-2 bg-slate-900 rounded border border-slate-800">
                        <span className="block text-slate-500 uppercase">Etapas</span>
                        <span className="text-cyan-400 font-bold">{wfResult.history?.length} / {wfResult.history?.length}</span>
                      </div>
                    </div>

                    <div className="space-y-1 bg-slate-950 p-3 rounded font-mono text-[10px] max-h-[120px] overflow-y-auto">
                      {wfResult.history?.map((step: any, stepIdx: number) => (
                        <div key={stepIdx} className="flex items-center justify-between text-slate-300">
                          <span>
                            <span className="text-emerald-400 font-bold">✓</span> {step.stepName}
                          </span>
                          <span className="text-slate-500">{step.durationMs}ms</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>

        </div>
      </div>

      {/* Real-time Logger Terminal */}
      <div id="logs-console" className="bg-[#0f172a] border border-slate-800 rounded-xl shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/30">
          <div className="flex items-center gap-2 text-white">
            <Terminal className="h-5 w-5 text-cyan-400" />
            <h3 className="font-display font-bold text-sm">Console de Auditoria do Barramento de Eventos</h3>
          </div>
          <span className="text-[10px] font-mono text-slate-500">Filtrando últimos 100 eventos • Auto-Refresh (8s)</span>
        </div>

        <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 max-h-[300px] overflow-y-auto space-y-1.5">
          {logs.length === 0 ? (
            <p className="text-slate-500 italic text-center py-4">Nenhum evento registrado no barramento ainda.</p>
          ) : (
            logs.map((log, idx) => (
              <div key={idx} className="flex items-start gap-2 hover:bg-slate-900/40 p-1 rounded transition-colors">
                <span className="text-slate-500 text-[10px] shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</span>
                <span className={`text-[10px] font-bold px-1 rounded uppercase shrink-0 ${
                  log.severity === "ERROR" ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                  log.severity === "WARNING" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" :
                  log.severity === "DEBUG" ? "bg-slate-800 text-slate-400" :
                  "bg-cyan-950/40 text-cyan-400 border border-cyan-800/20"
                }`}>
                  {log.severity}
                </span>
                <span className="text-slate-400 font-bold shrink-0">[{log.layer}]</span>
                <span className="text-cyan-600 font-bold shrink-0">({log.sourceId})</span>
                <span className="text-slate-200">{log.message}</span>
                {log.meta && (
                  <span className="text-slate-500 text-[10px] truncate" title={JSON.stringify(log.meta)}>
                    {JSON.stringify(log.meta)}
                  </span>
                )}
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}
