import React, { useState, useEffect } from "react";
import { 
  Search, RefreshCw, Layers, CheckCircle, AlertTriangle, Play, HelpCircle, 
  Settings, Database, Sliders, ArrowUpRight, TrendingUp, Compass, Plus, 
  ToggleLeft, ToggleRight, Loader2, Calendar, FileText, BarChart2
} from "lucide-react";

interface SearchQuery {
  query: string;
  pagina: string;
  pais: string;
  idioma: string;
  dispositivo: string;
  periodo: string;
}

interface SearchMetrics {
  query: string;
  pagina: string;
  impressoes: number;
  cliques: number;
  ctr: number;
  posicao_media: number;
  variacao: number;
  conversor_leads: number;
  conversao_leads: number;
  ultima_atualizacao: string;
}

interface SearchOpportunity {
  id: string;
  query: string;
  pagina: string;
  tipo: string;
  descricao: string;
  impacto: "alto" | "medio" | "baixo";
  metrica_atual: string;
  metrica_esperada: string;
  acao_recomendada: string;
  status: string;
  criado_em: string;
}

interface ConnectorStatus {
  id: string;
  nome: string;
  versao: string;
  status: "ativo" | "inativo" | "falha";
  erros: { timestamp: string; error: string }[];
}

export function OrganicSearch() {
  const [data, setData] = useState<{
    queries: SearchQuery[];
    metrics: SearchMetrics[];
    connectors: ConnectorStatus[];
  } | null>(null);

  const [opportunities, setOpportunities] = useState<SearchOpportunity[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Manual query form state
  const [showManualForm, setShowManualForm] = useState<boolean>(false);
  const [manualQuery, setManualQuery] = useState<string>("");
  const [manualPage, setManualPage] = useState<string>("/blog/");
  const [manualImpressions, setManualImpressions] = useState<number>(2000);
  const [manualClicks, setManualClicks] = useState<number>(150);
  const [manualPosition, setManualPosition] = useState<number>(4.5);
  const [manualLeads, setManualLeads] = useState<number>(25);

  const loadData = async () => {
    try {
      setLoading(true);
      const [resSearch, resOpp] = await Promise.all([
        fetch("/api/organic-os/search").then(r => r.json()),
        fetch("/api/organic-os/search/opportunities").then(r => r.json())
      ]);

      setData(resSearch);
      setOpportunities(resOpp);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError("Erro ao carregar os dados de inteligência de buscas.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSync = async () => {
    try {
      setSyncing(true);
      setSuccessMsg(null);
      const res = await fetch("/api/organic-os/search/sync", { method: "POST" });
      const stats = await res.json();
      
      if (stats.success) {
        setSuccessMsg(`Sincronização concluída! Processado ${stats.queriesProcessed} consultas, gerou ${stats.opportunitiesGenerated} novas oportunidades.`);
        loadData();
      } else {
        setError(stats.error || "Falha na sincronização.");
      }
    } catch (err: any) {
      setError(err.message || "Erro de rede durante sincronização.");
    } finally {
      setSyncing(false);
    }
  };

  const handleToggleConnector = async (id: string, currentlyActive: boolean) => {
    try {
      const res = await fetch("/api/organic-os/search/toggle-connector", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ativo: !currentlyActive })
      });
      const resJson = await res.json();
      if (resJson.success) {
        setSuccessMsg(resJson.message);
        loadData();
      } else {
        setError(resJson.message || "Não foi possível alternar o conector.");
      }
    } catch (err: any) {
      setError(err.message || "Erro ao alternar conector.");
    }
  };

  const handleSubmitManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualQuery.trim() || !manualPage.trim()) return;

    try {
      setSyncing(true);
      const queryPayload = {
        query: manualQuery.trim().toLowerCase(),
        pagina: manualPage.trim(),
        pais: "br",
        idioma: "pt",
        dispositivo: "all",
        periodo: "manual"
      };

      const metricsPayload = {
        query: manualQuery.trim().toLowerCase(),
        pagina: manualPage.trim(),
        impressoes: Number(manualImpressions),
        cliques: Number(manualClicks),
        ctr: Number(manualClicks) > 0 ? Number(manualClicks) / Number(manualImpressions) : 0,
        posicao_media: Number(manualPosition),
        variacao: 0.0,
        conversor_leads: Number(manualLeads),
        conversao_leads: Number(manualClicks) > 0 ? Number(manualLeads) / Number(manualClicks) : 0,
        ultima_atualizacao: new Date().toISOString()
      };

      const historyPayload = {
        data: new Date().toISOString().split("T")[0],
        query: manualQuery.trim().toLowerCase(),
        impressoes: Number(manualImpressions),
        cliques: Number(manualClicks),
        ctr: Number(manualClicks) > 0 ? Number(manualClicks) / Number(manualImpressions) : 0,
        posicao_media: Number(manualPosition)
      };

      const res = await fetch("/api/organic-os/search/manual", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: queryPayload,
          metrics: metricsPayload,
          history: historyPayload
        })
      });

      const resJson = await res.json();
      if (resJson.success) {
        setSuccessMsg("Entrada manual integrada e processada com sucesso!");
        setShowManualForm(false);
        setManualQuery("");
        setManualPage("/blog/");
        loadData();
      } else {
        setError(resJson.error || "Erro ao registrar entrada manual.");
      }
    } catch (err: any) {
      setError(err.message || "Erro ao submeter.");
    } finally {
      setSyncing(false);
    }
  };

  // Aggregated Stats
  const totalQueries = data?.metrics?.length || 0;
  const totalImpressions = data?.metrics?.reduce((sum, m) => sum + m.impressoes, 0) || 0;
  const totalClicks = data?.metrics?.reduce((sum, m) => sum + m.cliques, 0) || 0;
  const avgCtr = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
  const avgPosition = data?.metrics?.length 
    ? (data.metrics.reduce((sum, m) => sum + m.posicao_media, 0) / data.metrics.length) 
    : 0;

  return (
    <div className="space-y-6">
      {/* Upper Title and sync actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0f172a] border border-slate-800 p-6 rounded-xl shadow-xl">
        <div>
          <h2 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Search className="h-6 w-6 text-cyan-400" />
            Search Intelligence Engine
          </h2>
          <p className="text-sm text-slate-400">
            EPIC 02 — Inteligência Adaptativa. Monitoramento e aprendizado contínuo de dados reais de busca.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setShowManualForm(!showManualForm)}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold rounded-lg transition-all border border-slate-700"
          >
            <Plus className="h-4 w-4" />
            Inserir Consulta Manual
          </button>
          
          <button
            onClick={handleSync}
            disabled={syncing}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-800 text-slate-950 text-sm font-bold rounded-lg transition-all"
          >
            {syncing ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Sincronizando...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                Sincronizar Conectores Ativos
              </>
            )}
          </button>
        </div>
      </div>

      {/* Notifications */}
      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-3 text-red-400 text-sm">
          <AlertTriangle className="h-5 w-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-xl flex items-start gap-3 text-green-400 text-sm">
          <CheckCircle className="h-5 w-5 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Manual Input Form Overlay */}
      {showManualForm && (
        <form onSubmit={handleSubmitManual} className="bg-[#0f172a] border border-slate-800 p-6 rounded-xl space-y-4 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h3 className="font-display font-semibold text-white text-md flex items-center gap-2">
              <Plus className="h-5 w-5 text-cyan-400" />
              Adicionar Consulta Manual
            </h3>
            <button type="button" onClick={() => setShowManualForm(false)} className="text-slate-400 hover:text-slate-200">✕</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Palavra-Chave (Query)</label>
              <input
                type="text"
                required
                value={manualQuery}
                onChange={e => setManualQuery(e.target.value)}
                placeholder="ex: simulado prefeitura cumaru do norte"
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Slug da Página de Destino</label>
              <input
                type="text"
                required
                value={manualPage}
                onChange={e => setManualPage(e.target.value)}
                placeholder="ex: /blog/simulado-cumaru"
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Impressões Est. (Mensal)</label>
              <input
                type="number"
                required
                min={0}
                value={manualImpressions}
                onChange={e => setManualImpressions(Number(e.target.value))}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Cliques Est. (Mensal)</label>
              <input
                type="number"
                required
                min={0}
                value={manualClicks}
                onChange={e => setManualClicks(Number(e.target.value))}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Posição Média Atual</label>
              <input
                type="number"
                required
                step="0.1"
                min={1}
                value={manualPosition}
                onChange={e => setManualPosition(Number(e.target.value))}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Leads Capturados (Cliques convertidos)</label>
              <input
                type="number"
                required
                min={0}
                value={manualLeads}
                onChange={e => setManualLeads(Number(e.target.value))}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowManualForm(false)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-white text-sm font-semibold rounded-lg"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={syncing}
              className="px-5 py-2 bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-800 text-slate-950 text-sm font-bold rounded-lg"
            >
              Registrar Consulta
            </button>
          </div>
        </form>
      )}

      {/* Connectors Matrix Section */}
      <div className="bg-[#0f172a] border border-slate-800 p-6 rounded-xl shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-display font-bold text-white text-md flex items-center gap-2">
            <Database className="h-5 w-5 text-cyan-400" />
            Painel de Conectores (Connectors Platform)
          </h3>
          <span className="text-xs font-mono text-slate-500">Arquitetura Baseada em Contratos Únicos</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {data?.connectors?.map((conn) => (
            <div key={conn.id} className="bg-[#1e293b]/40 border border-slate-800 rounded-lg p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between">
                  <span className={`h-2.5 w-2.5 rounded-full ${
                    conn.status === "ativo" ? "bg-green-500" :
                    conn.status === "inativo" ? "bg-slate-600" : "bg-red-500"
                  }`} />
                  <span className="text-[10px] font-mono text-slate-500 uppercase">v{conn.versao}</span>
                </div>
                <h4 className="font-display font-semibold text-white text-sm mt-1.5 leading-snug">{conn.nome}</h4>
                <p className="text-[11px] text-slate-400 font-mono mt-1">ID: {conn.id}</p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 uppercase">
                  {conn.status === "ativo" ? "Ativado" : conn.status === "inativo" ? "Inativo" : "Falha"}
                </span>

                <button
                  type="button"
                  onClick={() => handleToggleConnector(conn.id, conn.status === "ativo")}
                  className="text-slate-400 hover:text-cyan-400 transition-colors"
                  title={conn.status === "ativo" ? "Desativar Conector" : "Ativar Conector"}
                >
                  {conn.status === "ativo" ? (
                    <ToggleRight className="h-7 w-7 text-cyan-400" />
                  ) : (
                    <ToggleLeft className="h-7 w-7 text-slate-600" />
                  )}
                </button>
              </div>

              {conn.erros.length > 0 && (
                <div className="bg-red-950/20 border border-red-900/30 rounded p-2 text-[10px] text-red-400 font-mono max-h-[60px] overflow-y-auto">
                  <strong>Erro:</strong> {conn.erros[0].error}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Aggregate Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[#0f172a] border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
          <span className="text-slate-400 text-xs font-mono uppercase">Consultas Monitoradas</span>
          <span className="text-2xl font-bold text-white mt-1">{totalQueries}</span>
        </div>
        <div className="bg-[#0f172a] border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
          <span className="text-slate-400 text-xs font-mono uppercase">Total Impressões</span>
          <span className="text-2xl font-bold text-cyan-400 mt-1">{totalImpressions.toLocaleString()}</span>
        </div>
        <div className="bg-[#0f172a] border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
          <span className="text-slate-400 text-xs font-mono uppercase">Total Cliques</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1">{totalClicks.toLocaleString()}</span>
        </div>
        <div className="bg-[#0f172a] border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
          <span className="text-slate-400 text-xs font-mono uppercase">Média CTR / Posição</span>
          <span className="text-2xl font-bold text-amber-400 mt-1">
            {avgCtr.toFixed(1)}% / #{avgPosition.toFixed(1)}
          </span>
        </div>
      </div>

      {/* Data split grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Search metrics list */}
        <div className="lg:col-span-2 bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-display font-bold text-white text-md flex items-center gap-2">
              <BarChart2 className="h-5 w-5 text-cyan-400" />
              Estatísticas Reais de Busca Normalizadas
            </h3>
            <span className="text-xs font-mono text-slate-500">Normalização unificada</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900 text-slate-400 uppercase font-mono border-b border-slate-800">
                <tr>
                  <th className="p-3">Consulta (Query)</th>
                  <th className="p-3">URL Alvo</th>
                  <th className="p-3 text-right">Impressões</th>
                  <th className="p-3 text-right">Cliques</th>
                  <th className="p-3 text-right">CTR %</th>
                  <th className="p-3 text-right">Posição</th>
                  <th className="p-3 text-right">Conversão Leads</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="p-4 text-center text-slate-500 italic">Carregando dados...</td>
                  </tr>
                ) : !data?.metrics || data.metrics.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-4 text-center text-slate-500 italic">Nenhum dado sincronizado. Clique em "Sincronizar Conectores Ativos" para carregar os dados.</td>
                  </tr>
                ) : (
                  data.metrics.map((m, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/40">
                      <td className="p-3 text-white font-medium">{m.query}</td>
                      <td className="p-3 text-slate-400 truncate max-w-[150px]" title={m.pagina}>{m.pagina}</td>
                      <td className="p-3 text-right text-cyan-400">{m.impressoes.toLocaleString()}</td>
                      <td className="p-3 text-right text-emerald-400">{m.cliques.toLocaleString()}</td>
                      <td className="p-3 text-right text-amber-400">{(m.ctr * 100).toFixed(1)}%</td>
                      <td className="p-3 text-right text-fuchsia-400">
                        #{m.posicao_media.toFixed(1)}
                        {m.variacao !== 0 && (
                          <span className={`text-[10px] ml-1 ${m.variacao > 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {m.variacao > 0 ? `+${m.variacao}` : m.variacao}
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-right text-slate-300">
                        {m.conversor_leads} / {m.cliques > 0 ? `${(m.conversao_leads * 100).toFixed(1)}%` : "0%"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Opportunities List */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-display font-bold text-white text-md flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-cyan-400" />
              Oportunidades Inteligentes
            </h3>
            <span className="text-xs font-mono text-slate-500">Motor Adaptativo</span>
          </div>

          <div className="space-y-4 max-h-[450px] overflow-y-auto pr-1">
            {loading ? (
              <p className="text-slate-500 italic text-center py-4">Processando oportunidades...</p>
            ) : opportunities.length === 0 ? (
              <p className="text-slate-500 italic text-center py-4">Nenhuma oportunidade gerada ainda. Sincronize os dados para ativar a análise adaptativa.</p>
            ) : (
              opportunities.map((opp) => (
                <div key={opp.id} className="p-4 bg-[#1e293b]/60 border border-slate-800 rounded-lg space-y-2.5">
                  <div className="flex justify-between items-start gap-2">
                    <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded border ${
                      opp.tipo === "alta_impressao_baixo_ctr" ? "bg-amber-500/10 text-amber-400 border-amber-500/20" :
                      opp.tipo === "alta_posicao_baixa_conversao" ? "bg-red-500/10 text-red-400 border-red-500/20" :
                      opp.tipo === "conteudo_promissor" ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" :
                      "bg-slate-500/10 text-slate-400 border-slate-500/20"
                    }`}>
                      {opp.tipo.replace(/_/g, " ")}
                    </span>

                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      opp.impacto === "alto" ? "bg-red-500/20 text-red-400" : "bg-amber-500/20 text-amber-400"
                    }`}>
                      IMPACTO {opp.impacto.toUpperCase()}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-mono text-slate-500 uppercase">Palavra-chave Alvo:</h4>
                    <p className="text-sm font-semibold text-white">'{opp.query}'</p>
                    <p className="text-xs text-slate-400 truncate mt-0.5">{opp.pagina}</p>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed bg-[#0b0f19]/80 p-2.5 rounded border border-slate-800">
                    {opp.descricao}
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-400 bg-slate-900/60 p-2 rounded">
                    <div>
                      <span className="block text-slate-500 font-semibold uppercase">Métrica Atual</span>
                      {opp.metrica_atual}
                    </div>
                    <div>
                      <span className="block text-slate-500 font-semibold uppercase">Meta</span>
                      {opp.metrica_esperada}
                    </div>
                  </div>

                  <div className="p-2.5 bg-cyan-950/20 border border-cyan-500/20 rounded text-xs text-cyan-300 leading-relaxed">
                    <strong>Ação Recomendada:</strong> {opp.acao_recomendada}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
