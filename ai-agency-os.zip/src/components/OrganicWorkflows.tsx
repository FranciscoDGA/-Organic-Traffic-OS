import React, { useState, useEffect, useRef } from "react";
import {
  Play, Pause, RotateCw, Ban, CheckCircle2, XCircle, AlertTriangle,
  Clock, Database, ListOrdered, Calendar, Sparkles, Loader2, ArrowRight,
  History, Eye, ClipboardList, Info, HelpCircle, ChevronRight, Activity, Zap
} from "lucide-react";
import { WorkflowExecution, WorkflowEvent, PipelineStep, PipelineDefinition } from "../../organic-traffic-os/orchestrator/models/workflow-models";

export function OrganicWorkflows() {
  const [executions, setExecutions] = useState<WorkflowExecution[]>([]);
  const [selectedExecId, setSelectedExecId] = useState<string | null>(null);
  const [selectedExecDetails, setSelectedExecDetails] = useState<WorkflowExecution | null>(null);
  const [selectedEvents, setSelectedEvents] = useState<WorkflowEvent[]>([]);
  const [pipeline, setPipeline] = useState<PipelineDefinition | null>(null);
  
  // Creation state
  const [blogName, setBlogName] = useState("");
  
  // UI states
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [viewReport, setViewReport] = useState(false);

  // Auto poll active execution
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetchInitialData();
    return () => {
      stopPolling();
    };
  }, []);

  // Poll current selection if running
  useEffect(() => {
    if (selectedExecId) {
      fetchWorkflowDetails(selectedExecId);
      
      const isCurrentlyRunning = selectedExecDetails?.status === "Running" || selectedExecDetails?.status === "Pending";
      if (isCurrentlyRunning) {
        startPolling(selectedExecId);
      } else {
        stopPolling();
      }
    } else {
      stopPolling();
    }
  }, [selectedExecId, selectedExecDetails?.status]);

  const startPolling = (id: string) => {
    stopPolling();
    pollIntervalRef.current = setInterval(() => {
      pollWorkflowDetails(id);
    }, 1500);
  };

  const stopPolling = () => {
    if (pollIntervalRef.current) {
      clearInterval(pollIntervalRef.current);
      pollIntervalRef.current = null;
    }
  };

  const fetchInitialData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [execsRes, pipeRes] = await Promise.all([
        fetch("/api/organic-os/workflows"),
        fetch("/api/organic-os/sources/categories") // just simple fetch to verify api up, actually pipeline.json is static
      ]);

      if (!execsRes.ok) {
        throw new Error("Falha ao se comunicar com o barramento do orquestrador.");
      }

      const execsData = await execsRes.json();
      setExecutions(execsData);

      // Set first selected
      if (execsData.length > 0) {
        setSelectedExecId(execsData[0].id);
      }

      // Fetch static pipeline structure
      // Wait, let's create a custom endpoint or fetch from hardcoded client-side array matching pipeline-definition.json
      // Let's create an endpoint in server or just define here:
      // Actually we have a pipeline-definition.json we created, let's fetch it if possible. We can write a quick endpoint if needed or load static.
      // Wait, let's check if we can fetch pipeline definition
      const pipelineDef: PipelineDefinition = {
        id: "pipeline-content-default",
        versao: "1.0.0",
        nome: "Pipeline de Produção de Conteúdo Orgânico Completo",
        descricao: "Coordenador unificado de todas as Engines de Inteligência e Conformidade SEO",
        etapas: [
          { id: "step-knowledge", nome: "Knowledge Base", descricao: "Mapeia nicho de mercado, tom de voz, persona de leitores e regras do blog.", modulo: "Knowledge Engine", dependencias: [] },
          { id: "step-inventory", nome: "Inventory Analysis", descricao: "Mapeia os artigos existentes no blog para evitar cannibalização.", modulo: "Inventory Engine", dependencias: ["step-knowledge"] },
          { id: "step-competitors", nome: "Competitors Intelligence", descricao: "Analisa blogs rivais para identificar lacunas estratégicas.", modulo: "Competitors Engine", dependencias: ["step-knowledge"] },
          { id: "step-serp", nome: "SERP Analysis", descricao: "Mapeia as intenções de busca do Google para a palavra-chave foco.", modulo: "SERP Engine", dependencias: ["step-knowledge"] },
          { id: "step-keywords", nome: "Keyword Clustering", descricao: "Encontra e agrupa palavras-chave secundárias com semântica compatível.", modulo: "Keywords Engine", dependencias: ["step-knowledge", "step-serp"] },
          { id: "step-opportunity", nome: "Opportunity Mapping", descricao: "Mapeia lacunas com maior potencial de tráfego rápido.", modulo: "Opportunities Engine", dependencias: ["step-inventory", "step-competitors", "step-keywords"] },
          { id: "step-editorial", nome: "Editorial Planner", descricao: "Gera o planejamento editorial completo de pautas com priorização técnica.", modulo: "Editorial Planner", dependencias: ["step-opportunity"] },
          { id: "step-briefs", nome: "Editorial Briefs", descricao: "Estrutura as seções, headings (H2, H3), CTA e intenção de cada artigo.", modulo: "Brief Engine", dependencias: ["step-editorial"] },
          { id: "step-blueprints", nome: "Page Blueprints", descricao: "Gera a estrutura visual, distribuição de parágrafos e intenção de links.", modulo: "Blueprint Engine", dependencias: ["step-briefs"] },
          { id: "step-research", nome: "Research Packs", descricao: "Coleta e organiza dados de contexto para o redator de inteligência.", modulo: "Research Engine", dependencias: ["step-blueprints"] },
          { id: "step-facts", nome: "Fact Checking Engine", descricao: "Estrutura fatos empíricos comprováveis e notas para o texto.", modulo: "Fact Engine", dependencias: ["step-research"] },
          { id: "step-sources", nome: "Source Intelligence Engine", descricao: "Calcula a autoridade de fontes e lastreia os fatos cadastrados.", modulo: "Source Engine", dependencias: ["step-facts"] }
        ]
      };
      setPipeline(pipelineDef);

    } catch (err: any) {
      setError(err.message || "Erro ao carregar workflows.");
    } finally {
      setLoading(false);
    }
  };

  const fetchWorkflowDetails = async (id: string) => {
    try {
      const res = await fetch(`/api/organic-os/workflows/${id}`);
      if (!res.ok) return;
      const data = await res.json();
      setSelectedExecDetails(data.execution);
      setSelectedEvents(data.events);
    } catch (e) {
      // Ignored
    }
  };

  const pollWorkflowDetails = async (id: string) => {
    try {
      const res = await fetch(`/api/organic-os/workflows/${id}`);
      if (!res.ok) return;
      const data = await res.json();
      setSelectedExecDetails(data.execution);
      setSelectedEvents(data.events);

      // Refresh parent list silently
      const listRes = await fetch("/api/organic-os/workflows");
      if (listRes.ok) {
        const listData = await listRes.json();
        setExecutions(listData);
      }
    } catch (e) {
      // Ignored
    }
  };

  const handleStartWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!blogName.trim()) {
      setError("Insira o nome do Blog para iniciar o pipeline.");
      return;
    }

    setActionLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch("/api/organic-os/workflows/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ blogName })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Erro ao disparar orquestrador.");
      }

      const data = await res.json();
      setSuccess(`Orquestrador inicializado com sucesso para o blog '${blogName}'!`);
      setBlogName("");
      
      // Update local state
      const listRes = await fetch("/api/organic-os/workflows");
      if (listRes.ok) {
        const listData = await listRes.json();
        setExecutions(listData);
        // auto select the new one
        setSelectedExecId(data.execution.id);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleCancelWorkflow = async () => {
    if (!selectedExecId) return;
    setActionLoading(true);
    try {
      const res = await fetch(`/api/organic-os/workflows/${selectedExecId}/cancel`, { method: "POST" });
      if (!res.ok) throw new Error("Erro ao enviar sinal de cancelamento.");
      setSuccess("Orquestração cancelada com sucesso.");
      await pollWorkflowDetails(selectedExecId);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handlePauseWorkflow = async () => {
    if (!selectedExecId) return;
    setActionLoading(true);
    try {
      const res = await fetch(`/api/organic-os/workflows/${selectedExecId}/pause`, { method: "POST" });
      if (!res.ok) throw new Error("Erro ao enviar sinal de pausa.");
      setSuccess("Sinal de pausa enviado. O pipeline será interrompido na próxima etapa.");
      await pollWorkflowDetails(selectedExecId);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleResumeWorkflow = async () => {
    if (!selectedExecId) return;
    setActionLoading(true);
    try {
      const res = await fetch(`/api/organic-os/workflows/${selectedExecId}/resume`, { method: "POST" });
      if (!res.ok) throw new Error("Erro ao enviar sinal de retoma.");
      setSuccess("Orquestrador retomado! Reexecutando etapas pendentes.");
      await pollWorkflowDetails(selectedExecId);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Icon mapping helper for execution status
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Pending":
        return <Clock className="h-4 w-4 text-amber-400" />;
      case "Running":
        return <Loader2 className="h-4 w-4 text-cyan-400 animate-spin" />;
      case "Paused":
        return <Pause className="h-4 w-4 text-amber-500" />;
      case "Completed":
        return <CheckCircle2 className="h-4 w-4 text-emerald-400" />;
      case "Failed":
        return <XCircle className="h-4 w-4 text-rose-500" />;
      case "Cancelled":
        return <Ban className="h-4 w-4 text-slate-500" />;
      default:
        return <HelpCircle className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case "Running":
        return "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20";
      case "Paused":
        return "bg-amber-500/10 text-amber-500 border border-amber-500/30";
      case "Completed":
        return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
      case "Failed":
        return "bg-rose-500/10 text-rose-400 border border-rose-500/20";
      case "Cancelled":
        return "bg-slate-500/10 text-slate-400 border border-slate-500/20";
      default:
        return "bg-slate-800 text-slate-400 border border-slate-700";
    }
  };

  // Check where a step stands in the pipeline
  const getStepStatus = (stepId: string) => {
    if (!selectedExecDetails || !pipeline) return "pending";
    const steps = pipeline.etapas;
    const currentIdx = steps.findIndex(s => s.id === selectedExecDetails.etapa_atual);
    const stepIdx = steps.findIndex(s => s.id === stepId);

    if (selectedExecDetails.status === "Completed") return "completed";
    if (stepIdx < currentIdx) return "completed";
    if (stepIdx === currentIdx) {
      if (selectedExecDetails.status === "Failed") return "failed";
      if (selectedExecDetails.status === "Paused") return "paused";
      return "running";
    }
    return "pending";
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-900 text-slate-100 font-sans">
      
      {/* Top Header */}
      <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-20 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-cyan-950 text-cyan-400 border border-cyan-800 rounded-lg shadow-inner">
            <Zap className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center">
              Content Workflow Orchestrator <span className="ml-2 text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded font-mono">Sprint 15</span>
            </h1>
            <p className="text-xs text-slate-400">Orquestrador Central e Barramento de Grafo de Dependências das Engines de Inteligência SEO</p>
          </div>
        </div>

        {/* Start new pipeline Form */}
        <form onSubmit={handleStartWorkflow} className="flex items-center space-x-2">
          <input
            type="text"
            placeholder="Nome do Blog (Ex: Portal Previdenciário)..."
            value={blogName}
            onChange={(e) => setBlogName(e.target.value)}
            className="text-xs bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 w-64 font-medium"
          />
          <button
            type="submit"
            disabled={actionLoading || !blogName.trim()}
            className="px-4 py-2 bg-cyan-500 text-slate-950 hover:bg-cyan-400 disabled:opacity-50 disabled:hover:bg-cyan-500 rounded-lg text-xs font-bold transition flex items-center shadow-lg whitespace-nowrap"
          >
            <Play className="h-3.5 w-3.5 mr-1.5 fill-current" /> Iniciar Pipeline
          </button>
        </form>
      </header>

      {/* Warnings & Success messages */}
      {error && (
        <div className="mx-6 mt-4 p-4 bg-rose-950/40 border border-rose-800/60 text-rose-300 rounded-lg text-sm flex items-center space-x-2">
          <XCircle className="h-5 w-5 flex-shrink-0 text-rose-500" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="mx-6 mt-4 p-4 bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 rounded-lg text-sm flex items-center space-x-2">
          <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-emerald-500" />
          <span>{success}</span>
        </div>
      )}

      {/* Main Grid View */}
      <div className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Executions Directory (4 cols) */}
        <aside className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl shadow-lg flex flex-col overflow-hidden max-h-[850px]">
          <div className="p-4 bg-slate-900/60 border-b border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center">
              <ClipboardList className="h-4 w-4 mr-2 text-cyan-400" /> Histórico de Orquestrações
            </h3>
            <p className="text-[10px] text-slate-500 mt-0.5">Execuções de artigos e pautas coordenadas pelo orquestrador</p>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-900">
            {executions.map(exec => {
              const isSelected = exec.id === selectedExecId;
              return (
                <div
                  key={exec.id}
                  onClick={() => {
                    setSelectedExecId(exec.id);
                    setViewReport(false);
                  }}
                  className={`p-4 cursor-pointer hover:bg-slate-900/40 transition flex flex-col ${
                    isSelected ? "bg-cyan-950/20 border-l-4 border-cyan-500" : ""
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] text-slate-500 font-mono">ID: {exec.id.substr(0, 10)}</span>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold flex items-center space-x-1 ${getStatusClass(exec.status)}`}>
                      {getStatusIcon(exec.status)}
                      <span className="ml-1 uppercase">{exec.status}</span>
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-white line-clamp-1 mb-2">
                    {exec.blog}
                  </h4>

                  {/* Progress bar */}
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span>Etapa: <span className="text-slate-300 font-mono font-bold">{exec.etapa_atual.replace("step-", "")}</span></span>
                    <span className="font-mono font-bold text-cyan-400">{exec.progresso}%</span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-1 overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        exec.status === "Failed" ? "bg-rose-500" :
                        exec.status === "Cancelled" ? "bg-slate-500" :
                        "bg-cyan-400"
                      }`}
                      style={{ width: `${exec.progresso}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[9px] text-slate-500 font-mono mt-2.5 pt-2 border-t border-slate-900">
                    <span className="flex items-center"><Clock className="h-3 w-3 mr-1" /> {exec.tempo_total || "Processando..."}</span>
                    <span className="text-rose-400/90 font-bold">Erros: {exec.erros.length}</span>
                  </div>
                </div>
              );
            })}

            {executions.length === 0 && (
              <div className="p-12 text-center text-slate-600 flex flex-col items-center">
                <AlertTriangle className="h-10 w-10 mb-2 stroke-1 text-slate-600" />
                <p className="text-xs">Nenhum pipeline foi executado ainda.</p>
              </div>
            )}
          </div>

          <div className="p-3 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center font-mono">
            <span>Orquestrador Ativo</span>
            <span>Policy: Max 3 Retries</span>
          </div>
        </aside>

        {/* Right Side: Active Workspace (8 cols) */}
        <main className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-xl shadow-lg flex flex-col overflow-hidden max-h-[850px]">
          {selectedExecDetails ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              
              {/* Workspace Header */}
              <div className="p-6 border-b border-slate-800 bg-slate-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center space-x-2 mb-1.5">
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-black uppercase font-mono tracking-wider ${getStatusClass(selectedExecDetails.status)}`}>
                      {selectedExecDetails.status}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">ID: {selectedExecDetails.id}</span>
                  </div>
                  <h2 className="text-base font-bold text-white tracking-tight">
                    Monitoramento da Orquestração: <span className="text-cyan-400">{selectedExecDetails.blog}</span>
                  </h2>
                </div>

                {/* Engine State Controls */}
                <div className="flex items-center space-x-2">
                  {(selectedExecDetails.status === "Running" || selectedExecDetails.status === "Pending") && (
                    <>
                      <button
                        onClick={handlePauseWorkflow}
                        className="px-3 py-1.5 bg-amber-500 text-slate-950 hover:bg-amber-400 rounded text-xs font-bold flex items-center transition"
                      >
                        <Pause className="h-3.5 w-3.5 mr-1" /> Pausar
                      </button>
                      <button
                        onClick={handleCancelWorkflow}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded text-xs font-bold flex items-center transition"
                      >
                        <Ban className="h-3.5 w-3.5 mr-1" /> Cancelar
                      </button>
                    </>
                  )}

                  {(selectedExecDetails.status === "Paused" || selectedExecDetails.status === "Failed") && (
                    <button
                      onClick={handleResumeWorkflow}
                      className="px-4 py-1.5 bg-emerald-500 text-slate-950 hover:bg-emerald-400 rounded text-xs font-bold flex items-center transition"
                    >
                      <RotateCw className="h-3.5 w-3.5 mr-1" /> Retomar Execução
                    </button>
                  )}

                  {selectedExecDetails.status === "Completed" && (
                    <button
                      onClick={() => setViewReport(!viewReport)}
                      className="px-3 py-1.5 bg-slate-800 text-cyan-400 border border-slate-700 hover:bg-slate-755 rounded text-xs font-bold flex items-center transition"
                    >
                      <Eye className="h-3.5 w-3.5 mr-1.5" /> {viewReport ? "Ver Grafo" : "Ver Relatório Técnico"}
                    </button>
                  )}
                </div>
              </div>

              {/* View final report if requested */}
              {viewReport ? (
                <div className="flex-1 overflow-y-auto p-6 bg-slate-950">
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-inner max-w-3xl mx-auto">
                    <div className="border-b border-slate-800 pb-4 mb-4 flex items-center justify-between">
                      <h3 className="font-bold text-white text-sm uppercase tracking-wider flex items-center">
                        <ClipboardList className="h-4 w-4 text-cyan-400 mr-2" /> Relatório Técnico Gerado
                      </h3>
                      <button onClick={() => setViewReport(false)} className="text-[10px] text-cyan-400 hover:underline">
                        Voltar para Grafo [x]
                      </button>
                    </div>

                    <div className="prose prose-invert text-xs text-slate-300 leading-relaxed font-mono space-y-4">
                      <p className="text-cyan-400 font-bold text-sm"># Relatório de Execução do Pipeline Unificado</p>
                      <p><strong>ID da Execução:</strong> {selectedExecDetails.id}</p>
                      <p><strong>Blog de Destino:</strong> {selectedExecDetails.blog}</p>
                      <p><strong>Início:</strong> {new Date(selectedExecDetails.inicio).toLocaleString()}</p>
                      <p><strong>Fim:</strong> {selectedExecDetails.fim ? new Date(selectedExecDetails.fim).toLocaleString() : "N/A"}</p>
                      <p><strong>Duração Decorrida:</strong> {selectedExecDetails.tempo_total || "N/A"}</p>
                      <p><strong>Erros:</strong> {selectedExecDetails.erros.length} | <strong>Avisos:</strong> {selectedExecDetails.avisos.length}</p>
                      
                      <div className="mt-4 p-3 bg-slate-950 border border-slate-800 rounded text-[11px] text-slate-400 space-y-1.5">
                        <span className="font-bold text-white block mb-1">Avisos Registrados pelas Engines:</span>
                        {selectedExecDetails.avisos.map((w, i) => (
                          <div key={i} className="flex items-start space-x-1.5">
                            <span className="text-amber-500">•</span>
                            <span>{w}</span>
                          </div>
                        ))}
                        {selectedExecDetails.avisos.length === 0 && <span className="italic text-slate-500">Nenhum aviso emitido.</span>}
                      </div>

                      <div className="mt-4 border-t border-slate-800 pt-4">
                        <span className="font-bold text-white block mb-2">Trilha de Eventos Registrada:</span>
                        <div className="space-y-1 text-[11px] max-h-[250px] overflow-y-auto">
                          {selectedEvents.map((evt, i) => (
                            <div key={i} className="flex items-start space-x-1 font-mono">
                              <span className="text-slate-500">[{new Date(evt.data).toLocaleTimeString()}]</span>
                              <span className="text-cyan-400 uppercase">[{evt.tipo}]</span>
                              <span className="text-slate-300">{evt.mensagem}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto p-6 flex flex-col space-y-6">
                  
                  {/* Pipeline Step Progress Visual Map */}
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4 flex items-center">
                      <ListOrdered className="h-4 w-4 mr-2 text-cyan-400" /> Grafo Sequencial do Pipeline de Produção
                    </h3>

                    {/* Stepper visual grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                      {pipeline?.etapas.map((step, idx) => {
                        const state = getStepStatus(step.id);
                        return (
                          <div
                            key={step.id}
                            className={`p-3.5 rounded-xl border transition flex flex-col justify-between ${
                              state === "completed" ? "bg-emerald-950/15 border-emerald-800/40 text-slate-300" :
                              state === "running" ? "bg-cyan-950/20 border-cyan-500 text-white shadow-lg shadow-cyan-950/20" :
                              state === "failed" ? "bg-rose-950/10 border-rose-800 text-slate-300" :
                              state === "paused" ? "bg-amber-950/10 border-amber-800 text-slate-300" :
                              "bg-slate-900/40 border-slate-800/80 text-slate-500"
                            }`}
                          >
                            <div className="flex items-start justify-between mb-2">
                              <span className="text-[10px] font-mono font-bold text-slate-400">Etapa {idx + 1}</span>
                              <span className={`w-2.5 h-2.5 rounded-full ${
                                state === "completed" ? "bg-emerald-400" :
                                state === "running" ? "bg-cyan-400 animate-ping" :
                                state === "failed" ? "bg-rose-500" :
                                state === "paused" ? "bg-amber-500" :
                                "bg-slate-700"
                              }`} />
                            </div>

                            <div>
                              <h4 className="text-xs font-bold text-slate-200 line-clamp-1">{step.nome}</h4>
                              <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-normal">{step.descricao}</p>
                            </div>

                            <div className="mt-3 pt-2.5 border-t border-slate-900 flex items-center justify-between text-[9px] font-mono">
                              <span className="text-slate-500">Módulo: {step.modulo.replace(" Engine", "")}</span>
                              {state === "completed" && <span className="text-emerald-400 font-bold">OK</span>}
                              {state === "running" && <span className="text-cyan-400 font-bold animate-pulse">PROCESSANDO</span>}
                              {state === "failed" && <span className="text-rose-400 font-bold">FALHOU</span>}
                              {state === "paused" && <span className="text-amber-400 font-bold">PAUSADO</span>}
                              {state === "pending" && <span className="text-slate-600">PENDENTE</span>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Anomaly Tracker / Output logs section */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Event Logs Timeline */}
                    <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 flex flex-col max-h-[350px]">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center">
                        <History className="h-4 w-4 mr-2 text-cyan-400" /> Eventos da Sessão (Audit Trail)
                      </h3>

                      <div className="flex-1 overflow-y-auto space-y-3 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-850 pr-1">
                        {selectedEvents.map((evt) => (
                          <div key={evt.id} className="flex items-start space-x-2 pl-0.5 relative">
                            <span className={`w-1.5 h-1.5 rounded-full mt-1.5 z-10 ${
                              evt.tipo === "inicio" ? "bg-cyan-400" :
                              evt.tipo === "fim" ? "bg-emerald-400" :
                              evt.tipo === "erro" ? "bg-rose-500" :
                              evt.tipo === "retry" ? "bg-amber-500" :
                              "bg-slate-500"
                            }`} />
                            <div className="text-[11px] leading-relaxed">
                              <div className="flex items-center space-x-1.5">
                                <span className="font-bold text-slate-300 uppercase text-[9px] font-mono">[{evt.tipo}]</span>
                                <span className="text-[9px] text-slate-500 font-mono">{new Date(evt.data).toLocaleTimeString()}</span>
                              </div>
                              <p className="text-slate-400">{evt.mensagem}</p>
                              {evt.detalhes && <p className="text-[10px] text-slate-500 italic font-mono">{evt.detalhes}</p>}
                            </div>
                          </div>
                        ))}

                        {selectedEvents.length === 0 && (
                          <p className="text-xs text-slate-600 italic pl-5">Nenhum evento registrado nesta orquestração.</p>
                        )}
                      </div>
                    </div>

                    {/* Sibling Details: Anomaly warnings & state info */}
                    <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between max-h-[350px]">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center">
                          <AlertTriangle className="h-4 w-4 mr-2 text-cyan-400" /> Anomalias & Alertas da Execução
                        </h3>

                        <div className="space-y-2 max-h-[180px] overflow-y-auto">
                          {selectedExecDetails.erros.map((err, i) => (
                            <div key={i} className="p-2.5 bg-rose-950/20 border border-rose-900/30 rounded-lg text-[11px] text-rose-300 flex items-center space-x-2">
                              <XCircle className="h-4 w-4 text-rose-500 flex-shrink-0" />
                              <span><strong>Erro Crítico:</strong> {err}</span>
                            </div>
                          ))}

                          {selectedExecDetails.avisos.map((warn, i) => (
                            <div key={i} className="p-2.5 bg-amber-950/20 border border-amber-900/30 rounded-lg text-[11px] text-amber-300 flex items-center space-x-2">
                              <AlertTriangle className="h-4 w-4 text-amber-500 flex-shrink-0" />
                              <span><strong>Aviso técnico:</strong> {warn}</span>
                            </div>
                          ))}

                          {selectedExecDetails.erros.length === 0 && selectedExecDetails.avisos.length === 0 && (
                            <div className="p-8 text-center text-xs text-slate-600">
                              Nenhum alerta ou erro gerado pelas engines. Pipeline em conformidade estrita.
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="p-3 bg-slate-900 border border-slate-850 rounded-xl flex items-center justify-between text-xs mt-4">
                        <div className="flex items-center space-x-2">
                          <Activity className="h-4 w-4 text-cyan-400 animate-pulse" />
                          <span className="font-bold text-slate-300">Tempo de Processamento:</span>
                        </div>
                        <span className="font-mono text-cyan-400 font-bold">{selectedExecDetails.tempo_total || "Em execução"}</span>
                      </div>
                    </div>

                  </div>

                </div>
              )}

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-12 text-slate-500">
              <Zap className="h-12 w-12 text-slate-700 mb-3 stroke-1" />
              <h3 className="font-bold text-slate-400">Selecione ou inicie uma Orquestração</h3>
              <p className="text-xs max-w-sm mt-1">
                Insira o nome do seu blog de teste no cabeçalho ou selecione um registro histórico ao lado para monitorar e auditar a orquestração integrada em tempo real.
              </p>
            </div>
          )}
        </main>
      </div>

    </div>
  );
}
