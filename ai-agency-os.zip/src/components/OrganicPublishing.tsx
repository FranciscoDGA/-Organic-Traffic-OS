import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Send, 
  RotateCw, 
  Trash2, 
  Copy, 
  Check, 
  AlertCircle, 
  Search, 
  Settings, 
  Globe, 
  Braces, 
  Terminal, 
  BookOpen, 
  Sparkles, 
  Clock, 
  FileCheck, 
  Eye, 
  PlusCircle, 
  Layers, 
  HelpCircle, 
  ExternalLink,
  ChevronRight,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ContentDocument {
  content_id: string;
  asset_id: string;
  titulo: string;
  slug: string;
  tipo: string;
  versao: string;
  status: "preparado" | "revisado" | "pronto_para_publicar";
  idioma: string;
  autor: string;
  created_at: string;
  updated_at: string;
  corpo_formatado: string;
  seo?: {
    titulo_seo: string;
    meta_descricao: string;
    palavras_chave: string[];
    canonical_url: string;
    open_graph?: {
      og_title: string;
      og_description: string;
      og_type: string;
    };
  };
  schema_org?: any;
  assets_relacionados: string[];
}

interface PublishManifest {
  content_id: string;
  versao: string;
  destino: string;
  renderer: "html" | "markdown" | "json" | "wordpress" | "nextjs";
  status: string;
  checksum: string;
}

interface PublishingPackage {
  documento: ContentDocument;
  metadados: {
    tempo_estimado_leitura_minutos: number;
    densidade_palavras_chave: Record<string, number>;
    contagem_palavras: number;
    data_preparacao: string;
  };
  seo?: ContentDocument["seo"];
  schema?: any;
  assets_relacionados?: any[];
  manifest: PublishManifest;
}

interface Asset {
  id: string;
  content_id: string;
  titulo: string;
  tipo: string;
  versao: string;
  criado_em: string;
}

export default function OrganicPublishing() {
  const [publications, setPublications] = useState<PublishingPackage[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPub, setSelectedPub] = useState<PublishingPackage | null>(null);
  
  // States for preparation form
  const [selectedAssetId, setSelectedAssetId] = useState("");
  const [selectedDestino, setSelectedDestino] = useState<"WordPress" | "Next.js" | "HTML" | "Markdown" | "CMS Headless" | "JSON" | "RSS" | "PDF">("HTML");
  
  // UI States
  const [copiedText, setCopiedText] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTabSub, setActiveTabSub] = useState<"visualizar" | "codigo" | "seo" | "schema">("visualizar");
  const [filterDestino, setFilterDestino] = useState<string>("todos");
  
  // Status message
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const showToast = (message: string, type: "success" | "error" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // Carregar publicações preparadas
      const pubRes = await fetch("/api/organic-os/publishing");
      if (pubRes.ok) {
        const data = await pubRes.json();
        setPublications(data);
        if (data.length > 0 && !selectedPub) {
          setSelectedPub(data[0]);
        }
      }

      // Carregar ativos disponíveis na biblioteca para formulário de preparação
      const assetRes = await fetch("/api/organic-os/assets");
      if (assetRes.ok) {
        const assetData = await assetRes.json();
        setAssets(assetData);
        if (assetData.length > 0 && !selectedAssetId) {
          setSelectedAssetId(assetData[0].id);
        }
      }
    } catch (e) {
      console.error("Erro ao buscar dados do Publishing Engine:", e);
      showToast("Não foi possível carregar os dados de publicação.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handlePrepare = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssetId || !selectedDestino) {
      showToast("Selecione um ativo e um destino para prosseguir.", "error");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/organic-os/publishing/prepare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assetId: selectedAssetId, destino: selectedDestino })
      });

      if (res.ok) {
        const data = await res.json();
        showToast(`Pacote de publicação para '${selectedDestino}' gerado com sucesso!`);
        fetchData();
        if (data.package) {
          setSelectedPub(data.package);
        }
      } else {
        const err = await res.json();
        showToast(err.error || "Erro ao preparar pacote de publicação.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Erro de rede ao conectar com o servidor.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (contentId: string) => {
    if (!confirm("Tem certeza que deseja excluir permanentemente este pacote de publicação? Isso apagará o manifesto e o arquivo de exportação.")) return;
    try {
      const res = await fetch(`/api/organic-os/publishing/${contentId}`, {
        method: "DELETE"
      });

      if (res.ok) {
        showToast("Pacote de publicação removido da fila de prontidão.");
        if (selectedPub?.documento.content_id === contentId) {
          setSelectedPub(null);
        }
        fetchData();
      } else {
        showToast("Falha ao excluir publicação.", "error");
      }
    } catch (e) {
      showToast("Erro ao tentar processar requisição.", "error");
    }
  };

  const handleUpdateStatus = async (contentId: string, newStatus: "preparado" | "revisado" | "pronto_para_publicar") => {
    try {
      const res = await fetch("/api/organic-os/publishing/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contentId, status: newStatus })
      });

      if (res.ok) {
        showToast(`Status da publicação atualizado para '${newStatus}'!`);
        // Atualizar localmente
        setPublications(prev => prev.map(p => {
          if (p.documento.content_id === contentId) {
            const updated = { ...p, documento: { ...p.documento, status: newStatus } };
            if (selectedPub?.documento.content_id === contentId) {
              setSelectedPub(updated);
            }
            return updated;
          }
          return p;
        }));
      } else {
        showToast("Falha ao atualizar status.", "error");
      }
    } catch (e) {
      showToast("Erro ao conectar ao servidor.", "error");
    }
  };

  const handleVersionIncremental = async (contentId: string) => {
    try {
      const res = await fetch("/api/organic-os/publishing/version", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contentId })
      });

      if (res.ok) {
        const data = await res.json();
        showToast(`Nova versão incremental ${data.package.documento.versao} criada com novo Checksum de segurança!`);
        setPublications(prev => prev.map(p => {
          if (p.documento.content_id === contentId) {
            if (selectedPub?.documento.content_id === contentId) {
              setSelectedPub(data.package);
            }
            return data.package;
          }
          return p;
        }));
      } else {
        showToast("Falha ao versionar conteúdo.", "error");
      }
    } catch (e) {
      showToast("Erro ao processar versionamento incremental.", "error");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Filtrar publicações com base na busca e filtro de destino
  const filteredPublications = publications.filter(p => {
    const matchesSearch = p.documento.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.documento.content_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.manifest.destino.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDestino = filterDestino === "todos" ? true : p.manifest.destino === filterDestino;
    
    return matchesSearch && matchesDestino;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl shadow-lg border flex items-center gap-2 ${
              toast.type === "success" 
                ? "bg-emerald-950/90 border-emerald-500/30 text-emerald-300" 
                : "bg-rose-950/90 border-rose-500/30 text-rose-300"
            }`}
          >
            {toast.type === "success" ? <Check className="h-5 w-5 text-emerald-400" /> : <AlertCircle className="h-5 w-5 text-rose-400" />}
            <span className="text-sm font-medium">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Panel */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Send className="w-40 h-40 text-cyan-400" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="inline-block px-2.5 py-0.5 bg-cyan-950 text-cyan-400 font-mono text-[10px] uppercase tracking-wider rounded-md border border-cyan-500/20 mb-2">
              Sprint 24 — Publishing Engine
            </span>
            <h2 className="text-2xl font-display font-bold text-white tracking-tight flex items-center gap-2">
              <Send className="h-6 w-6 text-cyan-400" />
              Motor de Preparação para Publicação
            </h2>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Transforme ativos de conteúdo aprovados em pacotes de publicação semanticamente otimizados, prontos para injeção e renderização em WordPress, Next.js, HTML, Markdown ou JSON.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={fetchData} 
              disabled={loading}
              className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-cyan-400 disabled:opacity-50 transition-colors"
              title="Recarregar dados"
            >
              <RotateCw className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <a 
              href="/organic-traffic-os/publishing/reports/sprint-24-summary.md" 
              target="_blank"
              className="px-4 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <BookOpen className="h-4 w-4" />
              Documentação
            </a>
          </div>
        </div>
      </div>

      {/* Form de Preparação Rápida */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-md">
        <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-2 border-b border-slate-800 pb-2">
          <PlusCircle className="h-4 w-4 text-cyan-400" />
          Preparar Novo Pacote de Publicação
        </h3>

        {assets.length === 0 ? (
          <div className="p-4 bg-slate-950/50 border border-slate-800/60 rounded-xl text-center">
            <p className="text-sm text-slate-500">Nenhum Ativo de Conteúdo encontrado na biblioteca. Gere ativos primeiro na aba "Ativos de Conteúdo (Asset Gen)".</p>
          </div>
        ) : (
          <form onSubmit={handlePrepare} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-medium">1. Escolher Ativo da Biblioteca</label>
              <select
                value={selectedAssetId}
                onChange={(e) => setSelectedAssetId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-cyan-500"
              >
                {assets.map(a => (
                  <option key={a.id} value={a.id}>
                    [{a.tipo.toUpperCase()}] {a.titulo} (v{a.versao})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-medium">2. Definir Destino / Canal</label>
              <select
                value={selectedDestino}
                onChange={(e) => setSelectedDestino(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-cyan-500"
              >
                <option value="HTML">HTML (Web Semântica)</option>
                <option value="Markdown">Markdown (.MD estático)</option>
                <option value="WordPress">WordPress (Blocos Gutenberg)</option>
                <option value="Next.js">Next.js (TSX Component)</option>
                <option value="JSON">JSON (REST API Carga)</option>
                <option value="CMS Headless">CMS Headless (Decoupled Payload)</option>
                <option value="RSS">RSS Feed</option>
                <option value="PDF">PDF Estruturado</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold py-2 px-4 rounded-lg text-sm flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <FileCheck className="h-4 w-4" />
              Preparar e Compilar Pacote
            </button>
          </form>
        )}
      </div>

      {/* Main Grid: List & Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Fila de Prontidão */}
        <div className="lg:col-span-5 bg-[#0f172a] border border-slate-800 rounded-xl shadow-md p-5 flex flex-col h-[700px]">
          <div className="mb-4">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Layers className="h-4 w-4 text-cyan-400" />
              Fila de Prontidão de Publicação ({filteredPublications.length})
            </h3>
            <p className="text-xs text-slate-500 mt-1">Pacotes compilados prontos para sincronização futura.</p>
          </div>

          {/* Search and Destination Filter */}
          <div className="space-y-2 mb-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
              <input
                type="text"
                placeholder="Buscar publicação ou ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-300 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {["todos", "WordPress", "Next.js", "HTML", "Markdown", "JSON", "CMS Headless"].map(dst => (
                <button
                  key={dst}
                  onClick={() => setFilterDestino(dst)}
                  className={`px-2.5 py-1 rounded text-[10px] font-medium border whitespace-nowrap transition-all ${
                    filterDestino === dst 
                      ? "bg-cyan-950 text-cyan-400 border-cyan-500/40" 
                      : "bg-slate-900 text-slate-400 border-transparent hover:text-slate-300"
                  }`}
                >
                  {dst === "todos" ? "Todos Destinos" : dst}
                </button>
              ))}
            </div>
          </div>

          {/* Queue List */}
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
            {filteredPublications.length === 0 ? (
              <div className="h-40 flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-xl">
                <FileText className="h-8 w-8 text-slate-600 mb-1" />
                <p className="text-xs text-slate-500 text-center px-4">Nenhuma publicação preparada encontrada no momento para os filtros aplicados.</p>
              </div>
            ) : (
              filteredPublications.map(p => {
                const isSelected = selectedPub?.documento.content_id === p.documento.content_id;
                
                // Definir cor com base no status de prontidão
                let statusColor = "bg-yellow-500/10 text-yellow-400 border-yellow-500/20";
                let statusLabel = "Preparado";
                if (p.documento.status === "revisado") {
                  statusColor = "bg-cyan-500/10 text-cyan-400 border-cyan-500/20";
                  statusLabel = "Revisado";
                } else if (p.documento.status === "pronto_para_publicar") {
                  statusColor = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
                  statusLabel = "Pronto P/ Pub";
                }

                // Ícones de renderizador
                let renderLabel = p.manifest.renderer.toUpperCase();

                return (
                  <div
                    key={p.documento.content_id}
                    onClick={() => setSelectedPub(p)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      isSelected 
                        ? "bg-cyan-950/20 border-cyan-500/40 shadow-md shadow-cyan-950/10" 
                        : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-[10px] font-mono text-slate-500 font-bold">{p.documento.content_id}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono border ${statusColor}`}>
                        {statusLabel}
                      </span>
                    </div>

                    <h4 className={`text-xs font-semibold mt-1.5 line-clamp-1 ${isSelected ? "text-cyan-400" : "text-slate-200"}`}>
                      {p.documento.titulo}
                    </h4>

                    <div className="flex flex-wrap items-center gap-2 mt-2.5 pt-2 border-t border-slate-800/40">
                      <span className="px-1.5 py-0.5 bg-slate-900 text-slate-400 text-[10px] rounded border border-slate-850">
                        {p.manifest.destino}
                      </span>
                      <span className="px-1.5 py-0.5 bg-slate-900 text-slate-400 text-[10px] rounded border border-slate-850">
                        Render: {renderLabel}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono ml-auto">
                        v{p.documento.versao}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Visualizador do Pacote de Publicação */}
        <div className="lg:col-span-7 bg-[#0f172a] border border-slate-800 rounded-xl shadow-md p-5 flex flex-col h-[700px]">
          {selectedPub ? (
            <div className="flex flex-col h-full">
              {/* Header de Visualização */}
              <div className="border-b border-slate-800 pb-4 mb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-md font-bold text-slate-100 line-clamp-1">{selectedPub.documento.titulo}</h3>
                    <span className="px-1.5 py-0.5 bg-slate-850 text-slate-400 text-[10px] rounded font-mono border border-slate-800">
                      v{selectedPub.documento.versao}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5 font-mono">
                    ID Conteúdo: {selectedPub.documento.content_id} | Checksum: {selectedPub.manifest.checksum.slice(0,18)}...
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {/* Atualizador de Status */}
                  <select
                    value={selectedPub.documento.status}
                    onChange={(e) => handleUpdateStatus(selectedPub.documento.content_id, e.target.value as any)}
                    className="bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded-md px-2 py-1 focus:outline-none focus:border-cyan-500"
                    title="Mudar status de prontidão"
                  >
                    <option value="preparado">Preparado</option>
                    <option value="revisado">Revisado</option>
                    <option value="pronto_para_publicar">Pronto p/ Publicar</option>
                  </select>

                  {/* Versionador manual */}
                  <button
                    onClick={() => handleVersionIncremental(selectedPub.documento.content_id)}
                    className="p-1 bg-slate-900 border border-slate-850 hover:border-slate-750 text-slate-400 hover:text-cyan-400 rounded transition-colors"
                    title="Gerar nova versão incremental (v+0.1)"
                  >
                    <RotateCw className="h-3.5 w-3.5" />
                  </button>

                  {/* Excluidor */}
                  <button
                    onClick={() => handleDelete(selectedPub.documento.content_id)}
                    className="p-1.5 bg-rose-950/20 border border-rose-900/30 hover:border-rose-700 text-rose-400 hover:text-rose-300 rounded transition-colors"
                    title="Excluir pacote preparado"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Sub-abas de conteúdo do pacote */}
              <div className="flex border-b border-slate-800 mb-4">
                <button
                  onClick={() => setActiveTabSub("visualizar")}
                  className={`py-2 px-3 text-xs font-semibold border-b-2 -mb-px transition-all flex items-center gap-1.5 ${
                    activeTabSub === "visualizar" 
                      ? "border-cyan-500 text-cyan-400" 
                      : "border-transparent text-slate-400 hover:text-slate-300"
                  }`}
                >
                  <Eye className="h-3.5 w-3.5" />
                  Visualizar Render
                </button>
                <button
                  onClick={() => setActiveTabSub("codigo")}
                  className={`py-2 px-3 text-xs font-semibold border-b-2 -mb-px transition-all flex items-center gap-1.5 ${
                    activeTabSub === "codigo" 
                      ? "border-cyan-500 text-cyan-400" 
                      : "border-transparent text-slate-400 hover:text-slate-300"
                  }`}
                >
                  <Terminal className="h-3.5 w-3.5" />
                  Código Fonte
                </button>
                <button
                  onClick={() => setActiveTabSub("seo")}
                  className={`py-2 px-3 text-xs font-semibold border-b-2 -mb-px transition-all flex items-center gap-1.5 ${
                    activeTabSub === "seo" 
                      ? "border-cyan-500 text-cyan-400" 
                      : "border-transparent text-slate-400 hover:text-slate-300"
                  }`}
                >
                  <Globe className="h-3.5 w-3.5" />
                  SEO & Metadados
                </button>
                <button
                  onClick={() => setActiveTabSub("schema")}
                  className={`py-2 px-3 text-xs font-semibold border-b-2 -mb-px transition-all flex items-center gap-1.5 ${
                    activeTabSub === "schema" 
                      ? "border-cyan-500 text-cyan-400" 
                      : "border-transparent text-slate-400 hover:text-slate-300"
                  }`}
                >
                  <Braces className="h-3.5 w-3.5" />
                  Schema JSON-LD
                </button>
              </div>

              {/* Área do Corpo das Sub-abas */}
              <div className="flex-1 overflow-y-auto bg-slate-950/40 border border-slate-850 rounded-xl p-4 min-h-0">
                {activeTabSub === "visualizar" && (
                  <div className="space-y-4">
                    {/* Badge de Metadados rápidos do Render */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 p-3 bg-slate-900 border border-slate-850 rounded-lg">
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-slate-500">Tempo de Leitura</span>
                        <span className="text-xs font-bold text-slate-300 flex items-center gap-1 mt-0.5">
                          <Clock className="h-3 w-3 text-cyan-400" />
                          ~{selectedPub.metadados.tempo_estimado_leitura_minutos} min
                        </span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-slate-500">Palavras Total</span>
                        <span className="text-xs font-bold text-slate-300 mt-0.5 block">
                          {selectedPub.metadados.contagem_palavras} palavras
                        </span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-slate-500">Destino Compilado</span>
                        <span className="text-xs font-bold text-cyan-400 mt-0.5 block font-mono">
                          {selectedPub.manifest.destino}
                        </span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-slate-500">Roteador Motor</span>
                        <span className="text-xs font-bold text-slate-300 mt-0.5 block font-mono">
                          {selectedPub.manifest.renderer.toUpperCase()}
                        </span>
                      </div>
                    </div>

                    {/* Visualização de Silo Conectado se houver */}
                    {selectedPub.assets_relacionados && selectedPub.assets_relacionados.length > 0 && (
                      <div className="p-3 bg-cyan-950/10 border border-cyan-500/20 rounded-lg">
                        <span className="text-[10px] uppercase font-mono font-bold text-cyan-400 flex items-center gap-1">
                          <Layers className="h-3.5 w-3.5" />
                          Ancoragem de Silagem Ativa ({selectedPub.assets_relacionados.length})
                        </span>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {selectedPub.assets_relacionados.map((rel: any, idx: number) => (
                            <span 
                              key={idx} 
                              className="px-2 py-0.5 bg-cyan-900/20 text-cyan-300 text-[10px] font-medium border border-cyan-500/10 rounded flex items-center gap-1"
                            >
                              {rel.titulo || `Ativo Conectado: ${rel.id || rel}`}
                              <ChevronRight className="h-2.5 w-2.5 text-cyan-500" />
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Conteúdo Renderizado (HTML Mock/Formatado) */}
                    <div className="prose prose-invert prose-sm max-w-none text-slate-300 p-1">
                      {selectedPub.manifest.renderer === "html" ? (
                        <div 
                          dangerouslySetInnerHTML={{ __html: selectedPub.documento.corpo_formatado }} 
                          className="organic-rendered-preview-box space-y-4"
                        />
                      ) : (
                        <div className="whitespace-pre-wrap font-sans text-xs bg-slate-900/60 p-4 rounded-xl border border-slate-850">
                          {selectedPub.documento.corpo_formatado}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeTabSub === "codigo" && (
                  <div className="h-full flex flex-col space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-medium">Código fonte completo para destino: <strong>{selectedPub.manifest.destino}</strong></span>
                      <button
                        onClick={() => copyToClipboard(selectedPub.documento.corpo_formatado)}
                        className="px-2.5 py-1 bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-semibold rounded text-slate-300 flex items-center gap-1.5 transition-colors"
                      >
                        {copiedText ? (
                          <>
                            <Check className="h-3 w-3 text-emerald-400" />
                            Copiado!
                          </>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            Copiar Código
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="flex-1 bg-slate-900/80 p-4 rounded-xl overflow-auto text-xs font-mono text-cyan-400/90 border border-slate-850 h-[380px] select-text">
                      <code>{selectedPub.documento.corpo_formatado}</code>
                    </pre>
                  </div>
                )}

                {activeTabSub === "seo" && (
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-slate-300 uppercase font-mono tracking-wider">Metadados de Injeção SERP (SEO)</h4>

                    <div className="space-y-3">
                      <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg">
                        <span className="block text-[10px] text-slate-500 uppercase font-mono">Title Tag do Cabeçalho</span>
                        <span className="text-sm font-semibold text-white mt-1 block">{selectedPub.seo?.titulo_seo}</span>
                      </div>

                      <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg">
                        <span className="block text-[10px] text-slate-500 uppercase font-mono">Meta Description tag</span>
                        <span className="text-xs text-slate-300 mt-1 block leading-relaxed">{selectedPub.seo?.meta_descricao}</span>
                      </div>

                      <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg">
                        <span className="block text-[10px] text-slate-500 uppercase font-mono">URL Canonical</span>
                        <span className="text-xs text-slate-400 font-mono mt-1 block break-all">{selectedPub.seo?.canonical_url}</span>
                      </div>

                      <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg">
                        <span className="block text-[10px] text-slate-500 uppercase font-mono mb-1">Palavras-chave Mapeadas</span>
                        <div className="flex flex-wrap gap-1.5">
                          {selectedPub.seo?.palavras_chave.map((kw, i) => {
                            const densidade = selectedPub.metadados.densidade_palavras_chave[kw] || 0;
                            return (
                              <span key={i} className="px-2 py-0.5 bg-slate-950 text-slate-400 text-[10px] font-mono border border-slate-800 rounded">
                                {kw} ({densidade}%)
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTabSub === "schema" && (
                  <div className="h-full flex flex-col space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-medium">Esquema Estruturado Schema.org (JSON-LD) gerado pelo motor:</span>
                      <button
                        onClick={() => copyToClipboard(JSON.stringify(selectedPub.schema, null, 2))}
                        className="px-2.5 py-1 bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-semibold rounded text-slate-300 flex items-center gap-1.5 transition-colors"
                      >
                        {copiedText ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                        Copiar Schema
                      </button>
                    </div>
                    <pre className="flex-1 bg-slate-900/80 p-4 rounded-xl overflow-auto text-xs font-mono text-emerald-400 border border-slate-850 h-[380px] select-text">
                      <code>{JSON.stringify(selectedPub.schema, null, 2)}</code>
                    </pre>
                  </div>
                )}
              </div>
              
              {/* Rodapé explicativo do compilador */}
              <div className="mt-3 text-[10px] text-slate-500 flex items-center gap-1.5">
                <Info className="h-3 w-3 text-cyan-500" />
                <span>O manifesto e o pacote de dados estão gravados estaticamente na pasta do servidor e prontos para publicação futura.</span>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-xl bg-[#0b0f19]/40">
              <Sparkles className="h-10 w-10 text-cyan-500/40 mb-2 animate-pulse" />
              <p className="text-sm font-semibold text-slate-400">Selecione um Pacote Preparado</p>
              <p className="text-xs text-slate-500 text-center px-8 mt-1 max-w-sm">
                Selecione uma publicação pronta na fila à esquerda para auditar, renderizar e inspecionar o código de injeção gerado.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
