import React, { useState, useEffect } from "react";
import { 
  Users, Target, BookOpen, Layers, CheckCircle, AlertTriangle, 
  RefreshCw, TrendingUp, Search, PlusCircle, Shield, Globe, Award, 
  Sliders, MessageSquare, ThumbsUp, ThumbsDown, HelpCircle, ExternalLink, 
  Map, Mail, Video, LayoutList
} from "lucide-react";

interface Competitor {
  id: string;
  nome: string;
  dominio: string;
  categoria: string;
  descricao: string;
  publico: string;
  cidade: string;
  estado: string;
  pais: string;
  tipo: string;
  status: "ativo" | "inativo";
  observacoes: string;
}

interface CompetitorProfile {
  id: string;
  autoridade_percebida: string;
  especialidades: string[];
  formato_conteudo: string[];
  tom_de_voz: string;
  qualidade_visual: string;
  nivel_tecnico: string;
  monetiza_com: string[];
  produtos: string[];
  serviços: string[];
  redes_social?: Record<string, string>;
  redes_sociais?: Record<string, string>;
  canal_youtube: string;
  newsletter: string;
  observacoes: string;
}

interface ContentStrategy {
  id: string;
  categorias_trabalhadas: string[];
  frequencia_publicacao: string;
  tipos_de_conteudo: string[];
  uso_de_faq: string;
  uso_de_tabelas: string;
  uso_de_imagens: string;
  uso_de_videos: string;
  uso_de_ebooks: string;
  uso_de_simulados: string;
  uso_de_cta: string;
}

interface SWOT {
  id: string;
  pontos_fortes: string[];
  pontos_fracos: string[];
  oportunidades: string[];
  ameacas: string[];
  observacoes: string;
}

interface Opportunity {
  tema: string;
  concorrentes_que_cobrem: string[];
  passacumaru_cobre: boolean;
  prioridade: "Baixa" | "Média" | "Alta" | "Crítica";
  potencial: "Baixo" | "Médio" | "Alto" | "Explosivo";
  observações: string;
}

interface CompetitorData {
  competitors: Competitor[];
  profiles: CompetitorProfile[];
  strategies: ContentStrategy[];
  swot: SWOT[];
  opportunities: Opportunity[];
  metadata: {
    totalCompetitors: number;
    totalCategories: number;
    totalTypes: number;
    activeCount: number;
    inactiveCount: number;
    totalOpportunities: number;
    isValid: boolean;
    errors: string[];
    lastUpdated: string;
  };
}

export function OrganicCompetitors() {
  const [data, setData] = useState<CompetitorData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [activeSubTab, setActiveSubTab] = useState<"list" | "strategy" | "swot" | "opportunities" | "add">("list");
  
  // Form State
  const [newComp, setNewComp] = useState({
    id: "",
    nome: "",
    dominio: "",
    categoria: "",
    descricao: "",
    publico: "",
    cidade: "Passa e Fica",
    estado: "RN",
    pais: "Brasil",
    tipo: "",
    status: "ativo" as "ativo" | "inativo",
    observacoes: ""
  });

  const [newProfile, setNewProfile] = useState({
    autoridade_percebida: "Média",
    especialidades: "",
    formato_conteudo: "",
    tom_de_voz: "Informativo",
    qualidade_visual: "Média",
    nivel_tecnico: "Básico",
    monetiza_com: "",
    produtos: "",
    serviços: "",
    canal_youtube: "",
    newsletter: "Não possui",
    observacoes: ""
  });

  const [newStrategy, setNewStrategy] = useState({
    categorias_trabalhadas: "",
    frequencia_publicacao: "Média",
    tipos_de_conteudo: "",
    uso_de_faq: "Médio",
    uso_de_tabelas: "Médio",
    uso_de_imagens: "Médio",
    uso_de_videos: "Médio",
    uso_de_ebooks: "Médio",
    uso_de_simulados: "Médio",
    uso_de_cta: "Médio"
  });

  const [newSwot, setNewSwot] = useState({
    pontos_fortes: "",
    pontos_fracos: "",
    oportunidades: "",
    ameacas: "",
    observacoes: ""
  });

  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const fetchCompetitorData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/organic-os/competitors");
      if (!res.ok) throw new Error("Erro ao carregar dados do endpoint de concorrentes");
      const json = await res.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Erro desconhecido");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCompetitorData();
  }, []);

  const handleRegisterCompetitor = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitSuccess(false);
    setSubmitError(null);

    // Auto-generate ID if missing
    const finalId = newComp.id || "comp-" + Math.random().toString(36).substr(2, 9);
    
    // Parse commas into arrays
    const formattedProfile: CompetitorProfile = {
      id: finalId,
      autoridade_percebida: newProfile.autoridade_percebida,
      especialidades: newProfile.especialidades.split(",").map(s => s.trim()).filter(Boolean),
      formato_conteudo: newProfile.formato_conteudo.split(",").map(s => s.trim()).filter(Boolean),
      tom_de_voz: newProfile.tom_de_voz,
      qualidade_visual: newProfile.qualidade_visual,
      nivel_tecnico: newProfile.nivel_tecnico,
      monetiza_com: newProfile.monetiza_com.split(",").map(s => s.trim()).filter(Boolean),
      produtos: newProfile.produtos.split(",").map(s => s.trim()).filter(Boolean),
      serviços: newProfile.serviços.split(",").map(s => s.trim()).filter(Boolean),
      canal_youtube: newProfile.canal_youtube,
      newsletter: newProfile.newsletter,
      observacoes: newProfile.observacoes
    };

    const formattedStrategy: ContentStrategy = {
      id: finalId,
      categorias_trabalhadas: newStrategy.categorias_trabalhadas.split(",").map(s => s.trim()).filter(Boolean),
      frequencia_publicacao: newStrategy.frequencia_publicacao,
      tipos_de_conteudo: newStrategy.tipos_de_conteudo.split(",").map(s => s.trim()).filter(Boolean),
      uso_de_faq: newStrategy.uso_de_faq,
      uso_de_tabelas: newStrategy.uso_de_tabelas,
      uso_de_imagens: newStrategy.uso_de_imagens,
      uso_de_videos: newStrategy.uso_de_videos,
      uso_de_ebooks: newStrategy.uso_de_ebooks,
      uso_de_simulados: newStrategy.uso_de_simulados,
      uso_de_cta: newStrategy.uso_de_cta
    };

    const formattedSwot: SWOT = {
      id: finalId,
      pontos_fortes: newSwot.pontos_fortes.split(",").map(s => s.trim()).filter(Boolean),
      pontos_fracos: newSwot.pontos_fracos.split(",").map(s => s.trim()).filter(Boolean),
      oportunidades: newSwot.oportunidades.split(",").map(s => s.trim()).filter(Boolean),
      ameacas: newSwot.ameacas.split(",").map(s => s.trim()).filter(Boolean),
      observacoes: newSwot.observacoes
    };

    const body = {
      competitor: { ...newComp, id: finalId },
      profile: formattedProfile,
      strategy: formattedStrategy,
      swot: formattedSwot
    };

    try {
      const res = await fetch("/api/organic-os/competitors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });

      if (!res.ok) {
        const errJson = await res.json();
        throw new Error(errJson.error || "Falha no envio");
      }

      setSubmitSuccess(true);
      fetchCompetitorData();
      
      // Reset form
      setNewComp({
        id: "",
        nome: "",
        dominio: "",
        categoria: "",
        descricao: "",
        publico: "",
        cidade: "Passa e Fica",
        estado: "RN",
        pais: "Brasil",
        tipo: "",
        status: "ativo",
        observacoes: ""
      });
      setNewProfile({
        autoridade_percebida: "Média",
        especialidades: "",
        formato_conteudo: "",
        tom_de_voz: "Informativo",
        qualidade_visual: "Média",
        nivel_tecnico: "Básico",
        monetiza_com: "",
        produtos: "",
        serviços: "",
        canal_youtube: "",
        newsletter: "Não possui",
        observacoes: ""
      });
      setNewStrategy({
        categorias_trabalhadas: "",
        frequencia_publicacao: "Média",
        tipos_de_conteudo: "",
        uso_de_faq: "Médio",
        uso_de_tabelas: "Médio",
        uso_de_imagens: "Médio",
        uso_de_videos: "Médio",
        uso_de_ebooks: "Médio",
        uso_de_simulados: "Médio",
        uso_de_cta: "Médio"
      });
      setNewSwot({
        pontos_fortes: "",
        pontos_fracos: "",
        oportunidades: "",
        ameacas: "",
        observacoes: ""
      });

      setTimeout(() => {
        setSubmitSuccess(false);
        setActiveSubTab("list");
      }, 2000);

    } catch (err: any) {
      setSubmitError(err.message || "Erro interno");
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <RefreshCw className="h-10 w-10 text-cyan-400 animate-spin" />
        <span className="text-sm font-mono text-slate-400">Carregando inteligência competitiva...</span>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6 bg-red-950/20 border border-red-500/30 rounded-xl flex items-start gap-4">
        <AlertTriangle className="h-6 w-6 text-red-400 shrink-0 mt-0.5" />
        <div>
          <h3 className="text-white font-bold mb-1">Erro ao Carregar Inteligência</h3>
          <p className="text-sm text-red-300">{error || "Estrutura de dados corrompida ou ausente."}</p>
          <button 
            onClick={fetchCompetitorData}
            className="mt-3 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-200 text-xs rounded font-mono flex items-center gap-2 transition"
          >
            <RefreshCw className="h-3 w-3" /> Tentar Novamente
          </button>
        </div>
      </div>
    );
  }

  const { competitors, profiles, strategies, swot, opportunities, metadata } = data;

  // Search filter
  const filteredCompetitors = competitors.filter(comp => {
    const matchesSearch = comp.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          comp.dominio.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          comp.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || comp.categoria === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(competitors.map(c => c.categoria).filter(Boolean)));

  return (
    <div className="space-y-6">
      {/* Overview Stats Grid */}
      <section className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-md">
          <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Total de Concorrentes</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-white">{metadata.totalCompetitors}</span>
            <Users className="h-5 w-5 text-cyan-400" />
          </div>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-md">
          <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Categorias Mapeadas</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-white">{metadata.totalCategories}</span>
            <LayoutList className="h-5 w-5 text-indigo-400" />
          </div>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-md">
          <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Tipos de Negócio</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-white">{metadata.totalTypes}</span>
            <Award className="h-5 w-5 text-emerald-400" />
          </div>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-md">
          <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Status Ativos/Inativos</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-lg font-bold text-white">
              {metadata.activeCount} <span className="text-xs text-slate-500">Ativos</span>
            </span>
            <div className="flex items-center gap-1 font-mono text-xs bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded">
              <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
              100% OK
            </div>
          </div>
        </div>

        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-md col-span-2 lg:col-span-1">
          <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Oportunidades de Conteúdo</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-yellow-400">{metadata.totalOpportunities}</span>
            <Target className="h-5 w-5 text-yellow-400" />
          </div>
        </div>
      </section>

      {/* Validation Status Notice */}
      {!metadata.isValid && (
        <div className="p-4 bg-amber-950/20 border border-amber-500/30 rounded-xl flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-amber-200 font-semibold text-sm">Problemas de Validação de Dados Encontrados</h4>
            <ul className="text-xs text-amber-300/85 mt-1 list-disc list-inside space-y-0.5">
              {metadata.errors.map((err, idx) => (
                <li key={idx}>{err}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Subtab Controllers */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-2 flex flex-wrap gap-2">
        <button 
          onClick={() => setActiveSubTab("list")}
          className={`py-2 px-4 rounded-lg text-xs font-semibold font-mono tracking-wider transition-all uppercase flex items-center gap-2 ${
            activeSubTab === "list" ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/10" : "text-slate-400 hover:text-slate-300"
          }`}
        >
          <Users className="h-4 w-4" /> Perfil de Concorrentes
        </button>

        <button 
          onClick={() => setActiveSubTab("strategy")}
          className={`py-2 px-4 rounded-lg text-xs font-semibold font-mono tracking-wider transition-all uppercase flex items-center gap-2 ${
            activeSubTab === "strategy" ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/10" : "text-slate-400 hover:text-slate-300"
          }`}
        >
          <Sliders className="h-4 w-4" /> Estratégias de Conteúdo
        </button>

        <button 
          onClick={() => setActiveSubTab("swot")}
          className={`py-2 px-4 rounded-lg text-xs font-semibold font-mono tracking-wider transition-all uppercase flex items-center gap-2 ${
            activeSubTab === "swot" ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/10" : "text-slate-400 hover:text-slate-300"
          }`}
        >
          <TrendingUp className="h-4 w-4" /> Matriz SWOT
        </button>

        <button 
          onClick={() => setActiveSubTab("opportunities")}
          className={`py-2 px-4 rounded-lg text-xs font-semibold font-mono tracking-wider transition-all uppercase flex items-center gap-2 ${
            activeSubTab === "opportunities" ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/10" : "text-slate-400 hover:text-slate-300"
          }`}
        >
          <Map className="h-4 w-4" /> Mapa de Oportunidades
        </button>

        <button 
          onClick={() => setActiveSubTab("add")}
          className={`py-2 px-4 rounded-lg text-xs font-semibold font-mono tracking-wider transition-all uppercase flex items-center gap-2 ml-auto ${
            activeSubTab === "add" ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/10" : "text-emerald-400 hover:text-emerald-300 border border-emerald-500/20"
          }`}
        >
          <PlusCircle className="h-4 w-4" /> Cadastrar Novo Concorrente
        </button>
      </div>

      {/* SEARCH AND FILTERS FOR LIST AND STRATEGY */}
      {(activeSubTab === "list" || activeSubTab === "strategy" || activeSubTab === "swot") && (
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
            <input 
              type="text"
              placeholder="Buscar por nome, domínio ou descrição do concorrente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0f172a] border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>
          <div className="w-full md:w-60">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full bg-[#0f172a] border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              <option value="all">Todas as Categorias</option>
              {categories.map((cat, i) => (
                <option key={i} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* SUBTAB: LIST OF COMPETITORS */}
      {activeSubTab === "list" && (
        <div className="grid grid-cols-1 gap-6">
          {filteredCompetitors.length === 0 ? (
            <div className="text-center py-10 bg-[#0f172a] border border-slate-800 rounded-xl text-slate-500 font-mono text-sm">
              Nenhum concorrente encontrado com os filtros atuais.
            </div>
          ) : (
            filteredCompetitors.map((comp) => {
              const profile = profiles.find(p => p.id === comp.id);
              return (
                <div key={comp.id} className="bg-[#0f172a] border border-slate-800 rounded-xl overflow-hidden shadow-lg hover:border-slate-700 transition flex flex-col md:flex-row">
                  {/* Left block / General */}
                  <div className="p-6 md:w-1/3 border-b md:border-b-0 md:border-r border-slate-800 bg-[#0d1424]">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded-md border border-cyan-500/20 uppercase tracking-wider">
                        {comp.categoria}
                      </span>
                      <span className={`h-2 w-2 rounded-full ${comp.status === "ativo" ? "bg-green-500" : "bg-red-500"}`} title={comp.status} />
                    </div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      {comp.nome}
                    </h3>
                    <a 
                      href={`https://${comp.dominio}`} 
                      target="_blank" 
                      referrerPolicy="no-referrer"
                      className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1 mt-1"
                    >
                      <Globe className="h-3 w-3" /> {comp.dominio} <ExternalLink className="h-2.5 w-2.5" />
                    </a>
                    
                    <p className="text-sm text-slate-400 mt-4 leading-relaxed">
                      {comp.descricao}
                    </p>

                    <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-2 text-xs text-slate-400">
                      <div>
                        <span className="font-semibold text-slate-300 block">Público-Alvo:</span>
                        {comp.publico}
                      </div>
                      <div>
                        <span className="font-semibold text-slate-300 block">Origem:</span>
                        {comp.cidade} - {comp.estado}, {comp.pais}
                      </div>
                      <div>
                        <span className="font-semibold text-slate-300 block">Tipo:</span>
                        {comp.tipo}
                      </div>
                    </div>
                  </div>

                  {/* Right block / Profile */}
                  <div className="p-6 flex-1 bg-[#0f172a] space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                        <span className="text-[10px] font-mono text-slate-500 block uppercase">Autoridade Percebida</span>
                        <span className="text-sm font-semibold text-white flex items-center gap-1 mt-1">
                          <Award className="h-4 w-4 text-amber-400" />
                          {profile?.autoridade_percebida || "Média"}
                        </span>
                      </div>
                      <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                        <span className="text-[10px] font-mono text-slate-500 block uppercase">Nível Técnico</span>
                        <span className="text-sm font-semibold text-white mt-1 block">
                          {profile?.nivel_tecnico || "Intermediário"}
                        </span>
                      </div>
                      <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                        <span className="text-[10px] font-mono text-slate-500 block uppercase">Qualidade Visual</span>
                        <span className="text-sm font-semibold text-white mt-1 block">
                          {profile?.qualidade_visual || "Média"}
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-xs font-mono uppercase text-slate-500 block mb-2">Especialidades e Nichos</span>
                      <div className="flex flex-wrap gap-1.5">
                        {profile?.especialidades.map((esp, i) => (
                          <span key={i} className="text-xs px-2 py-1 bg-slate-800 rounded text-slate-300 border border-slate-700">
                            {esp}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-xs font-mono uppercase text-slate-500 block mb-1">Canais e Monetização</span>
                        <ul className="space-y-1 text-xs text-slate-400">
                          <li><span className="text-slate-300">Monetização:</span> {profile?.monetiza_com.join(", ") || "Cursos"}</li>
                          <li><span className="text-slate-300">YouTube:</span> {profile?.canal_youtube !== "Não possui" ? <a href={profile?.canal_youtube} className="text-cyan-400 hover:underline">{profile?.canal_youtube}</a> : "Inexistente"}</li>
                          <li><span className="text-slate-300">Newsletter:</span> {profile?.newsletter || "Não"}</li>
                        </ul>
                      </div>
                      <div>
                        <span className="text-xs font-mono uppercase text-slate-500 block mb-1">Principais Produtos</span>
                        <div className="flex flex-wrap gap-1">
                          {profile?.produtos.map((prod, i) => (
                            <span key={i} className="text-[11px] px-2 py-0.5 bg-slate-900 rounded text-amber-300 border border-amber-500/10">
                              {prod}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {comp.observacoes && (
                      <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400 italic">
                        <span className="font-semibold text-slate-300 not-italic block mb-1">Notas de Inteligência:</span>
                        "{comp.observacoes}"
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* SUBTAB: CONTENT STRATEGY */}
      {activeSubTab === "strategy" && (
        <div className="space-y-6">
          {filteredCompetitors.map((comp) => {
            const strat = strategies.find(s => s.id === comp.id);
            if (!strat) return null;
            return (
              <div key={comp.id} className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 space-y-4 shadow-lg">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-lg font-bold text-white">{comp.nome}</h3>
                    <span className="text-xs text-cyan-400 font-mono">{comp.dominio}</span>
                  </div>
                  <span className="text-xs px-2.5 py-1 bg-slate-800 border border-slate-700 text-slate-300 rounded font-mono uppercase">
                    Frequência: {strat.frequencia_publicacao}
                  </span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Utiliza FAQ</span>
                    <span className="text-xs font-semibold text-white mt-1 block">{strat.uso_de_faq}</span>
                  </div>
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Uso de Tabelas</span>
                    <span className="text-xs font-semibold text-white mt-1 block">{strat.uso_de_tabelas}</span>
                  </div>
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Vídeos Acoplados</span>
                    <span className="text-xs font-semibold text-white mt-1 block">{strat.uso_de_videos}</span>
                  </div>
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Chamadas para Ação (CTA)</span>
                    <span className="text-xs font-semibold text-white mt-1 block">{strat.uso_de_cta}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Uso de E-books</span>
                    <span className="text-xs font-semibold text-white mt-1 block">{strat.uso_de_ebooks}</span>
                  </div>
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Uso de Simulados</span>
                    <span className="text-xs font-semibold text-white mt-1 block">{strat.uso_de_simulados}</span>
                  </div>
                  <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded-lg col-span-2">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase">Categorias de Conteúdo Principais</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {strat.categorias_trabalhadas.map((cat, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 bg-slate-800 rounded text-slate-400 border border-slate-700">
                          {cat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <span className="text-xs font-mono uppercase text-slate-500 block mb-1">Tipos de Formatos Explorados</span>
                  <div className="flex flex-wrap gap-1">
                    {strat.tipos_de_conteudo.map((tipo, idx) => (
                      <span key={idx} className="text-xs px-2 py-1 bg-cyan-950/20 text-cyan-300 border border-cyan-500/20 rounded">
                        {tipo}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SUBTAB: SWOT MATRIX */}
      {activeSubTab === "swot" && (
        <div className="space-y-6">
          {filteredCompetitors.map((comp) => {
            const matrix = swot.find(s => s.id === comp.id);
            if (!matrix) return null;
            return (
              <div key={comp.id} className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-lg font-bold text-white">{comp.nome}</h3>
                  <span className="text-xs font-mono text-slate-400">Análise SWOT / FOFA</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Strengths */}
                  <div className="p-4 bg-emerald-950/10 border border-emerald-500/10 rounded-xl space-y-2">
                    <h4 className="text-sm font-semibold text-emerald-400 flex items-center gap-1.5 uppercase font-mono tracking-wider">
                      <ThumbsUp className="h-4 w-4" /> Pontos Fortes
                    </h4>
                    <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside leading-relaxed">
                      {matrix.pontos_fortes.map((p, i) => (
                        <li key={i}>{p}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Weaknesses */}
                  <div className="p-4 bg-red-950/10 border border-red-500/10 rounded-xl space-y-2">
                    <h4 className="text-sm font-semibold text-red-400 flex items-center gap-1.5 uppercase font-mono tracking-wider">
                      <ThumbsDown className="h-4 w-4" /> Pontos Fracos
                    </h4>
                    <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside leading-relaxed">
                      {matrix.pontos_fracos.map((p, i) => (
                        <li key={i}>{p}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Opportunities */}
                  <div className="p-4 bg-cyan-950/10 border border-cyan-500/10 rounded-xl space-y-2">
                    <h4 className="text-sm font-semibold text-cyan-400 flex items-center gap-1.5 uppercase font-mono tracking-wider">
                      <TrendingUp className="h-4 w-4" /> Oportunidades Mapeadas
                    </h4>
                    <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside leading-relaxed">
                      {matrix.oportunidades.map((p, i) => (
                        <li key={i}>{p}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Threats */}
                  <div className="p-4 bg-amber-950/10 border border-amber-500/10 rounded-xl space-y-2">
                    <h4 className="text-sm font-semibold text-amber-400 flex items-center gap-1.5 uppercase font-mono tracking-wider">
                      <Shield className="h-4 w-4" /> Ameaças Externas
                    </h4>
                    <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside leading-relaxed">
                      {matrix.ameacas.map((p, i) => (
                        <li key={i}>{p}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {matrix.observacoes && (
                  <div className="pt-3 border-t border-slate-800 text-xs text-slate-400 font-mono italic">
                    Conclusão estratégica: "{matrix.observacoes}"
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* SUBTAB: OPPORTUNITY MAP */}
      {activeSubTab === "opportunities" && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Map className="h-5 w-5 text-cyan-400" />
                Mapa Estratégico de Lacunas e Oportunidades
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Mostra temas cobertos por concorrentes que o PassaCumaru precisa disputar ou otimizar para vencer no Google.
              </p>
            </div>
            <span className="text-[11px] font-mono bg-[#0b0f19] border border-slate-800 px-3 py-1 text-slate-500 rounded">
              {opportunities.length} Registros
            </span>
          </div>

          {opportunities.length === 0 ? (
            <div className="text-center py-12 bg-[#0b0f19] rounded-xl border border-slate-800 border-dashed space-y-3">
              <span className="inline-block p-2 rounded-full bg-slate-900 border border-slate-800">
                <Target className="h-6 w-6 text-slate-600" />
              </span>
              <p className="text-sm font-mono text-slate-400">O Mapa de Oportunidades está inicialmente vazio.</p>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Nas próximas Sprints (como a de Pesquisa de Palavras-chave e Editorial), este banco de dados será preenchido para guiar as lacunas.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-300">
                <thead className="bg-[#0b0f19] text-xs uppercase font-mono text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-4">Tema / Assunto</th>
                    <th className="p-4">Concorrentes Cobrem</th>
                    <th className="p-4">PassaCumaru Cobre?</th>
                    <th className="p-4">Prioridade</th>
                    <th className="p-4">Potencial</th>
                    <th className="p-4">Notas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {opportunities.map((opp, i) => (
                    <tr key={i} className="hover:bg-slate-900/40">
                      <td className="p-4 font-semibold text-white">{opp.tema}</td>
                      <td className="p-4 font-mono text-xs text-slate-400">
                        {opp.concorrentes_que_cobrem.join(", ")}
                      </td>
                      <td className="p-4">
                        {opp.passacumaru_cobre ? (
                          <span className="text-green-400 bg-green-500/10 border border-green-500/20 px-2 py-0.5 rounded text-xs uppercase">Sim</span>
                        ) : (
                          <span className="text-red-400 bg-red-500/10 border border-red-500/20 px-2 py-0.5 rounded text-xs uppercase">Não</span>
                        )}
                      </td>
                      <td className="p-4 font-mono text-xs">
                        <span className={`px-2 py-0.5 rounded ${
                          opp.prioridade === "Crítica" ? "text-red-400 bg-red-500/10 border border-red-500/20" :
                          opp.prioridade === "Alta" ? "text-amber-400 bg-amber-500/10 border border-amber-500/20" :
                          "text-slate-400 bg-slate-800"
                        }`}>
                          {opp.prioridade}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-xs text-cyan-400">{opp.potencial}</td>
                      <td className="p-4 text-xs text-slate-400 leading-relaxed">{opp.observações}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB: ADD COMPETITOR FORM */}
      {activeSubTab === "add" && (
        <form onSubmit={handleRegisterCompetitor} className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 space-y-8 shadow-xl max-w-4xl mx-auto">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <PlusCircle className="h-5 w-5 text-emerald-400" />
              Cadastrar Inteligência de Novo Concorrente
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Forneça as informações cadastrais, de perfil, estratégicas e SWOT para atualizar a inteligência mestre.
            </p>
          </div>

          {submitError && (
            <div className="p-4 bg-red-950/20 border border-red-500/30 rounded-lg text-xs text-red-300 font-mono">
              FALHA AO SALVAR: {submitError}
            </div>
          )}

          {submitSuccess && (
            <div className="p-4 bg-green-950/20 border border-green-500/30 rounded-lg text-xs text-green-300 font-mono">
              CONCORRENTE REGISTRADO E SALVO COM SUCESSO!
            </div>
          )}

          {/* Section 1: Cadastro Básico */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase font-mono text-cyan-400 border-b border-slate-800 pb-1">1. Informações de Cadastro</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">ID Único (Ex: comp-04)</label>
                <input 
                  type="text" 
                  required
                  placeholder="Deixe em branco para auto-gerar"
                  value={newComp.id}
                  onChange={(e) => setNewComp({ ...newComp, id: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Nome do Concorrente</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Aprova RN"
                  value={newComp.nome}
                  onChange={(e) => setNewComp({ ...newComp, nome: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Domínio Web</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: concorrente.com.br"
                  value={newComp.dominio}
                  onChange={(e) => setNewComp({ ...newComp, dominio: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Categoria</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Cursos Preparatórios ou Noticiário"
                  value={newComp.categoria}
                  onChange={(e) => setNewComp({ ...newComp, categoria: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Tipo de Negócio</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Portal Nacional Preparatório"
                  value={newComp.tipo}
                  onChange={(e) => setNewComp({ ...newComp, tipo: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Público Principal</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Concurseiros do RN e Nordeste"
                  value={newComp.publico}
                  onChange={(e) => setNewComp({ ...newComp, publico: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Descrição</label>
              <textarea 
                rows={2}
                required
                placeholder="Breve resumo sobre quem são e o que fazem..."
                value={newComp.descricao}
                onChange={(e) => setNewComp({ ...newComp, descricao: e.target.value })}
                className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Section 2: Perfil Estruturado */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase font-mono text-cyan-400 border-b border-slate-800 pb-1">2. Perfil Estruturado</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Autoridade Percebida</label>
                <select 
                  value={newProfile.autoridade_percebida}
                  onChange={(e) => setNewProfile({ ...newProfile, autoridade_percebida: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                >
                  <option value="Baixa">Baixa</option>
                  <option value="Média">Média</option>
                  <option value="Alta">Alta</option>
                  <option value="Excelente">Excelente</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Qualidade Visual</label>
                <select 
                  value={newProfile.qualidade_visual}
                  onChange={(e) => setNewProfile({ ...newProfile, qualidade_visual: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                >
                  <option value="Baixa">Baixa</option>
                  <option value="Média">Média</option>
                  <option value="Alta">Alta</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Nível Técnico</label>
                <select 
                  value={newProfile.nivel_tecnico}
                  onChange={(e) => setNewProfile({ ...newProfile, nivel_tecnico: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                >
                  <option value="Básico">Básico</option>
                  <option value="Intermediário">Intermediário</option>
                  <option value="Avançado">Avançado</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Especialidades (separadas por vírgula)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Direito Administrativo, Legislação Municipal, Redação"
                  value={newProfile.especialidades}
                  onChange={(e) => setNewProfile({ ...newProfile, especialidades: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Formatos de Conteúdo (separados por vírgula)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Videoaulas, PDFs, Artigos Rápidos"
                  value={newProfile.formato_conteudo}
                  onChange={(e) => setNewProfile({ ...newProfile, formato_conteudo: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Monetização (separados por vírgula)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Assinatura, Venda Direta, Apostila Física"
                  value={newProfile.monetiza_com}
                  onChange={(e) => setNewProfile({ ...newProfile, monetiza_com: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Principais Produtos (separados por vírgula)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Curso Prefeitura X, Assinatura Premium"
                  value={newProfile.produtos}
                  onChange={(e) => setNewProfile({ ...newProfile, produtos: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Estratégia de Conteúdo */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase font-mono text-cyan-400 border-b border-slate-800 pb-1">3. Estratégias Editoriais</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Categorias Trabalhadas (separados por vírgula)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Notícias RN, Dicas de Estudo"
                  value={newStrategy.categorias_trabalhadas}
                  onChange={(e) => setNewStrategy({ ...newStrategy, categorias_trabalhadas: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Formatos Explorados (separados por vírgula)</label>
                <input 
                  type="text" 
                  placeholder="Ex: Gabarito Preliminar, Edital Esquematizado"
                  value={newStrategy.tipos_de_conteudo}
                  onChange={(e) => setNewStrategy({ ...newStrategy, tipos_de_conteudo: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div>
                <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">Uso de FAQ</label>
                <select 
                  value={newStrategy.uso_de_faq}
                  onChange={(e) => setNewStrategy({ ...newStrategy, uso_de_faq: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-1.5 text-xs text-white focus:outline-none"
                >
                  <option value="Baixo">Baixo</option>
                  <option value="Médio">Médio</option>
                  <option value="Alto">Alto</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">Uso de Tabelas</label>
                <select 
                  value={newStrategy.uso_de_tabelas}
                  onChange={(e) => setNewStrategy({ ...newStrategy, uso_de_tabelas: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-1.5 text-xs text-white focus:outline-none"
                >
                  <option value="Baixo">Baixo</option>
                  <option value="Médio">Médio</option>
                  <option value="Alto">Alto</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">Uso de Vídeos</label>
                <select 
                  value={newStrategy.uso_de_videos}
                  onChange={(e) => setNewStrategy({ ...newStrategy, uso_de_videos: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-1.5 text-xs text-white focus:outline-none"
                >
                  <option value="Baixo">Baixo</option>
                  <option value="Médio">Médio</option>
                  <option value="Alto">Alto</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">Uso de E-books</label>
                <select 
                  value={newStrategy.uso_de_ebooks}
                  onChange={(e) => setNewStrategy({ ...newStrategy, uso_de_ebooks: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-1.5 text-xs text-white focus:outline-none"
                >
                  <option value="Baixo">Baixo</option>
                  <option value="Médio">Médio</option>
                  <option value="Alto">Alto</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">Uso de CTA</label>
                <select 
                  value={newStrategy.uso_de_cta}
                  onChange={(e) => setNewStrategy({ ...newStrategy, uso_de_cta: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-1.5 text-xs text-white focus:outline-none"
                >
                  <option value="Baixo">Baixo</option>
                  <option value="Médio">Médio</option>
                  <option value="Alto">Alto</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 4: SWOT / FOFA */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase font-mono text-cyan-400 border-b border-slate-800 pb-1">4. Análise SWOT (Pontos Fortes e Fracos)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Pontos Fortes (separados por vírgula)</label>
                <textarea 
                  rows={2}
                  placeholder="Ex: Professores famosos, Conteúdo regional ágil"
                  value={newSwot.pontos_fortes}
                  onChange={(e) => setNewSwot({ ...newSwot, pontos_fortes: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Pontos Fracos (separados por vírgula)</label>
                <textarea 
                  rows={2}
                  placeholder="Ex: Plataforma engessada, PDF excessivamente longo"
                  value={newSwot.pontos_fracos}
                  onChange={(e) => setNewSwot({ ...newSwot, pontos_fracos: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Oportunidades (separadas por vírgula)</label>
                <textarea 
                  rows={2}
                  placeholder="Ex: Capturar alunos insatisfeitos, Oferecer mentoria física"
                  value={newSwot.oportunidades}
                  onChange={(e) => setNewSwot({ ...newSwot, oportunidades: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Ameaças (separadas por vírgula)</label>
                <textarea 
                  rows={2}
                  placeholder="Ex: Pirataria de materiais, Entrada de rivais gigantes"
                  value={newSwot.ameacas}
                  onChange={(e) => setNewSwot({ ...newSwot, ameacas: e.target.value })}
                  className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4 border-t border-slate-800">
            <button 
              type="button"
              onClick={() => setActiveSubTab("list")}
              className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold font-mono text-xs uppercase rounded-lg transition"
            >
              Cancelar e Voltar
            </button>
            <button 
              type="submit"
              className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono text-xs uppercase rounded-lg transition ml-auto"
            >
              Salvar Inteligência Competitiva
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
