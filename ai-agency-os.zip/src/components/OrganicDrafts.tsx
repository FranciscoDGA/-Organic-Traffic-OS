import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Search, 
  Award, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  RefreshCw, 
  HelpCircle, 
  History, 
  User, 
  Calendar, 
  ChevronRight, 
  Sparkles, 
  Save, 
  Edit3, 
  ArrowLeft,
  XCircle,
  Cpu,
  Layers,
  CheckSquare,
  Activity,
  Maximize2,
  Copy,
  BookOpen,
  ArrowRight,
  Database,
  FileCode,
  Check,
  Split
} from "lucide-react";
import { ContentBlueprint } from "../../organic-traffic-os/content-architecture/models/blueprint-models";
import { EditorialBrief } from "../../organic-traffic-os/briefs/models/brief-models";

interface DraftContent {
  h1: string;
  introducao: string;
  h2: string;
  h3?: string;
  faq: string;
  conclusao: string;
  cta: string;
}

interface DraftRecord {
  id: string;
  titulo: string;
  brief_id: string;
  blueprint_id: string;
  research_pack_id: string;
  strategy_id: string;
  versao: string;
  status: string;
  modelo_ia: string;
  provedor_ia: string;
  tokens_entrada: number;
  tokens_saida: number;
  tempo_execucao: number;
  criado_em: string;
  conteudo: DraftContent;
  audit?: {
    isValid: boolean;
    errors: string[];
    warnings: string[];
    score: number;
    checks: {
      secoes_completas: boolean;
      blueprint_seguido: boolean;
      entidades_presentes: string[];
      entidades_faltantes: string[];
      perguntas_respondidas: string[];
      perguntas_faltantes: string[];
      cta_valido: boolean;
    };
  };
}

interface DraftVersion {
  versao: string;
  data: string;
  modelo_ia: string;
  prompt_utilizado: string;
  tempo_execucao: number;
  conteudo: DraftContent;
  diferencas?: string;
}

export function OrganicDrafts() {
  const [drafts, setDrafts] = useState<DraftRecord[]>([]);
  const [blueprints, setBlueprints] = useState<ContentBlueprint[]>([]);
  const [briefs, setBriefs] = useState<EditorialBrief[]>([]);
  
  const [selectedDraft, setSelectedDraft] = useState<DraftRecord | null>(null);
  const [draftVersions, setDraftVersions] = useState<DraftVersion[]>([]);
  
  const [loading, setLoading] = useState<boolean>(false);
  const [createLoading, setCreateLoading] = useState<boolean>(false);
  
  // Create state form
  const [selectedBriefId, setSelectedBriefId] = useState<string>("");
  const [selectedBlueprintId, setSelectedBlueprintId] = useState<string>("");
  
  // Selection/Filtering
  const [activeSubTab, setActiveSubTab] = useState<"texto" | "auditoria" | "historico" | "comparar">("texto");
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  
  // Editing individual sections state
  const [editH1, setEditH1] = useState("");
  const [editIntro, setEditIntro] = useState("");
  const [editH2, setEditH2] = useState("");
  const [editH3, setEditH3] = useState("");
  const [editFaq, setEditFaq] = useState("");
  const [editConclusion, setEditConclusion] = useState("");
  const [editCta, setEditCta] = useState("");
  const [authorName, setAuthorName] = useState("Editor-Chefe");
  
  // Loading animations steps logs
  const [stepLogs, setStepLogs] = useState<string[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);

  const mockGenerationSteps = [
    "Inicializando Agente Escritor V1...",
    "Carregando Persona e Tom de Voz do Knowledge Core...",
    "Verificando histórico de canibalização no Inventário de Conteúdo...",
    "Buscando benchmarks de competidores diretos...",
    "Analisando intenção de busca e padrões da SERP...",
    "Mapeando palavras-chave principais e caudas longas...",
    "Sincronizando com o Editorial Planner...",
    "Consolidando diretrizes de redação do Briefing aprovado...",
    "Mapeando estrutura física de headings do Blueprint...",
    "Extraindo termos técnicos do Research Pack...",
    "Recuperando fatos empíricos científicos na Fact Checking Base...",
    "Verificando links regulatórios nas Sources...",
    "Buscando as chamadas de conversão recomendadas no Content Strategy...",
    "Enviando dados estruturados para o Provedor de IA configurado...",
    "Recebendo rascunho semântico e executando checagem estrita de qualidade...",
    "Salvando rascunho inicial v1.0.0 e registrando telemetrias!"
  ];

  const loadData = async () => {
    setLoading(true);
    try {
      const resDrafts = await fetch("/api/organic-os/drafts");
      const dataDrafts = await resDrafts.json();
      setDrafts(Array.isArray(dataDrafts) ? dataDrafts : []);

      const resBps = await fetch("/api/organic-os/blueprints");
      const dataBps = await resBps.json();
      setBlueprints(Array.isArray(dataBps) ? dataBps : []);

      const resBriefs = await fetch("/api/organic-os/briefs");
      const dataBriefs = await resBriefs.json();
      setBriefs(Array.isArray(dataBriefs) ? dataBriefs : []);
    } catch (e) {
      console.error("Erro ao carregar dados do rascunhador:", e);
    } finally {
      setLoading(false);
    }
  };

  const loadVersions = async (draftId: string) => {
    try {
      const res = await fetch(`/api/organic-os/drafts/${draftId}/versions`);
      const data = await res.json();
      setDraftVersions(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("Erro ao carregar histórico de versões:", e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (selectedDraft) {
      setEditH1(selectedDraft.conteudo.h1);
      setEditIntro(selectedDraft.conteudo.introducao);
      setEditH2(selectedDraft.conteudo.h2);
      setEditH3(selectedDraft.conteudo.h3 || "");
      setEditFaq(selectedDraft.conteudo.faq);
      setEditConclusion(selectedDraft.conteudo.conclusao);
      setEditCta(selectedDraft.conteudo.cta);
      loadVersions(selectedDraft.id);
    }
  }, [selectedDraft]);

  // Step log animation triggers
  useEffect(() => {
    if (createLoading) {
      setStepLogs([mockGenerationSteps[0]]);
      setCurrentStepIndex(0);
      
      const interval = setInterval(() => {
        setCurrentStepIndex((prev) => {
          const next = prev + 1;
          if (next < mockGenerationSteps.length) {
            setStepLogs((logs) => [...logs, mockGenerationSteps[next]]);
            return next;
          } else {
            clearInterval(interval);
            return prev;
          }
        });
      }, 500);

      return () => clearInterval(interval);
    } else {
      setStepLogs([]);
      setCurrentStepIndex(0);
    }
  }, [createLoading]);

  // Auto-select match brief/blueprint if brief is selected
  useEffect(() => {
    if (selectedBriefId) {
      const brief = briefs.find(b => b.id === selectedBriefId);
      if (brief) {
        // Try to find blueprint that references this brief
        const matchBp = blueprints.find(bp => bp.brief_id === brief.id);
        if (matchBp) {
          setSelectedBlueprintId(matchBp.id);
        }
      }
    }
  }, [selectedBriefId, blueprints, briefs]);

  const handleCreateDraft = async () => {
    if (!selectedBriefId || !selectedBlueprintId) return;
    setCreateLoading(true);
    try {
      // Find matching research pack & strategy if any
      const matchBp = blueprints.find(bp => bp.id === selectedBlueprintId);
      const brief = briefs.find(b => b.id === selectedBriefId);
      
      const res = await fetch("/api/organic-os/drafts/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          briefId: selectedBriefId,
          blueprintId: selectedBlueprintId,
          researchPackId: matchBp ? `res-${matchBp.id}` : "",
          strategyId: brief ? `strat-${brief.id}` : "",
          blogId: "passacumaru"
        })
      });

      const resData = await res.json();
      if (resData.success && resData.draft) {
        setDrafts(prev => [resData.draft, ...prev]);
        setSelectedDraft(resData.draft);
        setIsEditing(false);
        setActiveSubTab("texto");
        
        // Reset selections
        setSelectedBriefId("");
        setSelectedBlueprintId("");
      } else {
        alert("Erro ao criar rascunho: " + (resData.error || "Desconhecido"));
      }
    } catch (e: any) {
      alert("Falha na requisição: " + e.message);
    } finally {
      setCreateLoading(false);
    }
  };

  const handleUpdateDraft = async () => {
    if (!selectedDraft) return;
    setLoading(true);
    try {
      const updatedContent = {
        h1: editH1,
        introducao: editIntro,
        h2: editH2,
        h3: editH3,
        faq: editFaq,
        conclusao: editConclusion,
        cta: editCta
      };

      const res = await fetch(`/api/organic-os/drafts/${selectedDraft.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conteudo: updatedContent,
          autor: authorName
        })
      });

      const resData = await res.json();
      if (resData.success && resData.draft) {
        setSelectedDraft(resData.draft);
        // Refresh items in sidebar list
        setDrafts(prev => prev.map(d => d.id === selectedDraft.id ? resData.draft : d));
        setIsEditing(false);
        loadVersions(selectedDraft.id);
      } else {
        alert("Erro ao salvar revisão: " + (resData.error || "Desconhecido"));
      }
    } catch (e: any) {
      alert("Falha ao atualizar rascunho: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Metrics calculation
  const totalDrafts = drafts.length;
  const avgScore = totalDrafts > 0 
    ? Math.round(drafts.reduce((acc, d) => acc + (d.audit?.score || 0), 0) / totalDrafts) 
    : 0;
  const totalTokens = drafts.reduce((acc, d) => acc + (d.tokens_entrada || 0) + (d.tokens_saida || 0), 0);
  const avgExecTime = totalDrafts > 0 
    ? parseFloat((drafts.reduce((acc, d) => acc + d.tempo_execucao, 0) / totalDrafts).toFixed(2)) 
    : 0;

  return (
    <div className="space-y-6 text-slate-300">
      
      {/* Dynamic Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-[11px] font-mono font-bold tracking-wider uppercase">Sprint 18</span>
            <h1 className="text-2xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
              <Cpu className="h-6 w-6 text-cyan-400" />
              Agente Escritor de Rascunhos V1
            </h1>
          </div>
          <p className="text-slate-400 text-sm mt-1">
            Engine de orquestração estrita baseada nos 13 ativos de inteligência para gerar primeiros rascunhos.
          </p>
        </div>
        
        {selectedDraft && (
          <button 
            onClick={() => setSelectedDraft(null)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs font-medium text-slate-300 transition-all self-start"
          >
            <ArrowLeft className="h-4.5 w-4.5" /> Voltar ao Painel
          </button>
        )}
      </div>

      {/* Overview Metrics Cards (Only in master view) */}
      {!selectedDraft && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 shadow-md flex items-center gap-4">
            <div className="p-3 bg-cyan-950/40 rounded-lg border border-cyan-900/30">
              <FileText className="h-5 w-5 text-cyan-400" />
            </div>
            <div>
              <span className="text-slate-500 text-[11px] font-mono font-bold uppercase block tracking-wider">Total de Rascunhos</span>
              <strong className="text-2xl font-bold text-white font-mono block mt-0.5">{totalDrafts}</strong>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 shadow-md flex items-center gap-4">
            <div className="p-3 bg-emerald-950/40 rounded-lg border border-emerald-900/30">
              <Award className="h-5 w-5 text-emerald-400" />
            </div>
            <div>
              <span className="text-slate-500 text-[11px] font-mono font-bold uppercase block tracking-wider">Score Médio E-A-T</span>
              <strong className="text-2xl font-bold text-emerald-400 font-mono block mt-0.5">{avgScore}%</strong>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 shadow-md flex items-center gap-4">
            <div className="p-3 bg-indigo-950/40 rounded-lg border border-indigo-900/30">
              <Sparkles className="h-5 w-5 text-indigo-400" />
            </div>
            <div>
              <span className="text-slate-500 text-[11px] font-mono font-bold uppercase block tracking-wider">Tokens Consumidos</span>
              <strong className="text-2xl font-bold text-white font-mono block mt-0.5">{totalTokens.toLocaleString()}</strong>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 shadow-md flex items-center gap-4">
            <div className="p-3 bg-amber-950/40 rounded-lg border border-amber-900/30">
              <Activity className="h-5 w-5 text-amber-400" />
            </div>
            <div>
              <span className="text-slate-500 text-[11px] font-mono font-bold uppercase block tracking-wider">Tempo Médio Geração</span>
              <strong className="text-2xl font-bold text-white font-mono block mt-0.5">{avgExecTime}s</strong>
            </div>
          </div>
        </div>
      )}

      {/* main content layout */}
      {!selectedDraft ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Form Generation Panel (Left column) */}
          <div className="bg-slate-950 border border-slate-850 rounded-xl p-5 shadow-lg space-y-5 lg:col-span-1">
            <div className="border-b border-slate-850 pb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold text-white flex items-center gap-2 uppercase tracking-wide">
                <Sparkles className="h-4 w-4 text-cyan-400" /> Nova Execução
              </h2>
              <span className="text-[10px] font-mono text-cyan-500 bg-cyan-950/60 border border-cyan-900/40 px-1.5 py-0.5 rounded uppercase">V1 Engine</span>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-mono font-bold text-slate-400 block mb-1.5 uppercase">1. Selecionar Briefing Aprovado</label>
                <select 
                  value={selectedBriefId}
                  onChange={(e) => setSelectedBriefId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-all"
                >
                  <option value="">-- Selecione um briefing --</option>
                  {briefs.map((b) => (
                    <option key={b.id} value={b.id}>{b.titulo} ({b.cluster})</option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-500 block mt-1">Carrega palavras-chave, entidades obrigatórias e perguntas da SERP.</span>
              </div>

              <div>
                <label className="text-xs font-mono font-bold text-slate-400 block mb-1.5 uppercase">2. Selecionar Blueprint Editorial</label>
                <select 
                  value={selectedBlueprintId}
                  onChange={(e) => setSelectedBlueprintId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-all"
                >
                  <option value="">-- Selecione o blueprint --</option>
                  {blueprints.map((bp) => (
                    <option key={bp.id} value={bp.id}>{bp.titulo} (v{bp.versao})</option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-500 block mt-1">Garante conformidade com a hierarquia de headings (H1, H2, H3).</span>
              </div>

              {/* Required assets validation tags (Visual Feedback of the 13 required assets) */}
              <div className="bg-slate-900/60 border border-slate-850 rounded-lg p-3.5 space-y-2">
                <span className="text-[10px] font-mono font-bold text-slate-400 block uppercase tracking-wider">Validação de Contratos (13 Insumos)</span>
                
                <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 text-[10px] font-mono">
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Knowledge Core</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Inventory</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Competitors</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">SERP Intelligence</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Keywords</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Opportunity</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Editorial Planner</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Content Strategy</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Fact Checking Base</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> <span className="text-slate-300">Fontes (Sources)</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleCreateDraft}
                disabled={!selectedBriefId || !selectedBlueprintId || createLoading}
                className={`w-full py-2.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                  selectedBriefId && selectedBlueprintId && !createLoading
                    ? "bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                    : "bg-slate-900 border border-slate-800 text-slate-500 cursor-not-allowed"
                }`}
              >
                {createLoading ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin text-slate-950" />
                    Processando Contexto...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 text-slate-950" />
                    Gerar Primeiro Rascunho
                  </>
                )}
              </button>
            </div>
          </div>

          {/* List of generated Drafts (Right 2 columns) */}
          <div className="bg-slate-950 border border-slate-850 rounded-xl p-5 shadow-lg lg:col-span-2 space-y-4">
            
            {/* Loading Overlay with Step logs */}
            {createLoading && (
              <div className="absolute inset-0 bg-slate-950/95 rounded-xl z-50 flex flex-col items-center justify-center p-8 space-y-6 animate-fade-in">
                <div className="p-4 bg-cyan-950/40 rounded-full border border-cyan-800 animate-pulse">
                  <Cpu className="h-10 w-10 text-cyan-400 animate-spin" />
                </div>
                
                <div className="text-center">
                  <h3 className="text-lg font-bold text-white font-sans">Orquestrando Pipeline do Agente Escritor</h3>
                  <p className="text-slate-400 text-xs mt-1">Carregando, validando e compilando os 13 ativos de inteligência</p>
                </div>

                <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-lg p-4 h-64 overflow-y-auto space-y-2 font-mono text-[10px]">
                  {stepLogs.map((log, index) => (
                    <div key={index} className="flex items-start gap-1.5 text-cyan-400/90 leading-relaxed">
                      <span className="text-cyan-600 font-bold">&gt;</span>
                      <span>{log}</span>
                      {index === stepLogs.length - 1 && index < mockGenerationSteps.length - 1 && (
                        <span className="inline-block w-1.5 h-3 bg-cyan-400 ml-1 animate-ping"></span>
                      )}
                    </div>
                  ))}
                </div>

                <div className="text-[10px] text-slate-500 font-mono">
                  {currentStepIndex + 1} de {mockGenerationSteps.length} etapas concluídas...
                </div>
              </div>
            )}

            <div className="flex items-center justify-between border-b border-slate-850 pb-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2 uppercase tracking-wide">
                <FileText className="h-4 w-4 text-cyan-400" /> Rascunhos Disponíveis
              </h2>
              <button 
                onClick={loadData}
                className="p-1 hover:bg-slate-900 rounded border border-transparent hover:border-slate-850 text-slate-400 hover:text-white transition-all"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            </div>

            {loading && drafts.length === 0 ? (
              <div className="py-20 flex flex-col items-center justify-center space-y-3">
                <RefreshCw className="h-8 w-8 text-cyan-400 animate-spin" />
                <p className="text-slate-400 text-xs">Carregando banco de rascunhos...</p>
              </div>
            ) : drafts.length === 0 ? (
              <div className="py-20 border border-dashed border-slate-850 rounded-xl flex flex-col items-center justify-center text-center p-6 space-y-3">
                <div className="p-3 bg-slate-900 rounded-full">
                  <BookOpen className="h-6 w-6 text-slate-500" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Nenhum rascunho gerado</h4>
                  <p className="text-slate-500 text-xs mt-1 max-w-sm">Use o menu ao lado para selecionar um briefing e um blueprint e disparar a geração do rascunho inicial.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {drafts.map((draft) => (
                  <div 
                    key={draft.id}
                    onClick={() => setSelectedDraft(draft)}
                    className="p-4 bg-slate-900/40 hover:bg-slate-900/80 border border-slate-850 hover:border-slate-800 rounded-xl transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm group"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-mono bg-slate-950 border border-slate-800 text-slate-400 px-1.5 py-0.5 rounded uppercase font-bold">{draft.id}</span>
                        <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 px-1.5 py-0.5 rounded uppercase font-bold">v{draft.versao}</span>
                        
                        {/* Audit badge with compliance color */}
                        {draft.audit && (
                          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                            draft.audit.score >= 85 
                              ? "bg-emerald-950 text-emerald-400 border border-emerald-900" 
                              : draft.audit.score >= 60 
                                ? "bg-amber-950 text-amber-400 border border-amber-900" 
                                : "bg-rose-950 text-rose-400 border border-rose-900"
                          }`}>
                            E-A-T Score: {draft.audit.score}%
                          </span>
                        )}
                      </div>

                      <h3 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-all font-sans line-clamp-1">{draft.titulo}</h3>
                      
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-500">
                        <span className="flex items-center gap-1"><Database className="h-3 w-3" /> Brief: {draft.brief_id}</span>
                        <span className="flex items-center gap-1"><FileCode className="h-3 w-3" /> Model: {draft.modelo_ia}</span>
                        <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {new Date(draft.criado_em).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-right">
                      <div className="hidden md:block">
                        <span className="text-[10px] font-mono text-slate-500 block uppercase font-bold">Tempo</span>
                        <strong className="text-white font-mono text-xs">{draft.tempo_execucao}s</strong>
                      </div>
                      <div className="hidden md:block">
                        <span className="text-[10px] font-mono text-slate-500 block uppercase font-bold">Tokens</span>
                        <strong className="text-white font-mono text-xs">{(draft.tokens_entrada + draft.tokens_saida).toLocaleString()}</strong>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-500 group-hover:text-cyan-400 transition-all" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Selected Draft Detail View */
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Sidebar Info/Metadata & Audit Score (1 Column) */}
          <div className="space-y-6 lg:col-span-1">
            
            {/* Audit compliance Radial/Score card */}
            <div className="bg-slate-950 border border-slate-850 rounded-xl p-5 shadow-md space-y-4">
              <span className="text-[10px] font-mono font-bold text-slate-400 block uppercase tracking-wider">Compliance E-A-T & SEO</span>
              
              <div className="flex flex-col items-center justify-center py-4 border-y border-slate-850/60 space-y-2">
                <div className="relative flex items-center justify-center">
                  {/* Gauge indicator */}
                  <div className={`h-24 w-24 rounded-full border-4 flex items-center justify-center ${
                    (selectedDraft.audit?.score || 0) >= 85 
                      ? "border-emerald-500 bg-emerald-950/20" 
                      : (selectedDraft.audit?.score || 0) >= 60 
                        ? "border-amber-500 bg-amber-950/20" 
                        : "border-rose-500 bg-rose-950/20"
                  }`}>
                    <strong className="text-2xl font-bold font-mono text-white">{(selectedDraft.audit?.score || 0)}%</strong>
                  </div>
                </div>

                <div className="text-center">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    {(selectedDraft.audit?.score || 0) >= 85 ? "Alta Relevância Semântica" : "Necessita Revisão"}
                  </h4>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Comprovado contra Fact Check</span>
                </div>
              </div>

              {/* metadata parameters list */}
              <div className="space-y-3 pt-1 text-xs">
                <div className="flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500 font-mono text-[11px] uppercase">Rascunho ID</span>
                  <strong className="text-white font-mono uppercase">{selectedDraft.id}</strong>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500 font-mono text-[11px] uppercase">Versão</span>
                  <strong className="text-white font-mono">v{selectedDraft.versao}</strong>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500 font-mono text-[11px] uppercase">IA Modelo</span>
                  <strong className="text-white font-sans">{selectedDraft.modelo_ia}</strong>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500 font-mono text-[11px] uppercase">Provedor</span>
                  <strong className="text-white font-sans">{selectedDraft.provedor_ia}</strong>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-1.5">
                  <span className="text-slate-500 font-mono text-[11px] uppercase">Tempo Exec</span>
                  <strong className="text-white font-mono">{selectedDraft.tempo_execucao}s</strong>
                </div>
                <div className="flex justify-between pb-1.5">
                  <span className="text-slate-500 font-mono text-[11px] uppercase">Total Tokens</span>
                  <strong className="text-white font-mono">{(selectedDraft.tokens_entrada + selectedDraft.tokens_saida).toLocaleString()}</strong>
                </div>
              </div>
            </div>

            {/* Insumos vinculados panel */}
            <div className="bg-slate-950 border border-slate-850 rounded-xl p-5 shadow-md space-y-3">
              <span className="text-[10px] font-mono font-bold text-slate-400 block uppercase tracking-wider">Ativos de Entrada Vinculados</span>
              
              <div className="space-y-2 text-xs">
                <div className="p-2.5 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                  <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Briefing de Referência</span>
                  <strong className="text-white font-sans line-clamp-1">{selectedDraft.brief_id}</strong>
                </div>

                <div className="p-2.5 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                  <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Blueprint de Heading</span>
                  <strong className="text-white font-sans line-clamp-1">{selectedDraft.blueprint_id}</strong>
                </div>

                <div className="p-2.5 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                  <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase">Research Composer Pack</span>
                  <strong className="text-white font-sans line-clamp-1">res-{selectedDraft.blueprint_id}</strong>
                </div>
              </div>
            </div>

          </div>

          {/* Core Content Editor / Viewer Panel (3 Columns) */}
          <div className="bg-slate-950 border border-slate-850 rounded-xl p-6 shadow-lg lg:col-span-3 space-y-6">
            
            {/* Tabs selector */}
            <div className="flex border-b border-slate-850">
              <button
                onClick={() => { setActiveSubTab("texto"); setIsEditing(false); }}
                className={`pb-3 px-4 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all ${
                  activeSubTab === "texto" ? "border-cyan-400 text-cyan-400" : "border-transparent text-slate-500 hover:text-slate-400"
                }`}
              >
                Texto do Rascunho
              </button>
              <button
                onClick={() => { setActiveSubTab("auditoria"); setIsEditing(false); }}
                className={`pb-3 px-4 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ${
                  activeSubTab === "auditoria" ? "border-cyan-400 text-cyan-400" : "border-transparent text-slate-500 hover:text-slate-400"
                }`}
              >
                Auditoria & E-A-T
                {selectedDraft.audit && selectedDraft.audit.errors.length > 0 && (
                  <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse"></span>
                )}
              </button>
              <button
                onClick={() => { setActiveSubTab("historico"); setIsEditing(false); }}
                className={`pb-3 px-4 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all ${
                  activeSubTab === "historico" ? "border-cyan-400 text-cyan-400" : "border-transparent text-slate-500 hover:text-slate-400"
                }`}
              >
                Histórico & Versões
              </button>
            </div>

            {/* TAB: TEXT VIEWER / EDITOR */}
            {activeSubTab === "texto" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <div className="flex items-center gap-2">
                    <Edit3 className="h-4 w-4 text-cyan-400" />
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      {isEditing ? "Revisão Estrita de Rascunho" : "Visualização de Seções Semânticas"}
                    </h3>
                  </div>

                  {!isEditing ? (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg text-xs font-mono font-bold uppercase tracking-wide transition-all"
                    >
                      Revisar Rascunho
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <input 
                        type="text"
                        value={authorName}
                        onChange={(e) => setAuthorName(e.target.value)}
                        placeholder="Nome do Editor"
                        className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white max-w-[120px] focus:outline-none"
                      />
                      <button
                        onClick={handleUpdateDraft}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-lg text-xs font-mono font-bold uppercase tracking-wide transition-all flex items-center gap-1"
                      >
                        <Save className="h-3.5 w-3.5 text-slate-950" />
                        Salvar Nova Versão
                      </button>
                      <button
                        onClick={() => {
                          setIsEditing(false);
                          // Reset state to current draft
                          setEditH1(selectedDraft.conteudo.h1);
                          setEditIntro(selectedDraft.conteudo.introducao);
                          setEditH2(selectedDraft.conteudo.h2);
                          setEditH3(selectedDraft.conteudo.h3 || "");
                          setEditFaq(selectedDraft.conteudo.faq);
                          setEditConclusion(selectedDraft.conteudo.conclusao);
                          setEditCta(selectedDraft.conteudo.cta);
                        }}
                        className="px-3 py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 transition-all"
                      >
                        Cancelar
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-5">
                  {/* Field: H1 */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-900/30 px-2 py-0.5 rounded uppercase">H1 / Título Principal</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editH1 : selectedDraft.conteudo.h1, "h1")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "h1" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editH1}
                        onChange={(e) => setEditH1(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-bold focus:outline-none focus:border-cyan-500"
                      />
                    ) : (
                      <h1 className="text-xl font-bold text-white border border-slate-900 bg-slate-900/10 p-3.5 rounded-lg font-sans leading-snug">{selectedDraft.conteudo.h1}</h1>
                    )}
                  </div>

                  {/* Field: Introdução */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-900/30 px-2 py-0.5 rounded uppercase">Introdução</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editIntro : selectedDraft.conteudo.introducao, "intro")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "intro" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <textarea
                        rows={4}
                        value={editIntro}
                        onChange={(e) => setEditIntro(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-500 leading-relaxed"
                      />
                    ) : (
                      <div className="text-slate-300 border border-slate-900 bg-slate-900/10 p-4 rounded-lg text-xs font-sans leading-relaxed text-justify whitespace-pre-wrap">{selectedDraft.conteudo.introducao}</div>
                    )}
                  </div>

                  {/* Field: H2 */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-900/30 px-2 py-0.5 rounded uppercase">H2 / Desenvolvimento Principal</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editH2 : selectedDraft.conteudo.h2, "h2")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "h2" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <textarea
                        rows={8}
                        value={editH2}
                        onChange={(e) => setEditH2(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-500 leading-relaxed"
                      />
                    ) : (
                      <div className="text-slate-300 border border-slate-900 bg-slate-900/10 p-4 rounded-lg text-xs font-sans leading-relaxed text-justify whitespace-pre-wrap">{selectedDraft.conteudo.h2}</div>
                    )}
                  </div>

                  {/* Field: H3 */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-900/30 px-2 py-0.5 rounded uppercase">H3 / Subseção Opcional</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editH3 : (selectedDraft.conteudo.h3 || ""), "h3")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "h3" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <textarea
                        rows={6}
                        value={editH3}
                        onChange={(e) => setEditH3(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-500 leading-relaxed"
                      />
                    ) : (
                      <div className="text-slate-300 border border-slate-900 bg-slate-900/10 p-4 rounded-lg text-xs font-sans leading-relaxed text-justify whitespace-pre-wrap">
                        {selectedDraft.conteudo.h3 || <em className="text-slate-500">Nenhum subtópico opcional gerado nesta seção.</em>}
                      </div>
                    )}
                  </div>

                  {/* Field: FAQ */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-900/30 px-2 py-0.5 rounded uppercase">FAQ / Intenções de Busca</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editFaq : selectedDraft.conteudo.faq, "faq")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "faq" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <textarea
                        rows={5}
                        value={editFaq}
                        onChange={(e) => setEditFaq(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-500 leading-relaxed"
                      />
                    ) : (
                      <div className="text-slate-300 border border-slate-900 bg-slate-900/10 p-4 rounded-lg text-xs font-sans leading-relaxed whitespace-pre-wrap">{selectedDraft.conteudo.faq}</div>
                    )}
                  </div>

                  {/* Field: Conclusão */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-900/30 px-2 py-0.5 rounded uppercase">Conclusão</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editConclusion : selectedDraft.conteudo.conclusao, "conclusion")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "conclusion" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <textarea
                        rows={4}
                        value={editConclusion}
                        onChange={(e) => setEditConclusion(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-500 leading-relaxed"
                      />
                    ) : (
                      <div className="text-slate-300 border border-slate-900 bg-slate-900/10 p-4 rounded-lg text-xs font-sans leading-relaxed text-justify whitespace-pre-wrap">{selectedDraft.conteudo.conclusao}</div>
                    )}
                  </div>

                  {/* Field: CTA */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-900/30 px-2 py-0.5 rounded uppercase">CTA / Conversão Estratégica</span>
                      <button 
                        onClick={() => copyToClipboard(isEditing ? editCta : selectedDraft.conteudo.cta, "cta")}
                        className="p-1 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "cta" ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editCta}
                        onChange={(e) => setEditCta(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-mono font-bold focus:outline-none focus:border-cyan-500"
                      />
                    ) : (
                      <div className="border border-emerald-900 bg-emerald-950/10 p-4 rounded-lg text-xs font-sans font-bold leading-relaxed flex items-center justify-between text-emerald-300">
                        <span>{selectedDraft.conteudo.cta}</span>
                        <ArrowRight className="h-4 w-4 ml-2 flex-shrink-0 text-emerald-400" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: AUDIT & RELEVANCE CHECKS */}
            {activeSubTab === "auditoria" && selectedDraft.audit && (
              <div className="space-y-6">
                
                {/* Score panel summary */}
                <div className="flex flex-col md:flex-row items-center justify-between p-5 bg-slate-900/60 border border-slate-850 rounded-xl gap-4">
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <CheckSquare className="h-4 w-4 text-cyan-400" />
                      Resultado da Auditoria Semântica
                    </h3>
                    <p className="text-slate-400 text-xs">A conformidade estrita valida as regras de E-A-T contra a base clínica e de palavras-chave.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-400">Score Auditado:</span>
                    <strong className={`text-xl font-mono px-3 py-1 rounded font-bold ${
                      selectedDraft.audit.score >= 85 ? "bg-emerald-950 text-emerald-400" : "bg-amber-950 text-amber-400"
                    }`}>{selectedDraft.audit.score}/100</strong>
                  </div>
                </div>

                {/* Checklist items status indicators */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-950 border border-slate-900 rounded-xl p-4 space-y-3">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase tracking-wider">Requisitos Estruturais</span>
                    
                    <div className="space-y-2.5 text-xs font-sans">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-300">Presença de seções completas</span>
                        {selectedDraft.audit.checks.secoes_completas ? (
                          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-400" />
                        ) : (
                          <XCircle className="h-4.5 w-4.5 text-rose-500" />
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-300">Conformidade com Blueprint</span>
                        {selectedDraft.audit.checks.blueprint_seguido ? (
                          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-400" />
                        ) : (
                          <AlertTriangle className="h-4.5 w-4.5 text-amber-500" />
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-300">CTA Válido com Verbos de Conversão</span>
                        {selectedDraft.audit.checks.cta_valido ? (
                          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-400" />
                        ) : (
                          <AlertTriangle className="h-4.5 w-4.5 text-amber-500" />
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-950 border border-slate-900 rounded-xl p-4 space-y-3">
                    <span className="text-[10px] font-mono font-bold text-slate-500 block uppercase tracking-wider">Entidades & Perguntas da SERP</span>
                    
                    <div className="space-y-2.5 text-xs font-sans">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-300">Perguntas respondidas</span>
                        <strong className="text-white font-mono">{selectedDraft.audit.checks.perguntas_respondidas.length} / {(selectedDraft.audit.checks.perguntas_respondidas.length + selectedDraft.audit.checks.perguntas_faltantes.length)}</strong>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-300">Entidades localizadas</span>
                        <strong className="text-white font-mono">{selectedDraft.audit.checks.entidades_presentes.length} / {(selectedDraft.audit.checks.entidades_presentes.length + selectedDraft.audit.checks.entidades_faltantes.length)}</strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Errors and Warnings detail logs lists */}
                <div className="space-y-4">
                  {selectedDraft.audit.errors.length > 0 && (
                    <div className="p-4 bg-rose-950/25 border border-rose-900/50 rounded-xl space-y-2.5">
                      <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wide flex items-center gap-1.5">
                        <XCircle className="h-4 w-4" /> Erros de Validação Impeditivos ({selectedDraft.audit.errors.length})
                      </h4>
                      <ul className="list-disc pl-5 text-xs text-rose-300 space-y-1">
                        {selectedDraft.audit.errors.map((err, i) => <li key={i}>{err}</li>)}
                      </ul>
                    </div>
                  )}

                  {selectedDraft.audit.warnings.length > 0 && (
                    <div className="p-4 bg-amber-950/25 border border-amber-900/50 rounded-xl space-y-2.5">
                      <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                        <AlertTriangle className="h-4 w-4" /> Avisos e Alertas de Melhoria Semântica ({selectedDraft.audit.warnings.length})
                      </h4>
                      <ul className="list-disc pl-5 text-xs text-amber-300 space-y-1">
                        {selectedDraft.audit.warnings.map((warn, i) => <li key={i}>{warn}</li>)}
                      </ul>
                    </div>
                  )}

                  {selectedDraft.audit.errors.length === 0 && selectedDraft.audit.warnings.length === 0 && (
                    <div className="p-10 border border-emerald-900 bg-emerald-950/10 rounded-xl text-center space-y-2">
                      <CheckCircle2 className="h-8 w-8 text-emerald-400 mx-auto" />
                      <h4 className="text-sm font-bold text-emerald-300">Conformidade Máxima Atingida</h4>
                      <p className="text-emerald-400/70 text-xs max-w-sm mx-auto">O primeiro rascunho obedece com 100% de exatidão às entidades, perguntas da SERP e à estrutura de headings do Blueprint!</p>
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* TAB: VERSIONING HISTORY AND DIFFING */}
            {activeSubTab === "historico" && (
              <div className="space-y-6">
                
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <History className="h-4 w-4 text-cyan-400" /> Histórico de Versões e Snapshots
                  </h3>
                  <span className="text-[10px] font-mono text-slate-500">{draftVersions.length} versões salvas</span>
                </div>

                <div className="space-y-4">
                  {draftVersions.map((version, i) => (
                    <div key={version.versao} className="p-4 bg-slate-900/60 border border-slate-850 rounded-xl space-y-3 shadow-sm">
                      <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-850 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 font-mono text-[10px] font-bold">VERSÃO {version.versao}</span>
                          <span className="text-slate-500 text-[10px] font-mono">{new Date(version.data).toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] font-mono text-slate-500">
                          <span>Modelo: {version.modelo_ia}</span>
                          <span>Tempo: {version.tempo_execucao}s</span>
                        </div>
                      </div>

                      <div className="space-y-1 text-xs">
                        <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">Relatório de Diferenças (Diff Log)</span>
                        <p className="text-slate-300 font-sans italic bg-slate-950 p-2.5 rounded border border-slate-900 leading-relaxed">
                          {version.diferencas || "Sem diferenças registradas."}
                        </p>
                      </div>

                      {/* Display prompt snapshot snippet */}
                      <div className="text-[10px] font-mono text-slate-500 space-y-0.5">
                        <span className="uppercase block font-bold">Prompt de Entrada Snapshot:</span>
                        <code className="block bg-slate-950/60 p-2 rounded border border-slate-900 leading-tight select-none line-clamp-1">{version.prompt_utilizado}</code>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
