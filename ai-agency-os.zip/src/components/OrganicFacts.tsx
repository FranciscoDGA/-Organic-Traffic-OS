import React, { useState, useEffect } from "react";
import {
  ShieldAlert, ShieldCheck, CheckCircle2, AlertTriangle, ExternalLink,
  History, Edit3, Save, RotateCcw, Plus, Check, Loader2, List, Shield,
  Search, Award, Clock, Database, FileSpreadsheet, Sparkles, Filter, Info, XCircle, ChevronRight
} from "lucide-react";
import { Fact, FactEvidence, FactCategory, FactRule } from "../../organic-traffic-os/facts/models/fact-models";
import { ResearchPack } from "../../organic-traffic-os/research-pack/models/research-models";

export function OrganicFacts() {
  const [facts, setFacts] = useState<Fact[]>([]);
  const [researchPacks, setResearchPacks] = useState<ResearchPack[]>([]);
  const [categories, setCategories] = useState<FactCategory[]>([]);
  const [rules, setRules] = useState<FactRule[]>([]);
  const [evidences, setEvidences] = useState<FactEvidence[]>([]);
  const [selectedFact, setSelectedFact] = useState<Fact | null>(null);
  
  // Filtering & Search
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");

  // Loading & State
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Selected pack to process
  const [packToProcess, setPackToProcess] = useState<string>("");

  // Edit states for selected fact
  const [isEditing, setIsEditing] = useState(false);
  const [editDesc, setEditDesc] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [editOrigem, setEditOrigem] = useState("");
  const [editObservacoes, setEditObservacoes] = useState("");
  const [editChangelog, setEditChangelog] = useState("");

  // Manual Creation state
  const [showAddForm, setShowAddForm] = useState(false);
  const [newDesc, setNewDesc] = useState("");
  const [newCategory, setNewCategory] = useState("Legislação");
  const [newOrigem, setNewOrigem] = useState("");
  const [newTipo, setNewTipo] = useState("regulamento");
  const [newObservacoes, setNewObservacoes] = useState("");
  const [newEvSource, setNewEvSource] = useState("");
  const [newEvUrl, setNewEvUrl] = useState("");
  const [newEvTitle, setNewEvTitle] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [factsRes, packsRes, catsRes, rulesRes, evsRes] = await Promise.all([
        fetch("/api/organic-os/facts"),
        fetch("/api/organic-os/research-packs"),
        fetch("/api/organic-os/facts/categories"),
        fetch("/api/organic-os/facts/rules"),
        fetch("/api/organic-os/facts/evidences")
      ]);

      if (!factsRes.ok || !packsRes.ok || !catsRes.ok || !rulesRes.ok || !evsRes.ok) {
        throw new Error("Erro ao carregar dados da API de Fatos.");
      }

      const factsData = await factsRes.json();
      const packsData = await packsRes.json();
      const catsData = await catsRes.json();
      const rulesData = await rulesRes.json();
      const evsData = await evsRes.json();

      setFacts(factsData);
      setResearchPacks(packsData);
      setCategories(catsData);
      setRules(rulesData);
      setEvidences(evsData);

      if (packsData.length > 0) {
        setPackToProcess(packsData[0].id);
      }

      if (factsData.length > 0) {
        setSelectedFact(factsData[0]);
      }
    } catch (err: any) {
      setError(err.message || "Erro desconhecido ao carregar dados.");
    } finally {
      setLoading(false);
    }
  };

  const handleProcessPack = async () => {
    if (!packToProcess) return;
    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const res = await fetch("/api/organic-os/facts/process-pack", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ packId: packToProcess })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Falha ao processar o Dossiê de Pesquisa.");
      }

      const data = await res.json();
      setSuccessMsg(`Fact Engine processado! ${data.count} novos fatos extraídos, validados e inseridos na base.`);
      
      // Refresh
      await fetchData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRegisterManualFact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDesc.trim() || !newOrigem.trim()) {
      setError("A descrição e a origem são obrigatórias.");
      return;
    }
    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const factId = `fact-manual-${Date.now().toString(36)}`;
      const newEvs: FactEvidence[] = [];
      if (newEvSource.trim() && newEvUrl.trim()) {
        newEvs.push({
          fonte: newEvSource,
          url: newEvUrl,
          titulo: newEvTitle || "Referência Auxiliar",
          tipo: "oficial",
          data: new Date().toISOString().split("T")[0],
          autor: "Editor de Fatos"
        });
      }

      const newFactPayload: Fact = {
        id: factId,
        descricao: newDesc,
        categoria: newCategory,
        origem: newOrigem,
        tipo: newTipo,
        nivel_confianca: "média", // default baseline calculated by engine on register
        status: "pendente",
        ultima_validacao: new Date().toISOString(),
        observacoes: newObservacoes || "Cadastrado manualmente pelo painel de controle.",
        evidencias: newEvs,
        versao: 1,
        historico: []
      };

      const res = await fetch("/api/organic-os/facts/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newFactPayload)
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Erro de validação ou de banco de dados.");
      }

      setSuccessMsg("Fato registrado com sucesso e enfileirado para auditoria.");
      setShowAddForm(false);
      // Reset form
      setNewDesc("");
      setNewOrigem("");
      setNewObservacoes("");
      setNewEvSource("");
      setNewEvUrl("");
      setNewEvTitle("");

      await fetchData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: "aprovado" | "rejeitado" | "pendente") => {
    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const res = await fetch(`/api/organic-os/facts/${id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          updatedData: { status: newStatus },
          autor: "Auditor de Fatos (UI)",
          alteracao: `Mudança de status de validação para '${newStatus}'`
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Falha ao alterar o status.");
      }

      const data = await res.json();
      setSuccessMsg(`Status do fato atualizado com sucesso para '${newStatus}'.`);
      
      // Update local state smoothly
      setFacts(prev => prev.map(f => f.id === id ? data.fact : f));
      setSelectedFact(data.fact);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleSaveEdit = async () => {
    if (!selectedFact) return;
    setActionLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const res = await fetch(`/api/organic-os/facts/${selectedFact.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          updatedData: {
            descricao: editDesc,
            categoria: editCategory,
            origem: editOrigem,
            observacoes: editObservacoes
          },
          autor: "Editor de Fatos (UI)",
          alteracao: editChangelog || "Edição direta dos campos do fato."
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Falha ao atualizar o fato.");
      }

      const data = await res.json();
      setSuccessMsg("Fato e histórico de versões atualizados com sucesso!");
      setIsEditing(false);
      setEditChangelog("");
      
      // Update state
      setFacts(prev => prev.map(f => f.id === selectedFact.id ? data.fact : f));
      setSelectedFact(data.fact);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const startEditing = () => {
    if (!selectedFact) return;
    setEditDesc(selectedFact.descricao);
    setEditCategory(selectedFact.categoria);
    setEditOrigem(selectedFact.origem);
    setEditObservacoes(selectedFact.observacoes);
    setEditChangelog("");
    setIsEditing(true);
  };

  // Live validator for the active detail view / creation view
  const runLiveValidation = (f: Fact) => {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!f.descricao.trim()) errors.push("Descrição do fato está em branco.");
    if (f.descricao.length < 15) warnings.push("Descrição técnica muito resumida.");
    if (!f.origem.trim()) errors.push("Nenhuma origem ou base técnica declarada.");
    
    const allowed = categories.map(c => c.nome.toLowerCase());
    if (f.categoria && !allowed.includes(f.categoria.toLowerCase())) {
      warnings.push(`Categoria '${f.categoria}' não é homologada.`);
    }

    if (!f.evidencias || f.evidencias.length === 0) {
      warnings.push("Falta base de evidências (anexos de URLs) para comprovação completa.");
    }

    return { errors, warnings };
  };

  // Filters
  const filteredFacts = facts.filter(f => {
    const matchesSearch = f.descricao.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.origem.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          f.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || f.categoria.toLowerCase() === selectedCategory.toLowerCase();
    const matchesStatus = selectedStatus === "all" || f.status.toLowerCase() === selectedStatus.toLowerCase();

    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Score statistics
  const avgConfidence = facts.length > 0
    ? Math.round(facts.reduce((acc, f) => acc + (f.score_detalhado?.geral || 50), 0) / facts.length)
    : 0;

  const countPending = facts.filter(f => f.status === "pendente").length;
  const countApproved = facts.filter(f => f.status === "aprovado").length;
  const countRejected = facts.filter(f => f.status === "rejeitado").length;

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 text-gray-800">
      {/* Header Banner */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-gray-900">Fact Intelligence Engine</h1>
            <p className="text-xs text-gray-500">Sprint 13 — Camada de Confiança e Base de Evidências do Organic Traffic OS</p>
          </div>
        </div>
        
        {/* Actions panel */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center bg-gray-100 p-1.5 rounded-lg border border-gray-200">
            <span className="text-xs text-gray-500 px-2 font-medium">Extrair do Pack:</span>
            <select
              value={packToProcess}
              onChange={(e) => setPackToProcess(e.target.value)}
              className="bg-white text-xs border border-gray-300 rounded px-2 py-1 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            >
              {researchPacks.map(p => (
                <option key={p.id} value={p.id}>{p.titulo.replace("Dossiê de Pesquisa: ", "")}</option>
              ))}
              {researchPacks.length === 0 && <option value="">Nenhum dossiê disponível</option>}
            </select>
            <button
              onClick={handleProcessPack}
              disabled={actionLoading || !packToProcess}
              className="ml-2 px-3 py-1 bg-emerald-600 text-white rounded text-xs font-semibold hover:bg-emerald-700 transition flex items-center disabled:opacity-50"
            >
              {actionLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <Sparkles className="h-3.5 w-3.5 mr-1" />}
              Extrair Fatos
            </button>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-3.5 py-1.5 bg-gray-900 text-white hover:bg-gray-800 rounded-lg text-xs font-semibold transition flex items-center"
          >
            <Plus className="h-4 w-4 mr-1" /> Novo Fato Manual
          </button>
        </div>
      </header>

      {/* Stats Cards */}
      <section className="p-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Total de Fatos</span>
            <div className="text-2xl font-bold mt-1 text-gray-900">{facts.length}</div>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
            <Database className="h-6 w-6" />
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-gray-400 font-medium">Confiabilidade Média</span>
            <div className="flex items-baseline mt-1 space-x-1">
              <span className="text-2xl font-bold text-gray-900">{avgConfidence}%</span>
              <span className="text-xs text-emerald-600 font-semibold">(Alta)</span>
            </div>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <Award className="h-6 w-6" />
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Auditoria Pendente</span>
            <div className="text-2xl font-bold mt-1 text-amber-600">{countPending}</div>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <Clock className="h-6 w-6" />
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Homologados</span>
            <div className="text-2xl font-bold mt-1 text-emerald-600">{countApproved}</div>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-lg">
            <ShieldCheck className="h-6 w-6" />
          </div>
        </div>
      </section>

      {/* Global Alerts & Error/Success notifications */}
      {error && (
        <div className="mx-6 mb-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm flex items-center space-x-2">
          <AlertTriangle className="h-5 w-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {successMsg && (
        <div className="mx-6 mb-4 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm flex items-center space-x-2">
          <CheckCircle2 className="h-5 w-5 flex-shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Manual Creation Form modal-overlay mock */}
      {showAddForm && (
        <div className="mx-6 mb-6 p-6 bg-white border border-gray-200 rounded-xl shadow-md">
          <div className="flex justify-between items-center mb-4 pb-2 border-b">
            <h3 className="font-bold text-gray-900 flex items-center">
              <Plus className="h-5 w-5 text-emerald-600 mr-1" /> Registrar Fato Manualmente na Base
            </h3>
            <button onClick={() => setShowAddForm(false)} className="text-gray-400 hover:text-gray-600">
              <XCircle className="h-5 w-5" />
            </button>
          </div>
          <form onSubmit={handleRegisterManualFact} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-semibold uppercase text-gray-500 mb-1">Descrição do Fato Técnico</label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Ex: De acordo com o Decreto-Lei nº 5.452/1943 (CLT) em seu Art. 477, o pagamento das verbas rescisórias deve ser efetuado até dez dias contados a partir da data de término do contrato..."
                rows={3}
                className="w-full text-sm border border-gray-300 rounded px-3 py-2 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase text-gray-500 mb-1">Categoria de Homologação</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="w-full text-sm border border-gray-300 rounded px-3 py-2 focus:outline-none"
              >
                {categories.map(c => (
                  <option key={c.nome} value={c.nome}>{c.nome}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase text-gray-500 mb-1">Origem / Referência Central</label>
              <input
                type="text"
                value={newOrigem}
                onChange={(e) => setNewOrigem(e.target.value)}
                placeholder="Ex: CLT Artigo 477 ou Edital Concurso PF 2026"
                className="w-full text-sm border border-gray-300 rounded px-3 py-2 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase text-gray-500 mb-1">Tipo de Documento</label>
              <select
                value={newTipo}
                onChange={(e) => setNewTipo(e.target.value)}
                className="w-full text-sm border border-gray-300 rounded px-3 py-2"
              >
                <option value="lei">Legislação / Decreto</option>
                <option value="regulamento">Regulamento Administrativo</option>
                <option value="edital">Edital de Concurso</option>
                <option value="salario">Tabela de Salários</option>
                <option value="cronograma">Calendário Oficial</option>
                <option value="fato_pesquisa">Fato Geral</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase text-gray-500 mb-1">Observações Operacionais</label>
              <input
                type="text"
                value={newObservacoes}
                onChange={(e) => setNewObservacoes(e.target.value)}
                placeholder="Notas internas..."
                className="w-full text-sm border border-gray-300 rounded px-3 py-2 focus:outline-none"
              />
            </div>

            <div className="col-span-2 border-t pt-3 mt-1">
              <h4 className="text-xs font-bold text-gray-600 mb-2 uppercase tracking-wide">Vincular Primeira Evidência (Opcional mas recomendado)</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Nome da Fonte (Ex: Diário Oficial da União)"
                  value={newEvSource}
                  onChange={(e) => setNewEvSource(e.target.value)}
                  className="text-xs border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="URL Oficial de comprovação (Ex: https://in.gov.br/...)"
                  value={newEvUrl}
                  onChange={(e) => setNewEvUrl(e.target.value)}
                  className="text-xs border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Título da página / Documento"
                  value={newEvTitle}
                  onChange={(e) => setNewEvTitle(e.target.value)}
                  className="text-xs border border-gray-300 rounded px-2.5 py-1.5 focus:outline-none"
                />
              </div>
            </div>

            <div className="col-span-2 flex justify-end space-x-2 pt-3 border-t">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 bg-gray-100 text-gray-700 hover:bg-gray-200 rounded-lg text-xs font-semibold"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={actionLoading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs"
              >
                Salvar Fato e Registrar Evidência
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Main Workspace split */}
      <div className="flex-1 px-6 pb-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left column: Facts directory */}
        <aside className="lg:col-span-5 bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col overflow-hidden max-h-[750px]">
          {/* List Toolbar */}
          <div className="p-4 border-b border-gray-200 bg-gray-50 flex flex-col space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Filtrar fatos por descrição ou origem..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-4 py-2 bg-white border border-gray-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            
            <div className="flex space-x-2">
              <div className="flex-1">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full text-xs bg-white border border-gray-300 rounded-lg px-2 py-1.5 text-gray-600 focus:outline-none"
                >
                  <option value="all">Todas as Categorias ({categories.length})</option>
                  {categories.map(c => (
                    <option key={c.nome} value={c.nome}>{c.nome}</option>
                  ))}
                </select>
              </div>
              <div className="flex-1">
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full text-xs bg-white border border-gray-300 rounded-lg px-2 py-1.5 text-gray-600 focus:outline-none"
                >
                  <option value="all">Todos os Status</option>
                  <option value="aprovado">Aprovados</option>
                  <option value="pendente">Pendentes de Auditoria</option>
                  <option value="rejeitado">Rejeitados</option>
                </select>
              </div>
            </div>
          </div>

          {/* Directory list */}
          <div className="flex-1 overflow-y-auto divide-y divide-gray-150">
            {filteredFacts.map(f => {
              const liveVal = runLiveValidation(f);
              const hasErrors = liveVal.errors.length > 0;
              const isSelected = selectedFact?.id === f.id;

              return (
                <div
                  key={f.id}
                  onClick={() => {
                    setSelectedFact(f);
                    setIsEditing(false);
                  }}
                  className={`p-4 cursor-pointer hover:bg-gray-50 transition ${
                    isSelected ? "bg-emerald-50/70 border-l-4 border-emerald-600" : ""
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="px-2 py-0.5 bg-gray-100 text-gray-600 font-semibold rounded text-[10px] uppercase tracking-wider">
                      {f.categoria}
                    </span>
                    <div className="flex items-center space-x-1.5">
                      {hasErrors ? (
                        <span className="p-0.5 bg-red-100 text-red-700 rounded text-[9px] font-bold" title="Violou regras de integridade">
                          Inválido
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[9px] font-bold flex items-center">
                          <Check className="h-2.5 w-2.5 mr-0.5" /> Consistente
                        </span>
                      )}
                      
                      <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        f.status === "aprovado" ? "bg-emerald-100 text-emerald-800" :
                        f.status === "rejeitado" ? "bg-red-100 text-red-800" :
                        "bg-amber-100 text-amber-800"
                      }`}>
                        {f.status}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-gray-700 font-medium line-clamp-2 mb-2 leading-relaxed">
                    {f.descricao}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-gray-500 font-mono">
                    <span className="truncate max-w-[150px]">Origem: {f.origem}</span>
                    <span className="flex items-center bg-gray-100 px-1.5 py-0.5 rounded font-bold text-gray-700">
                      Confiança: {f.score_detalhado?.geral || 50}%
                    </span>
                  </div>
                </div>
              );
            })}

            {filteredFacts.length === 0 && (
              <div className="p-8 text-center text-gray-400 flex flex-col items-center justify-center">
                <ShieldAlert className="h-10 w-10 mb-2 stroke-1" />
                <p className="text-xs">Nenhum fato localizado com os filtros selecionados.</p>
              </div>
            )}
          </div>

          {/* Left panel footer information list */}
          <div className="p-4 border-t border-gray-200 bg-gray-50 flex items-center justify-between text-xs text-gray-500">
            <span>Listando {filteredFacts.length} fatos de evidência</span>
            <span className="font-mono text-[10px]">Versão V1</span>
          </div>
        </aside>

        {/* Right column: Fact workspace details & validation checks */}
        <main className="lg:col-span-7 bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col overflow-hidden max-h-[750px]">
          {selectedFact ? (
            <div className="flex-1 flex flex-col overflow-y-auto">
              {/* Workspace Header */}
              <div className="p-6 border-b border-gray-150 flex items-start justify-between bg-gray-50">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="px-2 py-0.5 bg-emerald-600 text-white font-bold rounded text-xs uppercase tracking-widest font-mono">
                      {selectedFact.categoria}
                    </span>
                    <span className="text-xs text-gray-400 font-mono">ID: {selectedFact.id}</span>
                  </div>
                  <h2 className="text-lg font-bold text-gray-900 tracking-tight leading-snug">
                    Análise & Auditoria de Fato Técnico
                  </h2>
                </div>

                <div className="flex items-center space-x-2">
                  {selectedFact.status !== "aprovado" && (
                    <button
                      onClick={() => handleStatusChange(selectedFact.id, "aprovado")}
                      className="px-3 py-1.5 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition text-xs flex items-center"
                    >
                      <ShieldCheck className="h-4 w-4 mr-1" /> Homologar
                    </button>
                  )}
                  {selectedFact.status !== "rejeitado" && (
                    <button
                      onClick={() => handleStatusChange(selectedFact.id, "rejeitado")}
                      className="px-3 py-1.5 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition text-xs flex items-center"
                    >
                      <XCircle className="h-4 w-4 mr-1" /> Rejeitar
                    </button>
                  )}
                  {!isEditing && (
                    <button
                      onClick={startEditing}
                      className="p-1.5 bg-white text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-100 transition"
                      title="Editar Fato"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Editing Card panel */}
              {isEditing ? (
                <div className="p-6 border-b border-amber-200 bg-amber-50/40 space-y-4">
                  <h3 className="font-bold text-amber-900 text-sm flex items-center">
                    <Edit3 className="h-4 w-4 mr-1 text-amber-600" /> Edição de Registro Técnico (Modo Versionamento Ativo)
                  </h3>
                  <div>
                    <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Descrição</label>
                    <textarea
                      value={editDesc}
                      onChange={(e) => setEditDesc(e.target.value)}
                      rows={3}
                      className="w-full text-sm border border-gray-300 rounded px-3 py-2 bg-white focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Origem do Fato</label>
                      <input
                        type="text"
                        value={editOrigem}
                        onChange={(e) => setEditOrigem(e.target.value)}
                        className="w-full text-xs border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Categoria</label>
                      <select
                        value={editCategory}
                        onChange={(e) => setEditCategory(e.target.value)}
                        className="w-full text-xs border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                      >
                        {categories.map(c => (
                          <option key={c.nome} value={c.nome}>{c.nome}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Motivo / Alteração (Registrada no Histórico)</label>
                    <input
                      type="text"
                      placeholder="Ex: Correção de prazo regulamentar conforme portaria nova..."
                      value={editChangelog}
                      onChange={(e) => setEditChangelog(e.target.value)}
                      className="w-full text-xs border border-gray-300 rounded px-2.5 py-1.5 bg-white focus:outline-none"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-2">
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1.5 bg-gray-200 text-gray-700 hover:bg-gray-300 rounded-lg text-xs font-semibold"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={handleSaveEdit}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs"
                    >
                      Salvar Nova Versão (V{ (selectedFact.versao || 1) + 1 })
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-6 border-b border-gray-150">
                  <p className="text-sm text-gray-800 leading-relaxed font-semibold bg-gray-50 p-4 rounded-xl border border-gray-100">
                    "{selectedFact.descricao}"
                  </p>
                  <div className="flex items-center space-x-6 mt-4 text-xs text-gray-500">
                    <div>
                      <span className="font-semibold text-gray-700">Origem:</span> {selectedFact.origem}
                    </div>
                    <div>
                      <span className="font-semibold text-gray-700">Tipo:</span> {selectedFact.tipo}
                    </div>
                    <div>
                      <span className="font-semibold text-gray-700">Versão Ativa:</span> v{selectedFact.versao || 1}
                    </div>
                  </div>
                </div>
              )}

              {/* Confidence Score Breakdown */}
              <div className="p-6 border-b border-gray-150">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-4 flex items-center">
                  <Award className="h-4 w-4 mr-1 text-emerald-600" /> Distribuição de Peso de Confiança
                </h3>
                
                {selectedFact.score_detalhado ? (
                  <div className="space-y-4">
                    {/* Progress bars */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600 flex items-center">Confiabilidade <Info className="h-3 w-3 text-gray-400 ml-1" title="Nível de precisão da fonte primária." /></span>
                          <span className="font-mono font-bold text-gray-800">{selectedFact.score_detalhado.confiabilidade}%</span>
                        </div>
                        <div className="w-full bg-gray-150 h-2 rounded-full overflow-hidden">
                          <div className="bg-emerald-500 h-full transition-all" style={{ width: `${selectedFact.score_detalhado.confiabilidade}%` }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600 flex items-center">Quantidade de Fontes <Info className="h-3 w-3 text-gray-400 ml-1" title="Número de referências anexas suportando o fato." /></span>
                          <span className="font-mono font-bold text-gray-800">{selectedFact.score_detalhado.quantidade_fontes}%</span>
                        </div>
                        <div className="w-full bg-gray-150 h-2 rounded-full overflow-hidden">
                          <div className="bg-blue-500 h-full transition-all" style={{ width: `${selectedFact.score_detalhado.quantidade_fontes}%` }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600 flex items-center">Atualidade <Info className="h-3 w-3 text-gray-400 ml-1" title="Fatores cronológicos e vigência das evidências." /></span>
                          <span className="font-mono font-bold text-gray-800">{selectedFact.score_detalhado.atualidade}%</span>
                        </div>
                        <div className="w-full bg-gray-150 h-2 rounded-full overflow-hidden">
                          <div className="bg-amber-500 h-full transition-all" style={{ width: `${selectedFact.score_detalhado.atualidade}%` }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600 flex items-center">Autoridade <Info className="h-3 w-3 text-gray-400 ml-1" title="Qualidade acadêmica ou governamental das URLs fornecidas." /></span>
                          <span className="font-mono font-bold text-gray-800">{selectedFact.score_detalhado.autoridade}%</span>
                        </div>
                        <div className="w-full bg-gray-150 h-2 rounded-full overflow-hidden">
                          <div className="bg-purple-500 h-full transition-all" style={{ width: `${selectedFact.score_detalhado.autoridade}%` }} />
                        </div>
                      </div>

                      <div className="md:col-span-2">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600 flex items-center font-semibold">Consistência Interna <Info className="h-3 w-3 text-gray-400 ml-1" title="O fato é compatível com os demais fatos validados e regras." /></span>
                          <span className="font-mono font-bold text-gray-800">{selectedFact.score_detalhado.consistencia}%</span>
                        </div>
                        <div className="w-full bg-gray-150 h-2.5 rounded-full overflow-hidden">
                          <div className="bg-indigo-600 h-full transition-all" style={{ width: `${selectedFact.score_detalhado.consistencia}%` }} />
                        </div>
                      </div>
                    </div>

                    <div className="bg-emerald-50 rounded-lg p-3.5 border border-emerald-100 flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-emerald-950 uppercase tracking-wide">Fórmula Ponderada Final (Confidence Index)</h4>
                        <p className="text-[11px] text-emerald-800 mt-0.5">Calculado automaticamente com base nos pesos cadastrados no confidence-score.json.</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-black text-emerald-950">{selectedFact.score_detalhado.geral}%</div>
                        <span className="text-[10px] font-mono text-emerald-700 font-bold uppercase">Selo de Confiança</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-gray-400 bg-gray-50 p-4 rounded-xl border text-center font-medium">
                    Metadados de pontuação não computados ainda para este fato.
                  </div>
                )}
              </div>

              {/* Integrity Validator Rules Checks */}
              <div className="p-6 border-b border-gray-150">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center">
                  <Shield className="h-4 w-4 mr-1 text-emerald-600" /> Relatório de Auditoria (Fact Validator)
                </h3>

                {(() => {
                  const live = runLiveValidation(selectedFact);
                  const isValid = live.errors.length === 0;

                  return (
                    <div className="space-y-3">
                      <div className={`p-3 rounded-lg border flex items-center space-x-2 ${
                        isValid ? "bg-emerald-50 border-emerald-100 text-emerald-800" : "bg-red-50 border-red-100 text-red-800"
                      }`}>
                        {isValid ? <ShieldCheck className="h-5 w-5 flex-shrink-0" /> : <ShieldAlert className="h-5 w-5 flex-shrink-0" />}
                        <span className="text-xs font-semibold">
                          {isValid 
                            ? "Fato em conformidade estrita com todos os critérios de validação e consistência." 
                            : "Este registro possui inconformidades de auditoria ativa!"
                          }
                        </span>
                      </div>

                      {/* Display Warnings / Errors */}
                      {live.errors.map((err, idx) => (
                        <div key={`err-${idx}`} className="p-2.5 bg-red-50/50 border border-red-200/40 text-red-700 rounded-md text-xs flex items-center space-x-1.5">
                          <XCircle className="h-3.5 w-3.5 flex-shrink-0 text-red-600" />
                          <span><strong>Erro impeditivo:</strong> {err}</span>
                        </div>
                      ))}
                      
                      {live.warnings.map((warn, idx) => (
                        <div key={`warn-${idx}`} className="p-2.5 bg-amber-50 border border-amber-200/50 text-amber-700 rounded-md text-xs flex items-center space-x-1.5">
                          <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0 text-amber-500" />
                          <span><strong>Aviso técnico:</strong> {warn}</span>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>

              {/* Base de Evidências (References & Source links) */}
              <div className="p-6 border-b border-gray-150">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center">
                  <FileSpreadsheet className="h-4 w-4 mr-1 text-emerald-600" /> Base de Evidências Mapeada (Comprovação Científica)
                </h3>

                <div className="space-y-3">
                  {selectedFact.evidencias && selectedFact.evidencias.length > 0 ? (
                    selectedFact.evidencias.map((ev, index) => (
                      <div key={index} className="p-3 bg-gray-50 border border-gray-150 rounded-xl hover:shadow-sm transition flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-xs text-gray-900">{ev.fonte}</span>
                            <span className="px-1.5 py-0.5 bg-gray-200 text-gray-600 rounded text-[9px] font-mono font-bold uppercase">{ev.tipo}</span>
                          </div>
                          <p className="text-xs text-gray-600 mt-1">{ev.titulo}</p>
                          {ev.observacoes && <p className="text-[10px] text-gray-400 mt-0.5 italic">{ev.observacoes}</p>}
                        </div>

                        <div className="flex items-center space-x-3 self-end md:self-auto">
                          <div className="text-right">
                            <div className="text-[10px] text-gray-500 font-mono">Atualizado: {ev.data}</div>
                            <div className="text-[10px] text-gray-400">Autor: {ev.autor}</div>
                          </div>
                          <a
                            href={ev.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-white border border-gray-300 rounded hover:bg-gray-100 text-gray-600 transition"
                            title="Acessar Fonte Oficial"
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                          </a>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-4 bg-gray-50 text-center text-xs text-gray-400 border border-dashed rounded-xl">
                      Nenhuma comprovação de URL anexada a este fato técnico. Edite para incluir uma evidência.
                    </div>
                  )}
                </div>
              </div>

              {/* Version History Changelog */}
              <div className="p-6">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center">
                  <History className="h-4 w-4 mr-1 text-emerald-600" /> Histórico de Alterações & Rastreabilidade (Versionamento)
                </h3>

                <div className="space-y-3 relative before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-200">
                  <div className="flex items-start space-x-3 relative">
                    <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-black z-10">
                      {selectedFact.versao || 1}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-900">Versão Atual Ativa (v{selectedFact.versao || 1})</div>
                      <p className="text-[11px] text-gray-500 mt-0.5">Última validação: {new Date(selectedFact.ultima_validacao).toLocaleString()}</p>
                    </div>
                  </div>

                  {selectedFact.historico && selectedFact.historico.length > 0 ? (
                    selectedFact.historico.map((h, idx) => (
                      <div key={idx} className="flex items-start space-x-3 relative">
                        <div className="w-5 h-5 rounded-full bg-gray-300 text-gray-600 flex items-center justify-center text-[10px] font-black z-10">
                          {h.versao}
                        </div>
                        <div className="text-xs">
                          <div className="font-bold text-gray-800">Versão v{h.versao} → Snapshot</div>
                          <p className="text-gray-600 mt-0.5">Alteração: {h.alteracao}</p>
                          <p className="text-[10px] text-gray-400 font-mono mt-0.5">Autor: {h.autor} — Data: {new Date(h.data).toLocaleString()}</p>
                          <div className="mt-1.5 p-2 bg-gray-50 border rounded text-[11px] text-gray-500 font-mono line-clamp-2">
                            "{h.descricao_anterior}"
                          </div>
                        </div>
                      </div>
                    ))
                  ) : null}
                </div>
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-gray-400">
              <Shield className="h-12 w-12 mb-3 stroke-1 text-gray-300" />
              <h3 className="font-bold text-gray-700">Selecione um fato técnico</h3>
              <p className="text-xs max-w-sm mt-1">
                Selecione um fato da lista ao lado para inspecionar, auditar evidências de URLs, aprovar ou editar o versionamento.
              </p>
            </div>
          )}
        </main>
      </div>

      {/* Footer tab detailing active configurations (Rules & Confidence weights) */}
      <footer className="mx-6 mb-6 grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-gray-200">
        {/* Fact Rules list */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center">
            <List className="h-4 w-4 mr-1 text-emerald-600" /> Diretrizes de Integridade de Fatos (fact-rules.json)
          </h3>
          <div className="space-y-3.5 max-h-[220px] overflow-y-auto">
            {rules.map(r => (
              <div key={r.id} className="flex items-start space-x-2.5">
                <div className={`mt-0.5 px-1 py-0.5 rounded text-[9px] font-black uppercase font-mono ${
                  r.obrigatoria ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-600"
                }`}>
                  {r.obrigatoria ? "Mandatória" : "Diretriz"}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-gray-800 leading-none">{r.regra}</h4>
                  <p className="text-[11px] text-gray-500 mt-1 leading-relaxed">{r.descricao}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Confidence weights information table */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm flex flex-col">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center">
            <Info className="h-4 w-4 mr-1 text-emerald-600" /> Pesos da Fórmula de Confiança (confidence-score.json)
          </h3>
          <div className="flex-1 overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b text-[10px] font-bold text-gray-400 uppercase">
                  <th className="pb-1.5 font-bold">Métrica Analisada</th>
                  <th className="pb-1.5 font-bold">Descrição Técnica</th>
                  <th className="pb-1.5 text-right font-bold">Peso</th>
                </tr>
              </thead>
              <tbody className="divide-y text-gray-600">
                <tr>
                  <td className="py-2 font-semibold">Confiabilidade</td>
                  <td className="py-2 text-[11px] text-gray-400">Precisão da fonte primária (DOU / Leis)</td>
                  <td className="py-2 text-right font-mono font-bold">25%</td>
                </tr>
                <tr>
                  <td className="py-2 font-semibold">Quantidade de Fontes</td>
                  <td className="py-2 text-[11px] text-gray-400 font-mono">Número de referências corroborando</td>
                  <td className="py-2 text-right font-mono font-bold">15%</td>
                </tr>
                <tr>
                  <td className="py-2 font-semibold">Atualidade</td>
                  <td className="py-2 text-[11px] text-gray-400">Tempo de publicação e vigência cronológica</td>
                  <td className="py-2 text-right font-mono font-bold">20%</td>
                </tr>
                <tr>
                  <td className="py-2 font-semibold">Autoridade</td>
                  <td className="py-2 text-[11px] text-gray-400">Qualificação (.gov / planalto) da URL</td>
                  <td className="py-2 text-right font-mono font-bold">25%</td>
                </tr>
                <tr>
                  <td className="py-2 font-semibold">Consistência</td>
                  <td className="py-2 text-[11px] text-gray-400">Compatibilidade interna e ausência de divergências</td>
                  <td className="py-2 text-right font-mono font-bold">15%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </footer>
    </div>
  );
}
