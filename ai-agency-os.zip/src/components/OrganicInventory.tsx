import React, { useEffect, useState } from "react";
import { 
  Database, CheckCircle, AlertTriangle, RefreshCw, FileText, 
  HelpCircle, Search, Filter, ShieldAlert, Award, AlertCircle, Link2, 
  Copy, Layers, HelpCircle as FaqIcon, Check, X, FileMinus, ArrowRightLeft, BookOpen, Layers3
} from "lucide-react";

interface InventoryData {
  index: any[];
  health: any[];
  gaps: any[];
  duplicates: any[];
  orphans: any[];
  brokenLinks: any[];
  metadata: {
    totalContents: number;
    totalCategories: number;
    totalTags: number;
    articlesCount: number;
    pagesCount: number;
    videosCount: number;
    ebooksCount: number;
    simuladosCount: number;
    orphansCount: number;
    duplicatesCount: number;
    averageHealthScore: number;
    lastUpdated: string;
    isValid: boolean;
    errors: string[];
  };
}

export function OrganicInventory() {
  const [data, setData] = useState<InventoryData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<'index' | 'health' | 'orphans' | 'duplicates' | 'gaps' | 'broken'>('index');
  const [selectedItemDetail, setSelectedItemDetail] = useState<any | null>(null);

  const fetchInventory = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/organic-os/inventory");
      if (!res.ok) {
        throw new Error(`Failed to load inventory core: status ${res.status}`);
      }
      const json = await res.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to load inventory data");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <RefreshCw className="h-10 w-10 animate-spin text-cyan-400 mb-4" />
        <p className="font-mono text-sm">Scanning Blog & Compiling Live Inventory...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6 bg-red-950/20 border border-red-500/20 rounded-xl text-center my-6">
        <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-3 animate-bounce" />
        <h4 className="text-lg font-bold text-white mb-2">Error Scanning Content Inventory</h4>
        <p className="text-sm text-slate-300 max-w-md mx-auto mb-4">{error || "No inventory returned from backend."}</p>
        <button 
          onClick={fetchInventory}
          className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 border border-red-500/30 rounded-lg text-xs font-semibold font-mono"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const { index, health, gaps, duplicates, orphans, brokenLinks, metadata } = data;

  // Filter logic
  const filteredIndex = index.filter(item => {
    const matchesSearch = item.titulo.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.palavra_chave_principal.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.slug.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === "all" || item.tipo === selectedType;
    const matchesCategory = selectedCategory === "all" || item.categoria === selectedCategory;
    return matchesSearch && matchesType && matchesCategory;
  });

  const uniqueCategories = Array.from(new Set(index.map(i => i.categoria).filter(Boolean))) as string[];
  const uniqueTypes = Array.from(new Set(index.map(i => i.tipo).filter(Boolean))) as string[];

  // Health distribution
  const healthExcelent = health.filter(h => h.scoreGeral >= 85).length;
  const healthGood = health.filter(h => h.scoreGeral >= 70 && h.scoreGeral < 85).length;
  const healthNeedsAttention = health.filter(h => h.scoreGeral >= 50 && h.scoreGeral < 70).length;
  const healthCritical = health.filter(h => h.scoreGeral < 50).length;

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Scan Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 p-5 rounded-xl border border-slate-800/80">
        <div>
          <span className="text-xs font-mono uppercase text-cyan-400 tracking-widest font-semibold">Active Inventory Engine</span>
          <h2 className="text-xl font-bold text-white font-display mt-0.5">Content Audit & Structural Mapping</h2>
          <p className="text-xs text-slate-400 mt-1">Real-time web-crawler simulated scanner analyzing metadata, linkage silos, and duplication ratios.</p>
        </div>
        <div className="flex items-center gap-3 self-start md:self-center">
          <div className="text-right hidden sm:block">
            <span className="text-[10px] font-mono text-slate-500 block">LAST AUTO-SCAN</span>
            <span className="text-xs font-mono text-slate-300 font-semibold">{new Date(metadata.lastUpdated).toLocaleTimeString()}</span>
          </div>
          <button
            onClick={fetchInventory}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-white rounded-lg text-xs font-bold font-mono transition-all shadow-lg shadow-cyan-950/20"
          >
            <RefreshCw className="h-3.5 w-3.5 animate-spin-slow" /> Clear Cache & Re-Scan
          </button>
        </div>
      </div>

      {/* Grid: 8 Bento-Style Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
        
        {/* Metric 1 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Total Items</span>
          <div>
            <h3 className="text-2xl font-extrabold text-white font-mono mt-1">{metadata.totalContents}</h3>
            <span className="text-[9px] font-mono text-slate-500">Indexed URIs</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Articles</span>
          <div>
            <h3 className="text-2xl font-extrabold text-cyan-400 font-mono mt-1">{metadata.articlesCount}</h3>
            <span className="text-[9px] font-mono text-slate-500">Post Layouts</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Static Pages</span>
          <div>
            <h3 className="text-2xl font-extrabold text-white font-mono mt-1">{metadata.pagesCount}</h3>
            <span className="text-[9px] font-mono text-slate-500">Institutional</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Simulados</span>
          <div>
            <h3 className="text-2xl font-extrabold text-white font-mono mt-1">{metadata.simuladosCount}</h3>
            <span className="text-[9px] font-mono text-slate-500">Practice Exams</span>
          </div>
        </div>

        {/* Metric 5 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Orphan Pages</span>
          <div>
            <h3 className={`text-2xl font-extrabold font-mono mt-1 ${metadata.orphansCount > 0 ? "text-amber-400" : "text-slate-400"}`}>{metadata.orphansCount}</h3>
            <span className="text-[9px] font-mono text-slate-500">No incoming links</span>
          </div>
        </div>

        {/* Metric 6 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Duplicates</span>
          <div>
            <h3 className={`text-2xl font-extrabold font-mono mt-1 ${metadata.duplicatesCount > 0 ? "text-red-400" : "text-slate-400"}`}>{metadata.duplicatesCount}</h3>
            <span className="text-[9px] font-mono text-slate-500">Redundant URLs</span>
          </div>
        </div>

        {/* Metric 7 */}
        <div className="bg-[#0f172a] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Categories</span>
          <div>
            <h3 className="text-2xl font-extrabold text-white font-mono mt-1">{metadata.totalCategories}</h3>
            <span className="text-[9px] font-mono text-slate-500">Taxonomies</span>
          </div>
        </div>

        {/* Metric 8 */}
        <div className="bg-gradient-to-br from-[#0c1a2e] to-[#0f172a] border border-cyan-500/20 rounded-xl p-4 flex flex-col justify-between shadow-lg">
          <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider block">Avg Health</span>
          <div>
            <h3 className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">{metadata.averageHealthScore}%</h3>
            <span className="text-[9px] font-mono text-slate-400">Score Rating</span>
          </div>
        </div>

      </div>

      {/* Main Tab Controls & View Switchers */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Audit Sidebar Controls */}
        <div className="bg-[#0f172a] border border-slate-800/80 p-4 rounded-xl h-fit space-y-1">
          <span className="block text-[10px] font-mono uppercase text-slate-500 tracking-wider px-3 mb-2">Audit Sub-engines</span>
          
          <button 
            onClick={() => setActiveTab('index')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeTab === 'index' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <span className="flex items-center gap-2.5">
              <Database className="h-4 w-4" /> 01. Complete Index
            </span>
            <span className="font-mono bg-slate-900 border border-slate-800 text-[10px] px-1.5 py-0.2 rounded text-slate-400">
              {index.length}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('health')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeTab === 'health' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <span className="flex items-center gap-2.5">
              <Award className="h-4 w-4" /> 02. Health & SEO Audit
            </span>
            <span className="font-mono text-[10px] text-emerald-400 bg-emerald-500/5 border border-emerald-500/10 px-1.5 py-0.2 rounded">
              {metadata.averageHealthScore}%
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('orphans')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeTab === 'orphans' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <span className="flex items-center gap-2.5">
              <Link2 className="h-4 w-4" /> 03. Orphan Pages Check
            </span>
            {orphans.length > 0 && (
              <span className="font-mono text-[10px] text-amber-400 bg-amber-500/5 border border-amber-500/10 px-1.5 py-0.2 rounded">
                {orphans.length}
              </span>
            )}
          </button>

          <button 
            onClick={() => setActiveTab('duplicates')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeTab === 'duplicates' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <span className="flex items-center gap-2.5">
              <Copy className="h-4 w-4" /> 04. Duplication Inspector
            </span>
            {duplicates.length > 0 && (
              <span className="font-mono text-[10px] text-red-400 bg-red-500/5 border border-red-500/10 px-1.5 py-0.2 rounded">
                {duplicates.length}
              </span>
            )}
          </button>

          <button 
            onClick={() => setActiveTab('gaps')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeTab === 'gaps' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <span className="flex items-center gap-2.5">
              <Layers3 className="h-4 w-4" /> 05. Content Gaps (Queue)
            </span>
            <span className="font-mono text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-1.5 py-0.2 rounded">
              0
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('broken')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${activeTab === 'broken' ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"}`}
          >
            <span className="flex items-center gap-2.5">
              <ShieldAlert className="h-4 w-4" /> 06. Broken Outbounds
            </span>
            <span className="font-mono text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-1.5 py-0.2 rounded">
              0
            </span>
          </button>
        </div>

        {/* Details Display Panel */}
        <div className="lg:col-span-3 bg-[#0f172a] border border-slate-800/80 rounded-xl p-6 shadow-xl space-y-6">
          
          {/* Active Tab: Index */}
          {activeTab === 'index' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                <div>
                  <h4 className="text-md font-bold text-white">Central Content Master Index</h4>
                  <p className="text-[11px] text-slate-400">All scanned elements on the portal. Filter by taxonomy or content layout format.</p>
                </div>
                <span className="text-[11px] font-mono text-slate-500 uppercase">{filteredIndex.length} visible</span>
              </div>

              {/* Filtering Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Search by title, keyword, slug..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:border-cyan-500/40 focus:outline-none"
                  />
                </div>

                <div>
                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono focus:border-cyan-500/40 focus:outline-none"
                  >
                    <option value="all">All Layout Types</option>
                    {uniqueTypes.map((t, i) => <option key={i} value={t}>{t.toUpperCase()}</option>)}
                  </select>
                </div>

                <div>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono focus:border-cyan-500/40 focus:outline-none"
                  >
                    <option value="all">All Categories</option>
                    {uniqueCategories.map((c, i) => <option key={i} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              {/* Main Index Table */}
              <div className="border border-slate-800/60 rounded-lg overflow-x-auto">
                <table className="w-full text-left border-collapse font-sans">
                  <thead>
                    <tr className="bg-slate-900/80 border-b border-slate-800/80 text-[10px] font-mono text-slate-400 uppercase">
                      <th className="p-3">Title / Core Keyword</th>
                      <th className="p-3">Layout Type</th>
                      <th className="p-3">Category</th>
                      <th className="p-3">Links (In/Out)</th>
                      <th className="p-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-slate-800/60">
                    {filteredIndex.length > 0 ? (
                      filteredIndex.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/30 transition-all">
                          <td className="p-3 max-w-[240px]">
                            <div className="font-bold text-white truncate">{item.titulo}</div>
                            <div className="text-[10px] text-cyan-400 font-mono mt-0.5 truncate">
                              🔑 {item.palavra_chave_principal || "None"}
                            </div>
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-slate-900 border border-slate-800 text-[10px] font-mono rounded text-slate-300 uppercase">
                              {item.tipo}
                            </span>
                          </td>
                          <td className="p-3 text-slate-300">{item.categoria}</td>
                          <td className="p-3 font-mono text-[10px] text-slate-400">
                            In: <span className="text-cyan-400">{item.links_internos?.length || 0}</span> / Out: <span className="text-amber-400">{item.links_externos?.length || 0}</span>
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => setSelectedItemDetail(item)}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-[10px] font-mono"
                            >
                              Details
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="p-6 text-center text-slate-500 font-mono">
                          No indexed content matches your current query.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Active Tab: Health & SEO Audit */}
          {activeTab === 'health' && (
            <div className="space-y-6">
              <div className="border-b border-slate-800/80 pb-3">
                <h4 className="text-md font-bold text-white">Automated Health and On-Page SEO Audit</h4>
                <p className="text-[11px] text-slate-400">Scoring breakdown evaluating meta tags layout lengths, keyword relevance and content volume.</p>
              </div>

              {/* Health categories summary boxes */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs">
                <div className="bg-[#0b0f19] p-3 rounded-lg border border-emerald-500/20">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Excelente (90+)</span>
                  <h5 className="text-lg font-bold text-white mt-1 font-mono">{healthExcelent}</h5>
                </div>
                <div className="bg-[#0b0f19] p-3 rounded-lg border border-cyan-500/20">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold">Bom (70-89)</span>
                  <h5 className="text-lg font-bold text-white mt-1 font-mono">{healthGood}</h5>
                </div>
                <div className="bg-[#0b0f19] p-3 rounded-lg border border-amber-500/20">
                  <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">Atenção (50-69)</span>
                  <h5 className="text-lg font-bold text-white mt-1 font-mono">{healthNeedsAttention}</h5>
                </div>
                <div className="bg-[#0b0f19] p-3 rounded-lg border border-red-500/20">
                  <span className="text-[10px] font-mono text-red-400 uppercase font-bold">Crítico (&lt;50)</span>
                  <h5 className="text-lg font-bold text-white mt-1 font-mono">{healthCritical}</h5>
                </div>
              </div>

              {/* Detailed health scores list */}
              <div className="space-y-3">
                {health.map((item, idx) => (
                  <div key={idx} className="bg-[#0b0f19] border border-slate-800 p-4 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                          item.status === "Excelente" ? "bg-emerald-500/10 text-emerald-400" :
                          item.status === "Bom" ? "bg-cyan-500/10 text-cyan-400" :
                          item.status === "Precisa de Atenção" ? "bg-amber-500/10 text-amber-400" :
                          "bg-red-500/10 text-red-400"
                        }`}>
                          {item.status}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">Recency: {item.atualizacao}</span>
                      </div>
                      <h5 className="font-bold text-white text-xs">{item.titulo}</h5>
                      <span className="text-[10px] font-mono text-slate-400 block truncate max-w-md">{item.url}</span>
                    </div>

                    <div className="flex items-center gap-6 shrink-0">
                      <div className="text-center">
                        <span className="text-[9px] font-mono text-slate-500 uppercase block">SEO Score</span>
                        <span className="text-sm font-bold text-cyan-400 font-mono">{item.seoScore}/100</span>
                      </div>
                      <div className="text-center">
                        <span className="text-[9px] font-mono text-slate-500 uppercase block">Quality</span>
                        <span className="text-sm font-bold text-white font-mono">{item.qualidade}/100</span>
                      </div>
                      <div className="text-center pr-2 border-r border-slate-800">
                        <span className="text-[9px] font-mono text-slate-500 uppercase block">Structure</span>
                        <span className="text-sm font-bold text-white font-mono">{item.estrutura}/100</span>
                      </div>
                      <div className="text-center">
                        <span className="text-[9px] font-mono text-slate-500 uppercase block">Overall Score</span>
                        <span className="text-lg font-extrabold text-emerald-400 font-mono">{item.scoreGeral}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Active Tab: Orphan Pages */}
          {activeTab === 'orphans' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800/80 pb-3 flex justify-between items-center">
                <div>
                  <h4 className="text-md font-bold text-white">Orphan Pages Audit</h4>
                  <p className="text-[11px] text-slate-400">Pages with zero inbound internal links. These URLs are isolated from crawlers.</p>
                </div>
                <span className="text-xs font-mono bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2.5 py-1 rounded">
                  {orphans.length} Isolated
                </span>
              </div>

              {orphans.length > 0 ? (
                <div className="space-y-3.5">
                  <div className="bg-amber-950/20 border border-amber-500/20 p-4 rounded-lg text-xs leading-relaxed text-slate-300 flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-semibold">SEO Action Required:</strong>
                      Orphan pages receive zero internal page rank flow. They are difficult for Googlebot to discover and rank efficiently. Ensure you link to these URLs from relevant articles or the master navigation categories.
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {orphans.map((orph, i) => (
                      <div key={i} className="p-4 bg-[#0b0f19] border border-slate-800 rounded-lg flex flex-col justify-between">
                        <div>
                          <span className="text-[9px] font-mono text-amber-400 bg-amber-500/5 px-2 py-0.5 rounded uppercase">
                            {orph.categoria}
                          </span>
                          <h5 className="font-bold text-white text-xs mt-2">{orph.titulo}</h5>
                          <p className="text-[10px] font-mono text-slate-500 mt-1 truncate">{orph.url}</p>
                        </div>
                        <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-between items-center text-[10px] font-mono text-slate-400">
                          <span>id: {orph.id}</span>
                          <span className="text-red-400 uppercase font-semibold">● Orphaned</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-10 text-center bg-slate-900/20 rounded-xl border border-slate-800/60 text-slate-400 font-mono">
                  <CheckCircle className="h-10 w-10 text-emerald-400 mx-auto mb-3" />
                  No orphan pages detected on PassaCumaru. Every URI has incoming internal link flow.
                </div>
              )}
            </div>
          )}

          {/* Active Tab: Duplication Inspector */}
          {activeTab === 'duplicates' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800/80 pb-3 flex justify-between items-center">
                <div>
                  <h4 className="text-md font-bold text-white">Keyword & Slug Duplication Inspector</h4>
                  <p className="text-[11px] text-slate-400">Cross-referencing indices to catch articles competing for identical primary search keys.</p>
                </div>
                <span className="text-xs font-mono bg-red-500/10 border border-red-500/20 text-red-400 px-2.5 py-1 rounded">
                  {duplicates.length} Conflicted
                </span>
              </div>

              {duplicates.length > 0 ? (
                <div className="space-y-3">
                  <div className="bg-red-950/20 border border-red-500/20 p-4 rounded-lg text-xs leading-relaxed text-slate-300 flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block font-semibold">Keyword Cannibalization Alert:</strong>
                      Multiple files share identical slugs or target primary focus keywords. This leads to duplicate content penalties and internal organic competition. Recommend merging or setting proper canonical parameters.
                    </div>
                  </div>

                  {duplicates.map((dup, i) => (
                    <div key={i} className="p-4 bg-[#0b0f19] border border-slate-800/80 rounded-lg space-y-3">
                      <div className="flex items-center justify-between text-[10px] font-mono border-b border-slate-800 pb-2">
                        <span className="text-red-400 uppercase font-bold bg-red-500/10 px-2 py-0.5 rounded">
                          Conflict: {dup.conflito}
                        </span>
                        <span className="text-slate-400">Conflict Value: "{dup.valor_conflito}"</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80 text-xs">
                          <span className="text-[9px] font-mono text-cyan-400 uppercase block font-semibold">Document A (Original)</span>
                          <h6 className="font-bold text-white mt-1 truncate">{dup.titulo_A}</h6>
                          <span className="text-[10px] font-mono text-slate-500">id: {dup.id_A}</span>
                        </div>
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80 text-xs">
                          <span className="text-[9px] font-mono text-red-400 uppercase block font-semibold">Document B (Conflicted)</span>
                          <h6 className="font-bold text-white mt-1 truncate">{dup.titulo_B}</h6>
                          <span className="text-[10px] font-mono text-slate-500">id: {dup.id_B}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-10 text-center bg-slate-900/20 rounded-xl border border-slate-800/60 text-slate-400 font-mono">
                  <CheckCircle className="h-10 w-10 text-emerald-400 mx-auto mb-3" />
                  Duplication check successful. No keyword or slug redundancies located.
                </div>
              )}
            </div>
          )}

          {/* Active Tab: Content Gaps */}
          {activeTab === 'gaps' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800/80 pb-3">
                <h4 className="text-md font-bold text-white">Sprint 04 Sneak-Peek: Content Gaps Queue</h4>
                <p className="text-[11px] text-slate-400">List of high-priority traffic-winning topic suggestions missing from current indices.</p>
              </div>

              <div className="p-10 text-center bg-[#0b0f19] rounded-xl border border-dashed border-slate-800 text-slate-400 font-mono text-xs">
                <Layers className="h-10 w-10 text-slate-600 mx-auto mb-3" />
                No content gaps mapped in database yet.<br />
                <span className="text-[10px] text-slate-500 mt-1 block">This registry schema is empty and ready to be populated during keyword research Sprints.</span>
              </div>
            </div>
          )}

          {/* Active Tab: Broken Links */}
          {activeTab === 'broken' && (
            <div className="space-y-4">
              <div className="border-b border-slate-800/80 pb-3">
                <h4 className="text-md font-bold text-white">Broken Links and Redirection Auditing</h4>
                <p className="text-[11px] text-slate-400">Continuous check scanning external outbounds and checking response headers.</p>
              </div>

              <div className="p-10 text-center bg-[#0b0f19] rounded-xl border border-dashed border-slate-800 text-slate-400 font-mono text-xs">
                <Link2 className="h-10 w-10 text-slate-600 mx-auto mb-3" />
                No broken links reported.<br />
                <span className="text-[10px] text-slate-500 mt-1 block">Database schema is ready. Response header checks will run on active rendering cycles.</span>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Item Detail Modal/Drawer Overlay */}
      {selectedItemDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto shadow-2xl p-6 relative space-y-6">
            
            {/* Close Button */}
            <button 
              onClick={() => setSelectedItemDetail(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white bg-slate-800 p-1.5 rounded-lg text-xs"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Modal Header */}
            <div className="border-b border-slate-800 pb-3 pr-8">
              <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded uppercase font-semibold">
                {selectedItemDetail.tipo}
              </span>
              <h3 className="text-lg font-bold text-white font-display mt-2">{selectedItemDetail.titulo}</h3>
              <p className="text-[11px] text-slate-400 font-mono truncate mt-1">URI: {selectedItemDetail.url}</p>
            </div>

            {/* Details Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans text-slate-300">
              
              <div>
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Slug</span>
                <span className="text-white mt-0.5 block font-mono bg-slate-950 p-1 rounded border border-slate-800">{selectedItemDetail.slug}</span>
              </div>
              <div>
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Primary Focus Keyword</span>
                <span className="text-cyan-400 mt-0.5 block font-mono bg-slate-950 p-1 rounded border border-slate-800 font-bold">🔑 {selectedItemDetail.palavra_chave_principal || "None"}</span>
              </div>
              <div>
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Category</span>
                <span className="text-white mt-0.5 block">{selectedItemDetail.categoria}</span>
              </div>
              <div>
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Author</span>
                <span className="text-white mt-0.5 block">{selectedItemDetail.autor}</span>
              </div>
              <div>
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Publication Date</span>
                <span className="text-white mt-0.5 block font-mono">{new Date(selectedItemDetail.data_publicacao).toLocaleDateString()}</span>
              </div>
              <div>
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Last Updated</span>
                <span className="text-white mt-0.5 block font-mono">{new Date(selectedItemDetail.ultima_atualizacao).toLocaleDateString()}</span>
              </div>
              <div className="md:col-span-2">
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Secondary Target Keywords</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {selectedItemDetail.palavras_secundarias?.map((tag: string, i: number) => (
                    <span key={i} className="px-2 py-0.5 bg-[#0b0f19] border border-slate-800 rounded font-mono text-[10px] text-slate-300">
                      {tag}
                    </span>
                  )) || <span className="text-slate-600 font-mono">None</span>}
                </div>
              </div>
              <div className="md:col-span-2">
                <span className="text-slate-500 font-mono text-[9px] block uppercase">Internal Links Linked Out To</span>
                <ul className="list-disc list-inside space-y-0.5 font-mono text-[10px] text-slate-400 mt-1 max-h-[80px] overflow-y-auto bg-slate-950 p-2 rounded border border-slate-800">
                  {selectedItemDetail.links_internos?.map((link: string, i: number) => (
                    <li key={i} className="truncate">{link}</li>
                  )) || <li>None</li>}
                </ul>
              </div>
            </div>

            {/* Footer metadata */}
            <div className="border-t border-slate-800 pt-4 flex flex-wrap gap-4 text-[10px] font-mono text-slate-500 justify-between items-center">
              <div>
                Words: <span className="text-white font-bold">{selectedItemDetail.quantidade_palavras}</span> | Images: <span className="text-white font-bold">{selectedItemDetail.quantidade_imagens}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">FAQ: {selectedItemDetail.possui_FAQ ? <Check className="h-3 w-3 text-emerald-400" /> : <X className="h-3 w-3 text-red-400" />}</span>
                <span className="flex items-center gap-1">Schema: {selectedItemDetail.possui_schema ? <Check className="h-3 w-3 text-emerald-400" /> : <X className="h-3 w-3 text-red-400" />}</span>
                <span className="flex items-center gap-1">CTA: {selectedItemDetail.possui_CTA ? <Check className="h-3 w-3 text-emerald-400" /> : <X className="h-3 w-3 text-red-400" />}</span>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
