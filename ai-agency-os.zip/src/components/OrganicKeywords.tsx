import React, { useState, useEffect } from "react";
import { 
  Key, Target, Layers, FileQuestion, Sparkles, TrendingUp, AlertCircle, 
  CheckCircle2, PlusCircle, Search, HelpCircle, Sliders, ArrowUpRight, 
  Settings, Award, Clock, FileText, Plus, Database, RefreshCw, Bookmark,
  ExternalLink, BarChart2, Globe, ShieldAlert, Zap
} from "lucide-react";

// Front-end Interfaces matching JSON schemas
interface Keyword {
  id: string;
  keyword: string;
  idioma: string;
  categoria: string;
  cluster: string;
  entidade: string;
  status: string;
  intencao?: string;
  observacoes?: string;
  prioridade?: {
    impacto: number;
    esforco: number;
    potencial: number;
    urgencia: number;
    competicao: number;
    valorEstrategico: number;
    pontuacaoFinal: number;
  };
  longtails?: any[];
  questions?: any[];
}

interface Cluster {
  id: string;
  nome: string;
  descrição: string;
  categoria: string;
  palavraPrincipal: string;
  palavrasSecundárias: string[];
  objetivo: string;
  status: string;
  keywordCount?: number;
}

interface Entity {
  id: string;
  nome: string;
  categoria: string;
  aliases: string[];
  descricao: string;
  keywordCount?: number;
}

interface Question {
  id: string;
  keywordId?: string;
  keywordText?: string;
  pergunta: string;
  categoria: string;
  respostaSugestao: string;
}

interface Longtail {
  id: string;
  keywordId: string;
  keyword: string;
  volumeEstimado: number;
  dificuldade: number;
}

interface Opportunity {
  id: string;
  tema: string;
  prioridade: string;
  cluster: string;
  motivo: string;
  potencial: string;
  status: string;
}

interface KeywordsDashboardData {
  keywords: Keyword[];
  intents: any[];
  priorities: any[];
  clusters: Cluster[];
  entities: Entity[];
  questions: Question[];
  longtails: Longtail[];
  opportunities: Opportunity[];
  metadata: {
    totalKeywords: number;
    totalClusters: number;
    totalEntities: number;
    totalQuestions: number;
    totalLongtails: number;
    totalOpportunities: number;
    intentDistribution: Record<string, number>;
    statusCounts: Record<string, number>;
    priorityAverages: {
      impacto: number;
      esforco: number;
      potencial: number;
      urgencia: number;
      competicao: number;
      valorEstrategico: number;
      pontuacaoFinal: number;
    };
    entityCategoryCounts: Record<string, number>;
    validation: {
      isValid: boolean;
      errors: string[];
      warnings: string[];
    };
    lastUpdated: string;
  };
}

export function OrganicKeywords() {
  const [data, setData] = useState<KeywordsDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<"dashboard" | "keywords" | "clusters" | "entities" | "questions" | "opportunities" | "alimentar">("dashboard");

  // Filters
  const [keywordSearch, setKeywordSearch] = useState("");
  const [filterCluster, setFilterCluster] = useState("");
  const [filterIntent, setFilterIntent] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  // Modals / Form States
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // 1. Form: New Keyword
  const [newKeyword, setNewKeyword] = useState({
    keyword: "",
    idioma: "pt-BR",
    categoria: "Inscrições",
    cluster: "Concurso Passa e Fica",
    entidade: "Prefeitura de Passa e Fica",
    status: "mapeado",
    intencao: "Informacional",
    observacoes: "",
    impacto: 5,
    esforco: 3,
    potencial: 5,
    urgencia: 5,
    competicao: 5,
    valorEstrategico: 5
  });

  // 2. Form: New Cluster
  const [newCluster, setNewCluster] = useState({
    nome: "",
    descrição: "",
    categoria: "Inscrições",
    palavraPrincipal: "",
    palavrasSecundáriasRaw: "",
    objetivo: "",
    status: "ativo"
  });

  // 3. Form: New Entity
  const [newEntity, setNewEntity] = useState({
    nome: "",
    categoria: "Prefeituras",
    aliasesRaw: "",
    descricao: ""
  });

  // 4. Form: New Question
  const [newQuestion, setNewQuestion] = useState({
    keywordId: "",
    pergunta: "",
    categoria: "Inscrições",
    respostaSugestao: ""
  });

  // 5. Form: New Opportunity
  const [newOpportunity, setNewOpportunity] = useState({
    tema: "",
    prioridade: "Média",
    cluster: "Concurso Passa e Fica",
    motivo: "",
    potencial: "Médio",
    status: "Planejado"
  });

  // 6. Form: New Longtail
  const [newLongtail, setNewLongtail] = useState({
    keywordId: "",
    keyword: "",
    volumeEstimado: 200,
    dificuldade: 10
  });

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/organic-os/keywords");
      if (!response.ok) {
        throw new Error("Falha ao obter os dados do motor de palavras-chave");
      }
      const json = await response.json();
      setData(json);
    } catch (err: any) {
      setError(err.message || "Erro desconhecido ao carregar dados.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const clearSuccess = () => {
    setTimeout(() => {
      setSuccessMessage(null);
    }, 4000);
  };

  // Form Submission Handlers
  const handleAddKeyword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyword.keyword.trim()) return;

    setSubmitting(true);
    try {
      const payload = {
        keyword: {
          keyword: newKeyword.keyword,
          idioma: newKeyword.idioma,
          categoria: newKeyword.categoria,
          cluster: newKeyword.cluster,
          entidade: newKeyword.entidade,
          status: newKeyword.status
        },
        intent: {
          intencao: newKeyword.intencao,
          observacoes: newKeyword.observacoes
        },
        priority: {
          impacto: Number(newKeyword.impacto),
          esforco: Number(newKeyword.esforco),
          potencial: Number(newKeyword.potencial),
          urgencia: Number(newKeyword.urgencia),
          competicao: Number(newKeyword.competicao),
          valorEstrategico: Number(newKeyword.valorEstrategico)
        }
      };

      const res = await fetch("/api/organic-os/keywords", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error("Erro de servidor ao registrar palavra-chave");

      setSuccessMessage(`Palavra-chave "${newKeyword.keyword}" cadastrada e priorizada com sucesso!`);
      setNewKeyword({
        keyword: "",
        idioma: "pt-BR",
        categoria: "Inscrições",
        cluster: data?.clusters[0]?.nome || "Concurso Passa e Fica",
        entidade: data?.entities[0]?.nome || "Prefeitura de Passa e Fica",
        status: "mapeado",
        intencao: "Informacional",
        observacoes: "",
        impacto: 5,
        esforco: 3,
        potencial: 5,
        urgencia: 5,
        competicao: 5,
        valorEstrategico: 5
      });
      await fetchData();
      clearSuccess();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddCluster = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCluster.nome.trim() || !newCluster.palavraPrincipal.trim()) return;

    setSubmitting(true);
    try {
      const payload = {
        nome: newCluster.nome,
        descrição: newCluster.descrição,
        categoria: newCluster.categoria,
        palavraPrincipal: newCluster.palavraPrincipal,
        palavrasSecundárias: newCluster.palavrasSecundáriasRaw
          .split(",")
          .map(s => s.trim())
          .filter(Boolean),
        objetivo: newCluster.objetivo,
        status: newCluster.status
      };

      const res = await fetch("/api/organic-os/clusters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error("Erro ao salvar cluster no servidor");

      setSuccessMessage(`Tópico Cluster "${newCluster.nome}" criado estrategicamente.`);
      setNewCluster({
        nome: "",
        descrição: "",
        categoria: "Inscrições",
        palavraPrincipal: "",
        palavrasSecundáriasRaw: "",
        objetivo: "",
        status: "ativo"
      });
      await fetchData();
      clearSuccess();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddEntity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEntity.nome.trim()) return;

    setSubmitting(true);
    try {
      const payload = {
        nome: newEntity.nome,
        categoria: newEntity.categoria,
        aliases: newEntity.aliasesRaw.split(",").map(s => s.trim()).filter(Boolean),
        descricao: newEntity.descricao
      };

      const res = await fetch("/api/organic-os/entities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error("Erro ao salvar entidade no servidor");

      setSuccessMessage(`Entidade SEO "${newEntity.nome}" registrada.`);
      setNewEntity({
        nome: "",
        categoria: "Prefeituras",
        aliasesRaw: "",
        descricao: ""
      });
      await fetchData();
      clearSuccess();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestion.pergunta.trim()) return;

    setSubmitting(true);
    try {
      const payload = {
        keywordId: newQuestion.keywordId || undefined,
        pergunta: newQuestion.pergunta,
        categoria: newQuestion.categoria,
        respostaSugestao: newQuestion.respostaSugestao
      };

      const res = await fetch("/api/organic-os/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error("Erro ao salvar pergunta no servidor");

      setSuccessMessage(`Pergunta real de usuários salva com sucesso.`);
      setNewQuestion({
        keywordId: "",
        pergunta: "",
        categoria: "Inscrições",
        respostaSugestao: ""
      });
      await fetchData();
      clearSuccess();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddOpportunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOpportunity.tema.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/organic-os/opportunities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newOpportunity)
      });

      if (!res.ok) throw new Error("Erro ao registrar oportunidade no servidor");

      setSuccessMessage(`Nova pauta editorial urgente registrada em pautas de oportunidade.`);
      setNewOpportunity({
        tema: "",
        prioridade: "Média",
        cluster: "Concurso Passa e Fica",
        motivo: "",
        potencial: "Médio",
        status: "Planejado"
      });
      await fetchData();
      clearSuccess();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddLongtail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLongtail.keywordId || !newLongtail.keyword.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/organic-os/longtails", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newLongtail)
      });

      if (!res.ok) throw new Error("Erro ao registrar cauda longa");

      setSuccessMessage(`Variação cauda longa para micro-nicho adicionada.`);
      setNewLongtail({
        keywordId: "",
        keyword: "",
        volumeEstimado: 200,
        dificuldade: 10
      });
      await fetchData();
      clearSuccess();
    } catch (err: any) {
      alert(`Erro: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // Filtering processed keywords lists
  const filteredKeywords = data ? data.keywords.filter(kw => {
    const matchesSearch = kw.keyword.toLowerCase().includes(keywordSearch.toLowerCase()) ||
                          kw.categoria.toLowerCase().includes(keywordSearch.toLowerCase());
    const matchesCluster = !filterCluster || kw.cluster === filterCluster;
    const matchesStatus = !filterStatus || kw.status === filterStatus;

    // Fetch intent
    const itemIntent = data.intents.find(i => i.keywordId === kw.id);
    const matchesIntent = !filterIntent || (itemIntent && itemIntent.intencao === filterIntent);

    return matchesSearch && matchesCluster && matchesStatus && matchesIntent;
  }) : [];

  if (loading) {
    return (
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-12 shadow-xl flex flex-col items-center justify-center text-slate-300">
        <RefreshCw className="h-10 w-10 text-cyan-400 animate-spin mb-4" />
        <p className="font-mono text-sm">Carregando Motor de Inteligência de Palavras-chave...</p>
        <p className="text-xs text-slate-500 mt-1">Carregando clusters, entidades e priorizações de PassaCumaru</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-[#0f172a] border border-red-900 rounded-xl p-8 shadow-xl text-center">
        <ShieldAlert className="h-12 w-12 text-rose-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-white mb-2">Falha crítica ao inicializar módulo de keywords</h3>
        <p className="text-slate-400 text-sm mb-4">{error || "Estrutura de dados não encontrada."}</p>
        <button 
          onClick={fetchData} 
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-lg text-sm transition-all"
        >
          Tentar Reinstanciar Conexão
        </button>
      </div>
    );
  }

  const { metadata } = data;
  const validation = metadata.validation;

  return (
    <div className="space-y-6">
      {/* Header and Sync Indicators */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 text-[10px] tracking-wider font-mono font-bold uppercase rounded bg-cyan-950/80 border border-cyan-800/50 text-cyan-400 flex items-center gap-1">
              <Zap className="h-3 w-3 fill-cyan-400" /> SPRINT 06 ATIVA
            </span>
            <span className="text-slate-500 text-xs font-mono">• Versão 1.0 (Local Engine)</span>
          </div>
          <h2 className="text-2xl font-display font-bold text-slate-100 flex items-center gap-2.5">
            <Key className="h-6 w-6 text-cyan-400" />
            Keyword Intelligence Engine
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Motor avançado para modelar e estruturar o ecossistema tático de busca orgânica da Região Agreste do RN do blog <strong className="text-cyan-300/90 font-medium">PassaCumaru</strong>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button 
            onClick={fetchData}
            className="p-2.5 bg-slate-850 hover:bg-slate-800 border border-slate-700/50 rounded-xl text-slate-300 hover:text-white transition-all flex items-center gap-2 text-xs font-mono"
            title="Sincronizar dados locais"
          >
            <RefreshCw className="h-4 w-4" /> Sincronizar
          </button>
          
          <div className={`px-4 py-2.5 rounded-xl border flex items-center gap-2 ${
            validation.isValid 
              ? "bg-emerald-950/20 border-emerald-800/60 text-emerald-400" 
              : "bg-amber-950/20 border-amber-800/60 text-amber-400"
          }`}>
            {validation.isValid ? (
              <>
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-400" />
                <div className="text-left">
                  <div className="text-[11px] font-bold uppercase tracking-wider leading-none">Status JSON</div>
                  <div className="text-[10px] text-slate-400 leading-none mt-0.5">Assinatura Inteira</div>
                </div>
              </>
            ) : (
              <>
                <AlertCircle className="h-4.5 w-4.5 text-amber-400" />
                <div className="text-left">
                  <div className="text-[11px] font-bold uppercase tracking-wider leading-none">Erros de Validação</div>
                  <div className="text-[10px] text-slate-400 leading-none mt-0.5">{validation.errors.length} problemas</div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Database Validation Alerter */}
      {!validation.isValid && (
        <div className="bg-amber-950/15 border border-amber-900/50 rounded-xl p-4 text-sm text-amber-300 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-amber-400 mt-0.5 shrink-0" />
          <div>
            <span className="font-bold">Aviso do Validador de Consistência (Keyword Validator):</span>
            <ul className="list-disc pl-5 mt-1 space-y-0.5 text-xs text-slate-400">
              {validation.errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Success Banner */}
      {successMessage && (
        <div className="bg-emerald-950/40 border border-emerald-800 rounded-xl p-4 text-sm text-emerald-300 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="h-5 w-5 text-emerald-400" />
          <span className="font-medium">{successMessage}</span>
        </div>
      )}

      {/* Core KPIs Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-[#1e293b]/40 border border-slate-800/75 rounded-2xl p-4 shadow-lg text-left">
          <div className="text-slate-400 text-xs font-mono uppercase tracking-wider flex items-center justify-between">
            Keywords
            <Key className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-extrabold text-white mt-1.5">{metadata.totalKeywords}</div>
          <p className="text-[11px] text-slate-500 mt-1">
            Mapeadas: {metadata.statusCounts.mapeado || 0} | Pub: {metadata.statusCounts.publicado || 0}
          </p>
        </div>

        <div className="bg-[#1e293b]/40 border border-slate-800/75 rounded-2xl p-4 shadow-lg text-left">
          <div className="text-slate-400 text-xs font-mono uppercase tracking-wider flex items-center justify-between">
            Clusters
            <Layers className="h-4 w-4 text-indigo-400" />
          </div>
          <div className="text-3xl font-extrabold text-white mt-1.5">{metadata.totalClusters}</div>
          <p className="text-[11px] text-slate-500 mt-1">Eixos semânticos mapeados</p>
        </div>

        <div className="bg-[#1e293b]/40 border border-slate-800/75 rounded-2xl p-4 shadow-lg text-left">
          <div className="text-slate-400 text-xs font-mono uppercase tracking-wider flex items-center justify-between">
            Entidades
            <Award className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-extrabold text-white mt-1.5">{metadata.totalEntities}</div>
          <p className="text-[11px] text-slate-500 mt-1">
            Prefeituras: {metadata.entityCategoryCounts.Prefeituras || 0} | Bancas: {metadata.entityCategoryCounts.Bancas || 0}
          </p>
        </div>

        <div className="bg-[#1e293b]/40 border border-slate-800/75 rounded-2xl p-4 shadow-lg text-left">
          <div className="text-slate-400 text-xs font-mono uppercase tracking-wider flex items-center justify-between">
            Perguntas
            <FileQuestion className="h-4 w-4 text-amber-400" />
          </div>
          <div className="text-3xl font-extrabold text-white mt-1.5">{metadata.totalQuestions}</div>
          <p className="text-[11px] text-slate-500 mt-1">Dúvidas reais catalogadas</p>
        </div>

        <div className="bg-[#1e293b]/40 border border-slate-800/75 rounded-2xl p-4 shadow-lg text-left">
          <div className="text-slate-400 text-xs font-mono uppercase tracking-wider flex items-center justify-between">
            Cauda Longa
            <TrendingUp className="h-4 w-4 text-rose-400" />
          </div>
          <div className="text-3xl font-extrabold text-white mt-1.5">{metadata.totalLongtails}</div>
          <p className="text-[11px] text-slate-500 mt-1">Segmentações de nicho</p>
        </div>

        <div className="bg-[#1e293b]/40 border border-slate-800/75 rounded-2xl p-4 shadow-lg text-left">
          <div className="text-slate-400 text-xs font-mono uppercase tracking-wider flex items-center justify-between">
            Oportunidades
            <Sparkles className="h-4 w-4 text-yellow-400 animate-pulse" />
          </div>
          <div className="text-3xl font-extrabold text-white mt-1.5">{metadata.totalOpportunities}</div>
          <p className="text-[11px] text-slate-500 mt-1">Pautas de alta conversão</p>
        </div>
      </div>

      {/* Sub-Navigation Buttons */}
      <div className="flex flex-wrap items-center border-b border-slate-800 gap-1 bg-slate-950/25 p-1 rounded-xl">
        <button 
          onClick={() => setActiveSubTab("dashboard")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 ${
            activeSubTab === "dashboard" ? "bg-slate-850 text-cyan-400 border border-slate-700/50" : "text-slate-400 hover:text-slate-300 hover:bg-slate-900/40"
          }`}
        >
          <BarChart2 className="h-3.5 w-3.5" /> Dashboard Geral
        </button>
        <button 
          onClick={() => setActiveSubTab("keywords")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 ${
            activeSubTab === "keywords" ? "bg-slate-850 text-cyan-400 border border-slate-700/50" : "text-slate-400 hover:text-slate-300 hover:bg-slate-900/40"
          }`}
        >
          <Key className="h-3.5 w-3.5" /> Banco de Keywords
        </button>
        <button 
          onClick={() => setActiveSubTab("clusters")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 ${
            activeSubTab === "clusters" ? "bg-slate-850 text-cyan-400 border border-slate-700/50" : "text-slate-400 hover:text-slate-300 hover:bg-slate-900/40"
          }`}
        >
          <Layers className="h-3.5 w-3.5" /> Tópico Clusters
        </button>
        <button 
          onClick={() => setActiveSubTab("entities")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 ${
            activeSubTab === "entities" ? "bg-slate-850 text-cyan-400 border border-slate-700/50" : "text-slate-400 hover:text-slate-300 hover:bg-slate-900/40"
          }`}
        >
          <Award className="h-3.5 w-3.5" /> Entidades SEO
        </button>
        <button 
          onClick={() => setActiveSubTab("questions")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 ${
            activeSubTab === "questions" ? "bg-slate-850 text-cyan-400 border border-slate-700/50" : "text-slate-400 hover:text-slate-300 hover:bg-slate-900/40"
          }`}
        >
          <FileQuestion className="h-3.5 w-3.5" /> Perguntas & Longtails
        </button>
        <button 
          onClick={() => setActiveSubTab("opportunities")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 ${
            activeSubTab === "opportunities" ? "bg-slate-850 text-cyan-400 border border-slate-700/50" : "text-slate-400 hover:text-slate-300 hover:bg-slate-900/40"
          }`}
        >
          <Sparkles className="h-3.5 w-3.5" /> Oportunidades Latentes
        </button>
        <button 
          onClick={() => setActiveSubTab("alimentar")}
          className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all flex items-center gap-1.5 bg-cyan-950/20 text-cyan-400 hover:bg-cyan-950/40 ml-auto border border-cyan-800/40`}
        >
          <Plus className="h-3.5 w-3.5" /> Registrar Inteligência
        </button>
      </div>

      {/* SUB-TAB 1: DASHBOARD GERAL */}
      {activeSubTab === "dashboard" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main distribution charts / summary */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl">
              <h3 className="text-base font-display font-bold text-slate-100 mb-4 flex items-center gap-2">
                <Sliders className="h-5 w-5 text-cyan-400" />
                Matriz de Intenção de Busca Ativa
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3.5">
                  {Object.entries(metadata.intentDistribution).map(([intent, count]) => {
                    const countNum = Number(count);
                    const percentage = Math.round((countNum / (metadata.totalKeywords || 1)) * 100);
                    let barColor = "bg-cyan-500";
                    if (intent === "Local") barColor = "bg-emerald-500";
                    if (intent === "Transacional") barColor = "bg-rose-500";
                    if (intent === "Comercial") barColor = "bg-indigo-500";
                    if (intent === "Educacional") barColor = "bg-amber-500";
                    if (intent === "Navegacional") barColor = "bg-slate-500";

                    return (
                      <div key={intent}>
                        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                          <span className="font-medium text-slate-300">{intent}</span>
                          <span>{countNum} {countNum === 1 ? 'keyword' : 'keywords'} ({percentage}%)</span>
                        </div>
                        <div className="h-2 bg-slate-850 rounded-full overflow-hidden">
                          <div className={`h-full ${barColor}`} style={{ width: `${percentage}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                <div className="bg-slate-900/40 border border-slate-800 p-4 rounded-xl flex flex-col justify-between text-left">
                  <div>
                    <span className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider block mb-1">Entendimento Editorial</span>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      A intenção predominante no ecossistema orienta a criação de conteúdo. Pesquisas <strong className="text-slate-300">Educacionais</strong> exigem resumos minuciosos, enquanto as <strong className="text-slate-300">Transacionais</strong> necessitam de links rápidos de inscrição e cronogramas fáceis de ler.
                    </p>
                  </div>
                  <div className="border-t border-slate-800 pt-3 mt-4 text-[11px] text-slate-500 font-mono">
                    Atualizado em: {new Date(metadata.lastUpdated).toLocaleDateString("pt-BR")}
                  </div>
                </div>
              </div>
            </div>

            {/* Strategic Value Matrix Averages */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl">
              <h3 className="text-base font-display font-bold text-slate-100 mb-4 flex items-center gap-2">
                <BarChart2 className="h-5 w-5 text-cyan-400" />
                Métricas Médias de Priorização (Keyword Priorities)
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                {[
                  { label: "Impacto", val: metadata.priorityAverages.impacto, color: "text-emerald-400" },
                  { label: "Esforço", val: metadata.priorityAverages.esforco, color: "text-amber-400" },
                  { label: "Potencial", val: metadata.priorityAverages.potencial, color: "text-cyan-400" },
                  { label: "Urgência", val: metadata.priorityAverages.urgencia, color: "text-rose-400" },
                  { label: "Competição", val: metadata.priorityAverages.competicao, color: "text-slate-400" },
                  { label: "Valor Est.", val: metadata.priorityAverages.valorEstrategico, color: "text-indigo-400" },
                  { label: "Prioridade G.", val: metadata.priorityAverages.pontuacaoFinal, color: "text-yellow-400" },
                ].map((m, i) => (
                  <div key={i} className="bg-slate-900/50 border border-slate-800/80 p-3.5 rounded-xl text-center">
                    <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wider leading-none mb-1.5">{m.label}</div>
                    <div className={`text-xl font-extrabold ${m.color}`}>{m.val} <span className="text-xs text-slate-600">/10</span></div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar Roadmap & Strategic Intent */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-indigo-950/25 to-[#0f172a] border border-indigo-900/45 rounded-2xl p-6 shadow-xl text-left">
              <h3 className="text-sm font-mono font-bold text-indigo-300 uppercase tracking-widest mb-3.5 flex items-center gap-1.5">
                <Sparkles className="h-4.5 w-4.5 text-indigo-400 animate-pulse" />
                Integrações Ativas em Planejamento
              </h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                Este motor manual foi planejado para ser conectado a coletores autônomos nas próximas Sprints:
              </p>
              
              <div className="space-y-3.5">
                {[
                  { title: "Google Search Console", desc: "Varredura automática das queries que imprimem o PassaCumaru" },
                  { title: "Google Trends Breakout Alerts", desc: "Alerta o painel quando um concurso local tem pico de interesse" },
                  { title: "People Also Ask & Autocomplete", desc: "Raspador que extrai dúvidas dinâmicas do Google em tempo real" },
                  { title: "Agente de Triagem Social (AI)", desc: "Crawler de subreddits de concursos, canais do YouTube e fóruns locais" }
                ].map((item, i) => (
                  <div key={i} className="flex gap-2.5 items-start">
                    <div className="h-5 w-5 bg-indigo-900/40 rounded border border-indigo-800/60 text-indigo-400 text-xs font-mono font-bold flex items-center justify-center shrink-0">
                      {i + 1}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-200">{item.title}</h4>
                      <p className="text-[10px] text-slate-500 mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Entity SEO category map list */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-5 shadow-xl">
              <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center justify-between">
                Tipos de Entidades Mapeadas
                <Award className="h-4 w-4 text-cyan-400" />
              </h3>
              <div className="space-y-2">
                {Object.entries(metadata.entityCategoryCounts).map(([cat, count]) => (
                  <div key={cat} className="flex items-center justify-between text-xs bg-slate-900/30 border border-slate-850 px-3 py-2 rounded-lg">
                    <span className="text-slate-300 font-medium">{cat}</span>
                    <span className="px-2 py-0.5 bg-slate-850 text-cyan-400 font-mono font-bold text-[10px] rounded border border-slate-750">
                      {count} {count === 1 ? 'entidade' : 'entidades'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: BANCO DE KEYWORDS */}
      {activeSubTab === "keywords" && (
        <div className="space-y-4">
          {/* Filtering Controls */}
          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input 
                type="text" 
                placeholder="Buscar palavra-chave ou categoria..." 
                value={keywordSearch}
                onChange={(e) => setKeywordSearch(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-1.5 pl-9 pr-3 text-xs text-slate-300 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <select 
                value={filterCluster}
                onChange={(e) => setFilterCluster(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-400 focus:outline-none focus:border-cyan-500"
              >
                <option value="">Filtrar por Cluster (Todos)</option>
                {data.clusters.map(cl => (
                  <option key={cl.id} value={cl.nome}>{cl.nome}</option>
                ))}
              </select>
            </div>

            <div>
              <select 
                value={filterIntent}
                onChange={(e) => setFilterIntent(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-400 focus:outline-none focus:border-cyan-500"
              >
                <option value="">Filtrar por Intenção (Todas)</option>
                <option value="Informacional">Informacional</option>
                <option value="Comercial">Comercial</option>
                <option value="Transacional">Transacional</option>
                <option value="Local">Local</option>
                <option value="Navegacional">Navegacional</option>
                <option value="Educacional">Educacional</option>
              </select>
            </div>

            <div>
              <select 
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-400 focus:outline-none focus:border-cyan-500"
              >
                <option value="">Filtrar por Status (Todos)</option>
                <option value="mapeado">Mapeado</option>
                <option value="planejado">Planejado</option>
                <option value="em_andamento">Em Andamento</option>
                <option value="publicado">Publicado</option>
              </select>
            </div>
          </div>

          {/* Keywords Table */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-2xl overflow-hidden shadow-xl text-left">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/20">
              <h3 className="text-sm font-display font-bold text-slate-100 flex items-center gap-2">
                <Database className="h-4.5 w-4.5 text-cyan-400" />
                Dicionário de Termos Priorizados ({filteredKeywords.length} registros)
              </h3>
              <span className="text-[10px] font-mono text-slate-500">Ordenados por ID tático</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800/60 bg-slate-950/20 text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-5">Termo / Palavra-chave</th>
                    <th className="py-3 px-4">Cluster Semântico</th>
                    <th className="py-3 px-4">Entidade Relacionada</th>
                    <th className="py-3 px-4">Intenção</th>
                    <th className="py-3 px-4 text-center">Score tático</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 text-xs">
                  {filteredKeywords.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500 font-mono">
                        Nenhuma palavra-chave encontrada para os filtros atuais.
                      </td>
                    </tr>
                  ) : (
                    filteredKeywords.map((kw) => {
                      // Find intent and priority associated
                      const intentObj = data.intents.find(i => i.keywordId === kw.id);
                      const priorityObj = data.priorities.find(p => p.keywordId === kw.id);

                      // Badges
                      let intentBadgeColor = "text-slate-400 bg-slate-900 border-slate-850";
                      if (intentObj?.intencao === "Informacional") intentBadgeColor = "text-cyan-400 bg-cyan-950/40 border-cyan-900/50";
                      if (intentObj?.intencao === "Transacional") intentBadgeColor = "text-rose-400 bg-rose-950/40 border-rose-900/50";
                      if (intentObj?.intencao === "Educacional") intentBadgeColor = "text-amber-400 bg-amber-950/40 border-amber-900/50";
                      if (intentObj?.intencao === "Local") intentBadgeColor = "text-emerald-400 bg-emerald-950/40 border-emerald-900/50";

                      let statusBadgeColor = "text-slate-400 bg-slate-900/50 border-slate-800";
                      if (kw.status === "publicado") statusBadgeColor = "text-emerald-400 bg-emerald-950/20 border-emerald-900/50";
                      if (kw.status === "em_andamento") statusBadgeColor = "text-yellow-400 bg-yellow-950/20 border-yellow-900/50";
                      if (kw.status === "planejado") statusBadgeColor = "text-indigo-400 bg-indigo-950/20 border-indigo-900/50";

                      return (
                        <tr key={kw.id} className="hover:bg-slate-900/20 transition-all">
                          <td className="py-3.5 px-5 font-medium text-slate-200">
                            <div>{kw.keyword}</div>
                            <div className="text-[10px] text-slate-500 mt-0.5 font-mono">{kw.id} | categoria: {kw.categoria}</div>
                          </td>
                          <td className="py-3.5 px-4 text-slate-300">
                            <span className="flex items-center gap-1.5">
                              <Layers className="h-3 w-3 text-indigo-400" />
                              {kw.cluster}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-400">{kw.entidade}</td>
                          <td className="py-3.5 px-4">
                            <span className={`px-2 py-0.5 text-[10px] font-mono font-medium rounded-md border ${intentBadgeColor}`}>
                              {intentObj ? intentObj.intencao : "Não definida"}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            {priorityObj ? (
                              <div className="inline-block px-2.5 py-0.5 rounded-lg bg-yellow-950/20 border border-yellow-900/45 font-mono font-bold text-yellow-400 text-xs">
                                {priorityObj.pontuacaoFinal} <span className="text-[9px] text-yellow-600 font-normal">/10</span>
                              </div>
                            ) : (
                              <span className="text-slate-600 font-mono">-</span>
                            )}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`px-2 py-0.5 text-[10px] font-mono rounded border capitalize ${statusBadgeColor}`}>
                              {kw.status.replace("_", " ")}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: TÓPICO CLUSTERS */}
      {activeSubTab === "clusters" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          {data.clusters.map((cl) => {
            const clusterKeywords = data.keywords.filter(k => k.cluster === cl.nome);
            return (
              <div key={cl.id} className="bg-[#0f172a] border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/50 border border-cyan-900/60 px-2 py-0.5 rounded">
                      {cl.categoria}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      cl.status === "ativo" ? "bg-emerald-950/50 border border-emerald-900/50 text-emerald-400" : "bg-slate-900 text-slate-500"
                    }`}>
                      {cl.status}
                    </span>
                  </div>
                  
                  <h4 className="text-base font-display font-bold text-white flex items-center gap-1.5">
                    <Layers className="h-4.5 w-4.5 text-indigo-400" />
                    {cl.nome}
                  </h4>
                  
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed">
                    {cl.descrição}
                  </p>

                  <div className="mt-4 bg-slate-950/40 border border-slate-850 p-3 rounded-lg space-y-2">
                    <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Palavra Principal:</div>
                    <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Key className="h-3 w-3 text-yellow-400" />
                      {cl.palavraPrincipal}
                    </div>
                  </div>

                  {cl.palavrasSecundárias && cl.palavrasSecundárias.length > 0 && (
                    <div className="mt-4 space-y-1.5">
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Secundárias Mapeadas:</div>
                      <div className="flex flex-wrap gap-1.5">
                        {cl.palavrasSecundárias.map((sec, idx) => (
                          <span key={idx} className="bg-slate-900 border border-slate-800 text-slate-400 px-2 py-0.5 rounded text-[10px] font-mono">
                            {sec}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="border-t border-slate-850 pt-4 mt-5 flex items-center justify-between text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Database className="h-3.5 w-3.5 text-slate-600" />
                    Keywords Associadas:
                  </span>
                  <span className="font-bold text-cyan-400 font-mono">{clusterKeywords.length}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SUB-TAB 4: ENTIDADES SEO */}
      {activeSubTab === "entities" && (
        <div className="space-y-4 text-left">
          <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-base font-display font-bold text-slate-100 mb-2 flex items-center gap-2">
              <Award className="h-5 w-5 text-cyan-400" />
              Mapeamento de Entidades Locais do Concurso
            </h3>
            <p className="text-xs text-slate-400 mb-6">
              Registrar prefeituras, bancas de concurso e municípios em nosso ecossistema de dados ajuda o motor a conectar sinônimos, gerar clusters regionais e alimentar o grafo de conhecimento semântico.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data.entities.map((ent) => {
                const entityKeywords = data.keywords.filter(k => k.entidade === ent.nome);
                return (
                  <div key={ent.id} className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-900/50 px-2 py-0.5 rounded">
                          {ent.categoria}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">{ent.id}</span>
                      </div>
                      
                      <h4 className="text-sm font-bold text-white">{ent.nome}</h4>
                      <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{ent.descricao}</p>

                      {ent.aliases && ent.aliases.length > 0 && (
                        <div className="mt-3">
                          <span className="text-[10px] font-mono text-slate-500 block mb-1">Sinônimos / Aliases:</span>
                          <div className="flex flex-wrap gap-1">
                            {ent.aliases.map((al, idx) => (
                              <span key={idx} className="px-1.5 py-0.5 bg-slate-950 border border-slate-850 text-slate-400 rounded text-[9px] font-mono">
                                {al}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="border-t border-slate-800 pt-3 mt-4 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Associações Ativas:</span>
                      <span className="text-emerald-400 font-bold">{entityKeywords.length}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 5: PERGUNTAS & LONGTAILS */}
      {activeSubTab === "questions" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-left">
          {/* Mapped Questions list */}
          <div className="lg:col-span-2 bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-base font-display font-bold text-slate-100 mb-2 flex items-center gap-2">
              <FileQuestion className="h-5 w-5 text-amber-400" />
              Perguntas Reais Monitoradas (People Also Ask)
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Identificar as dúvidas diretas dos usuários é a base para o preenchimento de FAQs estruturadas de alto valor estratégico.
            </p>

            <div className="space-y-4">
              {data.questions.map((q) => (
                <div key={q.id} className="bg-slate-900/40 border border-slate-800 p-4 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 bg-amber-950/20 border border-amber-900/40 text-amber-400 font-mono text-[9px] font-bold uppercase rounded">
                      {q.categoria}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{q.id}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100 flex items-start gap-1.5">
                    <HelpCircle className="h-4.5 w-4.5 text-cyan-400 shrink-0 mt-0.5" />
                    {q.pergunta}
                  </h4>
                  <p className="text-xs text-slate-400 bg-slate-950/40 p-2.5 rounded border border-slate-850/80 leading-relaxed pl-3.5 border-l-2 border-l-cyan-500">
                    <strong className="text-cyan-400/90 font-mono block text-[9px] uppercase mb-1">Diretriz da Resposta / Schema FAQ:</strong>
                    {q.respostaSugestao}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Longtail keywords variations sidebar */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            <div>
              <h3 className="text-base font-display font-bold text-slate-100 mb-1 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-rose-400" />
                Variações de Cauda Longa
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Palavras de cauda longa possuem menor volume individual, mas concorrência ínfima, excelente para indexação ultra-rápida.
              </p>
            </div>

            <div className="space-y-3">
              {data.longtails.map((lt) => {
                // Determine difficulty color
                let diffColor = "text-emerald-400 bg-emerald-950/30 border-emerald-900/45";
                if (lt.dificuldade > 20) diffColor = "text-amber-400 bg-amber-950/30 border-amber-900/45";
                if (lt.dificuldade > 50) diffColor = "text-rose-400 bg-rose-950/30 border-rose-900/45";

                return (
                  <div key={lt.id} className="bg-slate-900/40 border border-slate-800/80 p-3.5 rounded-xl text-left space-y-2">
                    <div className="text-xs font-bold text-slate-200">{lt.keyword}</div>
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-slate-500">Buscas estimadas:</span>
                      <span className="text-slate-300 font-bold">{lt.volumeEstimado} /mês</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-slate-500">Dificuldade SEO:</span>
                      <span className={`px-1.5 py-0.5 rounded border ${diffColor} font-bold`}>{lt.dificuldade} /100</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 6: OPORTUNIDADES LATENTES */}
      {activeSubTab === "opportunities" && (
        <div className="space-y-4 text-left">
          <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-base font-display font-bold text-slate-100 mb-2 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-yellow-400" />
              Oportunidades Editoriais de Alta Conversão Detectadas
            </h3>
            <p className="text-xs text-slate-400 mb-6">
              Mapeamento estratégico de brechas deixadas pelas grandes mídias nacionais, com foco em priorização rápida de pautas urgentes.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {data.opportunities.map((op) => {
                let prioColor = "text-slate-400 bg-slate-900 border-slate-850";
                if (op.prioridade === "Crítica") prioColor = "text-rose-400 bg-rose-950/50 border-rose-900/80 font-bold";
                if (op.prioridade === "Alta") prioColor = "text-amber-400 bg-amber-950/50 border-amber-900/80 font-bold";
                if (op.prioridade === "Média" || op.prioridade === "Media") prioColor = "text-cyan-400 bg-cyan-950/50 border-cyan-900/80";

                return (
                  <div key={op.id} className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-5 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-3.5">
                        <span className={`px-2 py-0.5 text-[9px] font-mono rounded-md border uppercase tracking-wider ${prioColor}`}>
                          Prioridade: {op.prioridade}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">{op.id}</span>
                      </div>

                      <h4 className="text-sm font-bold text-white mb-2 leading-snug">{op.tema}</h4>
                      
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mt-3">Cluster:</div>
                      <span className="inline-flex items-center gap-1 text-xs text-indigo-400 font-medium mt-0.5">
                        <Layers className="h-3.5 w-3.5" /> {op.cluster}
                      </span>

                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mt-3">Motivação tática:</div>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed bg-slate-950/30 p-2.5 rounded border border-slate-850">
                        {op.motivo}
                      </p>
                    </div>

                    <div className="border-t border-slate-850 pt-3.5 mt-4 flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-500">Potencial Orgânico:</span>
                      <span className="text-yellow-400 font-bold">{op.potencial}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 7: ALIMENTAR INTELIGÊNCIA (MANUAL REGISTRY) */}
      {activeSubTab === "alimentar" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-left">
          {/* Form 1: Add Keyword (Fully priorized metrics) */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-display font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
              <PlusCircle className="h-5 w-5 text-cyan-400" />
              Nova Keyword com Modelo de Priorização Real
            </h3>

            <form onSubmit={handleAddKeyword} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Palavra-chave</label>
                  <input 
                    type="text" 
                    placeholder="Ex: concurso passa e fica rn vagas"
                    value={newKeyword.keyword}
                    onChange={(e) => setNewKeyword({...newKeyword, keyword: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Status Inicial</label>
                  <select 
                    value={newKeyword.status}
                    onChange={(e) => setNewKeyword({...newKeyword, status: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="mapeado">Mapeado</option>
                    <option value="planejado">Planejado</option>
                    <option value="em_andamento">Em Andamento</option>
                    <option value="publicado">Publicado</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Cluster Semântico</label>
                  <select 
                    value={newKeyword.cluster}
                    onChange={(e) => setNewKeyword({...newKeyword, cluster: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-cyan-500"
                  >
                    {data.clusters.map(cl => (
                      <option key={cl.id} value={cl.nome}>{cl.nome}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Entidade Mapeada</label>
                  <select 
                    value={newKeyword.entidade}
                    onChange={(e) => setNewKeyword({...newKeyword, entidade: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-cyan-500"
                  >
                    {data.entities.map(ent => (
                      <option key={ent.id} value={ent.nome}>{ent.nome}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-850 pt-3">
                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Classificar Intenção</label>
                  <select 
                    value={newKeyword.intencao}
                    onChange={(e) => setNewKeyword({...newKeyword, intencao: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Informacional">Informacional</option>
                    <option value="Comercial">Comercial</option>
                    <option value="Transacional">Transacional</option>
                    <option value="Local">Local</option>
                    <option value="Navegacional">Navegacional</option>
                    <option value="Educacional">Educacional</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Comportamento de Busca</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Candidatos buscando as vagas de nível médio."
                    value={newKeyword.observacoes}
                    onChange={(e) => setNewKeyword({...newKeyword, observacoes: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Slider priorities block */}
              <div className="bg-slate-900/60 border border-slate-850 p-4 rounded-xl space-y-3.5 border-t border-slate-850 pt-3">
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">Mapeamento de Pontuações Estratégicas (1 a 10)</span>
                
                <div className="grid grid-cols-2 gap-x-4 gap-y-2.5 text-xs">
                  {[
                    { key: "impacto", label: "Impacto estimado no tráfego" },
                    { key: "esforco", label: "Esforço / Tempo de redação" },
                    { key: "potencial", label: "Potencial de conversão" },
                    { key: "urgencia", label: "Urgência (ex: edital vazando)" },
                    { key: "competicao", label: "Concorrência de Domínios" },
                    { key: "valorEstrategico", label: "Alinhamento de Marca/Nicho" },
                  ].map((sl) => (
                    <div key={sl.key}>
                      <div className="flex items-center justify-between mb-1 font-mono text-[10px]">
                        <span className="text-slate-400">{sl.label}:</span>
                        <span className="text-cyan-400 font-bold">{(newKeyword as any)[sl.key]}</span>
                      </div>
                      <input 
                        type="range" 
                        min="1" 
                        max="10"
                        value={(newKeyword as any)[sl.key]}
                        onChange={(e) => setNewKeyword({...newKeyword, [sl.key]: Number(e.target.value)})}
                        className="w-full accent-cyan-400"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <button 
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg transition-all flex items-center justify-center gap-2 border border-cyan-500 shadow-lg disabled:opacity-50"
              >
                {submitting ? "Salvando..." : "Salvar Palavra-chave e Priorizar"}
              </button>
            </form>
          </div>

          {/* Form 2: Add Cluster */}
          <div className="space-y-6">
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h3 className="text-base font-display font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
                <PlusCircle className="h-5 w-5 text-indigo-400" />
                Criar Novo Tópico Cluster
              </h3>

              <form onSubmit={handleAddCluster} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Nome do Cluster</label>
                    <input 
                      type="text" 
                      placeholder="Ex: Concurso Nova Cruz"
                      value={newCluster.nome}
                      onChange={(e) => setNewCluster({...newCluster, nome: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Categoria Estratégica</label>
                    <select 
                      value={newCluster.categoria}
                      onChange={(e) => setNewCluster({...newCluster, categoria: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Inscrições">Inscrições</option>
                      <option value="Gabarito">Gabarito</option>
                      <option value="Estudo de Leis">Estudo de Leis</option>
                      <option value="Salários">Salários</option>
                      <option value="Convocação">Convocação</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Palavra-chave Principal do Tópico</label>
                  <input 
                    type="text" 
                    placeholder="Ex: concurso nova cruz rn 2026"
                    value={newCluster.palavraPrincipal}
                    onChange={(e) => setNewCluster({...newCluster, palavraPrincipal: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Termos Secundários Relacionados (Separados por vírgula)</label>
                  <input 
                    type="text" 
                    placeholder="Ex: edital nova cruz pdf, vagas nova cruz rn, prova anterior"
                    value={newCluster.palavrasSecundáriasRaw}
                    onChange={(e) => setNewCluster({...newCluster, palavrasSecundáriasRaw: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Descrição do Cluster</label>
                  <textarea 
                    rows={2}
                    placeholder="Defina o escopo do cluster..."
                    value={newCluster.descrição}
                    onChange={(e) => setNewCluster({...newCluster, descrição: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Objetivo Editorial</label>
                    <input 
                      type="text" 
                      placeholder="Ex: Dominar tráfego regional de Nova Cruz"
                      value={newCluster.objetivo}
                      onChange={(e) => setNewCluster({...newCluster, objetivo: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Status Inicial</label>
                    <select 
                      value={newCluster.status}
                      onChange={(e) => setNewCluster({...newCluster, status: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="ativo">Ativo</option>
                      <option value="planejado">Planejado</option>
                      <option value="pausado">Pausado</option>
                    </select>
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all border border-indigo-500 disabled:opacity-50"
                >
                  {submitting ? "Criando..." : "Salvar Cluster Semântico"}
                </button>
              </form>
            </div>

            {/* Quick Entity Creation Form */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h3 className="text-base font-display font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
                <PlusCircle className="h-5 w-5 text-emerald-400" />
                Registrar Entidade SEO Local
              </h3>

              <form onSubmit={handleAddEntity} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Nome da Entidade</label>
                    <input 
                      type="text" 
                      placeholder="Ex: Banca FUNCERN"
                      value={newEntity.nome}
                      onChange={(e) => setNewEntity({...newEntity, nome: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Categoria</label>
                    <select 
                      value={newEntity.categoria}
                      onChange={(e) => setNewEntity({...newEntity, categoria: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="Prefeituras">Prefeituras</option>
                      <option value="Bancas">Bancas</option>
                      <option value="Cidades">Cidades</option>
                      <option value="Estados">Estados</option>
                      <option value="Leis">Leis</option>
                      <option value="Órgãos">Órgãos</option>
                      <option value="Disciplinas">Disciplinas</option>
                      <option value="Concursos">Concursos</option>
                      <option value="Instituições">Instituições</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Sinônimos / Aliases (Separados por vírgula)</label>
                  <input 
                    type="text" 
                    placeholder="Ex: FUNCERN, Fundacao de Apoio ao IFRN"
                    value={newEntity.aliasesRaw}
                    onChange={(e) => setNewEntity({...newEntity, aliasesRaw: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Descrição / Definição de Conhecimento</label>
                  <textarea 
                    rows={2}
                    placeholder="Uma pequena descrição para orientar resumos sintáticos..."
                    value={newEntity.descricao}
                    onChange={(e) => setNewEntity({...newEntity, descricao: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-all border border-emerald-500 disabled:opacity-50"
                >
                  {submitting ? "Cadastrando..." : "Salvar Entidade SEO"}
                </button>
              </form>
            </div>

            {/* Form: Add Questions */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h3 className="text-base font-display font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
                <PlusCircle className="h-5 w-5 text-amber-400" />
                Registrar Pergunta do Usuário (FAQ)
              </h3>

              <form onSubmit={handleAddQuestion} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Relacionar à Palavra-chave</label>
                  <select 
                    value={newQuestion.keywordId}
                    onChange={(e) => setNewQuestion({...newQuestion, keywordId: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-amber-500"
                  >
                    <option value="">Nenhuma (Pergunta Solta)</option>
                    {data.keywords.map(kw => (
                      <option key={kw.id} value={kw.id}>{kw.keyword}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Pergunta Real</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Qual o salário de assistente administrativo?"
                    value={newQuestion.pergunta}
                    onChange={(e) => setNewQuestion({...newQuestion, pergunta: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Categoria</label>
                    <select 
                      value={newQuestion.categoria}
                      onChange={(e) => setNewQuestion({...newQuestion, categoria: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-amber-500"
                    >
                      <option value="Inscrições">Inscrições</option>
                      <option value="Gabarito">Gabarito</option>
                      <option value="Estudo de Leis">Estudo de Leis</option>
                      <option value="Salários">Salários</option>
                      <option value="Convocação">Convocação</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Diretriz de Resposta Sugerida</label>
                    <input 
                      type="text" 
                      placeholder="Ex: O vencimento básico inicial é de R$ 2.450,00 acrescido de gratificação..."
                      value={newQuestion.respostaSugestao}
                      onChange={(e) => setNewQuestion({...newQuestion, respostaSugestao: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg transition-all border border-amber-500 disabled:opacity-50"
                >
                  {submitting ? "Registrando..." : "Salvar Pergunta FAQ"}
                </button>
              </form>
            </div>

            {/* Form: Add Opportunity */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h3 className="text-base font-display font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
                <PlusCircle className="h-5 w-5 text-rose-400" />
                Registrar Pauta / Oportunidade Crítica
              </h3>

              <form onSubmit={handleAddOpportunity} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Tema Recomendado / Título de Pauta</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Estatuto dos Servidores Públicos de Passa e Fica Comentado"
                    value={newOpportunity.tema}
                    onChange={(e) => setNewOpportunity({...newOpportunity, tema: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Prioridade</label>
                    <select 
                      value={newOpportunity.prioridade}
                      onChange={(e) => setNewOpportunity({...newOpportunity, prioridade: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-rose-500"
                    >
                      <option value="Média">Média</option>
                      <option value="Alta">Alta</option>
                      <option value="Crítica">Crítica</option>
                      <option value="Baixa">Baixa</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Cluster Semântico</label>
                    <select 
                      value={newOpportunity.cluster}
                      onChange={(e) => setNewOpportunity({...newOpportunity, cluster: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-rose-500"
                    >
                      {data.clusters.map(cl => (
                        <option key={cl.id} value={cl.nome}>{cl.nome}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Motivação Tática da Pauta</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Concorrentes não cobrem o estatuto regional e há buscas mensais crescentes."
                    value={newOpportunity.motivo}
                    onChange={(e) => setNewOpportunity({...newOpportunity, motivo: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Potencial de Conversão</label>
                    <select 
                      value={newOpportunity.potencial}
                      onChange={(e) => setNewOpportunity({...newOpportunity, potencial: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-rose-500"
                    >
                      <option value="Médio">Médio</option>
                      <option value="Alto">Alto</option>
                      <option value="Explosivo">Explosivo</option>
                      <option value="Baixo">Baixo</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Status Inicial da Pauta</label>
                    <select 
                      value={newOpportunity.status}
                      onChange={(e) => setNewOpportunity({...newOpportunity, status: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-rose-500"
                    >
                      <option value="Planejado">Planejado</option>
                      <option value="Em andamento">Em andamento</option>
                      <option value="Publicado">Publicado</option>
                    </select>
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg transition-all border border-rose-500 disabled:opacity-50"
                >
                  {submitting ? "Gravando..." : "Salvar Oportunidade Pauta"}
                </button>
              </form>
            </div>

            {/* Form: Add Longtails */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h3 className="text-base font-display font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
                <PlusCircle className="h-5 w-5 text-indigo-400" />
                Registrar Variação Cauda Longa (Micro Nicho)
              </h3>

              <form onSubmit={handleAddLongtail} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Palavra-chave Base / Pai</label>
                  <select 
                    value={newLongtail.keywordId}
                    onChange={(e) => setNewLongtail({...newLongtail, keywordId: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-400 focus:outline-none focus:border-indigo-500"
                    required
                  >
                    <option value="">Selecione a keyword pai...</option>
                    {data.keywords.map(kw => (
                      <option key={kw.id} value={kw.id}>{kw.keyword}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Termo Cauda Longa</label>
                  <input 
                    type="text" 
                    placeholder="Ex: edital concurso de passa e fica rn vagas motorista"
                    value={newLongtail.keyword}
                    onChange={(e) => setNewLongtail({...newLongtail, keyword: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Volume Mensal Estimado</label>
                    <input 
                      type="number" 
                      value={newLongtail.volumeEstimado}
                      onChange={(e) => setNewLongtail({...newLongtail, volumeEstimado: Number(e.target.value)})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-mono mb-1.5 uppercase tracking-wider">Dificuldade Estimada (1 a 100)</label>
                    <input 
                      type="number" 
                      min="1"
                      max="100"
                      value={newLongtail.dificuldade}
                      onChange={(e) => setNewLongtail({...newLongtail, dificuldade: Number(e.target.value)})}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-slate-300 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all border border-indigo-500 disabled:opacity-50"
                >
                  {submitting ? "Gravando..." : "Salvar Keyword Cauda Longa"}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
