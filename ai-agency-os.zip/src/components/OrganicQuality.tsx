import React, { useState, useEffect } from "react";
import {
  Shield,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RotateCw,
  Eye,
  FileText,
  TrendingUp,
  TrendingDown,
  ExternalLink,
  BookOpen,
  Check,
  ChevronDown,
  ChevronUp,
  Sliders,
  Scale,
  Settings,
  HelpCircle
} from "lucide-react";

interface QualityScores {
  clareza: number;
  organizacao: number;
  cobertura_do_tema: number;
  aderencia_ao_brief: number;
  aderencia_ao_blueprint: number;
  uso_correto_dos_fatos: number;
  uso_correto_das_fontes: number;
  coerencia_narrativa: number;
  utilidade_para_o_leitor: number;
}

interface RuleEvaluation {
  ruleId: string;
  nome: string;
  pass: boolean;
  feedback: string;
  severidade: string;
}

interface QualityReport {
  id: string;
  draft_id: string;
  score_geral: number;
  status: "Aprovado" | "Reprovado" | "Pendente";
  observacoes: string;
  recomendacoes: string[];
  scores: QualityScores;
  regras_avaliadas: RuleEvaluation[];
  data: string;
}

interface DraftRecord {
  id: string;
  brief_id: string;
  blueprint_id: string;
  research_pack_id: string;
  strategy_id: string;
  titulo: string;
  autor: string;
  data_criacao: string;
  versao: number;
}

export function OrganicQuality() {
  const [reports, setReports] = useState<QualityReport[]>([]);
  const [drafts, setDrafts] = useState<DraftRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [selectedReport, setSelectedReport] = useState<QualityReport | null>(null);
  const [compareReportA, setCompareReportA] = useState<string>("");
  const [compareReportB, setCompareReportB] = useState<string>("");
  const [compareResult, setCompareResult] = useState<any | null>(null);
  const [showCompare, setShowCompare] = useState<boolean>(false);
  const [revisionNote, setRevisionNote] = useState<string>("");
  const [showRevisionModal, setShowRevisionModal] = useState<boolean>(false);
  const [activeReportForRevision, setActiveReportForRevision] = useState<string | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    try {
      const resReports = await fetch("/api/organic-os/quality/reports");
      const dataReports = await resReports.json();
      setReports(dataReports || []);

      const resDrafts = await fetch("/api/organic-os/drafts");
      const dataDrafts = await resDrafts.json();
      setDrafts(dataDrafts || []);

      if (dataReports && dataReports.length > 0) {
        setSelectedReport(dataReports[0]);
      }
    } catch (e) {
      console.error("Erro ao carregar dados do painel de qualidade:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleStartReview = async (draftId: string) => {
    setReviewingId(draftId);
    try {
      const res = await fetch("/api/organic-os/quality/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ draftId })
      });
      const data = await res.json();
      if (data.success && data.report) {
        // Refresh
        const updatedReports = [data.report, ...reports.filter(r => r.id !== data.report.id)];
        setReports(updatedReports);
        setSelectedReport(data.report);
      }
    } catch (err) {
      console.error("Erro ao revisar rascunho:", err);
    } finally {
      setReviewingId(null);
    }
  };

  const handleApprove = async (reportId: string) => {
    try {
      const res = await fetch(`/api/organic-os/quality/reports/${reportId}/approve`, {
        method: "POST"
      });
      const data = await res.json();
      if (data.success && data.report) {
        const updated = reports.map(r => r.id === reportId ? data.report : r);
        setReports(updated);
        setSelectedReport(data.report);
      }
    } catch (e) {
      console.error("Erro ao aprovar rascunho:", e);
    }
  };

  const handleOpenRevisionModal = (reportId: string) => {
    setActiveReportForRevision(reportId);
    setRevisionNote("");
    setShowRevisionModal(true);
  };

  const handleRequestRevision = async () => {
    if (!activeReportForRevision) return;
    try {
      const res = await fetch(`/api/organic-os/quality/reports/${activeReportForRevision}/request-revision`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ guidance: revisionNote })
      });
      const data = await res.json();
      if (data.success && data.report) {
        const updated = reports.map(r => r.id === activeReportForRevision ? data.report : r);
        setReports(updated);
        setSelectedReport(data.report);
        setShowRevisionModal(false);
      }
    } catch (e) {
      console.error("Erro ao solicitar revisão:", e);
    }
  };

  const handleCompare = async () => {
    if (!compareReportA || !compareReportB) return;
    try {
      const res = await fetch("/api/organic-os/quality/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ report1Id: compareReportA, report2Id: compareReportB })
      });
      const data = await res.json();
      setCompareResult(data);
    } catch (e) {
      console.error("Erro ao comparar relatórios:", e);
    }
  };

  // Aggregated indicators
  const averageScore = reports.length > 0
    ? Math.round(reports.reduce((sum, r) => sum + r.score_geral, 0) / reports.length)
    : 0;

  const approvedCount = reports.filter(r => r.status === "Aprovado").length;
  const rejectedCount = reports.filter(r => r.status === "Reprovado").length;

  return (
    <div className="space-y-6" id="quality-review-panel">
      {/* Upper header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl">
        <div>
          <h2 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Shield className="h-6 w-6 text-cyan-400" />
            Sprint 19 — Content Quality Review Engine V1
          </h2>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Agente editorial sênior programado para avaliar criticamente a qualidade do texto, aderência do briefing, consistência factual e conformidade estrutural.
          </p>
        </div>
        <button
          onClick={fetchInitialData}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-cyan-400 hover:text-cyan-300 bg-cyan-950/20 border border-cyan-500/30 rounded-lg hover:bg-cyan-950/40 transition-all self-start md:self-center"
        >
          <RotateCw className="h-4 w-4" />
          Sincronizar Bancos
        </button>
      </div>

      {/* Grid: Indicators and Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Metric 1 */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <span className="text-xs font-mono uppercase text-slate-400">Score Médio Geral</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-display font-bold text-white">{averageScore}</span>
            <span className="text-sm text-slate-500">/ 100</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-cyan-500 transition-all duration-500"
              style={{ width: `${averageScore}%` }}
            />
          </div>
          <span className="text-[10px] text-slate-500 mt-2">Média ponderada ponderando as 9 dimensões</span>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <span className="text-xs font-mono uppercase text-slate-400">Aprovados para Otimização</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-display font-bold text-emerald-400">{approvedCount}</span>
            <span className="text-sm text-slate-500">artigos</span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-[10px] text-emerald-400 font-medium">
            <CheckCircle className="h-3.5 w-3.5" /> Estabilidade de qualidade garantida
          </div>
          <span className="text-[10px] text-slate-500 mt-2">Rascunhos que superaram as metas editoriais</span>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <span className="text-xs font-mono uppercase text-slate-400">Retidos / Em Revisão</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-display font-bold text-rose-400">{rejectedCount}</span>
            <span className="text-sm text-slate-500">artigos</span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-[10px] text-rose-400 font-medium">
            <AlertTriangle className="h-3.5 w-3.5" /> Recomendações estruturadas geradas
          </div>
          <span className="text-[10px] text-slate-500 mt-2">Requerem correção para atingir os critérios</span>
        </div>

        {/* Action: Trigger review */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e1e38] border border-cyan-900/30 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <span className="text-xs font-mono uppercase text-cyan-400 font-bold">Iniciar Auditoria Crítica</span>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Selecione um rascunho para submeter ao robô de revisão editorial profunda do OS.
          </p>
          <div className="mt-4 space-y-2">
            {drafts.length === 0 ? (
              <span className="text-xs text-slate-500 block text-center italic py-2">Nenhum rascunho cadastrado</span>
            ) : (
              <select
                id="review-draft-select"
                className="w-full bg-[#111827] border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                defaultValue=""
                onChange={(e) => {
                  const val = e.target.value;
                  if (val) handleStartReview(val);
                }}
                disabled={reviewingId !== null}
              >
                <option value="" disabled>-- Escolha um Rascunho --</option>
                {drafts.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.titulo} (v{d.versao})
                  </option>
                ))}
              </select>
            )}
            {reviewingId && (
              <div className="flex items-center justify-center gap-2 text-xs font-mono text-cyan-400 py-1">
                <RotateCw className="h-3 w-3 animate-spin" /> Analisando clinicamente...
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main split dashboard: List of reviewed draft reviews vs selected report details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: Reviewed drafts list */}
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-display font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
            Rascunhos Auditados ({reports.length})
          </h3>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {reports.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-xs italic">
                Nenhum laudo emitido ainda. Selecione um rascunho acima e dispare a revisão.
              </div>
            ) : (
              reports.map((r) => {
                const draft = drafts.find(d => d.id === r.draft_id);
                const isSelected = selectedReport?.id === r.id;
                return (
                  <div
                    key={r.id}
                    onClick={() => setSelectedReport(r)}
                    className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? "bg-cyan-950/15 border-cyan-500"
                        : "bg-slate-900/40 border-slate-800/80 hover:bg-slate-900/80"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-mono text-slate-500">{r.id}</span>
                      <span
                        className={`text-[9px] font-mono uppercase px-2 py-0.5 rounded-full font-bold ${
                          r.status === "Aprovado"
                            ? "bg-emerald-950/30 text-emerald-400 border border-emerald-900/50"
                            : "bg-rose-950/30 text-rose-400 border border-rose-900/50"
                        }`}
                      >
                        {r.status}
                      </span>
                    </div>

                    <h4 className="text-xs font-medium text-slate-200 mt-2 line-clamp-1">
                      {draft?.titulo || `Rascunho ID: ${r.draft_id}`}
                    </h4>

                    <div className="flex items-center justify-between gap-2 mt-3 text-[10px] text-slate-400">
                      <span>Média: <strong>{r.score_geral} / 100</strong></span>
                      <span className="text-[9px] text-slate-500">
                        {new Date(r.data).toLocaleDateString("pt-BR")}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Version comparison drawer/section */}
          <div className="border-t border-slate-800 pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-display font-bold text-white flex items-center gap-1.5">
                <Sliders className="h-4 w-4 text-cyan-400" />
                Comparar Versionamentos
              </span>
              <button
                onClick={() => setShowCompare(!showCompare)}
                className="text-[10px] text-cyan-400 hover:underline"
              >
                {showCompare ? "Fechar" : "Abrir"}
              </button>
            </div>

            {showCompare && (
              <div className="space-y-3 bg-slate-900/30 border border-slate-800 p-3 rounded-lg">
                <div>
                  <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1">Versão Anterior</label>
                  <select
                    className="w-full bg-[#111827] border border-slate-800 rounded p-1.5 text-xs text-white"
                    value={compareReportA}
                    onChange={(e) => setCompareReportA(e.target.value)}
                  >
                    <option value="">-- Escolha o Laudo A --</option>
                    {reports.map(r => (
                      <option key={r.id} value={r.id}>{r.id} - Score {r.score_geral}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1">Versão Recente</label>
                  <select
                    className="w-full bg-[#111827] border border-slate-800 rounded p-1.5 text-xs text-white"
                    value={compareReportB}
                    onChange={(e) => setCompareReportB(e.target.value)}
                  >
                    <option value="">-- Escolha o Laudo B --</option>
                    {reports.map(r => (
                      <option key={r.id} value={r.id}>{r.id} - Score {r.score_geral}</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={handleCompare}
                  disabled={!compareReportA || !compareReportB}
                  className="w-full py-1.5 text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white rounded transition-all disabled:opacity-50"
                >
                  Computar Diferenças
                </button>

                {compareResult && (
                  <div className="text-[11px] space-y-2 border-t border-slate-800 pt-2">
                    <div className="flex items-center justify-between font-mono text-xs text-white font-bold">
                      <span>Evolução Geral:</span>
                      <span className={compareResult.differences.score_geral >= 0 ? "text-emerald-400" : "text-rose-400"}>
                        {compareResult.differences.score_geral >= 0 ? "+" : ""}
                        {compareResult.differences.score_geral} pts
                      </span>
                    </div>

                    <div className="space-y-1 text-slate-400 font-mono text-[10px]">
                      {Object.keys(compareResult.differences.metrics).map((m: string) => {
                        const val = compareResult.differences.metrics[m];
                        return (
                          <div key={m} className="flex justify-between">
                            <span className="capitalize">{m.replace(/_/g, " ")}:</span>
                            <span className={val >= 0 ? "text-emerald-400" : "text-rose-400"}>
                              {val >= 0 ? "+" : ""}
                              {val}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right column: Selected report details */}
        <div className="lg:col-span-2 space-y-6">
          {!selectedReport ? (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-10 shadow-xl flex flex-col items-center justify-center text-center">
              <Shield className="h-12 w-12 text-slate-700 mb-3" />
              <p className="text-sm text-slate-400">Nenhum laudo selecionado para exibição do diagnóstico detalhado.</p>
            </div>
          ) : (
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl space-y-6">
              {/* Header inside details */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">{selectedReport.id}</span>
                    <span className="text-xs text-slate-500">•</span>
                    <span className="text-xs text-slate-400">Rascunho: {selectedReport.draft_id}</span>
                  </div>
                  <h3 className="text-lg font-display font-bold text-white mt-1">
                    {drafts.find(d => d.id === selectedReport.draft_id)?.titulo || "Artigo em Auditoria"}
                  </h3>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-mono text-slate-400 block">Score Consolidado</span>
                    <span className="text-2xl font-bold text-white">{selectedReport.score_geral} / 100</span>
                  </div>
                  <div
                    className={`px-3 py-1.5 rounded-lg border text-xs font-mono uppercase font-bold tracking-wider ${
                      selectedReport.status === "Aprovado"
                        ? "bg-emerald-950/20 border-emerald-500/40 text-emerald-400"
                        : "bg-rose-950/20 border-rose-500/40 text-rose-400"
                    }`}
                  >
                    {selectedReport.status}
                  </div>
                </div>
              </div>

              {/* Action bar for senior editor overriding or requesting revision */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/50 p-4 rounded-xl border border-slate-800/80">
                <div className="text-xs text-slate-400">
                  <Scale className="h-4 w-4 inline mr-1 text-cyan-400" />
                  <strong>Controles de Decisão Editorial Sênior:</strong>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleApprove(selectedReport.id)}
                    className="px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-all shadow-md"
                  >
                    Aprovar Manualmente
                  </button>
                  <button
                    onClick={() => handleOpenRevisionModal(selectedReport.id)}
                    className="px-3 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-all shadow-md"
                  >
                    Solicitar Ajustes
                  </button>
                </div>
              </div>

              {/* Diagnostic Observations */}
              <div className="space-y-2">
                <h4 className="text-xs uppercase font-mono text-slate-400 tracking-wider">Diagnóstico Geral do Agente</h4>
                <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl">
                  <p className="text-sm text-slate-300 leading-relaxed italic">
                    "{selectedReport.observacoes || "Nenhuma observação cadastrada no laudo."}"
                  </p>
                </div>
              </div>

               <div className="space-y-3">
                <h4 className="text-xs uppercase font-mono text-slate-400 tracking-wider">Pilares e Dimensões de Performance (0-100)</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(selectedReport.scores || {}).map(([key, val]) => {
                    const value = val as number;
                    const cleanName = key.replace(/_/g, " ");
                    const scoreColor = value >= 85 ? "text-emerald-400" : value >= 70 ? "text-yellow-400" : "text-rose-400";
                    return (
                      <div key={key} className="p-3 bg-slate-900/30 border border-slate-800 rounded-lg space-y-1">
                        <span className="text-[10px] uppercase font-mono text-slate-400 block truncate">{cleanName}</span>
                        <div className="flex items-center justify-between mt-1">
                          <span className={`text-lg font-bold font-mono ${scoreColor}`}>{value}</span>
                          <span className="text-[9px] text-slate-500">Peso {key === "utilidade_para_o_leitor" ? "5%" : ["clareza", "organizacao", "uso_correto_dos_fatos", "uso_correto_das_fontes", "coerencia_narrativa"].includes(key) ? "10%" : "15%"}</span>
                        </div>
                        <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${value >= 85 ? "bg-emerald-500" : value >= 70 ? "bg-yellow-500" : "bg-rose-500"}`}
                            style={{ width: `${value}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Evaluated programmatic rules */}
              <div className="space-y-3">
                <h4 className="text-xs uppercase font-mono text-slate-400 tracking-wider">Lista de Regras Estritas de Qualidade</h4>
                <div className="space-y-2">
                  {selectedReport.regras_avaliadas?.map((rule) => (
                    <div
                      key={rule.ruleId}
                      className="p-3 bg-slate-900/10 border border-slate-800/80 rounded-lg flex items-start gap-3 justify-between"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] font-mono bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                            {rule.ruleId}
                          </span>
                          <span className="text-xs font-semibold text-slate-200">{rule.nome}</span>
                          <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${
                            rule.severidade === "Critica"
                              ? "bg-rose-950/40 text-rose-400 border border-rose-900/30"
                              : rule.severidade === "Alta"
                              ? "bg-amber-950/40 text-amber-400 border border-amber-900/30"
                              : "bg-slate-800/50 text-slate-400"
                          }`}>
                            {rule.severidade}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400">{rule.feedback}</p>
                      </div>

                      <div>
                        {rule.pass ? (
                          <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/20 border border-emerald-900/40 px-2 py-0.5 rounded-full">
                            <Check className="h-3 w-3" /> OK
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[11px] font-semibold text-rose-400 bg-rose-950/20 border border-rose-900/40 px-2 py-0.5 rounded-full">
                            <XCircle className="h-3 w-3" /> Falhou
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations list */}
              <div className="space-y-3">
                <h4 className="text-xs uppercase font-mono text-slate-400 tracking-wider text-rose-400">Recomendações de Ajuste Editorial</h4>
                <ul className="space-y-2">
                  {selectedReport.recomendacoes?.map((rec, idx) => (
                    <li
                      key={idx}
                      className="text-xs text-slate-300 bg-slate-950/30 border border-l-2 border-slate-800 border-l-rose-500 rounded-r p-3 leading-relaxed"
                    >
                      {rec}
                    </li>
                  ))}
                  {(!selectedReport.recomendacoes || selectedReport.recomendacoes.length === 0) && (
                    <span className="text-xs text-slate-500 italic block">Nenhuma recomendação emitida. Texto 100% aprovado.</span>
                  )}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Revision request note modal */}
      {showRevisionModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="text-rose-400 h-5 w-5" />
              Solicitar Ajustes de Rascunho
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Descreva brevemente quais melhorias clínicas, factuais ou editoriais devem ser resolvidas pela equipe de rascunho.
            </p>

            <textarea
              id="revision-note-textarea"
              className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 h-24"
              placeholder="Ex: Faltou contextualizar a dosagem correta do suplemento no H2 e ancorar a fonte regulatória no rodapé."
              value={revisionNote}
              onChange={(e) => setRevisionNote(e.target.value)}
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowRevisionModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                onClick={handleRequestRevision}
                disabled={!revisionNote.trim()}
                className="px-3 py-1.5 text-xs bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-all disabled:opacity-50"
              >
                Solicitar Revisão
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
