import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Layers, 
  GitMerge, 
  Plus, 
  Trash2, 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  Database, 
  RefreshCw, 
  Eye, 
  X, 
  HelpCircle, 
  ListTodo, 
  Grid, 
  CheckSquare, 
  Sparkles,
  ExternalLink,
  GitBranch,
  BookOpen,
  ArrowRight
} from "lucide-react";

interface AssetTypeDefinition {
  id: string;
  nome: string;
  descricao: string;
  melhorIntencao: string[];
  objetivoPadrao: string;
}

interface AssetRelation {
  id: string;
  source_asset_id: string;
  target_asset_id: string;
  tipo_relacao: string;
}

interface Asset {
  id: string;
  content_id: string;
  tipo: string;
  titulo: string;
  status: string;
  versao: string;
  formato: string;
  objetivo: string;
  publico: string;
  estrutura: any;
  criado_em: string;
  atualizado_em: string;
}

interface Opportunity {
  id: string;
  titulo: string;
  categoria: string;
  cluster: string;
  entidade: string;
  tipo: string;
  intencao: string;
  prioridade: string;
  score: number;
  origem: string;
  motivo: string;
  status: string;
}

interface ValidationIssue {
  type: "critical" | "warning" | "info";
  ruleId: string;
  field: string;
  message: string;
}

interface ValidationReport {
  assetId: string;
  valid: boolean;
  issues: ValidationIssue[];
}

export function OrganicAssets() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [relations, setRelations] = useState<AssetRelation[]>([]);
  const [assetTypes, setAssetTypes] = useState<AssetTypeDefinition[]>([]);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  
  // Selection/Input states
  const [selectedOpportunityId, setSelectedOpportunityId] = useState<string>("");
  const [selectedType, setSelectedType] = useState<string>("auto");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  
  // Relationship states
  const [sourceAssetId, setSourceAssetId] = useState<string>("");
  const [targetAssetId, setTargetAssetId] = useState<string>("");
  const [relationType, setRelationType] = useState<string>("pilar-satelite");
  const [isRelating, setIsRelating] = useState<boolean>(false);

  // Active View / Modal states
  const [viewingAsset, setViewingAsset] = useState<Asset | null>(null);
  const [validationReport, setValidationReport] = useState<ValidationReport | null>(null);
  const [activeTabSection, setActiveTabSection] = useState<"library" | "types" | "relations">("library");
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>("all");

  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  // Load baseline data on component mount
  useEffect(() => {
    fetchBaselineData();
    fetchOpportunities();
  }, []);

  const fetchBaselineData = async () => {
    try {
      const response = await fetch("/api/organic-os/assets");
      if (!response.ok) throw new Error("Erro ao buscar dados dos ativos.");
      const data = await response.json();
      setAssets(data.assets || []);
      setRelations(data.relations || []);
      setAssetTypes(data.types || []);
    } catch (err: any) {
      showToast(err.message || "Falha ao carregar ativos.", "error");
    }
  };

  const fetchOpportunities = async () => {
    try {
      const response = await fetch("/api/organic-os/opportunities");
      if (!response.ok) throw new Error("Erro ao buscar oportunidades.");
      const data = await response.json();
      setOpportunities(data || []);
      if (data && data.length > 0) {
        setSelectedOpportunityId(data[0].id);
      }
    } catch (err: any) {
      showToast("Falha ao carregar oportunidades.", "error");
    }
  };

  const showToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  const handleCreateAsset = async () => {
    if (!selectedOpportunityId) {
      showToast("Por favor, selecione uma oportunidade editorial.", "error");
      return;
    }

    setIsGenerating(true);
    showToast("Executando motor de seleção e geração de ativo...", "info");
    
    try {
      const response = await fetch("/api/organic-os/assets/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          opportunityId: selectedOpportunityId,
          tipo: selectedType === "auto" ? undefined : selectedType
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Erro ao gerar ativo de conteúdo.");
      }

      const result = await response.json();
      showToast(`Ativo "${result.asset.titulo}" gerado com sucesso!`, "success");
      
      // Atualizar lista local
      await fetchBaselineData();
    } catch (err: any) {
      showToast(err.message || "Erro ao gerar ativo.", "error");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCreateRelation = async () => {
    if (!sourceAssetId || !targetAssetId) {
      showToast("Selecione os ativos de origem e destino para conectar.", "error");
      return;
    }
    if (sourceAssetId === targetAssetId) {
      showToast("O ativo de origem não pode ser o mesmo que o de destino.", "error");
      return;
    }

    setIsRelating(true);
    try {
      const response = await fetch("/api/organic-os/assets/relation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceId: sourceAssetId,
          targetId: targetAssetId,
          relationType
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Erro ao conectar ativos.");
      }

      showToast("Relacionamento de silo criado com sucesso!", "success");
      setSourceAssetId("");
      setTargetAssetId("");
      await fetchBaselineData();
    } catch (err: any) {
      showToast(err.message || "Falha ao relacionar ativos.", "error");
    } finally {
      setIsRelating(false);
    }
  };

  const handleDeleteAsset = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Tem certeza que deseja excluir permanentemente este ativo de conteúdo?")) return;

    try {
      const response = await fetch(`/api/organic-os/assets/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Falha ao excluir ativo.");
      
      showToast("Ativo de conteúdo excluído com sucesso.", "success");
      if (viewingAsset?.id === id) {
        setViewingAsset(null);
        setValidationReport(null);
      }
      await fetchBaselineData();
    } catch (err: any) {
      showToast(err.message || "Erro ao excluir.", "error");
    }
  };

  const handleDeleteRelation = async (relationId: string) => {
    if (!confirm("Excluir esta fiação relacional de silo?")) return;

    try {
      const response = await fetch(`/api/organic-os/assets/relation/${relationId}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Falha ao excluir relação.");
      
      showToast("Relacionamento removido.", "success");
      await fetchBaselineData();
    } catch (err: any) {
      showToast(err.message || "Erro ao excluir relação.", "error");
    }
  };

  const handleVersionAsset = async (assetId: string) => {
    showToast("Incrementando versão operacional do ativo...", "info");
    try {
      const response = await fetch("/api/organic-os/assets/version", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assetId })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Erro ao re-versionar.");
      }

      const data = await response.json();
      showToast(`Versão do ativo atualizada para ${data.asset.versao}!`, "success");
      
      // Se estiver visualizando o mesmo ativo, atualizar modal
      if (viewingAsset?.id === assetId) {
        handleViewAsset(data.asset);
      }
      await fetchBaselineData();
    } catch (err: any) {
      showToast(err.message || "Falha ao versionar.", "error");
    }
  };

  const handleViewAsset = async (asset: Asset) => {
    setViewingAsset(asset);
    setValidationReport(null);

    // Buscar auditoria de validação fresca do backend
    try {
      const response = await fetch(`/api/organic-os/assets/${asset.id}`);
      if (response.ok) {
        const data = await response.json();
        setValidationReport(data.validation);
      }
    } catch (e) {
      console.error("Falha ao carregar validação do ativo:", e);
    }
  };

  const getAssetNameById = (id: string) => {
    const asset = assets.find(a => a.id === id);
    return asset ? asset.titulo : `[Ativo Desconhecido ${id}]`;
  };

  const getAssetTypeLabel = (typeId: string) => {
    const typeDef = assetTypes.find(t => t.id === typeId);
    return typeDef ? typeDef.nome : typeId;
  };

  const filteredAssets = selectedTypeFilter === "all" 
    ? assets 
    : assets.filter(a => a.tipo === selectedTypeFilter);

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {notification && (
        <div className={`fixed bottom-5 right-5 z-50 flex items-center gap-3 py-3 px-4 rounded-xl shadow-2xl border transition-all duration-300 ${
          notification.type === "success" ? "bg-emerald-950/90 border-emerald-500/30 text-emerald-300" :
          notification.type === "error" ? "bg-rose-950/90 border-rose-500/30 text-rose-300" :
          "bg-slate-900/90 border-cyan-500/30 text-cyan-300"
        }`}>
          {notification.type === "success" && <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />}
          {notification.type === "error" && <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0" />}
          {notification.type === "info" && <Sparkles className="h-5 w-5 text-cyan-400 shrink-0" />}
          <span className="text-sm font-medium">{notification.message}</span>
        </div>
      )}

      {/* Header Banner - Strategic Statement */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-950 via-slate-900 to-[#070b13] border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl -z-10" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/40 border border-cyan-500/30">
              <Sparkles className="h-3.5 w-3.5 text-cyan-400 animate-pulse" />
              <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">Sprint 23 • Ativos Digitais</span>
            </div>
            <h2 className="text-2xl font-display font-bold text-white tracking-tight">
              Content Asset Generation Engine V1
            </h2>
            <p className="text-slate-400 text-sm max-w-2xl">
              Deixando de ser apenas um gerador de artigos. Decida e estruture automaticamente o melhor formato de conteúdo (Checklists, Simulados, FAQs, Tabelas, Glossários) para maximizar a intenção de busca.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-xl text-center min-w-[80px]">
              <div className="text-2xl font-mono font-bold text-cyan-400">{assets.length}</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Ativos</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-xl text-center min-w-[80px]">
              <div className="text-2xl font-mono font-bold text-emerald-400">{relations.length}</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Silos</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-xl text-center min-w-[80px]">
              <div className="text-2xl font-mono font-bold text-amber-400">13</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Formatos</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Creator Pane (Always visible to generate) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Creator form card */}
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
            <h3 className="text-md font-display font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <Plus className="h-5 w-5 text-cyan-400" />
              Gerador de Ativos Estruturados
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1.5">
                  1. Selecionar Oportunidade Editorial
                </label>
                {opportunities.length === 0 ? (
                  <div className="text-xs text-rose-400 p-3 bg-rose-950/20 rounded-lg border border-rose-950">
                    Nenhuma oportunidade editorial carregada. Gere oportunidades na aba correspondente primeiro.
                  </div>
                ) : (
                  <select
                    value={selectedOpportunityId}
                    onChange={(e) => setSelectedOpportunityId(e.target.value)}
                    className="w-full bg-[#0b0f19] border border-slate-700 rounded-lg py-2 px-3 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 transition-all"
                  >
                    {opportunities.map((opp) => (
                      <option key={opp.id} value={opp.id}>
                        [{opp.intencao}] {opp.titulo.length > 50 ? opp.titulo.substring(0, 50) + "..." : opp.titulo}
                      </option>
                    ))}
                  </select>
                )}
                {selectedOpportunityId && (
                  <div className="mt-2 p-3 bg-slate-900/60 border border-slate-800 rounded-lg text-xs space-y-1">
                    <div className="text-slate-400">
                      <span className="font-mono text-slate-500 uppercase">Cluster:</span> {opportunities.find(o => o.id === selectedOpportunityId)?.cluster}
                    </div>
                    <div className="text-slate-400">
                      <span className="font-mono text-slate-500 uppercase">Motivo:</span> {opportunities.find(o => o.id === selectedOpportunityId)?.motivo}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1.5">
                  2. Decidir Formato Editorial
                </label>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-slate-700 rounded-lg py-2 px-3 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 transition-all"
                >
                  <option value="auto">🤖 Seleção Inteligente (Selector Engine)</option>
                  {assetTypes.map((t) => (
                    <option key={t.id} value={t.id}>
                      📁 Forçar: {t.nome}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  O modo inteligente analisa semântica de busca do título e aplica o melhor funil antes de escrever a estrutura.
                </p>
              </div>

              <button
                onClick={handleCreateAsset}
                disabled={isGenerating || opportunities.length === 0}
                className={`w-full py-2.5 px-4 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  isGenerating 
                    ? "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed" 
                    : "bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold hover:shadow-lg hover:shadow-cyan-500/10"
                }`}
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
                    Gerando Ativo...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Gerar Ativo de Conteúdo
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Siderbar info about Brazil Civil Service exams */}
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-5 space-y-3">
            <h4 className="text-xs font-mono uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <BookOpen className="h-4 w-4 text-emerald-400" />
              Nicho Pedagógico: PassaCumaru
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              O motor de inteligência artificial compreende que o blog-alvo atende candidatos de concursos públicos federais, estaduais e municipais. Todas as estruturas geradas (Simulados, Questionários, Linhas do tempo de editais, Tabelas de salários) são otimizadas para atender doutrinas de Direito Administrativo, Constitucional e técnicas avançadas de aprovação.
            </p>
          </div>

        </div>

        {/* Right Column: Interactive Panel with Tab selector */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Sub Tab Navigation */}
          <div className="flex border-b border-slate-800">
            <button
              onClick={() => setActiveTabSection("library")}
              className={`py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all ${
                activeTabSection === "library"
                  ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                  : "border-transparent text-slate-400 hover:text-slate-300"
              }`}
            >
              📚 Biblioteca de Ativos ({filteredAssets.length})
            </button>
            <button
              onClick={() => setActiveTabSection("relations")}
              className={`py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all ${
                activeTabSection === "relations"
                  ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                  : "border-transparent text-slate-400 hover:text-slate-300"
              }`}
            >
              🕸️ Fiação de Silos & Relações ({relations.length})
            </button>
            <button
              onClick={() => setActiveTabSection("types")}
              className={`py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-wider border-b-2 transition-all ${
                activeTabSection === "types"
                  ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                  : "border-transparent text-slate-400 hover:text-slate-300"
              }`}
            >
              📁 Formatos Disponíveis (13)
            </button>
          </div>

          {/* TAB SECTION: LIBRARY */}
          {activeTabSection === "library" && (
            <div className="space-y-4">
              
              {/* Filter bar */}
              <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-lg">
                <span className="text-xs font-mono text-slate-500 uppercase">Filtrar por Formato:</span>
                <select
                  value={selectedTypeFilter}
                  onChange={(e) => setSelectedTypeFilter(e.target.value)}
                  className="bg-[#0b0f19] border border-slate-700 rounded-lg py-1 px-2.5 text-xs text-slate-300 focus:outline-none"
                >
                  <option value="all">Ver Todos os Ativos</option>
                  {assetTypes.map((t) => (
                    <option key={t.id} value={t.id}>{t.nome}</option>
                  ))}
                </select>
              </div>

              {filteredAssets.length === 0 ? (
                <div className="text-center py-12 border border-dashed border-slate-800 rounded-xl bg-slate-900/20">
                  <FileText className="h-10 w-10 text-slate-600 mx-auto mb-2" />
                  <p className="text-sm text-slate-400">Nenhum ativo gerado para este filtro.</p>
                  <p className="text-xs text-slate-500 mt-1">Utilize o painel esquerdo para selecionar uma oportunidade e criar seu primeiro ativo estruturado.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredAssets.map((asset) => (
                    <div 
                      key={asset.id} 
                      onClick={() => handleViewAsset(asset)}
                      className={`group border rounded-xl p-4 cursor-pointer transition-all ${
                        viewingAsset?.id === asset.id 
                          ? "bg-slate-950 border-cyan-500/60 ring-1 ring-cyan-500/20" 
                          : "bg-[#0b0f19]/80 hover:bg-slate-900/60 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase bg-slate-800/80 border border-slate-700 text-slate-300 group-hover:border-cyan-500/30">
                          {getAssetTypeLabel(asset.tipo)}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/50 border border-cyan-500/20 px-1.5 py-0.5 rounded">
                            V{asset.versao || "1.0"}
                          </span>
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/30 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                            estruturado
                          </span>
                        </div>
                      </div>

                      <h4 className="text-sm font-bold text-white mt-2 group-hover:text-cyan-400 transition-colors line-clamp-1">
                        {asset.titulo}
                      </h4>
                      
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                        {asset.objetivo}
                      </p>

                      <div className="flex items-center justify-between border-t border-slate-800 mt-3 pt-3 text-[11px] font-mono text-slate-500">
                        <span>Atualizado: {new Date(asset.atualizado_em).toLocaleDateString()}</span>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleVersionAsset(asset.id); }}
                            title="Criar Nova Versão Incremental (+0.1)"
                            className="p-1 hover:text-cyan-400 hover:bg-slate-800 rounded transition-colors"
                          >
                            <RefreshCw className="h-3 w-3" />
                          </button>
                          <button 
                            onClick={(e) => handleDeleteAsset(asset.id, e)}
                            title="Excluir Ativo"
                            className="p-1 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB SECTION: RELATIONS */}
          {activeTabSection === "relations" && (
            <div className="space-y-6">
              
              {/* Connection creator pane */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 space-y-4">
                <h4 className="text-xs font-mono uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                  <GitBranch className="h-4 w-4 text-cyan-400" />
                  Estabelecer Fiação de Silos (Anchor Siloing Map)
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono text-slate-500 mb-1">ATIVO DE ORIGEM (PAI)</label>
                    <select
                      value={sourceAssetId}
                      onChange={(e) => setSourceAssetId(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="">Selecione...</option>
                      {assets.map(a => (
                        <option key={a.id} value={a.id}>[{getAssetTypeLabel(a.tipo)}] {a.titulo}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-500 mb-1">ATIVO DE DESTINO (FILHO)</label>
                    <select
                      value={targetAssetId}
                      onChange={(e) => setTargetAssetId(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="">Selecione...</option>
                      {assets.map(a => (
                        <option key={a.id} value={a.id}>[{getAssetTypeLabel(a.tipo)}] {a.titulo}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-500 mb-1">CATEGORIA DA CONEXÃO</label>
                    <select
                      value={relationType}
                      onChange={(e) => setRelationType(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="pilar-satelite">Pilar ➔ Artigo Satélite</option>
                      <option value="satelite-faq">Artigo ➔ FAQ Relacionado</option>
                      <option value="faq-quiz">FAQ ➔ Quiz Interativo</option>
                      <option value="quiz-simulado">Quiz ➔ Simulado de Concurso</option>
                      <option value="simulado-material">Simulado ➔ Lead Magnet / Landing</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleCreateRelation}
                    disabled={isRelating || !sourceAssetId || !targetAssetId}
                    className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-1.5 px-4 rounded-lg text-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Vincular Ativos
                  </button>
                </div>
              </div>

              {/* Active Relations List */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                  Mapeamentos Operacionais ({relations.length})
                </h4>

                {relations.length === 0 ? (
                  <div className="text-center py-6 border border-dashed border-slate-800 rounded-xl bg-slate-900/10">
                    <p className="text-xs text-slate-500">Nenhum relacionamento cadastrado.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {relations.map((rel) => (
                      <div key={rel.id} className="flex items-center justify-between p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg text-xs">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-slate-300 max-w-xs truncate" title={getAssetNameById(rel.source_asset_id)}>
                            {getAssetNameById(rel.source_asset_id)}
                          </span>
                          <span className="text-cyan-400 shrink-0 font-mono text-[10px] px-2 py-0.5 rounded-full bg-cyan-950/40 border border-cyan-500/20 uppercase tracking-wider">
                            {rel.tipo_relacao}
                          </span>
                          <ArrowRight className="h-3.5 w-3.5 text-slate-600 shrink-0" />
                          <span className="font-semibold text-slate-300 max-w-xs truncate" title={getAssetNameById(rel.target_asset_id)}>
                            {getAssetNameById(rel.target_asset_id)}
                          </span>
                        </div>
                        <button
                          onClick={() => handleDeleteRelation(rel.id)}
                          className="text-slate-500 hover:text-rose-400 p-1.5 rounded hover:bg-slate-900 transition-colors shrink-0"
                          title="Remover Vinculação"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB SECTION: REGISTERED TYPES */}
          {activeTabSection === "types" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {assetTypes.map((type) => (
                <div key={type.id} className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <FileText className="h-4 w-4 text-cyan-400" />
                      {type.nome}
                    </h4>
                    <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-500/20">
                      {type.id}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {type.descricao}
                  </p>
                  <div className="border-t border-slate-800/80 pt-2 text-[11px] space-y-1">
                    <div>
                      <span className="font-mono text-slate-500 uppercase">Intenção Ideal: </span>
                      {type.melhorIntencao.map(i => (
                        <span key={i} className="inline-block bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded mr-1 font-sans">{i}</span>
                      ))}
                    </div>
                    <div>
                      <span className="font-mono text-slate-500 uppercase">Meta do Funil: </span>
                      <span className="text-slate-400">{type.objetivoPadrao}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      </div>

      {/* FOOTER EXPLORATION PANEL (When viewing an Asset) */}
      {viewingAsset && (
        <div className="bg-[#0b0f19] border border-slate-800 rounded-xl p-6 shadow-2xl relative space-y-6">
          <button
            onClick={() => { setViewingAsset(null); setValidationReport(null); }}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-all"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono bg-cyan-950 text-cyan-400 px-2.5 py-0.5 rounded-full border border-cyan-500/30 font-semibold uppercase tracking-wider">
                  {getAssetTypeLabel(viewingAsset.tipo)}
                </span>
                <span className="text-xs font-mono text-slate-500">Versão {viewingAsset.versao}</span>
              </div>
              <h3 className="text-lg font-display font-bold text-white">{viewingAsset.titulo}</h3>
              <p className="text-xs text-slate-400 flex items-center gap-1.5">
                <span className="font-mono text-slate-500 uppercase">Público-alvo:</span> {viewingAsset.publico}
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleVersionAsset(viewingAsset.id)}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold py-1.5 px-3.5 rounded-lg text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5 text-cyan-400" />
                Versionar Ativo (+0.1)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Structural Preview Panels */}
            <div className="lg:col-span-8 space-y-4">
              <h4 className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                Visualizador de Estrutura de Ativo
              </h4>

              {/* Rendering schemas depending on types */}
              <div className="bg-[#070a13] border border-slate-800 rounded-xl p-5 text-slate-300 text-xs space-y-4 max-h-[500px] overflow-y-auto">
                
                {/* 1. ARTIGO */}
                {viewingAsset.tipo === "artigo" && viewingAsset.estrutura && (
                  <div className="space-y-3">
                    <h1 className="text-lg font-bold text-white border-b border-slate-800 pb-2">{viewingAsset.estrutura.h1 || viewingAsset.titulo}</h1>
                    <p className="text-slate-400 italic bg-slate-900/50 p-3 rounded-lg border border-slate-800">{viewingAsset.estrutura.introducao}</p>
                    {viewingAsset.estrutura.secoes && viewingAsset.estrutura.secoes.map((s: any, i: number) => (
                      <div key={i} className="space-y-1.5 pt-2">
                        <h2 className="text-sm font-semibold text-cyan-400 flex items-center gap-1.5">
                          <span className="font-mono text-xs text-slate-500">H2 #{i+1}</span> {s.subtitulo}
                        </h2>
                        <p className="text-slate-300 leading-relaxed font-sans">{s.texto}</p>
                      </div>
                    ))}
                    {viewingAsset.estrutura.conclusao && (
                      <div className="pt-3 border-t border-slate-800">
                        <h3 className="font-semibold text-white">Conclusão:</h3>
                        <p className="text-slate-400 mt-1">{viewingAsset.estrutura.conclusao}</p>
                      </div>
                    )}
                    {viewingAsset.estrutura.cta && (
                      <div className="mt-4 p-4 bg-cyan-950/30 border border-cyan-500/20 rounded-xl flex items-center justify-between gap-4">
                        <div>
                          <span className="text-[9px] font-mono text-cyan-400 uppercase font-bold tracking-widest block">Metodologia CTA</span>
                          <p className="text-white font-medium">{viewingAsset.estrutura.cta.texto}</p>
                        </div>
                        <span className="bg-cyan-500 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs font-sans shrink-0">{viewingAsset.estrutura.cta.destino || "/checkout"}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. PILLAR PAGE */}
                {viewingAsset.tipo === "pagina_pilar" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <div className="border-l-2 border-emerald-500 pl-3">
                      <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Tema Principal</span>
                      <h2 className="text-base font-bold text-white mt-0.5">{viewingAsset.estrutura.tema_principal}</h2>
                    </div>
                    <p className="text-slate-400 leading-relaxed">{viewingAsset.estrutura.resumo_autoridade}</p>
                    
                    <div className="space-y-3 pt-2">
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Silagem de Módulos Associados</span>
                      {viewingAsset.estrutura.modulos && viewingAsset.estrutura.modulos.map((m: any, idx: number) => (
                        <div key={idx} className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                          <h4 className="font-bold text-white flex items-center gap-1.5 text-xs">
                            <span className="bg-slate-800 text-slate-400 font-mono text-[9px] h-4 w-4 rounded-full flex items-center justify-center">{idx + 1}</span>
                            {m.titulo_modulo}
                          </h4>
                          <p className="text-slate-400 mt-1.5 text-xs leading-relaxed">{m.descricao}</p>
                          {m.links_satelite_sugeridos && m.links_satelite_sugeridos.length > 0 && (
                            <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                              <span className="text-[9px] font-mono text-slate-500 uppercase">Satélites Internos:</span>
                              {m.links_satelite_sugeridos.map((l: string, i: number) => (
                                <span key={i} className="bg-slate-850 border border-slate-700 text-[10px] px-2 py-0.2 rounded font-mono text-slate-300">{l}</span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. FAQ */}
                {viewingAsset.tipo === "faq" && viewingAsset.estrutura && (
                  <div className="space-y-3">
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Featured Schema FAQs</span>
                    {viewingAsset.estrutura.perguntas && viewingAsset.estrutura.perguntas.map((p: any, idx: number) => (
                      <div key={idx} className="p-3 bg-slate-900/40 border border-slate-800 rounded-lg">
                        <h4 className="font-bold text-cyan-300">Q: {p.pergunta}</h4>
                        <p className="text-slate-300 mt-1 font-sans leading-relaxed pl-4">A: {p.resposta}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* 4. LANDING */}
                {viewingAsset.tipo === "landing" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-cyan-950/10 border border-cyan-500/20 rounded-xl space-y-1.5">
                      <span className="text-[9px] font-mono text-cyan-400 uppercase tracking-widest">Headline Persuasiva</span>
                      <h2 className="text-base font-bold text-white">{viewingAsset.estrutura.hero_titulo}</h2>
                      <p className="text-slate-400 text-xs">{viewingAsset.estrutura.hero_subtitulo}</p>
                    </div>

                    <div className="space-y-1.5 pt-2">
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Lista de Benefícios Finais</span>
                      <ul className="space-y-1 pl-4 list-disc text-slate-300">
                        {viewingAsset.estrutura.beneficios && viewingAsset.estrutura.beneficios.map((b: string, i: number) => (
                          <li key={i}>{b}</li>
                        ))}
                      </ul>
                    </div>

                    {viewingAsset.estrutura.prova_social && (
                      <div className="p-3 bg-emerald-950/20 border border-emerald-500/20 rounded-xl">
                        <p className="italic text-slate-300">"{viewingAsset.estrutura.prova_social.depoimento}"</p>
                        <div className="text-right text-[10px] font-mono text-slate-400 mt-1.5">
                          — {viewingAsset.estrutura.prova_social.autor}, <span className="text-emerald-400">{viewingAsset.estrutura.prova_social.cargo}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex justify-center pt-3">
                      <span className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2 px-8 rounded-lg text-sm font-sans shrink-0 uppercase tracking-wider">{viewingAsset.estrutura.cta_botao || "Conversão"}</span>
                    </div>
                  </div>
                )}

                {/* 5. QUIZ */}
                {viewingAsset.tipo === "quiz" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <h3 className="font-bold text-white border-b border-slate-800 pb-2">{viewingAsset.estrutura.titulo_quiz}</h3>
                    
                    <div className="space-y-3">
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Questões do Quiz</span>
                      {viewingAsset.estrutura.questoes && viewingAsset.estrutura.questoes.map((q: any, idx: number) => (
                        <div key={idx} className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-2">
                          <h4 className="font-semibold text-slate-200">Questão {idx + 1}: {q.pergunta}</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                            {q.opcoes && q.opcoes.map((op: string, oIdx: number) => (
                              <div key={oIdx} className={`p-2 rounded border font-sans ${oIdx === q.gabarito_index ? "bg-emerald-950/30 border-emerald-500/40 text-emerald-300" : "bg-slate-950/40 border-slate-850"}`}>
                                {oIdx + 1}. {op} {oIdx === q.gabarito_index && "✓"}
                              </div>
                            ))}
                          </div>
                          <p className="text-[10px] font-mono text-slate-500 mt-1.5">Dica Explicativa: {q.feedback}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 6. CHECKLIST */}
                {viewingAsset.tipo === "checklist" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <h3 className="font-bold text-white border-b border-slate-800 pb-2">{viewingAsset.estrutura.nome_lista}</h3>
                    {viewingAsset.estrutura.fases && viewingAsset.estrutura.fases.map((f: any, fIdx: number) => (
                      <div key={fIdx} className="space-y-2">
                        <span className="text-[10px] font-mono text-cyan-400 uppercase font-semibold">{f.fase_nome}</span>
                        <div className="space-y-2 pl-2">
                          {f.itens && f.itens.map((it: any, iIdx: number) => (
                            <div key={iIdx} className="p-3 bg-slate-900/40 border border-slate-800 rounded-lg flex items-start gap-2.5">
                              <CheckSquare className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                              <div className="space-y-1">
                                <h4 className="font-semibold text-white">{it.tarefa}</h4>
                                <p className="text-[11px] text-slate-400 font-sans">{it.dica_de_execucao}</p>
                                <span className="inline-block text-[9px] font-mono bg-amber-950 text-amber-400 border border-amber-500/20 px-1.5 py-0.2 rounded mt-1 uppercase font-bold">Importância: {it.importancia}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 7. GLOSSARIO */}
                {viewingAsset.tipo === "glossario" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Glossary Terms Map</span>
                    {viewingAsset.estrutura.termos && viewingAsset.estrutura.termos.map((t: any, idx: number) => (
                      <div key={idx} className="p-3 bg-slate-900/40 border border-slate-800 rounded-xl space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="h-5 w-5 rounded-full bg-cyan-950 text-cyan-400 flex items-center justify-center font-mono font-bold text-[10px] border border-cyan-500/30">{t.letra}</span>
                          <h4 className="font-bold text-white text-sm">{t.termo}</h4>
                        </div>
                        <p className="text-slate-300 leading-relaxed font-sans mt-1.5 pl-7">{t.significado}</p>
                        <p className="text-[11px] text-slate-500 pl-7 mt-1 font-mono italic">Contexto em provas: {t.contexto_uso}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* 8. SIMULADO */}
                {viewingAsset.tipo === "simulado" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="text-[10px] font-mono text-slate-500 uppercase">Simulado Oficial do Concurso</span>
                      <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/40 px-2.5 py-0.5 rounded border border-emerald-500/20 font-bold">{viewingAsset.estrutura.edital_referencia}</span>
                    </div>

                    <div className="space-y-4">
                      {viewingAsset.estrutura.questoes && viewingAsset.estrutura.questoes.map((q: any, idx: number) => (
                        <div key={idx} className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl space-y-3">
                          <p className="font-semibold text-slate-200 leading-relaxed font-sans">
                            <span className="font-mono text-slate-500">QUESTÃO #{idx + 1}: </span> {q.enunciado}
                          </p>
                          <div className="space-y-1.5 text-xs pl-3">
                            {q.opcoes && Object.entries(q.opcoes).map(([letter, val]: [string, any]) => (
                              <div key={letter} className={`p-2.5 rounded-lg border font-sans flex items-center gap-2 ${letter === q.gabarito ? "bg-emerald-950/30 border-emerald-500/30 text-emerald-300" : "bg-slate-950/30 border-slate-850"}`}>
                                <span className="h-5 w-5 shrink-0 bg-slate-800 text-slate-400 rounded-full flex items-center justify-center uppercase font-bold text-[10px] border border-slate-700">{letter}</span>
                                <span>{val}</span>
                              </div>
                            ))}
                          </div>
                          <div className="p-3 bg-slate-950 rounded-lg border border-slate-850 text-[11px] text-slate-400">
                            <span className="font-mono font-bold text-emerald-400 block mb-1">GABARITO: LETRA {q.gabarito.toUpperCase()}</span>
                            <p className="font-sans leading-relaxed">{q.explicacao_didatica}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 9. TABELA COMPARATIVA */}
                {viewingAsset.tipo === "tabela" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Tabela Estruturada de Prós & Contras</span>
                    
                    <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
                      <table className="w-full text-left border-collapse text-[11px]">
                        <thead>
                          <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-mono">
                            {viewingAsset.estrutura.colunas && viewingAsset.estrutura.colunas.map((col: string, i: number) => (
                              <th key={i} className="p-3 font-semibold">{col}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {viewingAsset.estrutura.linhas && viewingAsset.estrutura.linhas.map((row: any, rIdx: number) => (
                            <tr key={rIdx} className="border-b border-slate-850/80 hover:bg-slate-900/30">
                              <td className="p-3 font-semibold text-white">{row.nome_linha}</td>
                              {row.valores && row.valores.map((val: string, vIdx: number) => (
                                <td key={vIdx} className="p-3 text-slate-300">{val}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {viewingAsset.estrutura.veredicto_especialista && (
                      <div className="p-3.5 bg-cyan-950/20 border border-cyan-500/20 rounded-xl text-xs space-y-1">
                        <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold tracking-wider block">Veredicto do Especialista</span>
                        <p className="text-slate-300 leading-relaxed font-sans">{viewingAsset.estrutura.veredicto_especialista}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* 10. LINHA DO TEMPO */}
                {viewingAsset.tipo === "linha_do_tempo" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <span className="text-[10px] font-mono text-slate-500 uppercase block">Cronograma de Marcos Temporais do Edital</span>
                    
                    <div className="relative pl-6 border-l border-slate-800 space-y-5 ml-2">
                      {viewingAsset.estrutura.marcos && viewingAsset.estrutura.marcos.map((m: any, idx: number) => (
                        <div key={idx} className="relative">
                          {/* Dot */}
                          <div className="absolute -left-[30px] top-1 h-3.5 w-3.5 bg-cyan-500 rounded-full border-4 border-[#070a13]" />
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/50 border border-cyan-500/10 px-2 py-0.5 rounded">{m.periodo}</span>
                            <h4 className="font-bold text-white text-sm mt-1">{m.evento}</h4>
                            <p className="text-slate-400 leading-relaxed text-xs font-sans">{m.detalhes}</p>
                            {m.base_legal && (
                              <span className="inline-block text-[10px] font-mono text-slate-500">Base legal: {m.base_legal}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 11. NEWSLETTER */}
                {viewingAsset.tipo === "newsletter" && viewingAsset.estrutura && (
                  <div className="space-y-3 font-sans text-xs bg-slate-950 p-4 rounded-xl border border-slate-850 max-w-lg mx-auto">
                    <div className="border-b border-slate-800 pb-2 mb-2 font-mono text-[10px] text-slate-500 space-y-0.5">
                      <div><span className="text-slate-600 uppercase font-bold">Assunto:</span> {viewingAsset.estrutura.assunto_email}</div>
                      <div><span className="text-slate-600 uppercase font-bold">De:</span> editorial@passacumaru.com.br</div>
                    </div>
                    <p className="font-semibold text-white">{viewingAsset.estrutura.saudacao}</p>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-line">{viewingAsset.estrutura.corpo}</p>
                    
                    {viewingAsset.estrutura.balas_destaque && (
                      <ul className="list-disc pl-5 text-slate-400 space-y-1 mt-2.5">
                        {viewingAsset.estrutura.balas_destaque.map((b: string, i: number) => <li key={i}>{b}</li>)}
                      </ul>
                    )}

                    {viewingAsset.estrutura.artigos_recomendados && (
                      <div className="space-y-1 mt-3">
                        <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block">Artigos sugeridos para leitura</span>
                        {viewingAsset.estrutura.artigos_recomendados.map((art: string, idx: number) => (
                          <div key={idx} className="flex items-center gap-1.5 text-cyan-400 hover:underline cursor-pointer font-mono text-[10px]">
                            <ExternalLink className="h-3 w-3 shrink-0" />
                            <span>{art}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="text-slate-400 border-t border-slate-850 pt-3.5 mt-3 text-[11px]">{viewingAsset.estrutura.rodape}</p>
                  </div>
                )}

                {/* 12. EBOOK */}
                {viewingAsset.tipo === "ebook" && viewingAsset.estrutura && (
                  <div className="space-y-4 max-w-lg mx-auto">
                    <div className="p-6 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-xl text-center space-y-2 shadow-2xl">
                      <span className="text-[9px] font-mono text-emerald-400 uppercase tracking-widest border border-emerald-500/20 px-2 py-0.5 rounded">Isca Digital (Lead Magnet)</span>
                      <h2 className="text-base font-bold text-white uppercase">{viewingAsset.estrutura.capa_titulo}</h2>
                      <div className="h-0.5 w-12 bg-cyan-400 mx-auto my-3" />
                      <p className="text-slate-400 text-xs italic">{viewingAsset.estrutura.capa_subtitulo}</p>
                    </div>

                    <div className="space-y-3">
                      <span className="text-[10px] font-mono text-slate-500 uppercase block">Esboço de Capítulos</span>
                      {viewingAsset.estrutura.capitulos && viewingAsset.estrutura.capitulos.map((c: any, idx: number) => (
                        <div key={idx} className="p-3 bg-[#0b0f19] border border-slate-800 rounded-xl">
                          <h4 className="font-bold text-white text-xs">Capítulo {c.numero}: {c.titulo_capitulo}</h4>
                          <p className="text-slate-400 mt-1 text-xs leading-relaxed font-sans">{c.resumo_conteudo}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 13. PAGINA_CATEGORIA */}
                {viewingAsset.tipo === "pagina_categoria" && viewingAsset.estrutura && (
                  <div className="space-y-4">
                    <div className="border-b border-slate-800 pb-2">
                      <span className="text-[10px] font-mono text-slate-500 uppercase">Categoria Otimizada</span>
                      <h2 className="text-base font-bold text-white">{viewingAsset.estrutura.nome_categoria}</h2>
                    </div>
                    <p className="text-slate-400 leading-relaxed font-sans">{viewingAsset.estrutura.introducao_seo}</p>

                    {viewingAsset.estrutura.subcategorias && (
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-mono text-slate-500 uppercase">Sub-taxonomia:</span>
                        {viewingAsset.estrutura.subcategorias.map((s: string, i: number) => (
                          <span key={i} className="bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded text-xs">{s}</span>
                        ))}
                      </div>
                    )}

                    {viewingAsset.estrutura.links_silo_recomendados && (
                      <div className="space-y-1 pt-2">
                        <span className="text-[10px] font-mono text-slate-500 uppercase block">Links recomendados para silo interno</span>
                        {viewingAsset.estrutura.links_silo_recomendados.map((link: string, idx: number) => (
                          <div key={idx} className="text-cyan-400 font-mono hover:underline">{link}</div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

              </div>
              
              {/* Raw JSON Toggle */}
              <details className="group bg-slate-900/40 border border-slate-850 rounded-xl p-3">
                <summary className="text-[11px] font-mono uppercase text-slate-400 tracking-wider cursor-pointer select-none list-none flex items-center justify-between">
                  <span>💾 Ver Estrutura JSON Bruta</span>
                  <span className="text-[10px] text-slate-500 group-open:hidden">Expandir ▾</span>
                  <span className="text-[10px] text-slate-500 hidden group-open:inline">Encolher ▴</span>
                </summary>
                <pre className="text-[10px] text-emerald-400 font-mono mt-3 overflow-x-auto bg-[#05080f] p-4 rounded-lg border border-slate-800 max-h-[300px] leading-relaxed">
                  {JSON.stringify(viewingAsset.estrutura, null, 2)}
                </pre>
              </details>
            </div>

            {/* Validation Audit Sidepane */}
            <div className="lg:col-span-4 space-y-4">
              <h4 className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                Auditoria de Validação Estrutural
              </h4>

              {validationReport ? (
                <div className={`border rounded-xl p-4 space-y-3 ${
                  validationReport.valid 
                    ? "bg-emerald-950/20 border-emerald-500/30 text-slate-300" 
                    : "bg-rose-950/20 border-rose-500/30 text-slate-300"
                }`}>
                  <div className="flex items-center gap-2">
                    {validationReport.valid ? (
                      <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0" />
                    )}
                    <span className="text-xs font-mono font-bold uppercase tracking-wider">
                      {validationReport.valid ? "Aprovado na Auditoria" : "Erros Estruturais"}
                    </span>
                  </div>

                  {validationReport.issues.length === 0 ? (
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Este ativo passou em 100% das diretrizes do validador. A estrutura está íntegra e sem anomalias.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {validationReport.issues.map((issue, idx) => (
                        <div key={idx} className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-850 text-xs space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-mono uppercase ${
                              issue.type === "critical" ? "bg-rose-950 text-rose-400 border border-rose-500/20 font-bold" :
                              issue.type === "warning" ? "bg-amber-950 text-amber-400 border border-amber-500/20 font-bold" :
                              "bg-cyan-950 text-cyan-400 border border-cyan-500/20"
                            }`}>
                              {issue.type}
                            </span>
                            <span className="text-[9px] font-mono text-slate-500">{issue.ruleId}</span>
                          </div>
                          <p className="text-slate-300 font-sans leading-snug">{issue.message}</p>
                          <p className="text-[9px] font-mono text-slate-500">Campo: {issue.field}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-6 border border-slate-850 rounded-xl bg-slate-900/15">
                  <RefreshCw className="h-5 w-5 animate-spin text-slate-600 mx-auto mb-1.5" />
                  <p className="text-xs text-slate-500">Rodando testes de dependência e silo...</p>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
export default OrganicAssets;
