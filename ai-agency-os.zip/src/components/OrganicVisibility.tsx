import React, { useState, useEffect } from "react";
import {
  Sparkles, RefreshCw, CheckCircle2, AlertTriangle,
  BookOpen, Play, FileText, ArrowRight, ChevronRight,
  Check, Layout, Eye, Code, Award, TrendingUp, Info,
  Copy, Globe, Cpu, Hash, FileJson, AlertCircle
} from "lucide-react";

interface DraftRecord {
  id: string;
  brief_id: string;
  blueprint_id: string;
  titulo: string;
  autor: string;
  data_criacao?: string;
  criado_em?: string;
  versao: string;
}

interface VisibilityRule {
  id: string;
  name: string;
  description: string;
  critical?: boolean;
}

interface SchemaRule {
  id: string;
  type: string;
  description: string;
  fields: string[];
}

interface SnippetRule {
  id: string;
  target: string;
  description: string;
  triggerPattern: string;
}

interface FullVisibilityReport {
  id: string;
  draft_id: string;
  seo_score: number;
  ai_visibility_score: number;
  schema_score: number;
  snippet_score: number;
  overall_score: number;
  recomendacoes: string[];
  optimized_title: string;
  optimized_content: string;
  meta_title: string;
  meta_description: string;
  slug: string;
  schema_json_ld: string;
  regras_validadas: Array<{
    ruleId: string;
    nome: string;
    pass: boolean;
    feedback: string;
  }>;
  data: string;
  original_title: string;
  original_content: string;
}

export function OrganicVisibility() {
  const [drafts, setDrafts] = useState<DraftRecord[]>([]);
  const [reports, setReports] = useState<FullVisibilityReport[]>([]);
  const [seoRules, setSeoRules] = useState<VisibilityRule[]>([]);
  const [aiRules, setAiRules] = useState<VisibilityRule[]>([]);
  const [schemaRules, setSchemaRules] = useState<SchemaRule[]>([]);
  const [snippetRules, setSnippetRules] = useState<SnippetRule[]>([]);

  // Selection states
  const [selectedDraftId, setSelectedDraftId] = useState<string>("");
  const [activeReport, setActiveReport] = useState<FullVisibilityReport | null>(null);

  // Engine processing states
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [optimizeStep, setOptimizeStep] = useState<string>("");

  // Tabs
  const [subTab, setSubTab] = useState<"optimize" | "reports" | "matrix">("optimize");
  const [textPreviewTab, setTextPreviewTab] = useState<"original" | "optimized" | "split">("split");
  const [matrixTab, setMatrixTab] = useState<"seo" | "ai" | "schema" | "snippets">("seo");

  // Notifications
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  useEffect(() => {
    loadBaselineData();
  }, []);

  const loadBaselineData = async () => {
    try {
      // 1. Fetch Drafts
      const draftsRes = await fetch("/api/organic-os/drafts");
      if (draftsRes.ok) {
        const data = await draftsRes.json();
        setDrafts(data || []);
        if (data.length > 0) {
          setSelectedDraftId(data[0].id);
        }
      }

      // 2. Fetch SEO Rules
      const seoRulesRes = await fetch("/organic-traffic-os/visibility/seo/seo-rules.json");
      if (seoRulesRes.ok) {
        const data = await seoRulesRes.json();
        setSeoRules(data.rules || []);
      }

      // 3. Fetch AI Rules
      const aiRulesRes = await fetch("/organic-traffic-os/visibility/ai/ai-visibility-rules.json");
      if (aiRulesRes.ok) {
        const data = await aiRulesRes.json();
        setAiRules(data.rules || []);
      }

      // 4. Fetch Schema Rules
      const schemaRulesRes = await fetch("/organic-traffic-os/visibility/schema/schema-rules.json");
      if (schemaRulesRes.ok) {
        const data = await schemaRulesRes.json();
        setSchemaRules(data.schemas || []);
      }

      // 5. Fetch Snippet Rules
      const snippetRulesRes = await fetch("/organic-traffic-os/visibility/snippets/snippet-rules.json");
      if (snippetRulesRes.ok) {
        const data = await snippetRulesRes.json();
        setSnippetRules(data.snippets || []);
      }

      // 6. Fetch Reports
      await fetchReports();
    } catch (e) {
      console.error("Erro ao carregar configurações de visibilidade:", e);
    }
  };

  const fetchReports = async () => {
    try {
      const res = await fetch("/api/organic-os/visibility/reports");
      if (res.ok) {
        const data = await res.json();
        setReports(data || []);
        if (data.length > 0 && !activeReport) {
          setActiveReport(data[0]);
        }
      }
    } catch (e) {
      console.error("Erro ao obter relatórios de visibilidade:", e);
    }
  };

  const showFeedback = (type: "success" | "error", text: string) => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 5000);
  };

  const handleCopy = (text: string, fieldId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2000);
    showFeedback("success", `Metadado copiado com sucesso!`);
  };

  const handleOptimize = async () => {
    if (!selectedDraftId) {
      showFeedback("error", "Selecione um rascunho de artigo para otimizar.");
      return;
    }

    setIsOptimizing(true);
    setOptimizeStep("Acessando o Rascunho Refinado...");
    await new Promise(r => setTimeout(r, 600));
    setOptimizeStep("Carregando o Briefing e Palavras-chave...");
    await new Promise(r => setTimeout(r, 600));
    setOptimizeStep("Carregando Diretrizes Estratégicas do Nicho...");
    await new Promise(r => setTimeout(r, 650));
    setOptimizeStep("Consolidando o Banco de Fatos e Fontes Oficiais...");
    await new Promise(r => setTimeout(r, 600));
    setOptimizeStep("Executando o Motor de Otimização de Visibilidade (Gemini)...");
    await new Promise(r => setTimeout(r, 800));
    setOptimizeStep("Rodando Validador de SEO, IA, Metadados e Schemas...");

    try {
      const res = await fetch("/api/organic-os/visibility/optimize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ draftId: selectedDraftId })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.report) {
          setActiveReport(data.report);
          // Adicionar no topo
          setReports(prev => [data.report, ...prev]);
          showFeedback("success", "Artigo otimizado para visibilidade de busca e IA com sucesso!");
        } else {
          showFeedback("error", "Erro ao otimizar visibilidade do artigo.");
        }
      } else {
        const errData = await res.json();
        showFeedback("error", errData.error || "Ocorreu um erro ao processar o motor.");
      }
    } catch (e) {
      console.error(e);
      showFeedback("error", "Falha de conexão com a API de Visibilidade.");
    } finally {
      setIsOptimizing(false);
      setOptimizeStep("");
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-[#0f172a] border border-cyan-500/20 rounded-xl p-6 shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl -z-10" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="bg-cyan-950 text-cyan-400 text-xs px-2.5 py-1 rounded-full font-semibold border border-cyan-800/50">
                Sprint 22 — V1
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400 text-xs font-medium">Search & AI Visibility Engine</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              <TrendingUp className="h-6 w-6 text-cyan-400" />
              Visibility Optimization Engine
            </h1>
            <p className="text-slate-400 text-sm max-w-2xl">
              Maximize as chances de indexação, destaque e citação do artigo no Google, Bing, ChatGPT, Claude, Gemini, Copilot e assistentes baseados em IA.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsOptimizing(false);
                loadBaselineData();
              }}
              className="p-2.5 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 hover:text-white transition-all border border-slate-700"
              title="Recarregar dados"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Global Tab bar */}
        <div className="flex border-b border-slate-800 mt-6">
          <button
            onClick={() => setSubTab("optimize")}
            className={`py-2.5 px-4 text-sm font-medium border-b-2 transition-all ${
              subTab === "optimize"
                ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                : "border-transparent text-slate-400 hover:text-slate-300"
            }`}
          >
            <Play className="h-4 w-4 inline mr-1.5" />
            Otimizador de Artigo
          </button>
          <button
            onClick={() => setSubTab("reports")}
            className={`py-2.5 px-4 text-sm font-medium border-b-2 transition-all ${
              subTab === "reports"
                ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                : "border-transparent text-slate-400 hover:text-slate-300"
            }`}
          >
            <History className="h-4 w-4 inline mr-1.5" />
            Laudos e Histórico
          </button>
          <button
            onClick={() => setSubTab("matrix")}
            className={`py-2.5 px-4 text-sm font-medium border-b-2 transition-all ${
              subTab === "matrix"
                ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                : "border-transparent text-slate-400 hover:text-slate-300"
            }`}
          >
            <BookOpen className="h-4 w-4 inline mr-1.5" />
            Matrizes de Regras
          </button>
        </div>
      </div>

      {/* Feedback Alerts */}
      {feedback && (
        <div
          className={`p-4 rounded-lg flex items-center justify-between border ${
            feedback.type === "success"
              ? "bg-emerald-950/30 text-emerald-400 border-emerald-800/50"
              : "bg-rose-950/30 text-rose-400 border-rose-800/50"
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === "success" ? (
              <CheckCircle2 className="h-5 w-5 shrink-0" />
            ) : (
              <AlertTriangle className="h-5 w-5 shrink-0" />
            )}
            <span className="text-sm font-medium">{feedback.text}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-xs hover:underline">
            Fechar
          </button>
        </div>
      )}

      {/* SECTION 1: OPTIMIZER TAB */}
      {subTab === "optimize" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left panel: Trigger optimization */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
              <h2 className="text-base font-semibold text-white flex items-center gap-2">
                <Layout className="h-4 w-4 text-cyan-400" />
                Selecione o Rascunho
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                Escolha o artigo produzido para otimizar estruturação, metatags, links e marcas de dados estructurados. O motor utiliza os relatórios de qualidade e público como contexto para o polimento refinado.
              </p>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400">Rascunho de Conteúdo</label>
                <select
                  value={selectedDraftId}
                  onChange={(e) => setSelectedDraftId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2.5 px-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-all"
                  disabled={isOptimizing}
                >
                  <option value="">Selecione um rascunho...</option>
                  {drafts.map((d) => (
                    <option key={d.id} value={d.id}>
                      [{d.id}] {d.titulo} (v{d.versao})
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleOptimize}
                disabled={isOptimizing || !selectedDraftId}
                className={`w-full py-3 px-4 rounded-lg font-semibold text-sm transition-all flex items-center justify-center gap-2 border ${
                  isOptimizing || !selectedDraftId
                    ? "bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed"
                    : "bg-cyan-500 text-slate-950 border-cyan-400 hover:bg-cyan-400"
                }`}
              >
                {isOptimizing ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    Otimizando...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Otimizar Visibilidade
                  </>
                )}
              </button>

              {/* Engine Loading Steps */}
              {isOptimizing && (
                <div className="p-3 bg-cyan-950/20 border border-cyan-800/30 rounded-lg space-y-2">
                  <div className="flex items-center justify-between text-xs text-cyan-400">
                    <span className="font-semibold animate-pulse">Processando...</span>
                    <span>Sprint 22 Engine</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-normal font-mono">
                    &gt; {optimizeStep}
                  </p>
                </div>
              )}
            </div>

            {/* Quick Summary of Active Report */}
            {activeReport && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-semibold text-white">Último Laudo Ativo</h3>
                  <span className="bg-cyan-950/80 text-cyan-400 border border-cyan-800/40 text-[10px] px-2 py-0.5 rounded font-mono">
                    {activeReport.id}
                  </span>
                </div>

                {/* Score Circle / Grid */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-mono font-bold">SEO Score</span>
                    <span className={`text-xl font-bold mt-1 ${activeReport.seo_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                      {activeReport.seo_score}%
                    </span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-mono font-bold">AI Visibility</span>
                    <span className={`text-xl font-bold mt-1 ${activeReport.ai_visibility_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                      {activeReport.ai_visibility_score}%
                    </span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-mono font-bold">Schema JSON-LD</span>
                    <span className={`text-xl font-bold mt-1 ${activeReport.schema_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                      {activeReport.schema_score}%
                    </span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-mono font-bold">Snippets</span>
                    <span className={`text-xl font-bold mt-1 ${activeReport.snippet_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                      {activeReport.snippet_score}%
                    </span>
                  </div>
                </div>

                <div className="bg-slate-900 p-3.5 rounded-lg border border-slate-800 space-y-1.5 text-center">
                  <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block">Score Geral Ponderado</span>
                  <div className="flex items-center justify-center gap-2">
                    <Award className="h-5 w-5 text-yellow-400" />
                    <span className="text-2xl font-black text-cyan-400">{activeReport.overall_score}%</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right panel: Active Report Viewer */}
          <div className="lg:col-span-2 space-y-6">
            {!activeReport ? (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-12 text-center shadow-xl flex flex-col items-center justify-center">
                <Globe className="h-12 w-12 text-slate-600 mb-3 animate-pulse" />
                <h3 className="text-lg font-bold text-white mb-1">Nenhum Artigo Otimizado</h3>
                <p className="text-slate-400 text-sm max-w-md">
                  Selecione um rascunho de artigo no painel esquerdo e execute o motor para gerar a versão de visibilidade enriquecida e analisar metadados.
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Metadados Cadastrados */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Globe className="h-4 w-4 text-cyan-400" />
                    Metadados Otimizados para Indexação
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 relative group space-y-1">
                      <span className="text-[10px] text-cyan-400 font-mono font-bold uppercase">Meta Title</span>
                      <p className="text-sm text-slate-200 pr-8">{activeReport.meta_title}</p>
                      <button
                        onClick={() => handleCopy(activeReport.meta_title, "m_title")}
                        className="absolute top-4 right-4 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "m_title" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>

                    <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 relative group space-y-1">
                      <span className="text-[10px] text-cyan-400 font-mono font-bold uppercase">Meta Description</span>
                      <p className="text-sm text-slate-200 pr-8">{activeReport.meta_description}</p>
                      <button
                        onClick={() => handleCopy(activeReport.meta_description, "m_desc")}
                        className="absolute top-4 right-4 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "m_desc" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>

                    <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 relative group space-y-1 md:col-span-2">
                      <span className="text-[10px] text-cyan-400 font-mono font-bold uppercase">SEO Friendly Slug</span>
                      <p className="text-sm text-slate-200 pr-8 font-mono bg-slate-950 px-2 py-1.5 rounded border border-slate-800/40 mt-1">
                        /organic-os/{activeReport.slug}
                      </p>
                      <button
                        onClick={() => handleCopy(activeReport.slug, "m_slug")}
                        className="absolute top-10 right-6 text-slate-500 hover:text-white transition-all"
                      >
                        {copiedField === "m_slug" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Recommendations and Rules checked */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <Info className="h-4 w-4 text-cyan-400" />
                    Críticas e Recomendações de Descobrimento
                  </h3>

                  <div className="space-y-2">
                    {activeReport.recomendacoes.map((rec, idx) => {
                      const isCritical = rec.includes("[CRÍTICO]");
                      const isWarn = rec.includes("[ATENÇÃO]");
                      const cleanText = rec.replace("[CRÍTICO]", "").replace("[ATENÇÃO]", "").trim();

                      return (
                        <div
                          key={idx}
                          className={`p-3 rounded-lg border text-xs flex items-start gap-2.5 ${
                            isCritical
                              ? "bg-rose-950/20 text-rose-300 border-rose-800/30"
                              : isWarn
                              ? "bg-amber-950/20 text-amber-300 border-amber-800/30"
                              : "bg-slate-900 text-slate-300 border-slate-800"
                          }`}
                        >
                          {isCritical ? (
                            <AlertCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
                          ) : isWarn ? (
                            <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                          ) : (
                            <CheckCircle2 className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
                          )}
                          <span>{cleanText}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Text Compare section */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl shadow-xl overflow-hidden">
                  <div className="bg-slate-900 border-b border-slate-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <FileText className="h-4 w-4 text-cyan-400" />
                      Visualização do Artigo
                    </h3>

                    {/* Compare buttons */}
                    <div className="flex bg-slate-950 border border-slate-800 rounded p-0.5 self-start">
                      <button
                        onClick={() => setTextPreviewTab("original")}
                        className={`text-[11px] px-2.5 py-1 rounded transition-all font-medium ${
                          textPreviewTab === "original" ? "bg-slate-800 text-cyan-400" : "text-slate-500 hover:text-slate-300"
                        }`}
                      >
                        Refinado (Antes)
                      </button>
                      <button
                        onClick={() => setTextPreviewTab("optimized")}
                        className={`text-[11px] px-2.5 py-1 rounded transition-all font-medium ${
                          textPreviewTab === "optimized" ? "bg-slate-800 text-cyan-400" : "text-slate-500 hover:text-slate-300"
                        }`}
                      >
                        Otimizado (Depois)
                      </button>
                      <button
                        onClick={() => setTextPreviewTab("split")}
                        className={`text-[11px] px-2.5 py-1 rounded transition-all font-medium ${
                          textPreviewTab === "split" ? "bg-slate-800 text-cyan-400" : "text-slate-500 hover:text-slate-300"
                        }`}
                      >
                        Lado a Lado
                      </button>
                    </div>
                  </div>

                  {/* Render content */}
                  <div className="p-4 bg-slate-950 font-mono text-xs overflow-auto max-h-[480px]">
                    {textPreviewTab === "original" && (
                      <div className="space-y-4">
                        <div className="text-cyan-400 text-[10px] font-bold border-b border-slate-800 pb-1 uppercase">
                          Original Refinado de Linguagem ({activeReport.original_title})
                        </div>
                        <pre className="whitespace-pre-wrap text-slate-300 leading-relaxed font-sans">
                          {activeReport.original_content}
                        </pre>
                      </div>
                    )}

                    {textPreviewTab === "optimized" && (
                      <div className="space-y-4">
                        <div className="text-cyan-400 text-[10px] font-bold border-b border-slate-800 pb-1 uppercase">
                          Otimizado para Visibilidade ({activeReport.optimized_title})
                        </div>
                        <pre className="whitespace-pre-wrap text-slate-300 leading-relaxed font-sans">
                          {activeReport.optimized_content}
                        </pre>
                      </div>
                    )}

                    {textPreviewTab === "split" && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 divide-y md:divide-y-0 md:divide-x divide-slate-800">
                        <div className="space-y-2 pb-4 md:pb-0">
                          <div className="text-slate-400 text-[10px] font-bold pb-1 border-b border-slate-900 uppercase">
                            Original Refinado
                          </div>
                          <pre className="whitespace-pre-wrap text-slate-400 leading-relaxed font-sans pr-2">
                            {activeReport.original_content}
                          </pre>
                        </div>
                        <div className="space-y-2 pt-4 md:pt-0 md:pl-4">
                          <div className="text-cyan-400 text-[10px] font-bold pb-1 border-b border-slate-900 uppercase">
                            Versão Otimizada
                          </div>
                          <pre className="whitespace-pre-wrap text-slate-200 leading-relaxed font-sans">
                            {activeReport.optimized_content}
                          </pre>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Schema JSON-LD blocks output */}
                {activeReport.schema_json_ld && (
                  <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-3 relative">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                      <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                        <FileJson className="h-4 w-4 text-cyan-400" />
                        Código Estruturado JSON-LD (Schema Markup)
                      </h3>
                      <button
                        onClick={() => handleCopy(activeReport.schema_json_ld, "m_schema")}
                        className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded border border-slate-800 flex items-center gap-1.5 text-xs transition-all"
                      >
                        {copiedField === "m_schema" ? (
                          <>
                            <Check className="h-3 w-3 text-emerald-400" />
                            Copiado
                          </>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            Copiar
                          </>
                        )}
                      </button>
                    </div>

                    <pre className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-slate-300 font-mono text-[11px] overflow-x-auto max-h-72">
                      {activeReport.schema_json_ld}
                    </pre>
                  </div>
                )}

                {/* Checklist de Regras */}
                <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                  <h3 className="text-sm font-semibold text-white">Resultados da Auditoria Estrita</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {activeReport.regras_validadas.map((reg, index) => (
                      <div
                        key={index}
                        className={`p-3.5 rounded-lg border flex items-start gap-3 transition-all ${
                          reg.pass
                            ? "bg-slate-900/60 border-slate-800"
                            : "bg-rose-950/15 border-rose-900/30"
                        }`}
                      >
                        {reg.pass ? (
                          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-400 shrink-0 mt-0.5" />
                        ) : (
                          <AlertTriangle className="h-4.5 w-4.5 text-rose-400 shrink-0 mt-0.5" />
                        )}
                        <div className="space-y-0.5">
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span className="text-[10px] bg-slate-800 text-slate-400 px-1 py-0.2 rounded font-mono">
                              {reg.ruleId}
                            </span>
                            {reg.nome}
                          </div>
                          <p className="text-[11px] text-slate-400 leading-normal">{reg.feedback}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: REPORTS HISTORY TAB */}
      {subTab === "reports" && (
        <div className="bg-[#0f172a] border border-slate-800 rounded-xl shadow-xl overflow-hidden">
          <div className="p-5 border-b border-slate-800 bg-slate-900/40 flex justify-between items-center">
            <div>
              <h2 className="text-base font-semibold text-white">Histórico de Laudos de Visibilidade</h2>
              <p className="text-xs text-slate-400">Todos os relatórios gerados pelo motor de otimização de visibilidade (SEO e IA) do portal.</p>
            </div>
            <span className="text-xs bg-slate-800 text-slate-300 font-bold font-mono px-2.5 py-1 rounded border border-slate-700">
              {reports.length} Total
            </span>
          </div>

          {reports.length === 0 ? (
            <div className="p-12 text-center text-slate-500 flex flex-col items-center justify-center">
              <History className="h-10 w-10 text-slate-600 mb-2" />
              <p className="text-sm font-semibold">Nenhum laudo encontrado no banco de dados.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900/60 border-b border-slate-800 text-slate-400 font-mono font-bold">
                    <th className="p-4">Código / Data</th>
                    <th className="p-4">Artigo Original</th>
                    <th className="p-4 text-center">SEO Score</th>
                    <th className="p-4 text-center">AI Visibility</th>
                    <th className="p-4 text-center">Schema</th>
                    <th className="p-4 text-center">Snippets</th>
                    <th className="p-4 text-center">Geral</th>
                    <th className="p-4 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {reports.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-900/30 transition-all">
                      <td className="p-4 font-mono">
                        <span className="text-white font-bold block">{r.id}</span>
                        <span className="text-slate-500 text-[10px]">
                          {new Date(r.data).toLocaleString("pt-BR")}
                        </span>
                      </td>
                      <td className="p-4 font-medium max-w-xs truncate">
                        <span className="text-slate-400 font-mono text-[10px] block">Draft: {r.draft_id}</span>
                        <span className="text-slate-200 font-semibold">{r.original_title}</span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`font-mono font-bold ${r.seo_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                          {r.seo_score}%
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`font-mono font-bold ${r.ai_visibility_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                          {r.ai_visibility_score}%
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`font-mono font-bold ${r.schema_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                          {r.schema_score}%
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`font-mono font-bold ${r.snippet_score >= 85 ? "text-emerald-400" : "text-amber-400"}`}>
                          {r.snippet_score}%
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className="text-cyan-400 font-black font-mono text-sm bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-900/30">
                          {r.overall_score}%
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => {
                            setActiveReport(r);
                            setSubTab("optimize");
                          }}
                          className="py-1 px-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded text-[10px] transition-all flex items-center gap-1 ml-auto"
                        >
                          <Eye className="h-3 w-3" />
                          Visualizar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: RULES MATRIX TAB */}
      {subTab === "matrix" && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Rules selection menu */}
          <div className="lg:col-span-1 space-y-2">
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-xl space-y-1">
              <h3 className="text-xs font-semibold text-slate-400 uppercase font-mono px-2 pb-2 block">
                Matrizes de Visibilidade
              </h3>
              <button
                onClick={() => setMatrixTab("seo")}
                className={`w-full text-left px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-between ${
                  matrixTab === "seo" ? "bg-cyan-950/50 text-cyan-400 border border-cyan-800/50" : "text-slate-400 hover:bg-slate-900/50 hover:text-slate-200 border border-transparent"
                }`}
              >
                <span>SEO Tradicional</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => setMatrixTab("ai")}
                className={`w-full text-left px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-between ${
                  matrixTab === "ai" ? "bg-cyan-950/50 text-cyan-400 border border-cyan-800/50" : "text-slate-400 hover:bg-slate-900/50 hover:text-slate-200 border border-transparent"
                }`}
              >
                <span>AI Visibility (LLMs)</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => setMatrixTab("schema")}
                className={`w-full text-left px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-between ${
                  matrixTab === "schema" ? "bg-cyan-950/50 text-cyan-400 border border-cyan-800/50" : "text-slate-400 hover:bg-slate-900/50 hover:text-slate-200 border border-transparent"
                }`}
              >
                <span>Schemas Disponíveis</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => setMatrixTab("snippets")}
                className={`w-full text-left px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-between ${
                  matrixTab === "snippets" ? "bg-cyan-950/50 text-cyan-400 border border-cyan-800/50" : "text-slate-400 hover:bg-slate-900/50 hover:text-slate-200 border border-transparent"
                }`}
              >
                <span>Snippet Formats</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Rules body */}
          <div className="lg:col-span-3">
            {/* SEO Rules */}
            {matrixTab === "seo" && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="text-sm font-semibold text-white">Diretrizes de SEO Tradicional (Crawler Friendly)</h3>
                  <p className="text-xs text-slate-400 mt-1">Regras e validações estritas de conformidade de tags, canonical, links e hierarquização.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {seoRules.map((rule) => (
                    <div key={rule.id} className="p-3.5 bg-slate-900/60 rounded-lg border border-slate-800 space-y-1.5 hover:border-slate-700/50 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/40">
                          {rule.id}
                        </span>
                        {rule.critical && (
                          <span className="bg-rose-950/80 text-rose-400 text-[9px] px-1.5 py-0.2 rounded font-semibold border border-rose-900/30 font-mono uppercase">
                            Crítico
                          </span>
                        )}
                      </div>
                      <h4 className="text-xs font-bold text-white">{rule.name}</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">{rule.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* AI Rules */}
            {matrixTab === "ai" && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="text-sm font-semibold text-white">Diretrizes de Visibilidade para Robôs de IA (AI-Friendly)</h3>
                  <p className="text-xs text-slate-400 mt-1">Otimizações focadas em fragmentação de parágrafo, escaneabilidade e extração de Q&A para AI Overviews.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {aiRules.map((rule) => (
                    <div key={rule.id} className="p-3.5 bg-slate-900/60 rounded-lg border border-slate-800 space-y-1.5 hover:border-slate-700/50 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/40">
                          {rule.id}
                        </span>
                        {rule.critical && (
                          <span className="bg-rose-950/80 text-rose-400 text-[9px] px-1.5 py-0.2 rounded font-semibold border border-rose-900/30 font-mono uppercase">
                            Crítico
                          </span>
                        )}
                      </div>
                      <h4 className="text-xs font-bold text-white">{rule.name}</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">{rule.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Schema Rules */}
            {matrixTab === "schema" && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="text-sm font-semibold text-white">Esquemas de Marcação Estruturada (Schema Markup)</h3>
                  <p className="text-xs text-slate-400 mt-1">Modelos de schemas JSON-LD injetados para habilitar Rich Results no Google e alimentar assistentes virtuais.</p>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {schemaRules.map((schema) => (
                    <div key={schema.id} className="p-4 bg-slate-900/60 rounded-lg border border-slate-800 space-y-2 hover:border-slate-700/50 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{schema.type} Schema</span>
                        <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/40">
                          {schema.id}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">{schema.description}</p>
                      <div className="pt-2 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] text-slate-500 uppercase font-mono font-bold block mr-1">Campos Principais:</span>
                        {schema.fields.map((f, idx) => (
                          <span key={idx} className="bg-slate-950 text-slate-400 font-mono text-[10px] px-2 py-0.5 rounded border border-slate-800">
                            {f}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Snippet Rules */}
            {matrixTab === "snippets" && (
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="text-sm font-semibold text-white">Formatos de Otimização para Snippets de Busca</h3>
                  <p className="text-xs text-slate-400 mt-1">Como estruturar chamadas de resposta direta para People Also Ask, Featured Snippets e resumos de inteligência artificial.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {snippetRules.map((snip) => (
                    <div key={snip.id} className="p-3.5 bg-slate-900/60 rounded-lg border border-slate-800 space-y-2 hover:border-slate-700/50 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/40">
                          {snip.id}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white">Alvo: {snip.target}</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">{snip.description}</p>
                      <div className="pt-1 border-t border-slate-800/50">
                        <span className="text-[9px] text-slate-500 font-bold uppercase font-mono block mb-0.5">Fórmula de Disparo:</span>
                        <p className="text-[11px] text-cyan-400 font-medium italic">"{snip.triggerPattern}"</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
