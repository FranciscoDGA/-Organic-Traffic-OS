import React, { useState, useEffect } from "react";
import { 
  FileText, 
  Search, 
  Award, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  RefreshCw, 
  HelpCircle, 
  History, 
  User, 
  Calendar, 
  ChevronRight, 
  Sparkles, 
  Link, 
  BookOpen, 
  Save, 
  Edit3, 
  ArrowLeft,
  XCircle,
  Cpu,
  Layers,
  CheckSquare,
  Wrench,
  Activity,
  ThumbsUp,
  Sliders,
  Maximize2
} from "lucide-react";
import { ContentBlueprint, BlueprintComponent, BlueprintScore } from "../../organic-traffic-os/content-architecture/models/blueprint-models";
import { EditorialBrief } from "../../organic-traffic-os/briefs/models/brief-models";

export function OrganicBriefs() { return null; } // mock so we don't conflict with export naming

export function OrganicBriefsPanel() { return null; }

export function OrganicBlueprints() {
  const [blueprints, setBlueprints] = useState<ContentBlueprint[]>([]);
  const [briefs, setBriefs] = useState<EditorialBrief[]>([]);
  const [selectedBlueprint, setSelectedBlueprint] = useState<ContentBlueprint | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [genLoadingId, setGenLoadingId] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<"geral" | "estrutura" | "componentes" | "score" | "audit" | "versoes">("geral");
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [filterCluster, setFilterCluster] = useState<string>("Todos");
  const [filterType, setFilterType] = useState<string>("Todos");

  // Edit states
  const [editTitle, setEditTitle] = useState("");
  const [editType, setEditType] = useState("");
  const [editObjective, setEditObjective] = useState("");
  const [editSize, setEditSize] = useState("");
  const [editLevel, setEditLevel] = useState("");
  const [editAuthor, setEditAuthor] = useState("Arquiteto Core");
  const [editEstrutura, setEditEstrutura] = useState<string>("");

  // Load Blueprints, Briefs
  const loadData = async () => {
    setLoading(true);
    try {
      const resBps = await fetch("/api/organic-os/blueprints");
      const dataBps = await resBps.json();
      setBlueprints(Array.isArray(dataBps) ? dataBps : []);

      const resBriefs = await fetch("/api/organic-os/briefs");
      const dataBriefs = await resBriefs.json();
      setBriefs(Array.isArray(dataBriefs) ? dataBriefs : []);
    } catch (e) {
      console.error("Erro ao carregar dados do arquiteto de conteúdo:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Set form states when selectedBlueprint changes
  useEffect(() => {
    if (selectedBlueprint) {
      setEditTitle(selectedBlueprint.titulo);
      setEditType(selectedBlueprint.tipo_de_conteudo);
      setEditObjective(selectedBlueprint.objetivo);
      setEditSize(selectedBlueprint.tamanho_estimado);
      setEditLevel(selectedBlueprint.nivel_tecnico);
      setEditAuthor(selectedBlueprint.autor || "Arquiteto Core");
      setEditEstrutura(JSON.stringify(selectedBlueprint.estrutura || [], null, 2));
    }
  }, [selectedBlueprint]);

  // Handle blueprint generation
  const handleGenerateBlueprint = async (briefId: string) => {
    setGenLoadingId(briefId);
    try {
      const res = await fetch("/api/organic-os/blueprints/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ briefId })
      });
      const data = await res.json();
      if (data.success && data.blueprint) {
        setBlueprints(prev => [data.blueprint, ...prev]);
        setSelectedBlueprint(data.blueprint);
        setActiveSubTab("geral");
        // Reload briefs to check status sync
        const resBriefs = await fetch("/api/organic-os/briefs");
        const dataBriefs = await resBriefs.json();
        setBriefs(Array.isArray(dataBriefs) ? dataBriefs : []);
      } else {
        alert("Erro ao gerar Blueprint: " + (data.error || "Erro desconhecido"));
      }
    } catch (err: any) {
      alert("Erro ao comunicar com o servidor: " + err.message);
    } finally {
      setGenLoadingId(null);
    }
  };

  // Save updated Blueprint
  const handleSaveBlueprint = async () => {
    if (!selectedBlueprint) return;

    setLoading(true);
    try {
      let parsedEstrutura = selectedBlueprint.estrutura;
      try {
        parsedEstrutura = JSON.parse(editEstrutura);
      } catch (err) {
        alert("A estrutura inserida não é um JSON válido. Por favor, corrija a sintaxe.");
        setLoading(false);
        return;
      }

      const updatedData: Partial<ContentBlueprint> = {
        titulo: editTitle,
        tipo_de_conteudo: editType,
        objetivo: editObjective,
        tamanho_estimado: editSize,
        nivel_tecnico: editLevel,
        estrutura: parsedEstrutura
      };

      const res = await fetch(`/api/organic-os/blueprints/${selectedBlueprint.id}/update`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ updatedData, autor: editAuthor })
      });

      const data = await res.json();
      if (data.success && data.blueprint) {
        setBlueprints(prev => prev.map(bp => bp.id === selectedBlueprint.id ? data.blueprint : bp));
        setSelectedBlueprint(data.blueprint);
        setIsEditing(false);
      } else {
        alert("Erro ao salvar Blueprint: " + (data.error || "Erro desconhecido"));
      }
    } catch (err: any) {
      alert("Erro ao atualizar Blueprint: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Filter lists
  const clusters = ["Todos", ...Array.from(new Set(briefs.map(b => b.cluster)))];
  const contentTypes = ["Todos", "Artigo Pilar", "Artigo Satélite", "Guia Completo", "Tutorial", "Checklist", "FAQ", "Glossário", "Comparativo", "Review", "Notícia", "Página de Categoria", "Landing Informativa"];

  const filteredBlueprints = blueprints.filter(bp => {
    const matchCluster = filterCluster === "Todos" || bp.cluster.toLowerCase() === filterCluster.toLowerCase();
    const matchType = filterType === "Todos" || bp.tipo_de_conteudo.toLowerCase() === filterType.toLowerCase();
    return matchCluster && matchType;
  });

  const briefsPendingBlueprint = briefs.filter(brief => {
    const alreadyHasBlueprint = blueprints.some(bp => bp.brief_id === brief.id);
    return !alreadyHasBlueprint;
  });

  // Calculate stats
  const totalBlueprintsCount = blueprints.length;
  const avgScore = blueprints.length > 0
    ? Math.round(blueprints.reduce((acc, bp) => acc + (bp.score?.geral || 0), 0) / blueprints.length)
    : 0;
  const validBlueprintsCount = blueprints.filter(bp => bp.audit?.isValid).length;

  return (
    <div className="space-y-6">
      {/* Overview stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-cyan-950/50 text-cyan-400 rounded-lg">
            <Cpu className="h-6 w-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-mono">BLUEPRINTS ATIVOS</div>
            <div className="text-2xl font-bold font-sans text-slate-100">{totalBlueprintsCount}</div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-emerald-950/50 text-emerald-400 rounded-lg">
            <Award className="h-6 w-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-mono">SCORE MÉDIO</div>
            <div className="text-2xl font-bold font-sans text-slate-100">{avgScore}%</div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-indigo-950/50 text-indigo-400 rounded-lg">
            <Layers className="h-6 w-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-mono">CONFORMIDADE</div>
            <div className="text-2xl font-bold font-sans text-slate-100">
              {totalBlueprintsCount > 0 ? Math.round((validBlueprintsCount / totalBlueprintsCount) * 100) : 0}%
            </div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-amber-950/50 text-amber-400 rounded-lg">
            <CheckSquare className="h-6 w-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-mono">PENDENTES DE BLUEPRINT</div>
            <div className="text-2xl font-bold font-sans text-slate-100">{briefsPendingBlueprint.length}</div>
          </div>
        </div>
      </div>

      {!selectedBlueprint ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main blueprints table */}
          <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Sliders className="text-cyan-400 h-5 w-5" /> Blueprints Editoriais Estruturados
                </h3>
                <p className="text-xs text-slate-400">Cada blueprint mapeia o formato ideal e os componentes recomendados antes da redação.</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={loadData}
                  disabled={loading}
                  className="p-2 border border-slate-800 hover:bg-slate-800 text-slate-300 rounded-lg transition-all"
                  title="Atualizar dados"
                >
                  <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin text-cyan-400" : ""}`} />
                </button>
              </div>
            </div>

            {/* Filter controls */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/30 p-4 border border-slate-800/60 rounded-lg">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">CLUSTER SEMÂNTICO (SILO)</label>
                <select
                  value={filterCluster}
                  onChange={(e) => setFilterCluster(e.target.value)}
                  className="w-full bg-slate-900 text-slate-200 border border-slate-800 rounded px-3 py-1.5 text-sm"
                >
                  {clusters.map((c, idx) => (
                    <option key={idx} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">FORMATO DE CONTEÚDO</label>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="w-full bg-slate-900 text-slate-200 border border-slate-800 rounded px-3 py-1.5 text-sm"
                >
                  {contentTypes.map((t, idx) => (
                    <option key={idx} value={t}>{t}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Blueprints list */}
            <div className="overflow-x-auto">
              {filteredBlueprints.length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-sm">
                  Nenhum blueprint editorial localizado com estes filtros.
                </div>
              ) : (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 uppercase font-mono tracking-wider">
                      <th className="py-3 px-4">Tema / ID</th>
                      <th className="py-3 px-4">Formato / Tamanho</th>
                      <th className="py-3 px-4 text-center">Componentes</th>
                      <th className="py-3 px-4 text-center">Score</th>
                      <th className="py-3 px-4">Conformidade</th>
                      <th className="py-3 px-4 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredBlueprints.map((bp) => (
                      <tr key={bp.id} className="border-b border-slate-800/40 hover:bg-slate-850/30 transition-all text-slate-300">
                        <td className="py-3.5 px-4 max-w-xs">
                          <div className="font-semibold text-slate-200 truncate">{bp.titulo}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5 flex items-center gap-1.5">
                            <span className="bg-slate-800 px-1 py-0.5 rounded text-slate-300">{bp.cluster}</span>
                            <span>v{bp.versao}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-cyan-400 bg-cyan-950/25 border border-cyan-800/30 px-2 py-0.5 rounded-full">
                            {bp.tipo_de_conteudo}
                          </span>
                          <div className="text-[10px] text-slate-400 mt-1">{bp.tamanho_estimado} ({bp.nivel_tecnico})</div>
                        </td>
                        <td className="py-3.5 px-4 text-center font-mono text-xs font-semibold text-indigo-400">
                          {bp.componentes?.length || 0}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            (bp.score?.geral || 0) >= 80 ? "bg-emerald-950/50 text-emerald-400 border border-emerald-800/30" : "bg-amber-950/50 text-amber-400 border border-amber-800/30"
                          }`}>
                            {bp.score?.geral || 0}%
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          {bp.audit?.isValid ? (
                            <span className="flex items-center gap-1 text-emerald-400 font-mono text-[10px]">
                              <CheckCircle2 className="h-3 w-3" /> Conforme
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-rose-400 font-mono text-[10px]" title={bp.audit?.errors.join(", ")}>
                              <AlertTriangle className="h-3 w-3" /> {bp.audit?.errors.length} Erros
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => setSelectedBlueprint(bp)}
                            className="text-xs bg-slate-850 hover:bg-cyan-950 hover:text-cyan-400 border border-slate-800 px-2.5 py-1 rounded font-semibold transition-all flex items-center gap-1 ml-auto"
                          >
                            Analisar <ChevronRight className="h-3 w-3" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* Pending creation queue */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <CheckSquare className="text-amber-400 h-4 w-4" /> Briefings de Origem
              </h3>
              <p className="text-xs text-slate-400">Gere Blueprints Estruturais a partir dos briefings de conteúdo aprovados.</p>
            </div>

            <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
              {briefsPendingBlueprint.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-lg">
                  Todos os briefings já possuem Blueprints criados! Pronto para a redação.
                </div>
              ) : (
                briefsPendingBlueprint.map((brief) => (
                  <div key={brief.id} className="p-3.5 bg-slate-950/40 border border-slate-850 rounded-lg space-y-2 hover:border-slate-800 transition-all">
                    <div>
                      <div className="text-xs font-semibold text-slate-200 line-clamp-1">{brief.titulo}</div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                        <span className="bg-slate-900 px-1 rounded">{brief.cluster}</span>
                        <span>{brief.categoria}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleGenerateBlueprint(brief.id)}
                      disabled={genLoadingId !== null}
                      className="w-full py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-400 border border-cyan-800/40 text-[11px] font-semibold rounded transition-all flex items-center justify-center gap-1.5"
                    >
                      {genLoadingId === brief.id ? (
                        <>
                          <RefreshCw className="h-3.5 w-3.5 animate-spin" /> Arquitetando...
                        </>
                      ) : (
                        <>
                          <Cpu className="h-3.5 w-3.5" /> Projetar Arquitetura Ideal
                        </>
                      )}
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Detailed View of Selected Blueprint */
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => { setSelectedBlueprint(null); setIsEditing(false); }}
                className="p-1.5 border border-slate-800 hover:bg-slate-800 text-slate-400 rounded-lg transition-all"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/30 px-2 py-0.5 rounded-full border border-cyan-900/40">
                  {selectedBlueprint.tipo_de_conteudo}
                </span>
                <h3 className="text-xl font-bold text-slate-100 mt-1">{selectedBlueprint.titulo}</h3>
                <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2 font-mono">
                  <span>Silo: {selectedBlueprint.cluster}</span>
                  <span>•</span>
                  <span>Versão {selectedBlueprint.versao}</span>
                  <span>•</span>
                  <span>Escrito por: {selectedBlueprint.autor || "Arquiteto Core"}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isEditing ? (
                <>
                  <button
                    onClick={handleSaveBlueprint}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all"
                  >
                    <Save className="h-3.5 w-3.5" /> Salvar Versão
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-4 py-2 rounded-lg transition-all"
                  >
                    Cancelar
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-750 text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all"
                >
                  <Edit3 className="h-3.5 w-3.5 text-cyan-400" /> Customizar Blueprint
                </button>
              )}
            </div>
          </div>

          {/* Sub-navigation tabs */}
          <div className="flex border-b border-slate-800 overflow-x-auto gap-2">
            {[
              { id: "geral", label: "Visão Geral", icon: BookOpen },
              { id: "estrutura", label: "Estrutura Recomendada", icon: Layers },
              { id: "componentes", label: "Componentes Interativos", icon: Wrench },
              { id: "score", label: "Métricas de Qualidade", icon: Award },
              { id: "audit", label: "Auditoria de Conformidade", icon: AlertTriangle },
              { id: "versoes", label: "Histórico de Versões", icon: History }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id as any)}
                  className={`py-2 px-3.5 text-xs font-medium border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    activeSubTab === tab.id
                      ? "border-cyan-400 text-cyan-400 bg-cyan-950/10"
                      : "border-transparent text-slate-400 hover:text-slate-300"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" /> {tab.label}
                </button>
              );
            })}
          </div>

          {/* Tab content renderer */}
          <div className="bg-slate-950/30 p-6 border border-slate-850 rounded-xl">
            {isEditing ? (
              /* Editable Forms view */
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">TÍTULO RECOMENDADO</label>
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">FORMATO DO CONTEÚDO</label>
                    <select
                      value={editType}
                      onChange={(e) => setEditType(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200"
                    >
                      {contentTypes.filter(x => x !== "Todos").map((t, i) => (
                        <option key={i} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">TAMANHO ESTIMADO</label>
                    <input
                      type="text"
                      value={editSize}
                      onChange={(e) => setEditSize(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">NÍVEL DE PROFUNDIDADE TÉCNICA</label>
                    <select
                      value={editLevel}
                      onChange={(e) => setEditLevel(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200"
                    >
                      <option value="iniciante">Iniciante</option>
                      <option value="médio">Médio</option>
                      <option value="avançado">Avançado</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">NOME DO AUTOR DO AJUSTE</label>
                    <input
                      type="text"
                      value={editAuthor}
                      onChange={(e) => setEditAuthor(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">OBJETIVO ESTRATÉGICO</label>
                  <textarea
                    rows={2}
                    value={editObjective}
                    onChange={(e) => setEditObjective(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">
                    ESTRUTURA DE TÓPICOS (CONFIGURAÇÃO JSON)
                  </label>
                  <textarea
                    rows={12}
                    value={editEstrutura}
                    onChange={(e) => setEditEstrutura(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-mono"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Insira a árvore de cabeçalhos no formato: JSON Array com as chaves: secao, titulo, instrucoes_de_escrita, componentes_sugeridos.</p>
                </div>
              </div>
            ) : (
              /* Non-editable sub-tab content */
              <div>
                {activeSubTab === "geral" && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h4 className="text-xs font-mono text-slate-400 border-b border-slate-800 pb-1 uppercase">Objetivo Estrutural</h4>
                        <p className="text-sm text-slate-300 leading-relaxed">{selectedBlueprint.objetivo}</p>

                        <div className="grid grid-cols-2 gap-4 pt-2">
                          <div>
                            <span className="block text-[10px] text-slate-500 font-mono">TAMANHO RECOMENDADO</span>
                            <span className="text-sm font-semibold text-slate-200">{selectedBlueprint.tamanho_estimado}</span>
                          </div>
                          <div>
                            <span className="block text-[10px] text-slate-500 font-mono">NÍVEL DE PROFUNDIDADE</span>
                            <span className="text-sm font-semibold text-slate-200 uppercase">{selectedBlueprint.nivel_tecnico}</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-slate-900/40 p-4 border border-slate-800/80 rounded-xl space-y-4">
                        <h4 className="text-xs font-mono text-slate-400 flex items-center gap-1.5 uppercase">
                          <Award className="h-4 w-4 text-cyan-400" /> Score Resumido do Blueprint
                        </h4>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-400">Potencial SEO</span>
                          <span className="text-xs font-mono font-bold text-slate-200">{selectedBlueprint.score?.potencial_seo}%</span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded">
                          <div className="bg-cyan-500 h-1.5 rounded" style={{ width: `${selectedBlueprint.score?.potencial_seo}%` }}></div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-400">Adequação à Intenção de Busca</span>
                          <span className="text-xs font-mono font-bold text-slate-200">{selectedBlueprint.score?.adequacao_intencao}%</span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded">
                          <div className="bg-emerald-500 h-1.5 rounded" style={{ width: `${selectedBlueprint.score?.adequacao_intencao}%` }}></div>
                        </div>

                        <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
                          <span className="text-xs font-semibold text-slate-300">Nota de Qualidade Geral:</span>
                          <span className="text-base font-bold text-cyan-400">{selectedBlueprint.score?.geral}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSubTab === "estrutura" && (
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h4 className="text-xs font-mono text-slate-400 border-b border-slate-800 pb-1 uppercase">Estrutura de Cabeçalhos e Escrita</h4>
                    </div>

                    <div className="space-y-4">
                      {selectedBlueprint.estrutura?.map((item, idx) => (
                        <div key={idx} className="p-4 bg-slate-950/50 border border-slate-850 rounded-lg flex items-start space-x-4 hover:border-slate-800 transition-all">
                          <span className={`px-2 py-1 rounded text-[10px] font-bold font-mono ${
                            item.secao === "H1" ? "bg-cyan-950 text-cyan-400 border border-cyan-800" :
                            item.secao === "H2" ? "bg-indigo-950 text-indigo-400 border border-indigo-800" :
                            "bg-slate-800 text-slate-400 border border-slate-700"
                          }`}>
                            {item.secao}
                          </span>
                          <div className="flex-1 space-y-1">
                            <div className="text-sm font-semibold text-slate-200">{item.titulo}</div>
                            <div className="text-xs text-slate-400 leading-relaxed">{item.instrucoes_de_escrita}</div>
                            {item.componentes_sugeridos && item.componentes_sugeridos.length > 0 && (
                              <div className="flex items-center gap-1.5 pt-2">
                                <span className="text-[10px] text-slate-500 font-mono">Componentes:</span>
                                {item.componentes_sugeridos.map((comp, cIdx) => (
                                  <span key={cIdx} className="bg-slate-900 text-slate-300 text-[10px] px-1.5 py-0.5 rounded font-mono">
                                    {comp}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeSubTab === "componentes" && (
                  <div className="space-y-6">
                    <h4 className="text-xs font-mono text-slate-400 border-b border-slate-800 pb-1 uppercase">Componentes Obrigatórios Escolhidos</h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {selectedBlueprint.componentes?.map((comp, idx) => (
                        <div key={idx} className="p-4 bg-slate-950/40 border border-slate-850 rounded-lg space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                              {comp.nome}
                            </span>
                            <span className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded ${
                              comp.obrigatorio ? "bg-rose-950/40 text-rose-400 border border-rose-900/30" : "bg-slate-800 text-slate-400"
                            }`}>
                              {comp.obrigatorio ? "Obrigatorio" : "Recomendado"}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 leading-relaxed">{comp.diretriz}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeSubTab === "score" && (
                  <div className="space-y-6">
                    <h4 className="text-xs font-mono text-slate-400 border-b border-slate-800 pb-1 uppercase">Detalhamento das Métricas do Blueprint</h4>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4 bg-slate-900/20 p-5 border border-slate-850 rounded-xl">
                        <h5 className="text-sm font-bold text-slate-300">Resumo por Critério</h5>
                        
                        <div className="space-y-3">
                          {[
                            { name: "Cobertura do Tema", val: selectedBlueprint.score?.cobertura_tema, color: "bg-cyan-500" },
                            { name: "Adequação à Intenção", val: selectedBlueprint.score?.adequacao_intencao, color: "bg-emerald-500" },
                            { name: "Potencial SEO", val: selectedBlueprint.score?.potencial_seo, color: "bg-indigo-500" },
                            { name: "Experiência do Usuário (UX)", val: selectedBlueprint.score?.experiencia_usuario, color: "bg-amber-500" },
                            { name: "Complexidade Técnica", val: selectedBlueprint.score?.complexidade, color: "bg-teal-500" },
                            { name: "Completude Estrutural", val: selectedBlueprint.score?.completude, color: "bg-rose-500" }
                          ].map((crit, index) => (
                            <div key={index} className="space-y-1">
                              <div className="flex justify-between text-xs text-slate-400">
                                <span>{crit.name}</span>
                                <span className="font-mono">{crit.val}%</span>
                              </div>
                              <div className="w-full bg-slate-900 h-1.5 rounded">
                                <div className={`${crit.color} h-1.5 rounded`} style={{ width: `${crit.val}%` }}></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="p-4 bg-cyan-950/20 border border-cyan-900/30 rounded-lg">
                          <h5 className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-semibold mb-1">Como o score funciona?</h5>
                          <p className="text-xs text-slate-300 leading-relaxed">
                            O score avalia heurísticas de SEO semântico e arquitetura estrutural: as tags e headings H1/H2/H3 garantem a cobertura semântica (Potencial SEO); o tipo de conteúdo precisa coincidir de forma natural com a intenção mapeada; e os componentes sugeridos (UX) quebram a fadiga textual oferecendo resumos visuais práticos.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSubTab === "audit" && (
                  <div className="space-y-6">
                    <h4 className="text-xs font-mono text-slate-400 border-b border-slate-800 pb-1 uppercase">Auditor de Integridade Estrutural</h4>

                    <div className="space-y-4">
                      {selectedBlueprint.audit?.errors.length === 0 && selectedBlueprint.audit?.warnings.length === 0 ? (
                        <div className="p-4 bg-emerald-950/30 border border-emerald-900/30 rounded-lg text-xs text-emerald-400 flex items-center gap-2">
                          <CheckCircle2 className="h-5 w-5" /> Nenhuma falha estrutural localizada. Blueprint pronto para produção!
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {selectedBlueprint.audit?.errors.map((err, i) => (
                            <div key={i} className="p-3 bg-rose-950/20 border border-rose-900/30 rounded-lg text-xs text-rose-400 flex items-center gap-2">
                              <XCircle className="h-4 w-4 shrink-0" /> {err}
                            </div>
                          ))}
                          {selectedBlueprint.audit?.warnings.map((warn, i) => (
                            <div key={i} className="p-3 bg-amber-950/20 border border-amber-900/30 rounded-lg text-xs text-amber-400 flex items-center gap-2">
                              <AlertTriangle className="h-4 w-4 shrink-0" /> {warn}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeSubTab === "versoes" && (
                  <div className="space-y-6">
                    <h4 className="text-xs font-mono text-slate-400 border-b border-slate-800 pb-1 uppercase">Linha do Tempo de Versionamento</h4>

                    <div className="space-y-4">
                      {/* Active Version */}
                      <div className="p-4 bg-slate-900/40 border border-slate-850 rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-slate-200">Versão Ativa (v{selectedBlueprint.versao})</span>
                          <span className="bg-cyan-950 text-cyan-400 text-[10px] font-mono px-2 py-0.5 rounded border border-cyan-800/30">ATIVO</span>
                        </div>
                        <div className="text-xs text-slate-400">Arquiteto de Conteúdo Core. Snapshot ativo no armazenamento.</div>
                      </div>

                      {/* Archived Versions */}
                      {selectedBlueprint.versions && selectedBlueprint.versions.length > 0 ? (
                        selectedBlueprint.versions.map((ver, idx) => (
                          <div key={idx} className="p-4 bg-slate-950/20 border border-slate-850 border-dashed rounded-lg space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-semibold text-slate-400">Versão Anterior v{ver.versao}</span>
                              <span className="text-[10px] text-slate-500 font-mono">{new Date(ver.data_snapshot).toLocaleString("pt-BR")}</span>
                            </div>
                            <p className="text-xs text-slate-500 italic">"{ver.mudancas}"</p>
                            <div className="text-[10px] text-slate-600 font-mono">Modificado por: {ver.autor}</div>
                          </div>
                        ))
                      ) : (
                        <div className="p-4 text-center border border-dashed border-slate-850 rounded-lg text-xs text-slate-500">
                          Nenhum snapshot de versão histórica armazenado ainda.
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
