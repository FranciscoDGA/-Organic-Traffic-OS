import React, { useState, useEffect } from "react";
import { 
  Search, LayoutGrid, TrendingUp, Zap, BarChart2, ListOrdered, 
  AlertCircle, CheckCircle2, HelpCircle, Clock, PlusCircle, RotateCw, 
  Bookmark, FileText, Layout, ChevronRight, Sparkles, Globe, Activity,
  Sliders, MessageSquare, ArrowUpRight, AlignLeft, ListCollapse, List, TableProperties,
  RefreshCw, AlertTriangle, Award
} from "lucide-react";

interface SerpQuery {
  id: string;
  query: string;
  categoria: string;
  cluster: string;
  idioma: string;
  pais: string;
  cidade: string;
  status: "analisado" | "pendente";
  ultima_analise: string;
}

interface SerpResult {
  id: string;
  queryId: string;
  posicao: number;
  url: string;
  dominio: string;
  titulo: string;
  descricao: string;
  tipo: string;
  data?: string;
}

interface FeaturedSnippet {
  presente: boolean;
  tipo: string;
  detentor: string;
  texto: string;
}

interface SerpFeatures {
  queryId: string;
  featuredSnippet: FeaturedSnippet;
  peopleAlsoAsk: string[];
  knowledgePanel: boolean;
  localPack: boolean;
  videos: boolean;
  imagens: boolean;
  news: boolean;
  faq: boolean;
  breadcrumb: boolean;
  richResults: boolean;
}

interface ContentPatterns {
  queryId: string;
  quantidadeMediaH2: number;
  quantidadeMediaH3: number;
  usoDeFaq: string;
  usoDeTabelas: string;
  usoDeListas: string;
  usoDeVideos: string;
  usoDeImagens: string;
  usoDeSchema: string;
  tamanhoMedio: number;
}

interface SearchIntent {
  queryId: string;
  intencao: string;
  distribuicao: Record<string, number>;
  observacoes: string;
}

interface SerpOpportunity {
  id: string;
  consulta: string;
  motivo: string;
  potencial: string;
  prioridade: string;
  status: string;
  observações: string;
}

interface ConsolidatedSerpData {
  queries: SerpQuery[];
  results: SerpResult[];
  features: SerpFeatures[];
  patterns: ContentPatterns[];
  intents: SearchIntent[];
  opportunities: SerpOpportunity[];
  metadata: {
    totalQueries: number;
    analysedCount: number;
    pendingCount: number;
    totalOpportunities: number;
    intentDistribution: Record<string, number>;
    featureCounts: {
      featuredSnippet: number;
      peopleAlsoAsk: number;
      faq: number;
      videos: number;
      imagens: number;
      localPack: number;
    };
    isValid: boolean;
    errors: string[];
    lastUpdated: string;
  };
}

export function OrganicSerp() {
  const [data, setData] = useState<ConsolidatedSerpData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [activeSubTab, setActiveSubTab] = useState<"dashboard" | "queries" | "patterns" | "opportunities" | "add">("dashboard");
  const [selectedQueryId, setSelectedQueryId] = useState<string | null>(null);

  // Form State for new Query and Analysis
  const [newQuery, setNewQuery] = useState({
    query: "",
    categoria: "Inscrições",
    cluster: "",
    idioma: "pt-BR",
    pais: "Brasil",
    cidade: "Passa e Fica",
    status: "analisado" as "analisado" | "pendente"
  });

  const [newResults, setNewResults] = useState<Omit<SerpResult, "id" | "queryId">[]>([
    { posicao: 1, url: "", dominio: "", titulo: "", descricao: "", tipo: "blog" },
    { posicao: 2, url: "", dominio: "", titulo: "", descricao: "", tipo: "governo" },
    { posicao: 3, url: "", dominio: "", titulo: "", descricao: "", tipo: "blog" }
  ]);

  const [newFeatures, setNewFeatures] = useState({
    featuredSnippet: { presente: false, tipo: "paragrafo", detentor: "", texto: "" },
    peopleAlsoAsk: ["", ""],
    knowledgePanel: false,
    localPack: false,
    videos: false,
    imagens: false,
    news: false,
    faq: false,
    breadcrumb: true,
    richResults: true
  });

  const [newPatterns, setNewPatterns] = useState({
    quantidadeMediaH2: 5,
    quantidadeMediaH3: 8,
    usoDeFaq: "Médio",
    usoDeTabelas: "Médio",
    usoDeListas: "Alto",
    usoDeVideos: "Baixo",
    usoDeImagens: "Alto",
    usoDeSchema: "Médio",
    tamanhoMedio: 1500
  });

  const [newIntent, setNewIntent] = useState({
    intencao: "Informacional",
    observacoes: ""
  });

  // Form state for Opportunity
  const [newOpp, setNewOpp] = useState({
    consulta: "",
    motivo: "",
    potencial: "Médio",
    prioridade: "Média",
    status: "Mapeado",
    observações: ""
  });

  const [submitting, setSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/organic-os/serp");
      if (!response.ok) {
        throw new Error("Falha ao obter dados consolidados da SERP");
      }
      const json = await response.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Erro desconhecido ao carregar dados.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuery.query.trim()) {
      alert("Por favor, digite a consulta de busca.");
      return;
    }

    setSubmitting(true);
    setFormSuccess(null);

    const queryId = "q-" + Date.now();
    const queryObj: SerpQuery = {
      id: queryId,
      query: newQuery.query,
      categoria: newQuery.categoria,
      cluster: newQuery.cluster || "Legislação Local",
      idioma: newQuery.idioma,
      pais: newQuery.pais,
      cidade: newQuery.cidade,
      status: newQuery.status,
      ultima_analise: newQuery.status === "analisado" ? new Date().toISOString() : ""
    };

    // Prepare complete payload if it's analyzed
    const finalResults: SerpResult[] = newResults
      .filter(r => r.url.trim() !== "")
      .map((r, index) => ({
        ...r,
        id: `res-${queryId}-${index + 1}`,
        queryId,
        posicao: index + 1
      }));

    const finalFeatures: SerpFeatures = {
      queryId,
      featuredSnippet: newFeatures.featuredSnippet,
      peopleAlsoAsk: newFeatures.peopleAlsoAsk.filter(p => p.trim() !== ""),
      knowledgePanel: newFeatures.knowledgePanel,
      localPack: newFeatures.localPack,
      videos: newFeatures.videos,
      imagens: newFeatures.imagens,
      news: newFeatures.news,
      faq: newFeatures.faq,
      breadcrumb: newFeatures.breadcrumb,
      richResults: newFeatures.richResults
    };

    const finalPatterns: ContentPatterns = {
      queryId,
      ...newPatterns
    };

    const finalIntent: SearchIntent = {
      queryId,
      intencao: newIntent.intencao,
      distribuicao: {
        [newIntent.intencao]: 100
      },
      observacoes: newIntent.observacoes || "Definição manual de intenção de busca"
    };

    try {
      const response = await fetch("/api/organic-os/serp/analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: queryObj,
          results: finalResults,
          features: finalFeatures,
          patterns: finalPatterns,
          intent: finalIntent
        })
      });

      if (!response.ok) {
        throw new Error("Erro de rede ao salvar a consulta da SERP");
      }

      setFormSuccess(`Consulta "${newQuery.query}" cadastrada e analisada com sucesso!`);
      // Reset form
      setNewQuery({
        query: "",
        categoria: "Inscrições",
        cluster: "",
        idioma: "pt-BR",
        pais: "Brasil",
        cidade: "Passa e Fica",
        status: "analisado"
      });
      // Refresh
      await fetchData();
    } catch (err: any) {
      alert("Erro ao salvar: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateOpportunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOpp.consulta.trim() || !newOpp.motivo.trim()) {
      alert("Por favor, preencha a consulta e o motivo da oportunidade.");
      return;
    }

    setSubmitting(true);
    try {
      const oppObj: SerpOpportunity = {
        id: "opp-" + Date.now(),
        ...newOpp
      };

      const response = await fetch("/api/organic-os/serp/opportunity", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ opportunity: oppObj })
      });

      if (!response.ok) {
        throw new Error("Erro de rede ao salvar oportunidade");
      }

      setFormSuccess("Nova oportunidade de SERP registrada com sucesso!");
      setNewOpp({
        consulta: "",
        motivo: "",
        potencial: "Médio",
        prioridade: "Média",
        status: "Mapeado",
        observações: ""
      });
      await fetchData();
    } catch (err: any) {
      alert("Erro ao registrar oportunidade: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleResultChange = (index: number, field: string, value: any) => {
    const updated = [...newResults];
    updated[index] = { ...updated[index], [field]: value };
    setNewResults(updated);
  };

  const addResultRow = () => {
    setNewResults([...newResults, { posicao: newResults.length + 1, url: "", dominio: "", titulo: "", descricao: "", tipo: "blog" }]);
  };

  const categories = data ? Array.from(new Set(data.queries.map(q => q.categoria))) : [];

  const filteredQueries = data ? data.queries.filter(q => {
    const matchesSearch = q.query.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          q.cluster.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || q.categoria === selectedCategory;
    return matchesSearch && matchesCategory;
  }) : [];

  const selectedQuery = data && selectedQueryId ? data.queries.find(q => q.id === selectedQueryId) : null;
  const selectedResults = data && selectedQueryId ? data.results.filter(r => r.queryId === selectedQueryId) : [];
  const selectedFeatures = data && selectedQueryId ? data.features.find(f => f.queryId === selectedQueryId) : null;
  const selectedPattern = data && selectedQueryId ? data.patterns.find(p => p.queryId === selectedQueryId) : null;
  const selectedIntent = data && selectedQueryId ? data.intents.find(i => i.queryId === selectedQueryId) : null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Sprint 05 Ativa
            </span>
            <span className="text-xs text-slate-400">|</span>
            <span className="text-xs text-slate-400 font-mono">SERP Intelligence Core</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-100 mt-1">
            Motor de Inteligência de SERP <span className="text-cyan-400">PassaCumaru</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Análise e engenharia reversa de como o Google responde às buscas locais do RN antes de produzir conteúdo.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={fetchData} 
            className="p-2 bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-800 transition text-slate-400 hover:text-slate-200"
            title="Recarregar Dados"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setActiveSubTab("add")}
            className="flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-900 font-medium rounded-lg text-sm transition shadow-lg shadow-cyan-950/20"
          >
            <PlusCircle className="h-4 w-4" />
            Nova Consulta / Análise
          </button>
        </div>
      </div>

      {/* Sub tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800/60 pb-3">
        <button
          onClick={() => { setActiveSubTab("dashboard"); setSelectedQueryId(null); }}
          className={`px-4 py-1.5 text-sm rounded-lg border transition ${
            activeSubTab === "dashboard"
              ? "bg-cyan-950/40 text-cyan-400 border-cyan-800"
              : "bg-slate-950 border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <LayoutGrid className="h-4 w-4" />
            Painel Geral
          </div>
        </button>
        <button
          onClick={() => setActiveSubTab("queries")}
          className={`px-4 py-1.5 text-sm rounded-lg border transition ${
            activeSubTab === "queries"
              ? "bg-cyan-950/40 text-cyan-400 border-cyan-800"
              : "bg-slate-950 border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Search className="h-4 w-4" />
            Análises de Consultas ({data?.queries.length || 0})
          </div>
        </button>
        <button
          onClick={() => { setActiveSubTab("patterns"); setSelectedQueryId(null); }}
          className={`px-4 py-1.5 text-sm rounded-lg border transition ${
            activeSubTab === "patterns"
              ? "bg-cyan-950/40 text-cyan-400 border-cyan-800"
              : "bg-slate-950 border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Sliders className="h-4 w-4" />
            Padrões Estruturais
          </div>
        </button>
        <button
          onClick={() => { setActiveSubTab("opportunities"); setSelectedQueryId(null); }}
          className={`px-4 py-1.5 text-sm rounded-lg border transition ${
            activeSubTab === "opportunities"
              ? "bg-cyan-950/40 text-cyan-400 border-cyan-800"
              : "bg-slate-950 border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Zap className="h-4 w-4" />
            Oportunidades de SERP ({data?.opportunities.length || 0})
          </div>
        </button>
        <button
          onClick={() => { setActiveSubTab("add"); setSelectedQueryId(null); }}
          className={`px-4 py-1.5 text-sm rounded-lg border transition ${
            activeSubTab === "add"
              ? "bg-cyan-950/40 text-cyan-400 border-cyan-800"
              : "bg-slate-950 border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <PlusCircle className="h-4 w-4" />
            Alimentar Engine (Manual)
          </div>
        </button>
      </div>

      {loading && !data && (
        <div className="flex flex-col items-center justify-center py-12 text-slate-400 space-y-3">
          <RotateCw className="h-8 w-8 animate-spin text-cyan-400" />
          <p>Carregando base de dados do motor de SERP...</p>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-950/20 border border-red-900/40 rounded-xl text-red-400 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold">Erro ao processar dados de SERP</h4>
            <p className="text-xs text-red-300/80 mt-1">{error}</p>
          </div>
        </div>
      )}

      {data && (
        <>
          {/* Main system validation alert if failed */}
          {!data.metadata.isValid && (
            <div className="p-4 bg-amber-950/20 border border-amber-900/40 rounded-xl text-amber-400 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold">Problemas de Integridade nos arquivos JSON da SERP</h4>
                <div className="text-xs text-amber-300/80 mt-1 space-y-1">
                  {data.metadata.errors.map((err, idx) => (
                    <p key={idx}>• {err}</p>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: Painel Geral */}
          {activeSubTab === "dashboard" && (
            <div className="space-y-6">
              {/* Bento Grid Summary */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl">
                  <div className="flex items-center justify-between text-slate-400 text-xs font-mono uppercase">
                    <span>Consultas Cadastradas</span>
                    <Search className="h-4 w-4 text-cyan-400" />
                  </div>
                  <div className="text-3xl font-extrabold text-slate-100 mt-2">{data.metadata.totalQueries}</div>
                  <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                    <span className="text-emerald-400 font-semibold">{data.metadata.analysedCount}</span> analisadas
                    <span className="text-slate-600">•</span>
                    <span className="text-amber-400 font-semibold">{data.metadata.pendingCount}</span> pendentes
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl">
                  <div className="flex items-center justify-between text-slate-400 text-xs font-mono uppercase">
                    <span>Oportunidades</span>
                    <Zap className="h-4 w-4 text-amber-400" />
                  </div>
                  <div className="text-3xl font-extrabold text-slate-100 mt-2">{data.metadata.totalOpportunities}</div>
                  <div className="text-xs text-emerald-400 mt-1 flex items-center gap-1 font-semibold">
                    <Activity className="h-3 w-3" />
                    Prontas para pauta editorial
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl">
                  <div className="flex items-center justify-between text-slate-400 text-xs font-mono uppercase">
                    <span>Featured Snippets</span>
                    <Sparkles className="h-4 w-4 text-purple-400" />
                  </div>
                  <div className="text-3xl font-extrabold text-slate-100 mt-2">{data.metadata.featureCounts.featuredSnippet}</div>
                  <div className="text-xs text-slate-400 mt-1">
                    {Math.round((data.metadata.featureCounts.featuredSnippet / (data.metadata.analysedCount || 1)) * 100)}% de cobertura nas SERPs
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl">
                  <div className="flex items-center justify-between text-slate-400 text-xs font-mono uppercase">
                    <span>Outras Features Google</span>
                    <Globe className="h-4 w-4 text-emerald-400" />
                  </div>
                  <div className="text-3xl font-extrabold text-slate-100 mt-2">
                    {data.metadata.featureCounts.featuredSnippet + data.metadata.featureCounts.peopleAlsoAsk + data.metadata.featureCounts.faq + data.metadata.featureCounts.videos + data.metadata.featureCounts.imagens + data.metadata.featureCounts.localPack}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    FAQs: {data.metadata.featureCounts.faq} | Vídeos: {data.metadata.featureCounts.videos} | Imagens: {data.metadata.featureCounts.imagens}
                  </div>
                </div>
              </div>

              {/* Intent and Features Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Search Intent Distribution */}
                <div className="bg-slate-900/20 border border-slate-800 rounded-xl p-5">
                  <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800/80 pb-3 flex items-center gap-2">
                    <BarChart2 className="h-4 w-4 text-cyan-400" />
                    Distribuição da Intenção de Busca
                  </h3>
                  <div className="mt-4 space-y-3.5">
                    {Object.entries(data.metadata.intentDistribution).map(([intent, count]) => {
                      const countNum = Number(count);
                      const percentage = Math.round((countNum / (data.metadata.analysedCount || 1)) * 100);
                      let barColor = "bg-cyan-500";
                      if (intent === "Local") barColor = "bg-emerald-500";
                      if (intent === "Transacional") barColor = "bg-rose-500";
                      if (intent === "Educacional") barColor = "bg-amber-500";
                      if (intent === "Comercial") barColor = "bg-indigo-500";

                      return (
                        <div key={intent}>
                          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                            <span className="font-medium text-slate-300">{intent}</span>
                            <span>{countNum} {countNum === 1 ? 'consulta' : 'consultas'} ({percentage}%)</span>
                          </div>
                          <div className="h-2 bg-slate-850 rounded-full overflow-hidden">
                            <div className={`h-full ${barColor}`} style={{ width: `${percentage}%` }} />
                          </div>
                        </div>
                      );
                    })}
                    {Object.keys(data.metadata.intentDistribution).length === 0 && (
                      <p className="text-xs text-slate-500 text-center py-6">Nenhuma análise disponível para calcular distribuição.</p>
                    )}
                  </div>
                </div>

                {/* Features Coverage */}
                <div className="bg-slate-900/20 border border-slate-800 rounded-xl p-5">
                  <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800/80 pb-3 flex items-center gap-2">
                    <Layout className="h-4 w-4 text-emerald-400" />
                    Presença de Features Complexas na SERP
                  </h3>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-cyan-950/30 text-cyan-400 border border-cyan-900/30">
                        <FileText className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-500 font-mono uppercase">Featured Snippets</div>
                        <div className="text-sm font-bold text-slate-200 mt-0.5">{data.metadata.featureCounts.featuredSnippet} ocorridos</div>
                      </div>
                    </div>

                    <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-emerald-950/30 text-emerald-400 border border-emerald-900/30">
                        <HelpCircle className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-500 font-mono uppercase">People Also Ask (PAA)</div>
                        <div className="text-sm font-bold text-slate-200 mt-0.5">{data.metadata.featureCounts.peopleAlsoAsk} ocorridos</div>
                      </div>
                    </div>

                    <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-purple-950/30 text-purple-400 border border-purple-900/30">
                        <MessageSquare className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-500 font-mono uppercase">FAQs Estruturados</div>
                        <div className="text-sm font-bold text-slate-200 mt-0.5">{data.metadata.featureCounts.faq} ocorridos</div>
                      </div>
                    </div>

                    <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-amber-950/30 text-amber-400 border border-amber-900/30">
                        <TrendingUp className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-500 font-mono uppercase">Painel de Conhecimento</div>
                        <div className="text-sm font-bold text-slate-200 mt-0.5">0 detectados</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Explanatory Info Card */}
              <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl flex items-start gap-4">
                <div className="p-3 bg-cyan-950/30 rounded-lg border border-cyan-900/40 text-cyan-400 shrink-0">
                  <Activity className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-200 text-sm">Próximo Passo Automatizado da Engine:</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Nesta sprint, toda a estrutura técnica do motor de SERP está pronta e persistindo de forma síncrona. A alimentação está em modo **Estratégico Manual**. Nas próximas iterações do Organic Traffic OS, adicionaremos ganchos automáticos de consulta via APIs do Google para atualizar as posições e mudanças de algoritmos de forma passiva.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Consultas da SERP */}
          {activeSubTab === "queries" && (
            <div className="space-y-6">
              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Buscar consultas ou clusters estratégicos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 pl-9 pr-4 text-sm text-slate-300 focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-slate-300 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500"
                >
                  <option value="all">Todas as Categorias</option>
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Grid with Query list and details */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* List - Left side */}
                <div className={`bg-slate-900/40 border border-slate-800 rounded-xl overflow-hidden ${selectedQueryId ? 'lg:col-span-5' : 'lg:col-span-12'}`}>
                  <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">
                      Filas de Consultas
                    </h3>
                    <span className="text-xs text-slate-500">
                      Exibindo {filteredQueries.length} resultados
                    </span>
                  </div>

                  <div className="divide-y divide-slate-800/60 max-h-[600px] overflow-y-auto">
                    {filteredQueries.map(q => {
                      const isSelected = q.id === selectedQueryId;
                      return (
                        <div
                          key={q.id}
                          onClick={() => setSelectedQueryId(isSelected ? null : q.id)}
                          className={`p-4 transition cursor-pointer flex items-center justify-between gap-3 hover:bg-slate-850/40 ${
                            isSelected ? 'bg-cyan-950/20 border-l-4 border-cyan-500 pl-3' : ''
                          }`}
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="text-sm font-bold text-slate-200 truncate font-mono">
                              "{q.query}"
                            </div>
                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              <span className="text-slate-500 font-mono">{q.cluster}</span>
                              <span className="text-slate-600">•</span>
                              <span className="text-slate-400">{q.categoria}</span>
                              {q.cidade && (
                                <>
                                  <span className="text-slate-600">•</span>
                                  <span className="text-slate-400 flex items-center gap-0.5">
                                    <Globe className="h-3 w-3 inline text-slate-500" />
                                    {q.cidade}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2.5 shrink-0">
                            {q.status === "analisado" ? (
                              <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                <CheckCircle2 className="h-3 w-3" />
                                Analisado
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                <Clock className="h-3 w-3" />
                                Pendente
                              </span>
                            )}
                            <ChevronRight className="h-4 w-4 text-slate-600" />
                          </div>
                        </div>
                      );
                    })}

                    {filteredQueries.length === 0 && (
                      <div className="p-8 text-center text-slate-500 text-xs">
                        Nenhuma consulta correspondente aos critérios encontrados.
                      </div>
                    )}
                  </div>
                </div>

                {/* Details - Right side */}
                {selectedQueryId && (
                  <div className="lg:col-span-7 space-y-6">
                    {selectedQuery && (
                      <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 space-y-6">
                        {/* Detail Header */}
                        <div className="border-b border-slate-800/80 pb-4 flex items-start justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-cyan-400 font-mono uppercase tracking-wider">{selectedQuery.categoria}</span>
                              <span className="text-slate-700">|</span>
                              <span className="text-xs text-slate-400 font-mono">{selectedQuery.cluster}</span>
                            </div>
                            <h2 className="text-lg font-bold text-slate-100 mt-1 font-mono">"{selectedQuery.query}"</h2>
                            <p className="text-slate-400 text-xs mt-1">
                              ID: <span className="font-mono">{selectedQuery.id}</span> • Última atualização:{" "}
                              {selectedQuery.ultima_analise ? new Date(selectedQuery.ultima_analise).toLocaleString() : "Nunca"}
                            </p>
                          </div>
                          <button
                            onClick={() => setSelectedQueryId(null)}
                            className="text-xs text-slate-500 hover:text-slate-300"
                          >
                            Fechar Detalhes
                          </button>
                        </div>

                        {selectedQuery.status === "pendente" ? (
                          <div className="text-center py-10 bg-slate-950/40 rounded-xl border border-dashed border-slate-800">
                            <Clock className="h-10 w-10 text-amber-500 mx-auto" />
                            <h4 className="font-semibold text-slate-300 mt-3">Consulta Pendente de Processamento</h4>
                            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                              Esta consulta está agendada para varredura. Você pode alimentá-la com resultados inserindo uma nova análise.
                            </p>
                          </div>
                        ) : (
                          <>
                            {/* Intent & Content Patterns summaries */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {/* Intent */}
                              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/60">
                                <h4 className="text-xs font-mono text-slate-400 uppercase flex items-center gap-1">
                                  <Sliders className="h-3.5 w-3.5 text-cyan-400" />
                                  Intenção de Busca
                                </h4>
                                <div className="mt-2 flex items-center gap-2">
                                  <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                    {selectedIntent?.intencao || "Informacional"}
                                  </span>
                                  <span className="text-xs text-slate-400">Predominante</span>
                                </div>
                                <p className="text-xs text-slate-400 mt-2 italic leading-relaxed">
                                  "{selectedIntent?.observacoes}"
                                </p>
                              </div>

                              {/* Content Pattern summary */}
                              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/60">
                                <h4 className="text-xs font-mono text-slate-400 uppercase flex items-center gap-1">
                                  <AlignLeft className="h-3.5 w-3.5 text-emerald-400" />
                                  Tamanho & Estrutura
                                </h4>
                                <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                                  <div>
                                    <span className="text-slate-500">Média Palavras:</span>
                                    <div className="font-bold text-slate-200 mt-0.5">{selectedPattern?.tamanhoMedio || 1500} palavras</div>
                                  </div>
                                  <div>
                                    <span className="text-slate-500">H2 / H3 Médios:</span>
                                    <div className="font-bold text-slate-200 mt-0.5">{selectedPattern?.quantidadeMediaH2 || 5} H2 / {selectedPattern?.quantidadeMediaH3 || 8} H3</div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* SERP Features detail */}
                            {selectedFeatures && (
                              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/60 space-y-3">
                                <h4 className="text-xs font-mono text-slate-400 uppercase flex items-center gap-1 border-b border-slate-800/60 pb-2">
                                  <Sparkles className="h-3.5 w-3.5 text-purple-400" />
                                  Recursos Especiais da SERP (Features)
                                </h4>

                                {selectedFeatures.featuredSnippet?.presente && (
                                  <div className="p-3 bg-purple-950/10 border border-purple-900/30 rounded-lg space-y-1.5">
                                    <div className="flex items-center justify-between text-[11px]">
                                      <span className="font-bold text-purple-400 flex items-center gap-1">
                                        <Award className="h-3 w-3" />
                                        Featured Snippet Ativo
                                      </span>
                                      <span className="text-slate-500 font-mono text-[10px]">Detentor: {selectedFeatures.featuredSnippet.detentor}</span>
                                    </div>
                                    <p className="text-xs text-slate-300 italic">
                                      "{selectedFeatures.featuredSnippet.texto}"
                                    </p>
                                  </div>
                                )}

                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                                  <div className={`px-2 py-1 rounded text-center text-[10px] font-mono border ${
                                    selectedFeatures.faq ? 'bg-emerald-500/5 border-emerald-900/30 text-emerald-400' : 'bg-slate-900/20 border-slate-850 text-slate-600'
                                  }`}>
                                    FAQ Schema
                                  </div>
                                  <div className={`px-2 py-1 rounded text-center text-[10px] font-mono border ${
                                    selectedFeatures.videos ? 'bg-emerald-500/5 border-emerald-900/30 text-emerald-400' : 'bg-slate-900/20 border-slate-850 text-slate-600'
                                  }`}>
                                    Carrossel Vídeos
                                  </div>
                                  <div className={`px-2 py-1 rounded text-center text-[10px] font-mono border ${
                                    selectedFeatures.imagens ? 'bg-emerald-500/5 border-emerald-900/30 text-emerald-400' : 'bg-slate-900/20 border-slate-850 text-slate-600'
                                  }`}>
                                    Imagens
                                  </div>
                                  <div className={`px-2 py-1 rounded text-center text-[10px] font-mono border ${
                                    selectedFeatures.richResults ? 'bg-emerald-500/5 border-emerald-900/30 text-emerald-400' : 'bg-slate-900/20 border-slate-850 text-slate-600'
                                  }`}>
                                    Rich Results
                                  </div>
                                </div>

                                {selectedFeatures.peopleAlsoAsk && selectedFeatures.peopleAlsoAsk.length > 0 && (
                                  <div className="space-y-1.5 pt-2">
                                    <h5 className="text-[10px] uppercase font-mono text-slate-500">As Pessoas Também Perguntam:</h5>
                                    <ul className="text-xs text-slate-400 space-y-1 bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                                      {selectedFeatures.peopleAlsoAsk.map((q, idx) => (
                                        <li key={idx} className="flex items-start gap-1.5">
                                          <span className="text-cyan-500 shrink-0">•</span>
                                          <span>{q}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Ranking list */}
                            <div className="space-y-3">
                              <h4 className="text-xs font-mono text-slate-400 uppercase flex items-center gap-1.5">
                                <ListOrdered className="h-4 w-4 text-cyan-400" />
                                Mapeamento Orgânico das Posições (1-10)
                              </h4>

                              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                                {selectedResults.map(res => {
                                  let typeBg = "bg-slate-800 text-slate-300";
                                  if (res.tipo === "blog") typeBg = "bg-cyan-950/40 text-cyan-400 border border-cyan-900/30";
                                  if (res.tipo === "governo") typeBg = "bg-emerald-950/40 text-emerald-400 border border-emerald-900/30";
                                  if (res.tipo === "pdf") typeBg = "bg-rose-950/40 text-rose-400 border border-rose-900/30";

                                  const isPassacumaru = res.dominio.includes("passacumaru");

                                  return (
                                    <div 
                                      key={res.id} 
                                      className={`p-3 bg-slate-950/80 rounded-lg border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs transition hover:border-slate-700 ${
                                        isPassacumaru ? 'border-amber-500/40 bg-amber-950/5' : 'border-slate-800/80'
                                      }`}
                                    >
                                      <div className="flex items-start gap-3 min-w-0">
                                        <span className={`h-6 w-6 rounded-full flex items-center justify-center font-bold font-mono text-[11px] shrink-0 ${
                                          res.posicao === 1 ? 'bg-amber-500 text-slate-950' : 
                                          res.posicao === 2 ? 'bg-slate-300 text-slate-950' : 
                                          res.posicao === 3 ? 'bg-amber-700 text-slate-100' : 
                                          'bg-slate-850 text-slate-400'
                                        }`}>
                                          {res.posicao}
                                        </span>
                                        <div className="min-w-0">
                                          <div className="font-bold text-slate-200 truncate flex items-center gap-1.5">
                                            {res.titulo}
                                            {isPassacumaru && (
                                              <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500 text-slate-950 font-bold uppercase">
                                                Nosso Blog
                                              </span>
                                            )}
                                          </div>
                                          <p className="text-[11px] text-slate-400 truncate mt-0.5">{res.url}</p>
                                          <p className="text-[11px] text-slate-500 italic truncate mt-1">"{res.descricao}"</p>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${typeBg}`}>
                                          {res.tipo}
                                        </span>
                                        <a 
                                          href={res.url} 
                                          target="_blank" 
                                          rel="referrer" 
                                          className="p-1 bg-slate-900 border border-slate-800 rounded text-slate-500 hover:text-slate-300 transition"
                                        >
                                          <ArrowUpRight className="h-3 w-3" />
                                        </a>
                                      </div>
                                    </div>
                                  );
                                })}

                                {selectedResults.length === 0 && (
                                  <p className="text-xs text-slate-500 text-center py-4">Nenhum resultado orgânico cadastrado para esta consulta.</p>
                                )}
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: Padrões de Conteúdo */}
          {activeSubTab === "patterns" && (
            <div className="space-y-6 bg-slate-900/40 border border-slate-800 rounded-xl p-5">
              <div className="border-b border-slate-800 pb-4">
                <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
                  <TableProperties className="h-4 w-4 text-cyan-400" />
                  Mapeamento Geral de Padrões Editoriais (Google SERP)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Mapeie o que o Google considera um conteúdo vencedor com base nos cabeçalhos, uso de tabelas, FAQs e tamanho médio de palavras por pauta.
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-mono text-[10px] uppercase">
                      <th className="py-3 px-4 font-normal">Consulta / Palavra-Chave</th>
                      <th className="py-3 px-4 font-normal">Média Palavras</th>
                      <th className="py-3 px-4 font-normal">Qtd H2</th>
                      <th className="py-3 px-4 font-normal">Qtd H3</th>
                      <th className="py-3 px-4 font-normal">Faq Schema</th>
                      <th className="py-3 px-4 font-normal">Tabelas</th>
                      <th className="py-3 px-4 font-normal">Listas</th>
                      <th className="py-3 px-4 font-normal">Schema.org</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {data.patterns.map(pat => {
                      const queryObj = data.queries.find(q => q.id === pat.queryId);
                      return (
                        <tr key={pat.queryId} className="hover:bg-slate-850/20 text-slate-300">
                          <td className="py-3 px-4 font-sans font-bold text-slate-200">
                            {queryObj ? `"${queryObj.query}"` : pat.queryId}
                          </td>
                          <td className="py-3 px-4 text-cyan-400 font-bold">{pat.tamanhoMedio} palavras</td>
                          <td className="py-3 px-4">{pat.quantidadeMediaH2} H2</td>
                          <td className="py-3 px-4">{pat.quantidadeMediaH3} H3</td>
                          <td className="py-3 px-4">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                              pat.usoDeFaq === "Alto" || pat.usoDeFaq === "Altíssimo" ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-950 text-slate-500"
                            }`}>{pat.usoDeFaq}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                              pat.usoDeTabelas === "Alto" || pat.usoDeTabelas === "Altíssimo" ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-950 text-slate-500"
                            }`}>{pat.usoDeTabelas}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                              pat.usoDeListas === "Alto" || pat.usoDeListas === "Altíssimo" ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-950 text-slate-500"
                            }`}>{pat.usoDeListas}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                              pat.usoDeSchema === "Alto" || pat.usoDeSchema === "Altíssimo" ? "bg-cyan-500/10 text-cyan-400" : "bg-slate-950 text-slate-500"
                            }`}>{pat.usoDeSchema}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: Oportunidades de SERP */}
          {activeSubTab === "opportunities" && (
            <div className="space-y-6">
              {/* Opportunities List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {data.opportunities.map(opp => {
                  let potColor = "text-slate-400 bg-slate-900";
                  if (opp.potencial === "Explosivo") potColor = "text-amber-400 bg-amber-500/10 border-amber-500/20";
                  if (opp.potencial === "Alto") potColor = "text-cyan-400 bg-cyan-500/10 border-cyan-500/20";

                  let prioColor = "text-slate-400 bg-slate-900";
                  if (opp.prioridade === "Crítica") prioColor = "text-red-400 bg-red-500/10 border-red-500/20";
                  if (opp.prioridade === "Alta") prioColor = "text-amber-400 bg-amber-500/10 border-amber-500/20";

                  return (
                    <div key={opp.id} className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex items-center justify-between gap-2 border-b border-slate-800/60 pb-2">
                          <span className="text-[10px] font-mono text-slate-500 uppercase">ID: {opp.id}</span>
                          <span className="text-xs px-2 py-0.5 rounded bg-cyan-950/40 text-cyan-400 font-semibold">{opp.status}</span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-200 font-mono mt-3">"{opp.consulta}"</h4>
                        <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                          <span className="font-semibold text-slate-300 block mb-1">Motivo / Lacuna:</span>
                          {opp.motivo}
                        </p>
                        {opp.observações && (
                          <p className="text-xs text-amber-300/80 mt-2 leading-relaxed bg-slate-950 p-2.5 rounded-lg border border-slate-850 italic">
                            💡 {opp.observações}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-3 pt-2">
                        <div className="text-xs">
                          <span className="text-slate-500">Potencial:</span>
                          <span className={`ml-1.5 px-2 py-0.5 rounded text-[10px] font-bold border ${potColor}`}>{opp.potencial}</span>
                        </div>
                        <div className="text-xs">
                          <span className="text-slate-500">Prioridade:</span>
                          <span className={`ml-1.5 px-2 py-0.5 rounded text-[10px] font-bold border ${prioColor}`}>{opp.prioridade}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Form to Register Opportunity */}
              <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl space-y-4">
                <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
                  <PlusCircle className="h-4 w-4 text-amber-400" />
                  Cadastrar Nova Oportunidade de SERP
                </h3>
                <form onSubmit={handleCreateOpportunity} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-400 uppercase">Consulta de Busca *</label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: concurso passa e fica rn lei municipal"
                      value={newOpp.consulta}
                      onChange={(e) => setNewOpp({ ...newOpp, consulta: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-400 uppercase">Nível de Prioridade</label>
                    <select
                      value={newOpp.prioridade}
                      onChange={(e) => setNewOpp({ ...newOpp, prioridade: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Baixa">Baixa</option>
                      <option value="Média">Média</option>
                      <option value="Alta">Alta</option>
                      <option value="Crítica">Crítica</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-400 uppercase">Potencial de Conversão/Tráfego</label>
                    <select
                      value={newOpp.potencial}
                      onChange={(e) => setNewOpp({ ...newOpp, potencial: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Baixo">Baixo</option>
                      <option value="Médio">Médio</option>
                      <option value="Alto">Alto</option>
                      <option value="Explosivo">Explosivo</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-400 uppercase">Status</label>
                    <select
                      value={newOpp.status}
                      onChange={(e) => setNewOpp({ ...newOpp, status: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Mapeado">Mapeado</option>
                      <option value="Em Progresso">Em Progresso</option>
                      <option value="Implementado">Implementado</option>
                    </select>
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-xs font-mono text-slate-400 uppercase">Brecha da Concorrência / Motivo do Alvo *</label>
                    <textarea
                      required
                      rows={3}
                      placeholder="Explique qual a falha nos resultados atuais que podemos atacar..."
                      value={newOpp.motivo}
                      onChange={(e) => setNewOpp({ ...newOpp, motivo: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-xs font-mono text-slate-400 uppercase">Observações Estratégicas</label>
                    <textarea
                      rows={2}
                      placeholder="Ideia de isca digital, infográfico, ou pauta..."
                      value={newOpp.observações}
                      onChange={(e) => setNewOpp({ ...newOpp, observações: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="md:col-span-2 flex justify-end">
                    <button
                      type="submit"
                      disabled={submitting}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-900 font-bold rounded-lg text-xs transition uppercase"
                    >
                      {submitting ? "Gravando Oportunidade..." : "Registrar Oportunidade"}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 5: Alimentar Engine (Manual) */}
          {activeSubTab === "add" && (
            <div className="bg-slate-900/40 border border-slate-800 p-5 rounded-xl space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">
                  Cadastrar e Analisar Nova Consulta (Alimentação Manual)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Insira o resultado de uma consulta real do Google para que o motor cataloge as métricas estruturais.
                </p>
              </div>

              {formSuccess && (
                <div className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-lg text-emerald-400 text-xs font-medium">
                  {formSuccess}
                </div>
              )}

              <form onSubmit={handleCreateQuery} className="space-y-6">
                {/* Section 1: Query Details */}
                <div className="space-y-4">
                  <h4 className="text-xs font-semibold text-cyan-400 font-mono uppercase tracking-wider border-b border-slate-800 pb-1.5">
                    1. Dados Básicos da Consulta de Busca
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1.5 col-span-1 md:col-span-2">
                      <label className="text-xs font-mono text-slate-400 uppercase">Consulta de Busca *</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: concurso nova cruz rn vagas"
                        value={newQuery.query}
                        onChange={(e) => setNewQuery({ ...newQuery, query: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 font-mono"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-slate-400 uppercase">Categoria</label>
                      <select
                        value={newQuery.categoria}
                        onChange={(e) => setNewQuery({ ...newQuery, categoria: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                      >
                        <option value="Inscrições">Inscrições</option>
                        <option value="Gabarito">Gabarito</option>
                        <option value="Estudo de Leis">Estudo de Leis</option>
                        <option value="Concorrência">Concorrência</option>
                        <option value="Resultado">Resultado</option>
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-slate-400 uppercase">Cluster Estratégico</label>
                      <input
                        type="text"
                        placeholder="Ex: Concurso Nova Cruz"
                        value={newQuery.cluster}
                        onChange={(e) => setNewQuery({ ...newQuery, cluster: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-slate-400 uppercase">Município RN Alvo</label>
                      <input
                        type="text"
                        placeholder="Ex: Nova Cruz"
                        value={newQuery.cidade}
                        onChange={(e) => setNewQuery({ ...newQuery, cidade: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-slate-400 uppercase">Status Inicial</label>
                      <select
                        value={newQuery.status}
                        onChange={(e) => setNewQuery({ ...newQuery, status: e.target.value as "analisado" | "pendente" })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
                      >
                        <option value="analisado">Analisar Imediatamente</option>
                        <option value="pendente">Apenas Agendar Varredura (Pendente)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {newQuery.status === "analisado" && (
                  <>
                    {/* Section 2: SERP Results */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                        <h4 className="text-xs font-semibold text-cyan-400 font-mono uppercase tracking-wider">
                          2. Mapeamento de Resultados Orgânicos do Google
                        </h4>
                        <button
                          type="button"
                          onClick={addResultRow}
                          className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
                        >
                          <PlusCircle className="h-3.5 w-3.5" />
                          Adicionar Linha (Max 10)
                        </button>
                      </div>

                      <div className="space-y-3">
                        {newResults.map((res, index) => (
                          <div key={index} className="grid grid-cols-1 sm:grid-cols-12 gap-2 bg-slate-950/40 p-3 rounded-lg border border-slate-800/80">
                            <div className="sm:col-span-1 flex items-center justify-center font-bold text-slate-400">
                              #{index + 1}
                            </div>
                            <div className="sm:col-span-3">
                              <input
                                type="text"
                                placeholder="Título do Resultado"
                                value={res.titulo}
                                onChange={(e) => handleResultChange(index, "titulo", e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300 focus:outline-none"
                              />
                            </div>
                            <div className="sm:col-span-4">
                              <input
                                type="text"
                                placeholder="URL Completa"
                                value={res.url}
                                onChange={(e) => {
                                  const url = e.target.value;
                                  let dom = "";
                                  try {
                                    dom = new URL(url).hostname;
                                  } catch {
                                    dom = "";
                                  }
                                  handleResultChange(index, "url", url);
                                  if (dom) handleResultChange(index, "dominio", dom);
                                }}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300 focus:outline-none"
                              />
                            </div>
                            <div className="sm:col-span-2">
                              <input
                                type="text"
                                placeholder="Domínio"
                                value={res.dominio}
                                onChange={(e) => handleResultChange(index, "dominio", e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300 focus:outline-none font-mono text-[10px]"
                              />
                            </div>
                            <div className="sm:col-span-2">
                              <select
                                value={res.tipo}
                                onChange={(e) => handleResultChange(index, "tipo", e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300 focus:outline-none"
                              >
                                <option value="blog">Blog</option>
                                <option value="governo">Portal Governo</option>
                                <option value="pdf">Documento PDF</option>
                                <option value="vídeo">Vídeo YouTube</option>
                                <option value="fórum">Fórum</option>
                              </select>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Section 3: SERP Features */}
                    <div className="space-y-4">
                      <h4 className="text-xs font-semibold text-cyan-400 font-mono uppercase tracking-wider border-b border-slate-800 pb-1.5">
                        3. Presença de Google SERP Features
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-3 bg-slate-950/40 p-4 rounded-lg border border-slate-800">
                          <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newFeatures.featuredSnippet.presente}
                              onChange={(e) => setNewFeatures({
                                ...newFeatures,
                                featuredSnippet: { ...newFeatures.featuredSnippet, presente: e.target.checked }
                              })}
                              className="accent-cyan-500 rounded"
                            />
                            Featured Snippet Ativo nesta busca?
                          </label>

                          {newFeatures.featuredSnippet.presente && (
                            <div className="space-y-2 mt-2">
                              <input
                                type="text"
                                placeholder="Site dono do Snippet (ex: aprovarn.com.br)"
                                value={newFeatures.featuredSnippet.detentor}
                                onChange={(e) => setNewFeatures({
                                  ...newFeatures,
                                  featuredSnippet: { ...newFeatures.featuredSnippet, detentor: e.target.value }
                                })}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300"
                              />
                              <textarea
                                placeholder="Texto do featured snippet..."
                                rows={2}
                                value={newFeatures.featuredSnippet.texto}
                                onChange={(e) => setNewFeatures({
                                  ...newFeatures,
                                  featuredSnippet: { ...newFeatures.featuredSnippet, texto: e.target.value }
                                })}
                                className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300"
                              />
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3 p-4 bg-slate-950/40 rounded-lg border border-slate-800">
                          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newFeatures.faq}
                              onChange={(e) => setNewFeatures({ ...newFeatures, faq: e.target.checked })}
                              className="accent-cyan-500"
                            />
                            Schema FAQ ativo
                          </label>
                          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newFeatures.videos}
                              onChange={(e) => setNewFeatures({ ...newFeatures, videos: e.target.checked })}
                              className="accent-cyan-500"
                            />
                            Vídeos incorporados
                          </label>
                          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newFeatures.imagens}
                              onChange={(e) => setNewFeatures({ ...newFeatures, imagens: e.target.checked })}
                              className="accent-cyan-500"
                            />
                            Imagens carrossel
                          </label>
                          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newFeatures.localPack}
                              onChange={(e) => setNewFeatures({ ...newFeatures, localPack: e.target.checked })}
                              className="accent-cyan-500"
                            />
                            Local Map Pack
                          </label>
                        </div>
                      </div>
                    </div>

                    {/* Section 4: Structural patterns and Intent */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                      {/* Intent Classification */}
                      <div className="space-y-4">
                        <h4 className="text-xs font-semibold text-cyan-400 font-mono uppercase tracking-wider border-b border-slate-800 pb-1.5">
                          4. Classificação de Intenção de Busca
                        </h4>
                        <div className="bg-slate-950/40 p-4 rounded-lg border border-slate-800 space-y-4">
                          <div className="space-y-1.5">
                            <label className="text-xs text-slate-400">Tipo de Intenção Predominante</label>
                            <select
                              value={newIntent.intencao}
                              onChange={(e) => setNewIntent({ ...newIntent, intencao: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-300 focus:outline-none"
                            >
                              <option value="Informacional">Informacional (Aprender sobre algo)</option>
                              <option value="Educacional">Educacional (Didática/Questões/Materiais)</option>
                              <option value="Local">Local (Busca focada no município específico)</option>
                              <option value="Transacional">Transacional (Banca/Inscrições/Baixar gabaritos)</option>
                              <option value="Comercial">Comercial (Comparação de materiais pagos)</option>
                              <option value="Navegacional">Navegacional (Site direto da banca)</option>
                            </select>
                          </div>
                          <div className="space-y-1.5">
                            <label className="text-xs text-slate-400">Observações sobre a jornada do usuário</label>
                            <textarea
                              rows={2}
                              placeholder="O usuário busca as inscrições direto para se inscrever ou quer bizus?"
                              value={newIntent.observacoes}
                              onChange={(e) => setNewIntent({ ...newIntent, observacoes: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-300"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Content Patterns */}
                      <div className="space-y-4">
                        <h4 className="text-xs font-semibold text-cyan-400 font-mono uppercase tracking-wider border-b border-slate-800 pb-1.5">
                          5. Padrões de Conteúdo Detectados
                        </h4>
                        <div className="bg-slate-950/40 p-4 rounded-lg border border-slate-800 grid grid-cols-2 gap-3.5">
                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-500 font-mono uppercase">Média Palavras</label>
                            <input
                              type="number"
                              value={newPatterns.tamanhoMedio}
                              onChange={(e) => setNewPatterns({ ...newPatterns, tamanhoMedio: Number(e.target.value) })}
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300 font-mono"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-500 font-mono uppercase">Qtd H2 Médios</label>
                            <input
                              type="number"
                              value={newPatterns.quantidadeMediaH2}
                              onChange={(e) => setNewPatterns({ ...newPatterns, quantidadeMediaH2: Number(e.target.value) })}
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300 font-mono"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-500 font-mono uppercase">Uso de Tabelas</label>
                            <select
                              value={newPatterns.usoDeTabelas}
                              onChange={(e) => setNewPatterns({ ...newPatterns, usoDeTabelas: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300"
                            >
                              <option value="Baixo">Baixo</option>
                              <option value="Médio">Médio</option>
                              <option value="Alto">Alto</option>
                              <option value="Altíssimo">Altíssimo</option>
                            </select>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-500 font-mono uppercase">Uso de FAQ</label>
                            <select
                              value={newPatterns.usoDeFaq}
                              onChange={(e) => setNewPatterns({ ...newPatterns, usoDeFaq: e.target.value })}
                              className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-xs text-slate-300"
                            >
                              <option value="Baixo">Baixo</option>
                              <option value="Médio">Médio</option>
                              <option value="Alto">Alto</option>
                              <option value="Altíssimo">Altíssimo</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                <div className="flex justify-end pt-4 border-t border-slate-800">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-900 font-extrabold rounded-lg text-xs transition uppercase tracking-wider shadow-lg shadow-cyan-950/25"
                  >
                    {submitting ? "Gravando no Banco..." : "Salvar Análise de SERP"}
                  </button>
                </div>
              </form>
            </div>
          )}
        </>
      )}
    </div>
  );
}
