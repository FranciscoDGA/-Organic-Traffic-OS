import React, { useState, useEffect } from "react";
import { 
  Play, Cpu, Layers, Activity, Database, ScrollText, CheckCircle, 
  AlertTriangle, Trash2, Settings, DollarSign, Clock, ArrowRight, 
  BookOpen, Users, Target, Compass, HelpCircle, GitMerge, Check, Loader2, RefreshCw
} from "lucide-react";
import { OrganicKnowledgeCore } from "./components/OrganicKnowledgeCore";
import { OrganicInventory } from "./components/OrganicInventory";
import { OrganicCompetitors } from "./components/OrganicCompetitors";
import { OrganicSerp } from "./components/OrganicSerp";
import { OrganicKeywords } from "./components/OrganicKeywords";
import { OrganicCollectors } from "./components/OrganicCollectors";
import { OrganicOpportunities } from "./components/OrganicOpportunities";
import { OrganicEditorial } from "./components/OrganicEditorial";
import { OrganicBriefs } from "./components/OrganicBriefs";
import { OrganicBlueprints } from "./components/OrganicBlueprints";
import { OrganicResearch } from "./components/OrganicResearch";
import { OrganicFacts } from "./components/OrganicFacts";
import { OrganicSources } from "./components/OrganicSources";
import { OrganicWorkflows } from "./components/OrganicWorkflows";
import { OrganicSystem } from "./components/OrganicSystem";
import { OrganicStrategy } from "./components/OrganicStrategy";
import { OrganicDrafts } from "./components/OrganicDrafts";
import { OrganicQuality } from "./components/OrganicQuality";
import { OrganicAudience } from "./components/OrganicAudience";
import { OrganicLanguage } from "./components/OrganicLanguage";
import { OrganicVisibility } from "./components/OrganicVisibility";
import { OrganicAssets } from "./components/OrganicAssets";
import OrganicPublishing from "./components/OrganicPublishing";
import OrganicPerformance from "./components/OrganicPerformance";
import { OrganicE2e } from "./components/OrganicE2e";
import { OrganicSearch } from "./components/OrganicSearch";
import { OrganicArchitecture } from "./components/OrganicArchitecture";


// Types corresponding to shared structures
interface AgentManifest {
  id: string;
  name: string;
  category: string;
  version: string;
  defaultProvider: string;
  capabilities: string[];
  input: string;
  output: string;
  dependencies: string[];
  priority: number;
  timeout: number;
}

interface ModuleManifest {
  name: string;
  version: string;
  dependencies: string[];
  agents: string[];
  workflows: string[];
  routes: string[];
  permissions: string[];
}

interface Task {
  id: string;
  moduleId: string;
  agentId: string;
  input: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  priority: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  result?: any;
  error?: string;
  cost?: {
    provider: string;
    model: string;
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    estimatedCostUSD: number;
  };
}

interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  source: 'runtime' | 'dispatcher' | 'executor' | 'queue' | 'provider' | 'agent';
  message: string;
  taskId?: string;
  metadata?: Record<string, any>;
}

interface KnowledgeItem {
  id: string;
  category: 'blogs' | 'products' | 'personas' | 'competitors' | 'rules' | 'tone' | 'memory';
  title: string;
  content: string;
  updatedAt: string;
}

interface Metrics {
  status: 'idle' | 'running' | 'paused';
  agentCount: number;
  moduleCount: number;
  queueDepth: number;
  successRate: number;
  aiUsage: {
    totalTasks: number;
    completed: number;
    failed: number;
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    totalCostUSD: number;
  };
}

export default function App() {
  type Tab = 'dashboard' | 'queue' | 'agents' | 'knowledge' | 'organic-knowledge' | 'organic-inventory' | 'organic-competitors' | 'organic-serp' | 'organic-keywords' | 'organic-collectors' | 'organic-opportunities' | 'organic-editorial' | 'organic-briefs' | 'organic-blueprints' | 'organic-research' | 'organic-facts' | 'organic-sources' | 'organic-workflows' | 'organic-system' | 'architecture' | 'organic-strategy' | 'organic-drafts' | 'organic-quality' | 'organic-audience' | 'organic-language' | 'organic-visibility' | 'organic-assets' | 'organic-publishing' | 'organic-performance' | 'organic-e2e' | 'organic-search';

  
  const [activeTab, setActiveTab] = useState<Tab>(() => {
    if (window.location.pathname === "/organic-os/knowledge") return "organic-knowledge";
    if (window.location.pathname === "/organic-os/inventory") return "organic-inventory";
    if (window.location.pathname === "/organic-os/competitors") return "organic-competitors";
    if (window.location.pathname === "/organic-os/serp") return "organic-serp";
    if (window.location.pathname === "/organic-os/keywords") return "organic-keywords";
    if (window.location.pathname === "/organic-os/collectors") return "organic-collectors";
    if (window.location.pathname === "/organic-os/opportunities") return "organic-opportunities";
    if (window.location.pathname === "/organic-os/editorial") return "organic-editorial";
    if (window.location.pathname === "/organic-os/briefs") return "organic-briefs";
    if (window.location.pathname === "/organic-os/blueprints") return "organic-blueprints";
    if (window.location.pathname === "/organic-os/research") return "organic-research";
    if (window.location.pathname === "/organic-os/facts") return "organic-facts";
    if (window.location.pathname === "/organic-os/sources") return "organic-sources";
    if (window.location.pathname === "/organic-os/workflows") return "organic-workflows";
    if (window.location.pathname === "/organic-os/system") return "organic-system";
    if (window.location.pathname === "/organic-os/strategy") return "organic-strategy";
    if (window.location.pathname === "/organic-os/drafts") return "organic-drafts";
    if (window.location.pathname === "/organic-os/quality") return "organic-quality";
    if (window.location.pathname === "/organic-os/audience") return "organic-audience";
    if (window.location.pathname === "/organic-os/natural-language") return "organic-language";
    if (window.location.pathname === "/organic-os/visibility") return "organic-visibility";
    if (window.location.pathname === "/organic-os/assets") return "organic-assets";
    if (window.location.pathname === "/organic-os/publishing") return "organic-publishing";
    if (window.location.pathname === "/organic-os/performance") return "organic-performance";
    if (window.location.pathname === "/organic-os/e2e") return "organic-e2e";
    if (window.location.pathname === "/organic-os/search") return "organic-search";
    if (window.location.pathname === "/organic-os/architecture") return "architecture";

    return "dashboard";
  });

  const switchTab = (tab: Tab) => {
    setActiveTab(tab);
    if (tab === "organic-knowledge") {
      window.history.pushState(null, "", "/organic-os/knowledge");
    } else if (tab === "organic-inventory") {
      window.history.pushState(null, "", "/organic-os/inventory");
    } else if (tab === "organic-competitors") {
      window.history.pushState(null, "", "/organic-os/competitors");
    } else if (tab === "organic-serp") {
      window.history.pushState(null, "", "/organic-os/serp");
    } else if (tab === "organic-keywords") {
      window.history.pushState(null, "", "/organic-os/keywords");
    } else if (tab === "organic-collectors") {
      window.history.pushState(null, "", "/organic-os/collectors");
    } else if (tab === "organic-opportunities") {
      window.history.pushState(null, "", "/organic-os/opportunities");
    } else if (tab === "organic-editorial") {
      window.history.pushState(null, "", "/organic-os/editorial");
    } else if (tab === "organic-briefs") {
      window.history.pushState(null, "", "/organic-os/briefs");
    } else if (tab === "organic-blueprints") {
      window.history.pushState(null, "", "/organic-os/blueprints");
    } else if (tab === "organic-research") {
      window.history.pushState(null, "", "/organic-os/research");
    } else if (tab === "organic-facts") {
      window.history.pushState(null, "", "/organic-os/facts");
    } else if (tab === "organic-sources") {
      window.history.pushState(null, "", "/organic-os/sources");
    } else if (tab === "organic-workflows") {
      window.history.pushState(null, "", "/organic-os/workflows");
    } else if (tab === "organic-system") {
      window.history.pushState(null, "", "/organic-os/system");
    } else if (tab === "organic-strategy") {
      window.history.pushState(null, "", "/organic-os/strategy");
    } else if (tab === "organic-drafts") {
      window.history.pushState(null, "", "/organic-os/drafts");
    } else if (tab === "organic-quality") {
      window.history.pushState(null, "", "/organic-os/quality");
    } else if (tab === "organic-audience") {
      window.history.pushState(null, "", "/organic-os/audience");
    } else if (tab === "organic-language") {
      window.history.pushState(null, "", "/organic-os/natural-language");
    } else if (tab === "organic-visibility") {
      window.history.pushState(null, "", "/organic-os/visibility");
    } else if (tab === "organic-assets") {
      window.history.pushState(null, "", "/organic-os/assets");
    } else if (tab === "organic-publishing") {
      window.history.pushState(null, "", "/organic-os/publishing");
    } else if (tab === "organic-performance") {
      window.history.pushState(null, "", "/organic-os/performance");
    } else if (tab === "organic-e2e") {
      window.history.pushState(null, "", "/organic-os/e2e");
    } else if (tab === "organic-search") {
      window.history.pushState(null, "", "/organic-os/search");
    } else if (tab === "architecture") {
      window.history.pushState(null, "", "/organic-os/architecture");
    } else {
      window.history.pushState(null, "", "/");
    }
  };

  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [agents, setAgents] = useState<AgentManifest[]>([]);
  const [modules, setModules] = useState<ModuleManifest[]>([]);
  const [knowledge, setKnowledge] = useState<KnowledgeItem[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  // Interaction states
  const [selectedAgentId, setSelectedAgentId] = useState<string>("");
  const [taskPrompt, setTaskPrompt] = useState<string>("");
  const [taskPriority, setTaskPriority] = useState<number>(5);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [selectedTaskResult, setSelectedTaskResult] = useState<Task | null>(null);

  // Poll server state
  const fetchData = async () => {
    try {
      const [resMetrics, resAgents, resModules, resKnowledge, resTasks, resLogs] = await Promise.all([
        fetch("/api/runtime/metrics").then(r => r.json()),
        fetch("/api/runtime/agents").then(r => r.json()),
        fetch("/api/runtime/modules").then(r => r.json()),
        fetch("/api/runtime/knowledge").then(r => r.json()),
        fetch("/api/runtime/queue").then(r => r.json()),
        fetch("/api/runtime/logs").then(r => r.json())
      ]);

      setMetrics(resMetrics);
      setAgents(resAgents);
      setModules(resModules);
      setKnowledge(resKnowledge);
      setTasks(resTasks);
      setLogs(resLogs);

      // Auto select first agent for workspace if not set
      if (resAgents.length > 0 && !selectedAgentId) {
        setSelectedAgentId(resAgents[0].id);
        setTaskPrompt(getSuggestedPrompt(resAgents[0].id));
      }
    } catch (err) {
      console.error("Error pulling runtime state:", err);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 1500); // Poll every 1.5s
    return () => clearInterval(interval);
  }, [selectedAgentId]);

  const handleAgentChange = (id: string) => {
    setSelectedAgentId(id);
    setTaskPrompt(getSuggestedPrompt(id));
  };

  const getSuggestedPrompt = (id: string) => {
    switch (id) {
      case "agent-research":
        return "Analyze competitor URL: 'ahrefs.com/blog' and find keyword gaps relative to the local knowledge guidelines.";
      case "agent-seo":
        return "Raw Content Draft: 'AI Agency OS provides automated agent loops to completely replace manual content generation workflows.' Optimize this sentence with secondary tags.";
      case "agent-content":
        return "Write a comprehensive article outline targeting the Inbound Marketing Agency owner looking to deploy automated SEO agent networks.";
      case "agent-citation":
        return "Find reference authority sources and draft internal citation anchors for an article discussing automated Search Console rank indexing.";
      case "agent-analytics":
        return "Historical rankings show a decline in CTR from 4.2% to 2.8% on term 'AI SaaS workflow'. Calculate projected conversion impact and draft suggestions.";
      default:
        return "Enter custom prompt guidelines...";
    }
  };

  const handleEnqueueTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgentId || !taskPrompt.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/runtime/tasks/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agentId: selectedAgentId,
          input: taskPrompt,
          priority: taskPriority
        })
      });
      if (res.ok) {
        setTaskPrompt("");
        // Instantly poll updates
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClearLogs = async () => {
    try {
      await fetch("/api/runtime/logs/clear", { method: "POST" });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleClearQueue = async () => {
    try {
      await fetch("/api/runtime/queue/clear", { method: "POST" });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-[#f3f4f6] font-sans">
      {/* Header Bar */}
      <header className="border-b border-slate-800 bg-[#0d1424] px-6 py-4 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center space-between gap-3">
            <div className="bg-cyan-500/10 p-2 rounded-lg border border-cyan-500/20">
              <Cpu className="h-6 w-6 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono px-2 py-0.5 bg-slate-800 rounded text-slate-400 uppercase tracking-wider">v2.0 Architecture</span>
                <span className="text-xs font-mono px-2 py-0.5 bg-green-500/10 text-green-400 rounded uppercase tracking-wider border border-green-500/20">Ready</span>
              </div>
              <h1 className="text-xl font-display font-bold text-white tracking-tight">
                AI Agency OS <span className="text-slate-400 font-light">| Workspace Control Hub</span>
              </h1>
            </div>
          </div>

          {/* Quick status bar */}
          <div className="flex items-center gap-6 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="text-slate-500">RUNTIME:</span>
              {metrics?.status === 'running' ? (
                <span className="flex items-center gap-1.5 text-amber-400">
                  <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
                  PROCESSING
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
                  ACTIVE IDLE
                </span>
              )}
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <span className="text-slate-500">MODULES LOADED:</span>
              <span className="text-white px-2 py-0.5 bg-slate-800 rounded">{metrics?.moduleCount || 0} active</span>
            </div>
            <div className="hidden md:flex items-center gap-2">
              <span className="text-slate-500">PROVIDERS:</span>
              <span className="text-white px-2 py-0.5 bg-slate-800 rounded">Gemini (Primary)</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 md:px-6">
        {/* Module Banner indicating integration */}
        <div className="mb-6 p-4 rounded-xl border border-dashed border-cyan-500/30 bg-cyan-950/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex gap-3">
            <GitMerge className="h-5 w-5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-white">Organic Traffic OS is running as an official Module</p>
              <p className="text-xs text-slate-400">
                Refactoring completed. The module successfully utilizes the Shared Runtime, Agent Registry, Task Queue, Shared Memory, Logger, and AI Provider of the parent platform.
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            {modules.map((m, i) => (
              <span key={i} className="text-[11px] font-mono px-2 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded text-cyan-400">
                {m.name} v{m.version}
              </span>
            ))}
          </div>
        </div>

        {/* Global Stats Grid */}
        <section className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">System Runtime</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-xl font-bold text-white capitalize">{metrics?.status || "idle"}</span>
              <Activity className="h-5 w-5 text-cyan-400" />
            </div>
          </div>
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Active Agents</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-xl font-bold text-white">{metrics?.agentCount || 0} loaded</span>
              <Cpu className="h-5 w-5 text-emerald-400" />
            </div>
          </div>
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Task Queue</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-xl font-bold text-white">{metrics?.queueDepth || 0} pending</span>
              <Clock className="h-5 w-5 text-amber-400" />
            </div>
          </div>
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Total Token Flow</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-xl font-bold text-white font-mono">{(metrics?.aiUsage.totalTokens || 0).toLocaleString()}</span>
              <Layers className="h-5 w-5 text-fuchsia-400" />
            </div>
          </div>
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col justify-between col-span-2 lg:col-span-1">
            <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">Accumulated AI Costs</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-xl font-bold text-cyan-400 font-mono">${metrics?.aiUsage.totalCostUSD.toFixed(5) || "0.00000"}</span>
              <DollarSign className="h-5 w-5 text-cyan-400" />
            </div>
          </div>
        </section>

        {/* Tab Controls */}
        <div className="flex border-b border-slate-800 mb-6 overflow-x-auto whitespace-nowrap">
          <button 
            onClick={() => switchTab('dashboard')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'dashboard' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Área de Trabalho Interativa
          </button>
          <button 
            onClick={() => switchTab('queue')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'queue' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Tarefas e Logs ({tasks.length})
          </button>
          <button 
            onClick={() => switchTab('agents')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'agents' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Manifestos e Agentes
          </button>
          <button 
            onClick={() => switchTab('organic-knowledge')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-knowledge' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Core de Conhecimento PassaCumaru
          </button>
          <button 
            onClick={() => switchTab('organic-inventory')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-inventory' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Inventário de Conteúdo PassaCumaru
          </button>
          <button 
            onClick={() => switchTab('organic-competitors')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-competitors' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Análise de Concorrentes PassaCumaru
          </button>
          <button 
            onClick={() => switchTab('organic-serp')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-serp' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Inteligência de SERP PassaCumaru
          </button>
          <button 
            onClick={() => switchTab('organic-keywords')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-keywords' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Inteligência de Keywords PassaCumaru
          </button>
          <button 
            onClick={() => switchTab('organic-collectors')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-collectors' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Coletores de Dados (Collectors)
          </button>
          <button 
            onClick={() => switchTab('organic-opportunities')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-opportunities' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Oportunidades Editoriais
          </button>
          <button 
            onClick={() => switchTab('organic-editorial')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-editorial' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Planejamento Editorial
          </button>
          <button 
            onClick={() => switchTab('organic-briefs')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-briefs' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Briefings Editoriais
          </button>
          <button 
            onClick={() => switchTab('organic-blueprints')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-blueprints' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Arquiteturas de Conteúdo (Blueprints)
          </button>
          <button 
            onClick={() => switchTab('organic-research')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-research' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Dossiês de Pesquisa (Research)
          </button>
          <button 
            onClick={() => switchTab('organic-facts')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-facts' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Fact Intelligence Engine
          </button>
          <button 
            onClick={() => switchTab('organic-sources')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-sources' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Source Intelligence Engine
          </button>
          <button 
            onClick={() => switchTab('organic-workflows')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-workflows' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Workflow Orchestrator
          </button>
          <button 
            onClick={() => switchTab('organic-system')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-system' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            System Status & Audit
          </button>
          <button 
            onClick={() => switchTab('organic-strategy')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-strategy' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Estratégia de Conteúdo
          </button>
          <button 
            onClick={() => switchTab('organic-drafts')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-drafts' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Rascunhos de Artigo (Drafts)
          </button>
          <button 
            onClick={() => switchTab('organic-quality')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-quality' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Revisão Editorial (Quality Review)
          </button>
          <button 
            onClick={() => switchTab('organic-audience')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-audience' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Adaptação ao Público (Audience)
          </button>
          <button 
            onClick={() => switchTab('organic-language')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-language' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Linguagem Natural (Ritmo)
          </button>
          <button 
            onClick={() => switchTab('organic-visibility')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-visibility' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Otimização de Visibilidade (SEO & IA)
          </button>
          <button 
            onClick={() => switchTab('organic-assets')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-assets' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Ativos de Conteúdo (Asset Gen)
          </button>
          <button 
            onClick={() => switchTab('organic-publishing')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-publishing' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Preparação para Publicação (Publishing)
          </button>
          <button 
            onClick={() => switchTab('organic-performance')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-performance' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Desempenho de Conteúdo (Performance)
          </button>
          <button 
            onClick={() => switchTab('organic-e2e')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-e2e' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Validação E2E (E2E Validation)
          </button>
          <button 
            onClick={() => switchTab('organic-search')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'organic-search' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Search Intelligence (Epic 02)
          </button>

          <button 
            onClick={() => switchTab('knowledge')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'knowledge' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Ativos de Conhecimento
          </button>
          <button 
            onClick={() => switchTab('architecture')}
            className={`py-3 px-4 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'architecture' ? 'border-cyan-400 text-cyan-400 bg-cyan-950/10' : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            Diagrama de Arquitetura
          </button>
        </div>

        {/* Tab Contents */}
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Interactive Workspace form */}
            <div className="lg:col-span-2 bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
                  <Play className="h-5 w-5 text-cyan-400" />
                  Trigger Modular Agent Task
                </h3>
                <span className="text-xs font-mono text-slate-500">Dispatched server-side</span>
              </div>
              
              <form onSubmit={handleEnqueueTask}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Select Target Agent</label>
                    <select 
                      value={selectedAgentId} 
                      onChange={(e) => handleAgentChange(e.target.value)}
                      className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    >
                      {agents.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name} ({a.category.toUpperCase()})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Task Priority Level</label>
                    <select 
                      value={taskPriority} 
                      onChange={(e) => setTaskPriority(Number(e.target.value))}
                      className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    >
                      <option value="1">1 (Lowest Priority)</option>
                      <option value="3">3 (Normal Background)</option>
                      <option value="5">5 (Standard Operation)</option>
                      <option value="8">8 (High Expedited)</option>
                      <option value="10">10 (Urgent Immediate)</option>
                    </select>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-mono uppercase text-slate-400 mb-1">Agent Input Prompt Context</label>
                  <textarea 
                    value={taskPrompt}
                    onChange={(e) => setTaskPrompt(e.target.value)}
                    rows={4}
                    placeholder="Enter keywords, guidelines, or sitemap target URLs..."
                    className="w-full bg-[#1e293b] border border-slate-700 rounded-lg p-3 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    *The dispatch engine will automatically compile relevant Rules, Persona profiles, and Tone guidelines from the shared Knowledge Core before invoking Gemini.
                  </p>
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting || !taskPrompt.trim()}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-800 disabled:text-slate-500 font-semibold text-slate-950 rounded-lg transition-all"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Dispatching to Shared Runtime...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 fill-slate-950 text-slate-950" />
                      Enqueue Task in Platform Queue
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Quick overview panels */}
            <div className="space-y-6">
              {/* Active Providers List */}
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg">
                <h4 className="text-sm font-semibold tracking-wide text-white uppercase mb-3 flex items-center gap-2">
                  <Database className="h-4 w-4 text-cyan-400" />
                  Shared AI Providers Layer
                </h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2.5 bg-cyan-950/10 border border-cyan-500/20 rounded-lg">
                    <div className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-cyan-400" />
                      <span className="text-sm font-medium text-white">Gemini API</span>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 px-2 py-0.5 bg-cyan-500/10 rounded border border-cyan-500/20">PRIMARY ACTIVE</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-slate-900 border border-slate-800 rounded-lg opacity-60">
                    <div className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-slate-500" />
                      <span className="text-sm font-medium text-slate-300">Claude Integration</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 px-2 py-0.5 bg-slate-800 rounded">ROUTABLE COLD</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-slate-900 border border-slate-800 rounded-lg opacity-60">
                    <div className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-slate-500" />
                      <span className="text-sm font-medium text-slate-300">OpenAI Client</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 px-2 py-0.5 bg-slate-800 rounded">ROUTABLE COLD</span>
                  </div>
                </div>
              </div>

              {/* Running summary stats */}
              <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg">
                <h4 className="text-sm font-semibold tracking-wide text-white uppercase mb-3 flex items-center gap-2">
                  <ScrollText className="h-4 w-4 text-cyan-400" />
                  Shared Memory Registers
                </h4>
                <div className="text-xs space-y-2.5 max-h-[140px] overflow-y-auto font-mono text-slate-300">
                  {tasks.some(t => t.status === 'completed') ? (
                    tasks.filter(t => t.status === 'completed').map((t, i) => (
                      <div key={i} className="p-2 bg-slate-800/50 rounded border border-slate-700 flex justify-between items-center">
                        <span className="truncate max-w-[140px]">Latest {t.agentId} Output</span>
                        <span className="text-emerald-400">Memory Retained</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-slate-500 italic">No variables retained in Shared Memory yet. Dispatch an agent task to build semantic registries.</p>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Task Live View */}
            <div className="lg:col-span-3 bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg mt-4">
              <h3 className="text-sm font-semibold tracking-wide text-white uppercase mb-4 flex items-center gap-2">
                <Clock className="h-4 w-4 text-cyan-400" />
                Active Dispatch Queue ({tasks.length} tasks recorded)
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900 text-slate-400 uppercase tracking-wider font-mono">
                    <tr>
                      <th className="p-3">Task ID</th>
                      <th className="p-3">Agent</th>
                      <th className="p-3">Priority</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Cost Breakdown</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {tasks.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-4 text-center text-slate-500 italic">No tasks enqueued. Select an agent above and dispatch one!</td>
                      </tr>
                    ) : (
                      tasks.map((t) => (
                        <tr key={t.id} className="hover:bg-slate-900/40">
                          <td className="p-3 text-cyan-400">{t.id}</td>
                          <td className="p-3 font-semibold text-white">{agents.find(a => a.id === t.agentId)?.name || t.agentId}</td>
                          <td className="p-3">{t.priority}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                              t.status === 'completed' ? 'bg-green-500/10 text-green-400' :
                              t.status === 'running' ? 'bg-amber-500/10 text-amber-400 animate-pulse' :
                              t.status === 'failed' ? 'bg-red-500/10 text-red-400' : 'bg-slate-800 text-slate-400'
                            }`}>
                              {t.status}
                            </span>
                          </td>
                          <td className="p-3 text-slate-400">
                            {t.cost ? (
                              <span>{t.cost.totalTokens} tokens (${t.cost.estimatedCostUSD.toFixed(5)})</span>
                            ) : (
                              <span className="text-slate-600">Pending Run</span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            {t.status === 'completed' && (
                              <button 
                                onClick={() => setSelectedTaskResult(t)}
                                className="px-2 py-1 bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold text-[10px] rounded"
                              >
                                View Article Draft / Output
                              </button>
                            )}
                            {t.status === 'failed' && (
                              <span className="text-red-400 truncate max-w-[200px] inline-block">{t.error}</span>
                            )}
                            {t.status === 'running' && (
                              <span className="text-amber-400 flex items-center gap-1 justify-end"><Loader2 className="h-3 w-3 animate-spin" /> executing...</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* Tab: Tasks & Logs */}
        {activeTab === 'queue' && (
          <div className="space-y-6">
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
                  <Clock className="h-5 w-5 text-cyan-400" />
                  Task Queue Management
                </h3>
                <button 
                  onClick={handleClearQueue}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-lg text-xs font-semibold"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Clear Task History
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900 text-slate-400 uppercase tracking-wider font-mono">
                    <tr>
                      <th className="p-3">Task ID</th>
                      <th className="p-3">Module</th>
                      <th className="p-3">Target Agent</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Created At</th>
                      <th className="p-3">Finished At</th>
                      <th className="p-3">Est Cost</th>
                      <th className="p-3 text-right">Result Payload</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {tasks.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-500 italic">No task executions found in queue database.</td>
                      </tr>
                    ) : (
                      tasks.map((t) => (
                        <tr key={t.id} className="hover:bg-slate-900/40">
                          <td className="p-3 text-cyan-400">{t.id}</td>
                          <td className="p-3 text-slate-400">{t.moduleId}</td>
                          <td className="p-3 text-white font-semibold">{agents.find(a => a.id === t.agentId)?.name || t.agentId}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                              t.status === 'completed' ? 'bg-green-500/10 text-green-400' :
                              t.status === 'running' ? 'bg-amber-500/10 text-amber-400 animate-pulse' :
                              t.status === 'failed' ? 'bg-red-500/10 text-red-400' : 'bg-slate-800 text-slate-400'
                            }`}>
                              {t.status}
                            </span>
                          </td>
                          <td className="p-3 text-slate-400">{new Date(t.createdAt).toLocaleTimeString()}</td>
                          <td className="p-3 text-slate-400">{t.completedAt ? new Date(t.completedAt).toLocaleTimeString() : "-"}</td>
                          <td className="p-3 text-cyan-400">${t.cost?.estimatedCostUSD.toFixed(5) || "0.00"}</td>
                          <td className="p-3 text-right">
                            {t.status === 'completed' ? (
                              <button 
                                onClick={() => setSelectedTaskResult(t)}
                                className="px-2 py-1 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/20 rounded"
                              >
                                Expand Output
                              </button>
                            ) : t.status === 'failed' ? (
                              <span className="text-red-400">{t.error}</span>
                            ) : (
                              <span className="text-slate-500">Awaiting processing</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* System Logs */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
                  <ScrollText className="h-5 w-5 text-cyan-400" />
                  Shared Runtime Live Log Stream
                </h3>
                <button 
                  onClick={handleClearLogs}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Clear Console Stream
                </button>
              </div>

              <div className="bg-[#0b0f19] border border-slate-800 rounded-lg p-4 h-[350px] overflow-y-auto font-mono text-xs space-y-2">
                {logs.length === 0 ? (
                  <p className="text-slate-600 italic">No system log logs available.</p>
                ) : (
                  logs.map((log) => (
                    <div key={log.id} className="flex gap-2">
                      <span className="text-slate-500 shrink-0">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                      <span className={`shrink-0 uppercase font-bold text-[10px] px-1.5 py-0.2 rounded border ${
                        log.level === 'success' ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                        log.level === 'warn' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                        log.level === 'error' ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                      }`}>
                        {log.source}:{log.level}
                      </span>
                      {log.taskId && <span className="text-cyan-500 shrink-0">[{log.taskId}]</span>}
                      <span className="text-slate-300">{log.message}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab: Module Manifests & Agents */}
        {activeTab === 'agents' && (
          <div className="space-y-8">
            {/* Integrated Modules List */}
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <h3 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
                <Layers className="h-5 w-5 text-cyan-400" />
                Integrated Module Manifests (`module.json`)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {modules.map((m, index) => (
                  <div key={index} className="bg-[#0b0f19] border border-slate-800 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-md font-bold text-white">{m.name}</h4>
                      <span className="text-xs font-mono px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded">v{m.version}</span>
                    </div>
                    <div className="space-y-4 text-xs">
                      <div>
                        <span className="text-slate-500 block uppercase font-mono tracking-wider mb-1">Module Dependencies:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {m.dependencies.map((dep, i) => (
                            <span key={i} className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-mono">{dep}</span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-500 block uppercase font-mono tracking-wider mb-1">Registered Workflows:</span>
                        <ul className="list-disc list-inside space-y-1 text-slate-300">
                          {m.workflows.map((wf, i) => <li key={i}>{wf}</li>)}
                        </ul>
                      </div>
                      <div>
                        <span className="text-slate-500 block uppercase font-mono tracking-wider mb-1">Module API Routes:</span>
                        <div className="flex flex-col gap-1 text-slate-300 font-mono text-[11px]">
                          {m.routes.map((rt, i) => <span key={i} className="text-cyan-400">{rt}</span>)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Registered Agents Registry */}
            <div>
              <h3 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
                <Cpu className="h-5 w-5 text-cyan-400" />
                V2 Standard Agent manifestations ({agents.length} Agents active)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {agents.map((agent) => (
                  <div key={agent.id} className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-800 rounded text-slate-400 uppercase tracking-wider">
                            {agent.category}
                          </span>
                          <h4 className="text-md font-bold text-white mt-1">{agent.name}</h4>
                        </div>
                        <span className="text-xs font-mono text-cyan-400">v{agent.version}</span>
                      </div>
                      
                      <div className="space-y-3 my-4 text-xs text-slate-300">
                        <div>
                          <span className="text-slate-500 font-mono uppercase block text-[10px]">Capabilities:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {agent.capabilities.map((cap, i) => (
                              <span key={i} className="px-1.5 py-0.5 bg-slate-900 rounded text-slate-300 font-mono text-[10px] border border-slate-800">{cap}</span>
                            ))}
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[11px]">
                          <div>
                            <span className="text-slate-500 font-mono block text-[10px]">Input Standard:</span>
                            <span className="truncate block font-mono text-slate-400" title={agent.input}>{agent.input}</span>
                          </div>
                          <div>
                            <span className="text-slate-500 font-mono block text-[10px]">Output Target:</span>
                            <span className="truncate block font-mono text-slate-400" title={agent.output}>{agent.output}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-800 pt-3 mt-2 flex justify-between items-center text-xs font-mono">
                      <span className="text-slate-500">Provider: {agent.defaultProvider}</span>
                      <span className="text-slate-500">Priority: {agent.priority}/10</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab: Knowledge Core */}
        {activeTab === 'knowledge' && (
          <div className="space-y-6">
            <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-5 shadow-xl">
              <h3 className="text-lg font-display font-bold text-white mb-2 flex items-center gap-2">
                <Database className="h-5 w-5 text-cyan-400" />
                Unified Knowledge Core
              </h3>
              <p className="text-sm text-slate-400 mb-6">
                All platform modules pull from this standardized system assets library. Changes here immediately configure prompts across all automated workspaces.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {knowledge.map((item) => {
                  let Icon = BookOpen;
                  if (item.category === 'products') Icon = Compass;
                  if (item.category === 'personas') Icon = Users;
                  if (item.category === 'competitors') Icon = Target;
                  if (item.category === 'rules') Icon = Settings;
                  if (item.category === 'tone') Icon = ScrollText;
                  if (item.category === 'memory') Icon = Database;

                  return (
                    <div key={item.id} className="bg-[#0b0f19] border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded uppercase border border-cyan-500/20">
                            {item.category}
                          </span>
                          <Icon className="h-4 w-4 text-slate-400" />
                        </div>
                        <h4 className="text-sm font-semibold text-white mb-2">{item.title}</h4>
                        <p className="text-xs text-slate-400 font-mono whitespace-pre-wrap leading-relaxed">
                          {item.content}
                        </p>
                      </div>
                      <div className="border-t border-slate-800/80 pt-3 mt-4 text-[10px] text-slate-600 font-mono text-right">
                        Last Modified: {new Date(item.updatedAt).toLocaleTimeString()}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Tab: PassaCumaru Knowledge Core */}
        {activeTab === 'organic-knowledge' && (
          <OrganicKnowledgeCore />
        )}

        {/* Tab: PassaCumaru Inventory Core */}
        {activeTab === 'organic-inventory' && (
          <OrganicInventory />
        )}

        {/* Tab: PassaCumaru Competitors Core */}
        {activeTab === 'organic-competitors' && (
          <OrganicCompetitors />
        )}

        {/* Tab: PassaCumaru SERP Core */}
        {activeTab === 'organic-serp' && (
          <OrganicSerp />
        )}

        {/* Tab: PassaCumaru Keywords Core */}
        {activeTab === 'organic-keywords' && (
          <OrganicKeywords />
        )}

        {/* Tab: Research Collectors Engine */}
        {activeTab === 'organic-collectors' && (
          <OrganicCollectors />
        )}

        {/* Tab: Opportunity Discovery Engine */}
        {activeTab === 'organic-opportunities' && (
          <OrganicOpportunities />
        )}

        {/* Tab: Editorial Planning Engine */}
        {activeTab === 'organic-editorial' && (
          <OrganicEditorial />
        )}

        {/* Tab: Brief Intelligence Engine */}
        {activeTab === 'organic-briefs' && (
          <OrganicBriefs />
        )}

        {/* Tab: Content Architecture Blueprints Engine */}
        {activeTab === 'organic-blueprints' && (
          <OrganicBlueprints />
        )}

        {/* Tab: Research Composer Engine */}
        {activeTab === 'organic-research' && (
          <OrganicResearch />
        )}

        {/* Tab: Fact Intelligence Engine (Sprint 13) */}
        {activeTab === 'organic-facts' && (
          <OrganicFacts />
        )}

        {/* Tab: Source Intelligence Engine (Sprint 14) */}
        {activeTab === 'organic-sources' && (
          <OrganicSources />
        )}

        {/* Tab: Content Workflow Orchestrator (Sprint 15) */}
        {activeTab === 'organic-workflows' && (
          <OrganicWorkflows />
        )}

        {/* Tab: System Status & Audit (Sprint 15.5) */}
        {activeTab === 'organic-system' && (
          <OrganicSystem />
        )}

        {/* Tab: Content Strategy Engine (Sprint 17) */}
        {activeTab === 'organic-strategy' && (
          <OrganicStrategy />
        )}

        {/* Tab: Draft Writer Engine (Sprint 18) */}
        {activeTab === 'organic-drafts' && (
          <OrganicDrafts />
        )}

        {/* Tab: Content Quality Review Engine (Sprint 19) */}
        {activeTab === 'organic-quality' && (
          <OrganicQuality />
        )}

        {/* Tab: Audience Adaptation Engine (Sprint 20) */}
        {activeTab === 'organic-audience' && (
          <OrganicAudience />
        )}

        {/* Tab: Natural Language Engine (Sprint 21) */}
        {activeTab === 'organic-language' && (
          <OrganicLanguage />
        )}

        {/* Tab: Visibility Optimization Engine (Sprint 22) */}
        {activeTab === 'organic-visibility' && (
          <OrganicVisibility />
        )}

        {/* Tab: Content Asset Generation Engine (Sprint 23) */}
        {activeTab === 'organic-assets' && (
          <OrganicAssets />
        )}

        {/* Tab: Publishing Engine (Sprint 24) */}
        {activeTab === 'organic-publishing' && (
          <OrganicPublishing />
        )}

        {/* Tab: Performance Engine (Sprint 25) */}
        {activeTab === 'organic-performance' && (
          <OrganicPerformance />
        )}

        {/* Tab: E2E Validation (Sprint 25.5) */}
        {activeTab === 'organic-e2e' && (
          <OrganicE2e />
        )}

        {/* Tab: Search Intelligence Engine (EPIC 02 - Sprint 26) */}
        {activeTab === 'organic-search' && (
          <OrganicSearch />
        )}


        {/* Tab: Architecture Diagram */}
        {activeTab === 'architecture' && (
          <OrganicArchitecture />
        )}
      </main>

      {/* Task Output Display Modal */}
      {selectedTaskResult && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            <div className="p-5 border-b border-slate-800 bg-[#0d1424] flex justify-between items-center">
              <div>
                <span className="text-[10px] font-mono uppercase bg-green-500/10 text-green-400 px-2 py-0.5 rounded border border-green-500/20">
                  {selectedTaskResult.agentId} Completed
                </span>
                <h3 className="text-md font-display font-bold text-white mt-1">
                  Task Execution Outcome ({selectedTaskResult.id})
                </h3>
              </div>
              <button 
                onClick={() => setSelectedTaskResult(null)}
                className="text-slate-400 hover:text-slate-300 text-lg font-mono"
              >
                ✕
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-4">
              <div>
                <span className="text-xs uppercase font-mono text-slate-500 block mb-1">TASK INPUT:</span>
                <div className="p-3 bg-[#0b0f19] border border-slate-800 rounded text-xs font-mono text-slate-400">
                  {selectedTaskResult.input}
                </div>
              </div>

              <div>
                <span className="text-xs uppercase font-mono text-slate-500 block mb-1">GENERATED OUTPUT (MD):</span>
                <div className="p-4 bg-[#0b0f19] border border-slate-800 rounded-lg text-sm text-slate-300 leading-relaxed font-mono whitespace-pre-wrap select-text">
                  {selectedTaskResult.result}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-[#0d1424] flex justify-between items-center text-xs font-mono text-slate-500">
              <span>Tokens Used: {selectedTaskResult.cost?.totalTokens || 0}</span>
              <span>Estimated Cost: ${selectedTaskResult.cost?.estimatedCostUSD.toFixed(5) || "0.00"}</span>
              <button 
                onClick={() => setSelectedTaskResult(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded"
              >
                Close Output
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
