import fs from "fs";
import path from "path";
import { Collector, CollectorResult } from "./base/collector";
import { CollectorRegistry } from "./collector-registry";
import { CollectorCache } from "./base/collector-cache";
import { CollectorQueue } from "./base/collector-queue";
import { CollectorValidator } from "./base/collector-validator";

const CACHE_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const LOGS_FILE = path.join(CACHE_DIR, "logs.json");
const RESULTS_FILE = path.join(CACHE_DIR, "results.json");

export interface CollectorLog {
  id: string;
  collectorId: string;
  data: string; // ISO String
  tipo: "info" | "sucesso" | "erro" | "alerta";
  mensagem: string;
  duracaoMs?: number;
}

export class CollectorManager {
  private static ensureLogsFileExists() {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    if (!fs.existsSync(LOGS_FILE)) {
      fs.writeFileSync(LOGS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public static registrarLog(collectorId: string, tipo: CollectorLog["tipo"], mensagem: string, duracaoMs?: number): void {
    this.ensureLogsFileExists();
    try {
      const logsContent = fs.readFileSync(LOGS_FILE, "utf-8");
      const logs: CollectorLog[] = JSON.parse(logsContent);

      logs.unshift({
        id: "log-" + Math.random().toString(36).substring(2, 11),
        collectorId,
        data: new Date().toISOString(),
        tipo,
        mensagem,
        duracaoMs
      });

      // Limitar a 300 logs para evitar sobrecarga
      if (logs.length > 300) {
        logs.pop();
      }

      fs.writeFileSync(LOGS_FILE, JSON.stringify(logs, null, 2), "utf-8");
    } catch (err) {
      console.error("Erro ao escrever log do collector:", err);
    }
  }

  public static listarLogs(): CollectorLog[] {
    this.ensureLogsFileExists();
    try {
      return JSON.parse(fs.readFileSync(LOGS_FILE, "utf-8"));
    } catch (err) {
      console.error("Erro ao ler logs dos collectors:", err);
      return [];
    }
  }

  public static limparLogs(): void {
    this.ensureLogsFileExists();
    fs.writeFileSync(LOGS_FILE, JSON.stringify([], null, 2), "utf-8");
  }

  /**
   * Habilita um coletor no registro
   */
  public static habilitar(id: string): boolean {
    return CollectorRegistry.atualizarStatusColetor(id, "ativo");
  }

  /**
   * Desabilita um coletor no registro
   */
  public static desabilitar(id: string): boolean {
    return CollectorRegistry.atualizarStatusColetor(id, "inativo");
  }

  /**
   * Executa um coletor e registra tudo no sistema (logs, fila, cache, resultados)
   */
  public static async executarCollector(id: string, params?: any): Promise<CollectorResult> {
    const collector = CollectorRegistry.obter(id);
    if (!collector) {
      const msg = `Coletor '${id}' não encontrado no Registro.`;
      this.registrarLog("sistema", "erro", msg);
      throw new Error(msg);
    }

    if (collector.status === "inativo") {
      const msg = `O coletor '${collector.nome}' está desabilitado. Habilite-o antes de executar.`;
      this.registrarLog(id, "alerta", msg);
      throw new Error(msg);
    }

    // Registrar na Fila
    const qItem = CollectorQueue.adicionar(id, "manual");
    CollectorQueue.atualizarStatus(qItem.id, "executando", { dataExecucao: new Date().toISOString() });

    const startTime = Date.now();
    this.registrarLog(id, "info", `Iniciando execução do coletor ${collector.nome}...`);

    try {
      // Executa a coleta real
      const resultado = await collector.coletar(params);
      const duration = Date.now() - startTime;

      // Validar dados coletados
      const validation = CollectorValidator.validarIntegridade(resultado);
      if (!validation.isValid) {
        this.registrarLog(id, "alerta", `Dados coletados com avisos de integridade: ${validation.errors.join("; ")}`, duration);
      }

      // Salvar no Cache tático
      const cacheKey = `latest_run_${id}`;
      CollectorCache.salvar(cacheKey, resultado, 3600); // Cache válido por 1 hora

      // Atualizar Fila e Logs
      CollectorQueue.atualizarStatus(qItem.id, "sucesso", { 
        duracaoMs: duration,
        tentativas: 1
      });

      this.registrarLog(id, "sucesso", `Coletor executado com sucesso em ${duration}ms.`, duration);
      return resultado;

    } catch (err: any) {
      const duration = Date.now() - startTime;
      const errorMsg = err.message || "Erro desconhecido na coleta.";

      CollectorQueue.atualizarStatus(qItem.id, "falha", {
        duracaoMs: duration,
        erro: errorMsg,
        tentativas: 1
      });

      this.registrarLog(id, "erro", `Falha na execução do coletor: ${errorMsg}`, duration);

      // Criar resultado de erro para salvar integridade
      const errorResult: CollectorResult = {
        id: "col-err-" + Math.random().toString(36).substring(2, 11),
        collector: id,
        origem: collector.fonte,
        data_coleta: new Date().toISOString(),
        tipo: id.replace("-collector", ""),
        conteudo: { erro: errorMsg },
        confiabilidade: 0,
        status: "falha",
        observacoes: `Execução falhou: ${errorMsg}`
      };

      return errorResult;
    }
  }

  /**
   * Retorna os coletores com suas métricas consolidadas
   */
  public static listarCollectorsComMetricas(): any[] {
    const collectors = CollectorRegistry.listarTodos();
    const logs = this.listarLogs();
    const queue = CollectorQueue.listar();

    // Carregar contagem real de resultados por coletor
    let totalCollectedCount: Record<string, number> = {};
    let lastRunMap: Record<string, string> = {};
    let sumDurationMap: Record<string, number> = {};
    let countDurationMap: Record<string, number> = {};
    let failureCountMap: Record<string, number> = {};

    try {
      if (fs.existsSync(RESULTS_FILE)) {
        const results: CollectorResult[] = JSON.parse(fs.readFileSync(RESULTS_FILE, "utf-8"));
        results.forEach(res => {
          totalCollectedCount[res.collector] = (totalCollectedCount[res.collector] || 0) + 1;
        });
      }
    } catch (e) {
      console.error("Erro ao compilar métricas de resultados:", e);
    }

    // Analisar logs/fila para tempos de execução e falhas
    logs.forEach(log => {
      if (log.duracaoMs !== undefined) {
        sumDurationMap[log.collectorId] = (sumDurationMap[log.collectorId] || 0) + log.duracaoMs;
        countDurationMap[log.collectorId] = (countDurationMap[log.collectorId] || 0) + 1;
      }
      if (log.tipo === "erro") {
        failureCountMap[log.collectorId] = (failureCountMap[log.collectorId] || 0) + 1;
      }
    });

    queue.forEach(q => {
      if (q.status === "sucesso" || q.status === "falha") {
        if (!lastRunMap[q.collectorId] || new Date(q.dataAgendada) > new Date(lastRunMap[q.collectorId])) {
          lastRunMap[q.collectorId] = q.dataAgendada;
        }
      }
    });

    return collectors.map(c => {
      const avgDuration = countDurationMap[c.id] > 0 
        ? Math.round(sumDurationMap[c.id] / countDurationMap[c.id]) 
        : 0;
      
      const cacheKey = `latest_run_${c.id}`;
      const cacheValido = CollectorCache.validar(cacheKey);

      return {
        id: c.id,
        nome: c.nome,
        versao: c.versão,
        fonte: c.fonte,
        status: c.status,
        totalColetas: totalCollectedCount[c.id] || 0,
        ultimaExecucao: lastRunMap[c.id] || "Nunca executado",
        tempoMedioMs: avgDuration,
        falhas: failureCountMap[c.id] || 0,
        cacheAtivo: cacheValido,
        tipo: c.id.replace("-collector", "")
      };
    });
  }
}

export default CollectorManager;
