import { Collector, CollectorResult } from "../base/collector";
import fs from "fs";
import path from "path";

const RESULTS_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const RESULTS_FILE = path.join(RESULTS_DIR, "results.json");

export class RssCollector implements Collector {
  public id = "rss-collector";
  public nome = "Coletor de Feeds RSS";
  public versão = "1.0.0";
  public fonte = "RSS Feed / XML";
  public status: "ativo" | "inativo" = "ativo";

  private ensureResultsFileExists() {
    if (!fs.existsSync(RESULTS_DIR)) {
      fs.mkdirSync(RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(RESULTS_FILE)) {
      fs.writeFileSync(RESULTS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public async coletar(params?: any): Promise<CollectorResult> {
    const url = params?.url || "https://g1.globo.com/rn/rio-grande-do-norte/rss/g1.xml";
    let feedTitle = "Rio Grande do Norte RSS";
    let items: any[] = [];
    let status: "sucesso" | "falha" | "alerta" = "sucesso";
    let errorMsg = "";

    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (!response.ok) {
        throw new Error(`Falha de conexão http: ${response.status}`);
      }
      const text = await response.text();
      
      // Parse simples de XML usando RegExp para evitar dependências de terceiros
      const channelTitleMatch = text.match(/<title[^>]*>([\s\S]*?)<\/title>/);
      if (channelTitleMatch && channelTitleMatch[1]) {
        feedTitle = channelTitleMatch[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").trim();
      }

      const itemRegex = /<item>([\s\S]*?)<\/item>/g;
      let match;
      while ((match = itemRegex.exec(text)) !== null) {
        const itemContent = match[1];
        
        const titleMatch = itemContent.match(/<title[^>]*>([\s\S]*?)<\/title>/);
        const linkMatch = itemContent.match(/<link[^>]*>([\s\S]*?)<\/link>/);
        const descriptionMatch = itemContent.match(/<description[^>]*>([\s\S]*?)<\/description>/);
        const pubDateMatch = itemContent.match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/);

        const cleanString = (str: string) => {
          return str
            .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&amp;/g, "&")
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'")
            .trim();
        };

        const title = titleMatch ? cleanString(titleMatch[1]) : "Sem título";
        const link = linkMatch ? cleanString(linkMatch[1]) : "";
        const description = descriptionMatch ? cleanString(descriptionMatch[1]).replace(/<[^>]*>/g, "") : "";
        const pubDate = pubDateMatch ? cleanString(pubDateMatch[1]) : new Date().toISOString();

        items.push({
          titulo: title,
          link: link,
          descricao: description.substring(0, 250),
          data_publicacao: pubDate
        });

        if (items.length >= 15) break; // Trava para evitar sobrecarga
      }
    } catch (err: any) {
      status = "alerta";
      errorMsg = err.message || "Erro desconhecido de fetch";
      console.warn("Conexão falhou ao baixar RSS, carregando dados simulados de fallback.", err.message);

      // Dados táticos locais de fallback para o Agreste do RN e Concurso Passa e Fica
      items = [
        {
          titulo: "Prefeitura de Passa e Fica prorroga inscrições para Concurso Público da Saúde",
          link: "https://passaecumaru.com.br/concursos/passa-e-fica-saude-prorrogado",
          descricao: "As inscrições para o certame da Secretaria Municipal de Saúde de Passa e Fica foram estendidas até a próxima sexta-feira. Salários de até R$ 4.500.",
          data_publicacao: new Date().toISOString()
        },
        {
          titulo: "Edital divulgado para concurso de Nova Cruz com mais de 100 vagas",
          link: "https://passaecumaru.com.br/concursos/nova-cruz-edital-aberto",
          descricao: "O edital para o provimento de cargos públicos na Prefeitura de Nova Cruz foi homologado nesta manhã. Banca organizadora confirmada.",
          data_publicacao: new Date(Date.now() - 36 * 3600 * 1000).toISOString()
        },
        {
          titulo: "Banca Funcerne é contratada para concurso unificado no Agreste Potiguar",
          link: "https://passaecumaru.com.br/concursos/banca-funcerne-agreste",
          descricao: "Consórcio de municípios do Agreste do RN oficializa a contratação da Funcerne para organizar os certames táticos da região.",
          data_publicacao: new Date(Date.now() - 48 * 3600 * 1000).toISOString()
        }
      ];
    }

    const rawData = {
      feedUrl: url,
      nomeFeed: feedTitle,
      itens: items,
      observacao_erro: errorMsg || undefined
    };

    const valid = this.validar(rawData);
    const normalized = this.normalizar(rawData);

    const result: CollectorResult = {
      id: "col-rss-" + Math.random().toString(36).substring(2, 11),
      collector: this.id,
      origem: url,
      data_coleta: new Date().toISOString(),
      tipo: "rss",
      conteudo: normalized,
      confiabilidade: status === "sucesso" ? 95 : 70, // Confiabilidade reduzida se veio do fallback
      status: status,
      observacoes: status === "sucesso" 
        ? `Coleta do feed RSS efetuada com sucesso: ${normalized.itens.length} notícias.` 
        : `Erro ao buscar Feed RSS remoto (${errorMsg}). Usando cache regional de fallback.`
    };

    await this.salvar(result);
    return result;
  }

  public validar(dados: any): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];
    if (!dados) {
      return { isValid: false, errors: ["Dados nulos"] };
    }
    if (!dados.feedUrl) {
      errors.push("URL do Feed de origem ausente.");
    }
    if (!Array.isArray(dados.itens)) {
      errors.push("Array de itens do RSS não encontrado.");
    }
    return {
      isValid: errors.length === 0,
      errors
    };
  }

  public normalizar(dados: any): any {
    if (!dados) return { feedUrl: "", nomeFeed: "Desconhecido", itens: [] };
    return {
      feedUrl: dados.feedUrl,
      nomeFeed: dados.nomeFeed || "Canal de RSS",
      itens: (dados.itens || []).map((item: any) => ({
        titulo: typeof item.titulo === "string" ? item.titulo.trim() : "Notícia Sem Título",
        link: typeof item.link === "string" ? item.link.trim() : "",
        descricao: typeof item.descricao === "string" ? item.descricao.trim().substring(0, 300) : "",
        data_publicacao: item.data_publicacao || new Date().toISOString()
      })),
      observacao_erro: dados.observacao_erro
    };
  }

  public async salvar(resultado: CollectorResult): Promise<boolean> {
    this.ensureResultsFileExists();
    try {
      const content = fs.readFileSync(RESULTS_FILE, "utf-8");
      const results: CollectorResult[] = JSON.parse(content);
      
      results.unshift(resultado);
      
      if (results.length > 500) {
        results.pop();
      }

      fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Erro ao salvar resultado de coleta RSS:", err);
      return false;
    }
  }
}
export default RssCollector;
