import { Collector } from "./base/collector";
import { ManualCollector } from "./manual/manual-collector";
import { RssCollector } from "./rss/rss-collector";
import { SearchConsoleCollector } from "./google/search-console/search-console-collector";
import { GoogleTrendsCollector } from "./google/google-trends/google-trends-collector";
import { AutocompleteCollector } from "./google/autocomplete/autocomplete-collector";
import { PeopleAlsoAskCollector } from "./google/people-also-ask/people-also-ask-collector";
import { YoutubeCollector } from "./youtube/youtube-collector";
import { RedditCollector } from "./reddit/reddit-collector";
import { NewsCollector } from "./news/news-collector";

export class CollectorRegistry {
  private static registry = new Map<string, Collector>();

  public static inicializar(): void {
    if (this.registry.size > 0) return; // Já inicializado

    const collectorsList: Collector[] = [
      new ManualCollector(),
      new RssCollector(),
      new SearchConsoleCollector(),
      new GoogleTrendsCollector(),
      new AutocompleteCollector(),
      new PeopleAlsoAskCollector(),
      new YoutubeCollector(),
      new RedditCollector(),
      new NewsCollector()
    ];

    collectorsList.forEach(c => {
      this.registry.set(c.id, c);
    });
  }

  public static obter(id: string): Collector | undefined {
    this.inicializar();
    return this.registry.get(id);
  }

  public static listarTodos(): Collector[] {
    this.inicializar();
    return Array.from(this.registry.values());
  }

  public static atualizarStatusColetor(id: string, status: "ativo" | "inactive" | "inativo"): boolean {
    this.inicializar();
    const collector = this.registry.get(id);
    if (collector) {
      collector.status = status === "ativo" ? "ativo" : "inativo";
      return true;
    }
    return false;
  }
}

export default CollectorRegistry;
