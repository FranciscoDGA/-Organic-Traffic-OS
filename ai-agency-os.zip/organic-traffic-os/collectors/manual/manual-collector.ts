import { Collector, CollectorResult } from "../base/collector";
import fs from "fs";
import path from "path";

const RESULTS_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const RESULTS_FILE = path.join(RESULTS_DIR, "results.json");

export class ManualCollector implements Collector {
  public id = "manual-collector";
  public nome = "Coletor Manual PassaCumaru";
  public versão = "1.0.0";
  public fonte = "Entrada Manual";
  public status: "ativo" | "inativo" = "ativo";

  private ensureResultsFileExists() {
    if (!fs.existsSync(RESULTS_DIR)) {
      fs.mkdirSync(RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(RESULTS_FILE)) {
      fs.writeFileSync(RESULTS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public async coletar(params?: any): Promise<CollectorResult> {
    const rawData = params || {
      titulo: "Informação manual em lote",
      conteudo: "Coleta efetuada sem parâmetros específicos"
    };

    const valid = this.validar(rawData);
    const normalized = this.normalizar(rawData);

    const result: CollectorResult = {
      id: "col-manual-" + Math.random().toString(36).substring(2, 11),
      collector: this.id,
      origem: "Administrador / Interface Humana",
      data_coleta: new Date().toISOString(),
      tipo: "manual",
      conteudo: normalized,
      confiabilidade: 100, // Entrada humana direta de alta confiabilidade
      status: valid.isValid ? "sucesso" : "alerta",
      observacoes: valid.isValid 
        ? "Coleta manual concluída e validada." 
        : `Coleta manual concluída com ressalvas: ${valid.errors.join(", ")}`
    };

    if (result.status === "sucesso") {
      await this.salvar(result);
    }

    return result;
  }

  public validar(dados: any): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];
    if (!dados) {
      return { isValid: false, errors: ["Dados nulos ou vazios"] };
    }
    if (!dados.titulo || typeof dados.titulo !== "string" || !dados.titulo.trim()) {
      errors.push("O campo 'titulo' é obrigatório e deve ser preenchido.");
    }
    return {
      isValid: errors.length === 0,
      errors
    };
  }

  public normalizar(dados: any): any {
    if (!dados) return {};
    return {
      titulo: typeof dados.titulo === "string" ? dados.titulo.trim() : "Sem Título",
      categoria: typeof dados.categoria === "string" ? dados.categoria.trim() : "Geral",
      descricao: typeof dados.descricao === "string" ? dados.descricao.trim() : "",
      origem_url: typeof dados.origem_url === "string" ? dados.origem_url.trim() : "https://passacumaru.com.br",
      data_observada: dados.data_observada || new Date().toISOString(),
      metadados: dados.metadados || {}
    };
  }

  public async salvar(resultado: CollectorResult): Promise<boolean> {
    this.ensureResultsFileExists();
    try {
      const content = fs.readFileSync(RESULTS_FILE, "utf-8");
      const results: CollectorResult[] = JSON.parse(content);
      
      // Adicionar novo resultado
      results.unshift(resultado);
      
      // Limitar a 500 para evitar sobrecarga
      if (results.length > 500) {
        results.pop();
      }

      fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Erro ao salvar resultado de coleta manual:", err);
      return false;
    }
  }
}
export default ManualCollector;
