import { Collector, CollectorResult } from "../base/collector";
import fs from "fs";
import path from "path";

const RESULTS_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const RESULTS_FILE = path.join(RESULTS_DIR, "results.json");

export class RedditCollector implements Collector {
  public id = "reddit-collector";
  public nome = "Reddit Forum Crawler";
  public versão = "1.0.0";
  public fonte = "Reddit API (r/concursospublicos)";
  public status: "ativo" | "inativo" = "inativo";

  private ensureResultsFileExists() {
    if (!fs.existsSync(RESULTS_DIR)) {
      fs.mkdirSync(RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(RESULTS_FILE)) {
      fs.writeFileSync(RESULTS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public async coletar(params?: any): Promise<CollectorResult> {
    const subreddit = params?.subreddit || "concursospublicos";
    const dataPlaceholder = {
      subreddit,
      threads: [
        { id: "t1", titulo: "Alguém estudando pro concurso de Passa e Fica/RN?", upvotes: 15, replies: 28 },
        { id: "t2", titulo: "Dúvidas sobre o conteúdo programático de Nova Cruz", upvotes: 8, replies: 12 }
      ],
      mensagem: "Este é um coletor placeholder preparado para se integrar à API do Reddit ou varrer threads públicas do fórum de concursos."
    };

    const valid = this.validar(dataPlaceholder);
    const normalized = this.normalizar(dataPlaceholder);

    const result: CollectorResult = {
      id: "col-reddit-" + Math.random().toString(36).substring(2, 11),
      collector: this.id,
      origem: `Reddit: r/${subreddit}`,
      data_coleta: new Date().toISOString(),
      tipo: "reddit",
      conteudo: normalized,
      confiabilidade: 50,
      status: "alerta",
      observacoes: "Módulo em estágio de placeholder."
    };

    await this.salvar(result);
    return result;
  }

  public validar(dados: any): { isValid: boolean; errors: string[] } {
    return { isValid: true, errors: [] };
  }

  public normalizar(dados: any): any {
    return dados;
  }

  public async salvar(resultado: CollectorResult): Promise<boolean> {
    this.ensureResultsFileExists();
    try {
      const content = fs.readFileSync(RESULTS_FILE, "utf-8");
      const results: CollectorResult[] = JSON.parse(content);
      results.unshift(resultado);
      if (results.length > 500) results.pop();
      fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Erro ao salvar resultado de Reddit Collector:", err);
      return false;
    }
  }
}
export default RedditCollector;
