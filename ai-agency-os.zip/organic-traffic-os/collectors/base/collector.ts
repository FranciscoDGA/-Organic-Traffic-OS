export interface CollectorResult {
  id: string;          // ID único da coleta
  collector: string;   // ID do collector
  origem: string;      // URL, RSS feed, etc.
  data_coleta: string; // ISO String timestamp
  tipo: string;        // Tipo de conteúdo coletado
  conteudo: any;       // Conteúdo coletado e normalizado
  confiabilidade: number; // Grau de confiabilidade (0 a 100)
  status: "sucesso" | "falha" | "alerta";
  observacoes?: string; // Observações adicionais
}

export interface Collector {
  id: string;
  nome: string;
  versão: string;
  fonte: string;
  status: "ativo" | "inativo";
  coletar(params?: any): Promise<CollectorResult>;
  validar(dados: any): { isValid: boolean; errors: string[] };
  normalizar(dados: any): any;
  salvar(dados: any): Promise<boolean>;
}
