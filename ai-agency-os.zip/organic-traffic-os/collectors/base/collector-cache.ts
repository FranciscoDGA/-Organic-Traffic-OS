import fs from "fs";
import path from "path";

const CACHE_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const CACHE_FILE = path.join(CACHE_DIR, "cache.json");

interface CacheEntry {
  key: string;
  data: any;
  createdAt: string; // ISO String
  expiresAt: string; // ISO String or null (never expires)
}

export class CollectorCache {
  private static ensureCacheExists() {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    if (!fs.existsSync(CACHE_FILE)) {
      fs.writeFileSync(CACHE_FILE, JSON.stringify({}, null, 2), "utf-8");
    }
  }

  private static readCache(): Record<string, CacheEntry> {
    this.ensureCacheExists();
    try {
      const content = fs.readFileSync(CACHE_FILE, "utf-8");
      return JSON.parse(content);
    } catch (err) {
      console.error("Erro ao ler cache.json, resetando...", err);
      return {};
    }
  }

  private static writeCache(cache: Record<string, CacheEntry>) {
    this.ensureCacheExists();
    try {
      fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), "utf-8");
    } catch (err) {
      console.error("Erro ao escrever no cache.json:", err);
    }
  }

  /**
   * Salva dados no cache com uma chave e TTL opcional (em segundos)
   */
  public static salvar(key: string, data: any, ttlSeconds?: number): void {
    const cache = this.readCache();
    const now = new Date();
    let expiresAt: string | null = null;

    if (ttlSeconds) {
      const expDate = new Date(now.getTime() + ttlSeconds * 1000);
      expiresAt = expDate.toISOString();
    }

    cache[key] = {
      key,
      data,
      createdAt: now.toISOString(),
      expiresAt: expiresAt || new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString() // Default 1 dia
    };

    this.writeCache(cache);
  }

  /**
   * Busca dados no cache, retorna null se não existir ou se expirado
   */
  public static buscar(key: string): any | null {
    const cache = this.readCache();
    const entry = cache[key];

    if (!entry) return null;

    if (entry.expiresAt) {
      const expiresAtDate = new Date(entry.expiresAt);
      if (new Date() > expiresAtDate) {
        // Expirou! Removemos e retornamos null
        this.expirar(key);
        return null;
      }
    }

    return entry.data;
  }

  /**
   * Força a expiração (remoção) de uma chave do cache
   */
  public static expirar(key: string): void {
    const cache = this.readCache();
    if (cache[key]) {
      delete cache[key];
      this.writeCache(cache);
    }
  }

  /**
   * Limpa todo o cache
   */
  public static limpar(): void {
    this.writeCache({});
  }

  /**
   * Valida se uma chave existe no cache e é válida (não expirada)
   */
  public static validar(key: string): boolean {
    const cache = this.readCache();
    const entry = cache[key];
    if (!entry) return false;

    if (entry.expiresAt) {
      const expiresAtDate = new Date(entry.expiresAt);
      if (new Date() > expiresAtDate) {
        return false;
      }
    }
    return true;
  }

  /**
   * Retorna todas as entradas do cache de forma simplificada para o Painel
   */
  public static listarCache(): any[] {
    const cache = this.readCache();
    return Object.values(cache).map(entry => {
      const isExpired = entry.expiresAt ? new Date() > new Date(entry.expiresAt) : false;
      return {
        key: entry.key,
        createdAt: entry.createdAt,
        expiresAt: entry.expiresAt,
        isExpired,
        sizeBytes: JSON.stringify(entry.data).length
      };
    });
  }
}
export default CollectorCache;
