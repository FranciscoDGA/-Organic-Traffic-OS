import { CollectorResult } from "./collector";

export class CollectorValidator {
  /**
   * Valida se o resultado segue a estrutura padrão de CollectorResult
   */
  public static validarEstrutura(resultado: any): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!resultado) {
      return { isValid: false, errors: ["Resultado nulo ou indefinido."] };
    }

    const camposObrigatorios = [
      "id",
      "collector",
      "origem",
      "data_coleta",
      "tipo",
      "conteudo",
      "confiabilidade",
      "status"
    ];

    for (const campo of camposObrigatorios) {
      if (resultado[campo] === undefined || resultado[campo] === null) {
        errors.push(`Campo obrigatório ausente: '${campo}'.`);
      }
    }

    if (resultado.confiabilidade !== undefined) {
      const conf = Number(resultado.confiabilidade);
      if (isNaN(conf) || conf < 0 || conf > 100) {
        errors.push("O campo 'confiabilidade' deve ser um número entre 0 e 100.");
      }
    }

    if (resultado.status && !["sucesso", "falha", "alerta"].includes(resultado.status)) {
      errors.push(`Status inválido: '${resultado.status}'. Valores aceitos: 'sucesso', 'falha', 'alerta'.`);
    }

    if (resultado.data_coleta) {
      const dateTest = Date.parse(resultado.data_coleta);
      if (isNaN(dateTest)) {
        errors.push(`Formato inválido de timestamp em 'data_coleta': '${resultado.data_coleta}'. Deve ser ISO 8601.`);
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Valida se há duplicidade entre o resultado atual e um conjunto de dados históricos
   */
  public static validarDuplicidade(resultado: CollectorResult, historico: CollectorResult[]): boolean {
    if (!resultado || !historico || historico.length === 0) return false;

    // Duplicidade baseada em ID, ou conteúdo de forma simples
    const contentString = JSON.stringify(resultado.conteudo);
    
    return historico.some(item => {
      if (item.id === resultado.id) return true;
      if (item.collector === resultado.collector && JSON.stringify(item.conteudo) === contentString) {
        return true;
      }
      return false;
    });
  }

  /**
   * Validação detalhada de integridade lógica dos dados dependendo do tipo de coletor
   */
  public static validarIntegridade(resultado: CollectorResult): { isValid: boolean; errors: string[] } {
    const structVal = this.validarEstrutura(resultado);
    if (!structVal.isValid) return structVal;

    const errors: string[] = [];

    // Verificações específicas do tipo de conteúdo
    if (resultado.tipo === "rss") {
      const conteudo = resultado.conteudo;
      if (conteudo && Array.isArray(conteudo.itens)) {
        if (conteudo.itens.length === 0) {
          errors.push("Aviso de integridade: Feed RSS não contém nenhum item de notícia.");
        } else {
          conteudo.itens.forEach((item: any, i: number) => {
            if (!item.titulo) errors.push(`Item ${i} do RSS está sem título.`);
            if (!item.link) errors.push(`Item ${i} do RSS está sem link de origem.`);
          });
        }
      } else {
        errors.push("Formato de conteúdo RSS inválido. Deve conter um objeto com um array 'itens'.");
      }
    }

    if (resultado.tipo === "manual") {
      const conteudo = resultado.conteudo;
      if (!conteudo || typeof conteudo !== "object" || Object.keys(conteudo).length === 0) {
        errors.push("Formato de entrada manual inválido. Conteúdo do objeto de entrada está vazio.");
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}
export default CollectorValidator;
