import fs from "fs";
import path from "path";

const QUEUE_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const QUEUE_FILE = path.join(QUEUE_DIR, "queue.json");

export interface QueueItem {
  id: string;
  collectorId: string;
  status: "pendente" | "executando" | "sucesso" | "falha" | "cancelado";
  tipoExecucao: "manual" | "agendada";
  dataAgendada: string; // ISO String
  dataExecucao?: string; // ISO String
  duracaoMs?: number;
  erro?: string;
  tentativas: number;
}

export class CollectorQueue {
  private static ensureQueueExists() {
    if (!fs.existsSync(QUEUE_DIR)) {
      fs.mkdirSync(QUEUE_DIR, { recursive: true });
    }
    if (!fs.existsSync(QUEUE_FILE)) {
      fs.writeFileSync(QUEUE_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public static listar(): QueueItem[] {
    this.ensureQueueExists();
    try {
      const content = fs.readFileSync(QUEUE_FILE, "utf-8");
      return JSON.parse(content);
    } catch (err) {
      console.error("Erro ao ler queue.json:", err);
      return [];
    }
  }

  private static salvarFila(fila: QueueItem[]) {
    this.ensureQueueExists();
    try {
      fs.writeFileSync(QUEUE_FILE, JSON.stringify(fila, null, 2), "utf-8");
    } catch (err) {
      console.error("Erro ao escrever no queue.json:", err);
    }
  }

  /**
   * Adiciona um novo item à fila para execução manual imediata ou futura agendada
   */
  public static adicionar(collectorId: string, tipo: "manual" | "agendada" = "manual", dataAgendada?: string): QueueItem {
    const fila = this.listar();
    const now = new Date();

    const novoItem: QueueItem = {
      id: "qitem-" + Math.random().toString(36).substring(2, 11),
      collectorId,
      status: "pendente",
      tipoExecucao: tipo,
      dataAgendada: dataAgendada || now.toISOString(),
      tentativas: 0
    };

    fila.unshift(novoItem); // Novo na frente
    this.salvarFila(fila);
    return novoItem;
  }

  /**
   * Cancela uma tarefa pendente na fila
   */
  public static cancelar(id: string): boolean {
    const fila = this.listar();
    const item = fila.find(i => i.id === id);
    if (item && item.status === "pendente") {
      item.status = "cancelado";
      this.salvarFila(fila);
      return true;
    }
    return false;
  }

  /**
   * Coloca um item de volta para pendente para reexecução imediata
   */
  public static reexecutar(id: string): QueueItem | null {
    const fila = this.listar();
    const item = fila.find(i => i.id === id);
    if (item) {
      item.status = "pendente";
      item.dataAgendada = new Date().toISOString();
      item.erro = undefined;
      item.duracaoMs = undefined;
      item.dataExecucao = undefined;
      this.salvarFila(fila);
      return item;
    }
    return null;
  }

  /**
   * Atualiza o status e parâmetros de um item da fila
   */
  public static atualizarStatus(id: string, status: QueueItem["status"], extra?: Partial<QueueItem>): void {
    const fila = this.listar();
    const idx = fila.findIndex(i => i.id === id);
    if (idx !== -1) {
      fila[idx] = {
        ...fila[idx],
        status,
        ...extra
      };
      this.salvarFila(fila);
    }
  }

  /**
   * Limpa a fila inteira
   */
  public static limpar(): void {
    this.salvarFila([]);
  }
}
export default CollectorQueue;
