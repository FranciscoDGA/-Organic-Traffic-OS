import { Collector, CollectorResult } from "../../base/collector";
import fs from "fs";
import path from "path";

const RESULTS_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const RESULTS_FILE = path.join(RESULTS_DIR, "results.json");

export class SearchConsoleCollector implements Collector {
  public id = "search-console-collector";
  public nome = "Google Search Console API Collector";
  public versão = "1.0.0";
  public fonte = "Google Search Console API (Oficial)";
  public status: "ativo" | "inativo" = "inativo"; // Placeholder inativo

  private ensureResultsFileExists() {
    if (!fs.existsSync(RESULTS_DIR)) {
      fs.mkdirSync(RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(RESULTS_FILE)) {
      fs.writeFileSync(RESULTS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public async coletar(params?: any): Promise<CollectorResult> {
    const siteUrl = params?.siteUrl || "https://passacumaru.com.br";
    
    // Placeholder payload
    const dataPlaceholder = {
      siteUrl,
      integrado: false,
      mensagem: "Este é um coletor placeholder preparado para integrações futuras com a API oficial do Search Console.",
      queriesPlaceholder: [
        { query: "concurso de passa e fica", clicks: 120, impressions: 850, ctr: 14.1, position: 2.1 },
        { query: "inscrição concurso passa e fica 2026", clicks: 80, impressions: 450, ctr: 17.7, position: 1.5 },
        { query: "banca de concurso agreste rn", clicks: 35, impressions: 310, ctr: 11.2, position: 4.2 }
      ]
    };

    const valid = this.validar(dataPlaceholder);
    const normalized = this.normalizar(dataPlaceholder);

    const result: CollectorResult = {
      id: "col-gsc-" + Math.random().toString(36).substring(2, 11),
      collector: this.id,
      origem: siteUrl,
      data_coleta: new Date().toISOString(),
      tipo: "search-console",
      conteudo: normalized,
      confiabilidade: 50, // Confiabilidade baixa para dados placeholder simulados
      status: "alerta",
      observacoes: "Módulo em estágio de placeholder. Aguardando credenciais OAuth do Google Search Console na Sprint 08."
    };

    await this.salvar(result);
    return result;
  }

  public validar(dados: any): { isValid: boolean; errors: string[] } {
    return { isValid: true, errors: [] };
  }

  public normalizar(dados: any): any {
    return dados;
  }

  public async salvar(resultado: CollectorResult): Promise<boolean> {
    this.ensureResultsFileExists();
    try {
      const content = fs.readFileSync(RESULTS_FILE, "utf-8");
      const results: CollectorResult[] = JSON.parse(content);
      results.unshift(resultado);
      if (results.length > 500) results.pop();
      fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Erro ao salvar resultado de Search Console Collector:", err);
      return false;
    }
  }
}
export default SearchConsoleCollector;
