import { Collector, CollectorResult } from "../../base/collector";
import fs from "fs";
import path from "path";

const RESULTS_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const RESULTS_FILE = path.join(RESULTS_DIR, "results.json");

export class PeopleAlsoAskCollector implements Collector {
  public id = "people-also-ask-collector";
  public nome = "Google People Also Ask (PAA) Collector";
  public versão = "1.0.0";
  public fonte = "Google SERP FAQ Extractions";
  public status: "ativo" | "inativo" = "inativo";

  private ensureResultsFileExists() {
    if (!fs.existsSync(RESULTS_DIR)) {
      fs.mkdirSync(RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(RESULTS_FILE)) {
      fs.writeFileSync(RESULTS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public async coletar(params?: any): Promise<CollectorResult> {
    const query = params?.query || "passa e fica concurso";
    const dataPlaceholder = {
      query,
      questions: [
        { pergunta: "Quando sai o edital do concurso de Passa e Fica?", resposta: "O edital tem previsão para o segundo semestre de 2026." },
        { pergunta: "Qual a banca do concurso de Passa e Fica?", resposta: "A comissão do concurso está em fase de escolha de banca licitada." },
        { pergunta: "Como se inscrever no concurso da Prefeitura de Passa e Fica?", resposta: "As inscrições serão realizadas de forma 100% online através do site da banca contratada." }
      ],
      mensagem: "Este é um coletor placeholder preparado para extrair perguntas e respostas sugeridas diretamente do bloco People Also Ask da SERP do Google."
    };

    const valid = this.validar(dataPlaceholder);
    const normalized = this.normalizar(dataPlaceholder);

    const result: CollectorResult = {
      id: "col-paa-" + Math.random().toString(36).substring(2, 11),
      collector: this.id,
      origem: `Google PAA: ${query}`,
      data_coleta: new Date().toISOString(),
      tipo: "people-also-ask",
      conteudo: normalized,
      confiabilidade: 50,
      status: "alerta",
      observacoes: "Módulo em estágio de placeholder."
    };

    await this.salvar(result);
    return result;
  }

  public validar(dados: any): { isValid: boolean; errors: string[] } {
    return { isValid: true, errors: [] };
  }

  public normalizar(dados: any): any {
    return dados;
  }

  public async salvar(resultado: CollectorResult): Promise<boolean> {
    this.ensureResultsFileExists();
    try {
      const content = fs.readFileSync(RESULTS_FILE, "utf-8");
      const results: CollectorResult[] = JSON.parse(content);
      results.unshift(resultado);
      if (results.length > 500) results.pop();
      fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Erro ao salvar resultado de PAA Collector:", err);
      return false;
    }
  }
}
export default PeopleAlsoAskCollector;
