import { Collector, CollectorResult } from "../base/collector";
import fs from "fs";
import path from "path";

const RESULTS_DIR = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache");
const RESULTS_FILE = path.join(RESULTS_DIR, "results.json");

export class NewsCollector implements Collector {
  public id = "news-collector";
  public nome = "Portal de Notícias Local RSS & HTML Collector";
  public versão = "1.0.0";
  public fonte = "Portais Regionais do RN (Diário de Natal, etc.)";
  public status: "ativo" | "inativo" = "inativo";

  private ensureResultsFileExists() {
    if (!fs.existsSync(RESULTS_DIR)) {
      fs.mkdirSync(RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(RESULTS_FILE)) {
      fs.writeFileSync(RESULTS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  public async coletar(params?: any): Promise<CollectorResult> {
    const portal = params?.portal || "Portal RN Concursos";
    const dataPlaceholder = {
      portal,
      noticias: [
        { titulo: "Abertura de vagas na Região Agreste bate recorde em 2026", data: "Ontem", autor: "Equipe Portal RN" },
        { titulo: "Candidatos se preparam para as provas unificadas do RN", data: "3 dias atrás", autor: "Colunista Político" }
      ],
      mensagem: "Este é um coletor placeholder preparado para crawlear portais regionais do RN para buscar notícias táticas de concursos."
    };

    const valid = this.validar(dataPlaceholder);
    const normalized = this.normalizar(dataPlaceholder);

    const result: CollectorResult = {
      id: "col-news-" + Math.random().toString(36).substring(2, 11),
      collector: this.id,
      origem: `News: ${portal}`,
      data_coleta: new Date().toISOString(),
      tipo: "news",
      conteudo: normalized,
      confiabilidade: 50,
      status: "alerta",
      observacoes: "Módulo em estágio de placeholder."
    };

    await this.salvar(result);
    return result;
  }

  public validar(dados: any): { isValid: boolean; errors: string[] } {
    return { isValid: true, errors: [] };
  }

  public normalizar(dados: any): any {
    return dados;
  }

  public async salvar(resultado: CollectorResult): Promise<boolean> {
    this.ensureResultsFileExists();
    try {
      const content = fs.readFileSync(RESULTS_FILE, "utf-8");
      const results: CollectorResult[] = JSON.parse(content);
      results.unshift(resultado);
      if (results.length > 500) results.pop();
      fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2), "utf-8");
      return true;
    } catch (err) {
      console.error("Erro ao salvar resultado de News Collector:", err);
      return false;
    }
  }
}
export default NewsCollector;
