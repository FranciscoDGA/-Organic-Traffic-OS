import { Strategy } from "./strategy-validator";

export class StrategyEngine {
  /**
   * Determina e gera automaticamente uma recomendação estratégica com base nos insumos do Brief e intenção de busca.
   */
  static generateStrategyRecommendation(params: {
    briefId: string;
    keyword: string;
    searchIntent: string;
    primaryCategory: string;
  }): Omit<Strategy, "status"> {
    const { briefId, keyword, searchIntent, primaryCategory } = params;

    const id = `strat-${briefId || "auto"}-${Math.floor(Math.random() * 1000)}`;
    let objective = "goal-teach";
    let persona = "persona-seo-analyst";
    let nivel_tecnico: "Iniciante" | "Intermediário" | "Avançado" = "Intermediário";
    let tom = "Didático e Pragmático";
    let cta = "cta-run-audit";
    let publico = "Analistas de Marketing e SEO Juniors";

    // Intent-based heuristic map
    const intentLower = searchIntent.toLowerCase();
    const keywordLower = keyword.toLowerCase();

    if (intentLower.includes("comercial") || intentLower.includes("transacional") || keywordLower.includes("melhor") || keywordLower.includes("comparativo")) {
      objective = "goal-sell";
      persona = "persona-tech-lead";
      nivel_tecnico = "Avançado";
      tom = "Especialista, Analítico e focado em ROI";
      cta = "cta-schedule-demo";
      publico = "Tech Leads, Gerentes de Produto e Diretores de Engenharia";
    } else if (intentLower.includes("informativa") || keywordLower.includes("o que é") || keywordLower.includes("como funciona")) {
      objective = "goal-teach";
      persona = "persona-seo-analyst";
      nivel_tecnico = "Iniciante";
      tom = "Didático, didático e de alta clareza";
      cta = "cta-run-audit";
      publico = "Profissionais de Conteúdo e SEO em transição de carreira";
    } else if (intentLower.includes("guias") || keywordLower.includes("passo a passo") || keywordLower.includes("tutorial")) {
      objective = "goal-solve-problem";
      persona = "persona-seo-analyst";
      nivel_tecnico = "Intermediário";
      tom = "Pragmático, direto ao ponto e focado em soluções";
      cta = "cta-read-blueprint";
      publico = "Analistas de SEO Sêniors e Implementadores Técnicos";
    }

    const narrativa = `Abordar a palavra-chave '${keyword}' com foco principal em '${primaryCategory || "SEO Técnico"}'. A narrativa deve esclarecer como a automação estruturada resolve a dor principal da persona de forma escalável, utilizando as soluções do Organic OS.`;

    return {
      id,
      objetivo: objective,
      publico,
      persona,
      intencao: searchIntent || "Informativa",
      nivel_tecnico,
      tom,
      narrativa,
      cta
    };
  }
}
