import fs from "fs";
import path from "path";
import { Strategy, StrategyValidator } from "./strategy-validator";

export class StrategyService {
  private static getFilePath(subPath: string): string {
    return path.join(process.cwd(), "organic-traffic-os", "strategy", subPath);
  }

  static getStrategies(): Strategy[] {
    try {
      const filePath = this.getFilePath("strategy.json");
      if (fs.existsSync(filePath)) {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
      }
    } catch (e) {
      console.error("Erro ao ler strategy.json", e);
    }
    return [];
  }

  static getPersonas() {
    try {
      const filePath = this.getFilePath("personas/persona-map.json");
      if (fs.existsSync(filePath)) {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
      }
    } catch (e) {
      console.error("Erro ao ler persona-map.json", e);
    }
    return [];
  }

  static getCTAs() {
    try {
      const filePath = this.getFilePath("cta/cta-strategy.json");
      if (fs.existsSync(filePath)) {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
      }
    } catch (e) {
      console.error("Erro ao ler cta-strategy.json", e);
    }
    return [];
  }

  static getGoals() {
    try {
      const filePath = this.getFilePath("templates/content-goals.json");
      if (fs.existsSync(filePath)) {
        const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
        return data.categorias || {};
      }
    } catch (e) {
      console.error("Erro ao ler content-goals.json", e);
    }
    return {};
  }

  static createStrategy(data: Omit<Strategy, "status">): { success: boolean; strategy?: Strategy; error?: string } {
    try {
      const strategies = this.getStrategies();
      const personas = this.getPersonas();
      const ctas = this.getCTAs();
      const goals = this.getGoals();

      const allowedPersonas = personas.map((p: any) => p.id);
      const allowedCTAs = ctas.map((c: any) => c.id);
      const allowedGoals = Object.keys(goals);

      const newStrategy: Strategy = {
        ...data,
        status: "Aprovado" // Auto-approve valid entries
      };

      // Perform strict validation
      const validation = StrategyValidator.validate(newStrategy, allowedPersonas, allowedCTAs, allowedGoals);
      if (!validation.isValid) {
        return { success: false, error: `Falha na validação do contrato estratégico: ${validation.errors.join("; ")}` };
      }

      // Check if ID already exists
      if (strategies.some((s) => s.id === newStrategy.id)) {
        return { success: false, error: `Já existe uma estratégia cadastrada com o ID '${newStrategy.id}'.` };
      }

      strategies.push(newStrategy);
      fs.writeFileSync(this.getFilePath("strategy.json"), JSON.stringify(strategies, null, 2), "utf-8");

      return { success: true, strategy: newStrategy };
    } catch (err: any) {
      return { success: false, error: err.message || "Erro inesperado ao persistir estratégia." };
    }
  }

  static updateStrategyStatus(id: string, status: "Pendente" | "Aprovado" | "Rejeitado"): boolean {
    try {
      const strategies = this.getStrategies();
      const index = strategies.findIndex((s) => s.id === id);
      if (index !== -1) {
        strategies[index].status = status;
        fs.writeFileSync(this.getFilePath("strategy.json"), JSON.stringify(strategies, null, 2), "utf-8");
        return true;
      }
    } catch (e) {
      console.error("Erro ao atualizar status de estratégia", e);
    }
    return false;
  }
}
