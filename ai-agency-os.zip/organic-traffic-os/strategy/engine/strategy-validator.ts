export interface Strategy {
  id: string;
  objetivo: string;
  publico: string;
  persona: string;
  intencao: string;
  nivel_tecnico: "Iniciante" | "Intermediário" | "Avançado";
  tom: string;
  narrativa: string;
  cta: string;
  status: "Pendente" | "Aprovado" | "Rejeitado";
}

export interface StrategyValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export class StrategyValidator {
  /**
   * Valida as diretrizes de uma estratégia de conteúdo proposta.
   */
  static validate(
    strategy: Strategy,
    allowedPersonas: string[],
    allowedCTAs: string[],
    allowedGoals: string[]
  ): StrategyValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 1. Validar preenchimento geral de campos obrigatórios
    if (!strategy.id) errors.push("ID da estratégia é obrigatório.");
    if (!strategy.publico || strategy.publico.trim() === "") {
      errors.push("O público-alvo da estratégia não pode estar vazio.");
    }
    if (!strategy.tom || strategy.tom.trim() === "") {
      errors.push("O tom de voz recomendado não pode estar vazio.");
    }

    // 2. Validar Persona referenciada
    if (!strategy.persona) {
      errors.push("Uma Persona de público-alvo precisa ser selecionada.");
    } else if (allowedPersonas.length > 0 && !allowedPersonas.includes(strategy.persona)) {
      errors.push(`A Persona '${strategy.persona}' não foi mapeada formalmente no cadastro de Personas.`);
    }

    // 3. Validar Objetivo referenciado
    if (!strategy.objetivo) {
      errors.push("O objetivo estratégico de conteúdo é obrigatório.");
    } else if (allowedGoals.length > 0 && !allowedGoals.includes(strategy.objetivo)) {
      errors.push(`O objetivo '${strategy.objetivo}' não faz parte das categorias homologadas.`);
    }

    // 4. Validar CTA correspondente
    if (!strategy.cta) {
      errors.push("O call-to-action (CTA) principal é obrigatório.");
    } else if (allowedCTAs.length > 0 && !allowedCTAs.includes(strategy.cta)) {
      errors.push(`O CTA '${strategy.cta}' não corresponde a uma tática de conversão homologada.`);
    }

    // 5. Validar profundidade narrativa
    if (!strategy.narrativa || strategy.narrativa.trim().length < 20) {
      errors.push("A narrativa principal precisa ser descrita com profundidade mínima de 20 caracteres.");
    }

    // 6. Alertas e boas práticas (Warnings)
    if (strategy.nivel_tecnico === "Avançado" && strategy.tom.toLowerCase().includes("emocional")) {
      warnings.push("Estratégias de nível técnico 'Avançado' performam melhor com tons mais 'Especialistas' e 'Analíticos' do que puramente emocionais.");
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}
