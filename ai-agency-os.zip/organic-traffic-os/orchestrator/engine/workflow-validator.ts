import { PipelineDefinition, WorkflowExecution, WorkflowState } from "../models/workflow-models";
import stateMachine from "../state/state-machine.json";

export class WorkflowValidator {
  /**
   * Validates if a state transition is permitted by the state machine definition
   */
  public static isValidTransition(fromState: WorkflowState, toState: WorkflowState): boolean {
    if (fromState === toState) return true;
    
    const rules = (stateMachine as Record<string, any>)[fromState];
    if (!rules) return false;
    
    const allowed = rules.proximos_estados_permitidos || [];
    return allowed.includes(toState);
  }

  /**
   * Validates that the sequence of steps in a pipeline satisfies the declared dependency graph.
   * If a step depends on another step, that dependency must appear BEFORE it in the list.
   */
  public static validatePipelineDependencies(pipeline: PipelineDefinition): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];
    const registeredStepIds = new Set<string>();

    for (const step of pipeline.etapas) {
      // Check if step ID is unique
      if (registeredStepIds.has(step.id)) {
        errors.push(`Identificador de etapa duplicado: '${step.id}' na definição do pipeline.`);
      }
      registeredStepIds.add(step.id);

      // Verify that all declared dependencies are already processed/defined before this step
      for (const depId of step.dependencias) {
        if (!registeredStepIds.has(depId)) {
          errors.push(`A etapa '${step.nome}' (${step.id}) depende de '${depId}', que não foi definida anteriormente no fluxo.`);
        }
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Performs an integrity check on an active workflow execution
   */
  public static validateExecutionIntegrity(execution: WorkflowExecution): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!execution.id || !execution.id.trim()) {
      errors.push("O identificador da execução (id) é obrigatório.");
    }
    if (!execution.blog || !execution.blog.trim()) {
      errors.push("O nome do blog de destino é obrigatório.");
    }
    if (!execution.pipelineId) {
      errors.push("O identificador do pipeline é obrigatório.");
    }
    if (execution.progresso < 0 || execution.progresso > 100) {
      errors.push("O progresso da execução deve estar compreendido entre 0% e 100%.");
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}
