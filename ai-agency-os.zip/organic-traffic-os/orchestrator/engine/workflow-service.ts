import fs from "fs";
import path from "path";
import {
  PipelineDefinition,
  WorkflowExecution,
  WorkflowEvent,
  RetryPolicy,
  WorkflowState,
  PipelineStep
} from "../models/workflow-models";
import { WorkflowValidator } from "./workflow-validator";

const PIPELINE_PATH = path.join(process.cwd(), "organic-traffic-os", "orchestrator", "pipelines", "pipeline-definition.json");
const EXECUTIONS_PATH = path.join(process.cwd(), "organic-traffic-os", "orchestrator", "executions", "execution.json");
const EVENTS_PATH = path.join(process.cwd(), "organic-traffic-os", "orchestrator", "events", "events.json");
const RETRY_PATH = path.join(process.cwd(), "organic-traffic-os", "orchestrator", "state", "retry-policy.json");

export class WorkflowService {
  // --- Data Loaders & Savers ---
  
  public static getPipelineDefinition(): PipelineDefinition {
    try {
      if (!fs.existsSync(PIPELINE_PATH)) {
        throw new Error("Definição do pipeline principal não encontrada.");
      }
      return JSON.parse(fs.readFileSync(PIPELINE_PATH, "utf-8"));
    } catch (e: any) {
      throw new Error(`Falha ao ler definição de pipeline: ${e.message}`);
    }
  }

  public static getExecutions(): WorkflowExecution[] {
    try {
      if (!fs.existsSync(EXECUTIONS_PATH)) return [];
      return JSON.parse(fs.readFileSync(EXECUTIONS_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  public static saveExecutions(executions: WorkflowExecution[]): void {
    try {
      fs.writeFileSync(EXECUTIONS_PATH, JSON.stringify(executions, null, 2), "utf-8");
    } catch (e: any) {
      throw new Error(`Erro ao salvar execuções: ${e.message}`);
    }
  }

  public static getEvents(): WorkflowEvent[] {
    try {
      if (!fs.existsSync(EVENTS_PATH)) return [];
      return JSON.parse(fs.readFileSync(EVENTS_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  public static saveEvents(events: WorkflowEvent[]): void {
    try {
      fs.writeFileSync(EVENTS_PATH, JSON.stringify(events, null, 2), "utf-8");
    } catch (e: any) {
      throw new Error(`Erro ao salvar eventos do orquestrador: ${e.message}`);
    }
  }

  public static getRetryPolicy(): RetryPolicy {
    try {
      if (!fs.existsSync(RETRY_PATH)) {
        return { maxAttempts: 3, backoffSeconds: 2, retryOnErrors: [] };
      }
      return JSON.parse(fs.readFileSync(RETRY_PATH, "utf-8"));
    } catch (e) {
      return { maxAttempts: 3, backoffSeconds: 2, retryOnErrors: [] };
    }
  }

  // --- Core API Helpers ---

  public static getExecution(id: string): WorkflowExecution | null {
    const list = this.getExecutions();
    return list.find(ex => ex.id === id) || null;
  }

  public static getEventsByExecution(executionId: string): WorkflowEvent[] {
    const list = this.getEvents();
    return list.filter(evt => evt.executionId === executionId);
  }

  /**
   * Log an event linked to a specific workflow execution
   */
  public static addEvent(
    executionId: string,
    tipo: WorkflowEvent["tipo"],
    mensagem: string,
    etapa?: string,
    detalhes?: string
  ): WorkflowEvent {
    const events = this.getEvents();
    const newEvent: WorkflowEvent = {
      id: `evt-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 4)}`,
      executionId,
      data: new Date().toISOString(),
      tipo,
      etapa,
      mensagem,
      detalhes
    };
    events.push(newEvent);
    this.saveEvents(events);
    return newEvent;
  }

  /**
   * Initiates a brand new pipeline execution record
   */
  public static registerNewExecution(blogName: string): WorkflowExecution {
    const pipeline = this.getPipelineDefinition();
    
    // Validate the topological steps
    const pipelineVal = WorkflowValidator.validatePipelineDependencies(pipeline);
    if (!pipelineVal.isValid) {
      throw new Error(`Pipeline corrompido: ${pipelineVal.errors.join(" | ")}`);
    }

    const executions = this.getExecutions();
    const firstStepId = pipeline.etapas[0]?.id || "";

    const newExec: WorkflowExecution = {
      id: `exec-${Date.now().toString(36)}`,
      pipelineId: pipeline.id,
      blog: blogName,
      status: "Pending",
      etapa_atual: firstStepId,
      progresso: 0,
      inicio: new Date().toISOString(),
      erros: [],
      avisos: [],
      tentativas: {}
    };

    // Initialize attempts count for steps
    pipeline.etapas.forEach(step => {
      newExec.tentativas[step.id] = 0;
    });

    const val = WorkflowValidator.validateExecutionIntegrity(newExec);
    if (!val.isValid) {
      throw new Error(`Execução inválida: ${val.errors.join(" | ")}`);
    }

    executions.push(newExec);
    this.saveExecutions(executions);

    this.addEvent(
      newExec.id,
      "inicio",
      `Workflow registrado e agendado para o blog '${blogName}'.`,
      undefined,
      `Pipeline ID: ${pipeline.id}`
    );

    return newExec;
  }

  /**
   * Update and save status changes
   */
  public static updateExecutionState(id: string, newState: WorkflowState, reason = ""): WorkflowExecution {
    const list = this.getExecutions();
    const idx = list.findIndex(ex => ex.id === id);
    if (idx === -1) {
      throw new Error(`Execução '${id}' não encontrada.`);
    }

    const current = list[idx];
    if (!WorkflowValidator.isValidTransition(current.status, newState)) {
      throw new Error(`Transição de estado inválida de '${current.status}' para '${newState}'.`);
    }

    current.status = newState;
    
    if (newState === "Completed") {
      current.fim = new Date().toISOString();
      current.progresso = 100;
      current.tempo_total = this.calculateTotalTime(current.inicio, current.fim);
      this.addEvent(id, "fim", "Sessão do pipeline concluída com sucesso.", undefined, reason);
    } else if (newState === "Failed") {
      current.fim = new Date().toISOString();
      current.tempo_total = this.calculateTotalTime(current.inicio, current.fim);
      this.addEvent(id, "erro", `Execução interrompida por erro crítico.`, current.etapa_atual, reason);
    } else if (newState === "Cancelled") {
      current.fim = new Date().toISOString();
      current.tempo_total = this.calculateTotalTime(current.inicio, current.fim);
      this.addEvent(id, "cancelamento", `Pipeline cancelado manualmente pelo operador de SEO.`, current.etapa_atual, reason);
    } else if (newState === "Paused") {
      this.addEvent(id, "aviso", `Pipeline pausado temporariamente pelo usuário.`, current.etapa_atual, reason);
    } else if (newState === "Running") {
      this.addEvent(id, "inicio", `Pipeline retomado / iniciado em modo de processamento ativo.`, current.etapa_atual, reason);
    }

    list[idx] = current;
    this.saveExecutions(list);
    return current;
  }

  private static calculateTotalTime(startStr: string, endStr: string): string {
    const start = new Date(startStr).getTime();
    const end = new Date(endStr).getTime();
    const diffMs = end - start;
    if (diffMs <= 0) return "0s";
    
    const totalSecs = Math.floor(diffMs / 1000);
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    
    if (mins > 0) {
      return `${mins}m ${secs}s`;
    }
    return `${secs}s`;
  }
}
