import fs from "fs";
import path from "path";
import { WorkflowService } from "./workflow-service";
import { WorkflowExecution, PipelineStep, WorkflowState } from "../models/workflow-models";

// Map to track running interval/timer IDs so we can stop/cancel them cleanly in-memory
const activeIntervals: Record<string, NodeJS.Timeout> = {};

export class WorkflowOrchestrator {
  /**
   * Starts or Resumes an execution asynchronously
   */
  public static async startOrResume(executionId: string): Promise<void> {
    const execution = WorkflowService.getExecution(executionId);
    if (!execution) {
      throw new Error(`Execução '${executionId}' não encontrada para iniciar.`);
    }

    // Move to Running
    try {
      WorkflowService.updateExecutionState(executionId, "Running", "Iniciando processamento ativo do pipeline.");
    } catch (e: any) {
      // Transition might already be running if we just resume
    }

    // Trigger asynchronous step processor
    this.runProcessorLoop(executionId);
  }

  /**
   * Pauses an active execution
   */
  public static pause(executionId: string): void {
    const execution = WorkflowService.getExecution(executionId);
    if (!execution) throw new Error("Execução não encontrada.");
    
    WorkflowService.updateExecutionState(executionId, "Paused", "Pausa solicitada pelo usuário.");
    this.clearTimer(executionId);
  }

  /**
   * Cancels an active execution
   */
  public static cancel(executionId: string): void {
    const execution = WorkflowService.getExecution(executionId);
    if (!execution) throw new Error("Execução não encontrada.");
    
    WorkflowService.updateExecutionState(executionId, "Cancelled", "Cancelamento manual comandado.");
    this.clearTimer(executionId);
  }

  /**
   * Resumes a paused or failed execution
   */
  public static resume(executionId: string): void {
    const execution = WorkflowService.getExecution(executionId);
    if (!execution) throw new Error("Execução não encontrada.");

    if (execution.status !== "Paused" && execution.status !== "Failed") {
      throw new Error("Apenas execuções pausadas ou com falha podem ser retomadas.");
    }

    // Reset current step attempts count to allow retrying
    const list = WorkflowService.getExecutions();
    const idx = list.findIndex(ex => ex.id === executionId);
    if (idx !== -1) {
      list[idx].status = "Running";
      list[idx].tentativas[list[idx].etapa_atual] = 0; // reset attempts of current step
      WorkflowService.saveExecutions(list);
    }

    WorkflowService.addEvent(
      executionId,
      "inicio",
      `Processamento retomado a partir da etapa atual: '${execution.etapa_atual}'.`,
      execution.etapa_atual
    );

    this.runProcessorLoop(executionId);
  }

  // --- Internals ---

  private static clearTimer(executionId: string) {
    if (activeIntervals[executionId]) {
      clearTimeout(activeIntervals[executionId]);
      delete activeIntervals[executionId];
    }
  }

  /**
   * The actual asynchronous processing loop
   */
  private static runProcessorLoop(executionId: string) {
    this.clearTimer(executionId);

    const stepIntervalMs = 1500; // time simulated for each step

    const processNext = async () => {
      // Reload execution state to check if user paused or cancelled
      const exec = WorkflowService.getExecution(executionId);
      if (!exec || exec.status !== "Running") {
        this.clearTimer(executionId);
        return;
      }

      const pipeline = WorkflowService.getPipelineDefinition();
      const steps = pipeline.etapas;

      // Find the step index of the current step
      const currentStepIdx = steps.findIndex(s => s.id === exec.etapa_atual);
      if (currentStepIdx === -1) {
        // Corrupted step ID
        this.failExecution(executionId, `Identificador de etapa corrompido ou inválido: '${exec.etapa_atual}'.`);
        return;
      }

      const step = steps[currentStepIdx];

      // Simulate step execution logic
      const success = await this.executeStepSimulation(exec, step);

      if (success) {
        // Move to next step or complete pipeline
        const nextStepIdx = currentStepIdx + 1;
        
        // Calculate progress
        const nextProgress = Math.round((nextStepIdx / steps.length) * 100);
        
        const list = WorkflowService.getExecutions();
        const liveIdx = list.findIndex(ex => ex.id === executionId);
        
        if (liveIdx !== -1) {
          const liveExec = list[liveIdx];
          liveExec.progresso = nextProgress;

          if (nextStepIdx < steps.length) {
            // Advance to next stage
            const nextStep = steps[nextStepIdx];
            liveExec.etapa_atual = nextStep.id;
            WorkflowService.saveExecutions(list);

            WorkflowService.addEvent(
              executionId,
              "etapa_sucesso",
              `Etapa '${step.nome}' concluída. Avançando para '${nextStep.nome}'.`,
              step.id,
              `Progresso atual: ${nextProgress}%`
            );

            // Schedule next step execution
            activeIntervals[executionId] = setTimeout(processNext, stepIntervalMs);
          } else {
            // Finished last step! Complete pipeline
            liveExec.progresso = 100;
            WorkflowService.saveExecutions(list);
            
            WorkflowService.updateExecutionState(executionId, "Completed", "Todas as etapas do pipeline foram orquestradas.");
            
            // Generate final report
            this.generateExecutionReport(executionId);
            this.clearTimer(executionId);
          }
        }
      } else {
        // Step failed! Handle retry policy
        const policy = WorkflowService.getRetryPolicy();
        const currentAttempts = exec.tentativas[step.id] || 0;
        const nextAttempts = currentAttempts + 1;

        // Update attempts in file
        const list = WorkflowService.getExecutions();
        const liveIdx = list.findIndex(ex => ex.id === executionId);
        if (liveIdx !== -1) {
          list[liveIdx].tentativas[step.id] = nextAttempts;
          WorkflowService.saveExecutions(list);
        }

        if (nextAttempts < policy.maxAttempts) {
          // Retry within policy
          WorkflowService.addEvent(
            executionId,
            "retry",
            `Falha intermitente detectada na etapa '${step.nome}'. Tentativa ${nextAttempts}/${policy.maxAttempts}. Executando backoff de ${policy.backoffSeconds}s...`,
            step.id,
            `Erro simulado de timeout de conexão da API.`
          );

          // Wait backoff then run step again
          activeIntervals[executionId] = setTimeout(processNext, policy.backoffSeconds * 1000);
        } else {
          // Exhausted retries! Mark as failed
          this.failExecution(executionId, `Número máximo de tentativas (${policy.maxAttempts}) esgotado na etapa '${step.nome}'. Erro de barramento de dados persistente.`);
        }
      }
    };

    // Begin loop immediately
    activeIntervals[executionId] = setTimeout(processNext, 500);
  }

  private static failExecution(executionId: string, errorMsg: string) {
    const list = WorkflowService.getExecutions();
    const idx = list.findIndex(ex => ex.id === executionId);
    if (idx !== -1) {
      list[idx].erros.push(errorMsg);
      list[idx].status = "Failed";
      list[idx].fim = new Date().toISOString();
      WorkflowService.saveExecutions(list);
    }
    
    WorkflowService.updateExecutionState(executionId, "Failed", errorMsg);
    this.clearTimer(executionId);
  }

  /**
   * Simulated engine worker
   * Gives step-specific details, warnings and simulated results
   */
  private static async executeStepSimulation(exec: WorkflowExecution, step: PipelineStep): Promise<boolean> {
    // We simulate a 12% failure chance specifically on step-serp or step-research to demonstrate retry policy!
    const isErrorProne = step.id === "step-serp" || step.id === "step-research";
    if (isErrorProne) {
      const currentAttempts = exec.tentativas[step.id] || 0;
      // If it has not failed yet, trigger a mock failure
      if (currentAttempts === 0 && Math.random() < 0.35) {
        return false;
      }
    }

    // Add customized warning/info message based on step
    const list = WorkflowService.getExecutions();
    const liveIdx = list.findIndex(e => e.id === exec.id);
    if (liveIdx !== -1) {
      const live = list[liveIdx];
      
      if (step.id === "step-inventory") {
        live.avisos.push("Identificados 2 artigos arquivados sem tag de canonical.");
      } else if (step.id === "step-keywords") {
        live.avisos.push("Palavra-chave 'direito previdenciário' possui volume de busca saturado.");
      } else if (step.id === "step-sources") {
        live.avisos.push("Encontrado 1 link sem certificado HTTPS seguro (.gov.br).");
      }
      
      WorkflowService.saveExecutions(list);
    }

    return true;
  }

  /**
   * Generates a fully audit-compliant markdown report in reports/ folder
   */
  public static generateExecutionReport(executionId: string): string {
    const exec = WorkflowService.getExecution(executionId);
    if (!exec) return "";

    const events = WorkflowService.getEventsByExecution(executionId);
    const pipeline = WorkflowService.getPipelineDefinition();

    const reportContent = `# Relatório de Execução do Pipeline Unificado
## Identificador da Execução: \`${exec.id}\`

---

### Metadados Gerais
- **Blog de Destino:** ${exec.blog}
- **Pipeline Executado:** ${pipeline.nome} (v${pipeline.versao})
- **Status Final:** **${exec.status.toUpperCase()}**
- **Início do Processamento:** ${new Date(exec.inicio).toLocaleString()}
- **Fim do Processamento:** ${exec.fim ? new Date(exec.fim).toLocaleString() : "N/A"}
- **Tempo Total Decorrido:** ${exec.tempo_total || "N/A"}
- **Progresso de Conclusão:** ${exec.progresso}%

---

### Escopo de Execução das Etapas
A tabela abaixo detalha cada uma das engines orquestradas e seu papel na conformidade técnica do artigo:

| Etapa | Nome da Engine | Descrição | Módulo |
| :--- | :--- | :--- | :--- |
${pipeline.etapas.map((step, idx) => `| ${idx + 1} | **${step.nome}** | ${step.descricao} | \`${step.modulo}\` |`).join("\n")}

---

### Resumo Técnico de Anomalias
- **Total de Erros Registrados:** ${exec.erros.length}
${exec.erros.map(e => `  - ❌ *Erro:* ${e}`).join("\n")}
- **Total de Avisos Emitidos:** ${exec.avisos.length}
${exec.avisos.map(w => `  - ⚠️ *Aviso:* ${w}`).join("\n")}

---

### Trilha Cronológica de Eventos (Audit Trail)
Abaixo está o log cronológico completo de mensagens disparadas pelas engines durante a orquestração:

${events.map(evt => `- **[${new Date(evt.data).toLocaleTimeString()}]** \`[${evt.tipo.toUpperCase()}]\` ${evt.mensagem} ${evt.detalhes ? `*(${evt.detalhes})*` : ""}`).join("\n")}

---
*Relatório emitido automaticamente pelo Workflow Orchestrator do Organic Traffic OS.*
`;

    const reportsDir = path.join(process.cwd(), "organic-traffic-os", "orchestrator", "reports");
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }

    const reportPath = path.join(reportsDir, `execution-report-${executionId}.md`);
    fs.writeFileSync(reportPath, reportContent, "utf-8");

    return reportContent;
  }
}
