export type WorkflowState = "Pending" | "Running" | "Paused" | "Completed" | "Failed" | "Cancelled";

export interface PipelineStep {
  id: string;
  nome: string;
  descricao: string;
  modulo: string;
  dependencias: string[];
}

export interface PipelineDefinition {
  id: string;
  versao: string;
  nome: string;
  descricao: string;
  etapas: PipelineStep[];
}

export interface WorkflowExecution {
  id: string;
  pipelineId: string;
  blog: string;
  status: WorkflowState;
  etapa_atual: string; // Step ID
  progresso: number; // 0-100
  inicio: string;
  fim?: string;
  tempo_total?: string; // e.g., "1m 32s"
  erros: string[];
  avisos: string[];
  tentativas: Record<string, number>; // Record of stepId -> current retry attempts count
}

export interface WorkflowEvent {
  id: string;
  executionId: string;
  data: string;
  tipo: "inicio" | "fim" | "erro" | "aviso" | "retry" | "cancelamento" | "etapa_sucesso" | "etapa_inicio";
  etapa?: string;
  mensagem: string;
  detalhes?: string;
}

export interface RetryPolicy {
  maxAttempts: number;
  backoffSeconds: number;
  retryOnErrors: string[];
}
