# Sprint 15 Summary — Content Workflow Orchestrator V1

## Objetivo Geral
Implementar o orquestrador unificado de fluxo de trabalho do **Organic Traffic OS**. Ele coordena e executa todas as 12 engines criadas ao longo do projeto em uma ordem topologicamente correta, registrando o progresso, tratando falhas via políticas de re-tentativa (retries) com backoff e emitindo relatórios de auditoria técnicos detalhados ao fim de cada sessão.

Nenhuma engine individual de IA, conformidade ou arquitetura deverá ser invocada diretamente pelo operador; toda a execução agora é gerenciada de forma centralizada pelo orquestrador.

---

## 📂 Arquitetura Física e Estrutura de Diretórios
O módulo foi acomodado de forma isolada e modularizada sob a pasta:

```text
organic-traffic-os/orchestrator/
├── models/
│   └── workflow-models.ts       # Tipagens TypeScript estritas de pipelines, estados e eventos
├── engine/
│   ├── workflow-orchestrator.ts # Motor assíncrono de execução, re-tentativa e geração de logs
│   ├── workflow-service.ts      # Serviços I/O de persistência de execuções, eventos e políticas
│   └── workflow-validator.ts    # Validador de integridade, ordem de dependências e transições
├── pipelines/
│   └── pipeline-definition.json # Grafo sequencial das 12 etapas oficiais de produção
├── state/
│   ├── state-machine.json       # Definição declarativa da máquina de estados permitidos
│   └── retry-policy.json        # Configuração de limites de tentativas e tempo de recuo (backoff)
├── executions/
│   └── execution.json           # Banco de dados local de histórico de execuções
├── events/
│   └── events.json              # Banco de dados local de logs de auditoria cronológicos
└── reports/
    ├── sprint-15-summary.md     # Este documento técnico explicativo
    └── execution-report-*.md    # Relatórios gerados automaticamente ao fim de cada execução
```

---

## 🗺️ Pipeline de Produção Declarativo (`pipeline-definition.json`)
O pipeline foi construído para alinhar perfeitamente a progressão das dependências lógicas de conformidade técnica:

1. **Knowledge Base (`step-knowledge`)** ➔ Define o nicho e tom.
2. **Inventory Analysis (`step-inventory`)** ➔ Evita canibalização de URLs (depende do Conhecimento).
3. **Competitors Intelligence (`step-competitors`)** ➔ Mapeia os blogs concorrentes.
4. **SERP Analysis (`step-serp`)** ➔ Avalia intenções de busca do Google.
5. **Keyword Clustering (`step-keywords`)** ➔ Agrupa palavras-chave secundárias relevantes.
6. **Opportunity Mapping (`step-opportunity`)** ➔ Identifica as melhores lacunas com potencial imediato de tráfego.
7. **Editorial Planner (`step-editorial`)** ➔ Cria o cronograma estratégico de pautas prioritárias.
8. **Editorial Briefs (`step-briefs`)** ➔ Organiza seções, headings (H2/H3) e CTAs.
9. **Page Blueprints (`step-blueprints`)** ➔ Estrutura o layout visual, links e densidade.
10. **Research Packs (`step-research`)** ➔ Consolida dados brutos governamentais ou de mercado.
11. **Fact Checking Engine (`step-facts`)** ➔ Valida fatos e declarações empíricas a serem citadas.
12. **Source Intelligence Engine (`step-sources`)** ➔ Avalia a autoridade científica das fontes de lastro.

---

## ⚙️ Máquina de Estados (`state-machine.json`)
As execuções progridem de maneira determinística, obedecendo regras estritas de transição:

- **`Pending`**: Execução inicializada e aguardando processador ativo.
- **`Running`**: Etapas processadas recursivamente.
- **`Paused`**: Interrupção temporária acionada pelo usuário para validação manual de dados.
- **`Completed`**: Grafo de etapas concluído com absoluto sucesso de validação.
- **`Failed`**: Ocorreu um erro impeditivo sem mais tentativas de retry disponíveis.
- **`Cancelled`**: Processo voluntariamente abortado pelo operador de conteúdo.

---

## 🛡️ Tratamento de Erros e Política de Retentativas (Retry Policy)
Configurado de forma centralizada em `retry-policy.json`, o orquestrador lida com falhas temporárias de forma robusta:
- **Máximo de Tentativas**: `3` tentativas consecutivas antes de abortar a etapa.
- **Tempo de Recuo (Backoff)**: `2 segundos` de atraso entre falhas consecutivas de uma etapa.
- **Intermitência Simulada**: Etapas sensíveis à API externa (como `SERP Analysis` ou `Research Packs`) possuem chance de falha transitória configurada no orquestrador para demonstrar visualmente o fluxo de retentativa, recuo e restauração da estabilidade do pipeline em tempo real.

---

## 🧩 Como Adicionar Novas Etapas ao Pipeline
Para estender a esteira de orquestração do **Organic Traffic OS**, siga estes passos simples:

1. **Defina a Nova Etapa no Grafo**:
   Abra `/organic-traffic-os/orchestrator/pipelines/pipeline-definition.json` e adicione o objeto da etapa no vetor `"etapas"`, declarando suas dependências de etapas anteriores. Exemplo:
   ```json
   {
     "id": "step-indexing-request",
     "nome": "Google Indexing API Trigger",
     "descricao": "Envia o artigo gerado automaticamente para requisição de indexação prioritária.",
     "modulo": "Indexing Engine",
     "dependencias": ["step-sources"]
   }
   ```

2. **Acople o Simulador / Executor**:
   Abra `/organic-traffic-os/orchestrator/engine/workflow-orchestrator.ts` e atualize o método `executeStepSimulation()` para prever comportamentos, warnings específicos ou regras de negócio para a nova etapa (`step-indexing-request`).

3. **Valide a Sequência de Dependências**:
   Ao iniciar o fluxo de trabalho, o `WorkflowValidator.validatePipelineDependencies()` garantirá de forma automatizada que a nova etapa respeita a ordenação topológica declarada antes do início da execução física.
