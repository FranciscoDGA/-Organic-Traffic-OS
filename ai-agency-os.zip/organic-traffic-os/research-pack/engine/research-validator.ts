import { ResearchPack, ResearchValidation } from "../models/research-models";

/**
 * Validates a ResearchPack for completeness, structural integrity, duplicates, links, and entities.
 */
export function validateResearchPack(pack: Partial<ResearchPack>): ResearchValidation {
  const errors: string[] = [];
  const warnings: string[] = [];

  // 1. Campos obrigatórios (Required fields)
  if (!pack.id) errors.push("Campo obrigatório ausente: 'id'.");
  if (!pack.brief_id) errors.push("Campo obrigatório ausente: 'brief_id'.");
  if (!pack.blueprint_id) errors.push("Campo obrigatório ausente: 'blueprint_id'.");
  if (!pack.titulo || pack.titulo.trim() === "") errors.push("Campo obrigatório ausente ou vazio: 'titulo'.");
  if (!pack.objetivo || pack.objetivo.trim() === "") errors.push("Campo obrigatório ausente ou vazio: 'objetivo'.");
  if (!pack.contexto || pack.contexto.trim() === "") errors.push("Campo obrigatório ausente ou vazio: 'contexto'.");

  // 2. Estrutura (Structural checklist)
  if (!pack.entidades || !Array.isArray(pack.entidades)) {
    errors.push("Estrutura inválida: 'entidades' deve ser uma lista (array).");
  } else if (pack.entidades.length === 0) {
    warnings.push("O dossiê de pesquisa não contém nenhuma entidade obrigatória mapeada.");
  }

  if (!pack.perguntas || !Array.isArray(pack.perguntas)) {
    errors.push("Estrutura inválida: 'perguntas' deve ser uma lista (array).");
  } else if (pack.perguntas.length === 0) {
    warnings.push("Nenhuma pergunta chave de SEO foi mapeada para este conteúdo.");
  }

  if (!pack.fontes || !Array.isArray(pack.fontes)) {
    errors.push("Estrutura inválida: 'fontes' deve ser uma lista (array).");
  } else if (pack.fontes.length === 0) {
    errors.push("É obrigatório mapear ao menos uma fonte oficial ou de documentação.");
  }

  if (!pack.fatos || !Array.isArray(pack.fatos)) {
    errors.push("Estrutura inválida: 'fatos' deve ser uma lista (array).");
  } else if (pack.fatos.length === 0) {
    warnings.push("Nenhum fato técnico relevante foi adicionado ao dossiê.");
  }

  // 3. Duplicidades (Checking for duplicates)
  if (pack.entidades && Array.isArray(pack.entidades)) {
    const seenEntities = new Set<string>();
    pack.entidades.forEach(ent => {
      const normalized = ent.toLowerCase().trim();
      if (seenEntities.has(normalized)) {
        warnings.push(`Entidade duplicada no dossiê: "${ent}".`);
      }
      seenEntities.add(normalized);
    });
  }

  if (pack.perguntas && Array.isArray(pack.perguntas)) {
    const seenQuestions = new Set<string>();
    pack.perguntas.forEach(q => {
      const normalized = (q.pergunta || "").toLowerCase().trim();
      if (seenQuestions.has(normalized)) {
        warnings.push(`Pergunta duplicada no dossiê: "${q.pergunta}".`);
      }
      seenQuestions.add(normalized);
    });
  }

  if (pack.fatos && Array.isArray(pack.fatos)) {
    const seenFacts = new Set<string>();
    pack.fatos.forEach(f => {
      const normalized = (f.descricao || "").toLowerCase().trim();
      if (seenFacts.has(normalized)) {
        warnings.push(`Fato duplicado no dossiê: "${f.descricao.slice(0, 30)}...".`);
      }
      seenFacts.add(normalized);
    });
  }

  // 4. Links (Validating source URLs)
  if (pack.fontes && Array.isArray(pack.fontes)) {
    pack.fontes.forEach(fonte => {
      if (!fonte.url || fonte.url.trim() === "") {
        errors.push(`Fonte "${fonte.nome}" possui URL vazia.`);
      } else {
        const urlStr = (fonte.url || "").trim();
        const hasProtocol = urlStr.startsWith("http://") || urlStr.startsWith("https://");
        if (!hasProtocol) {
          errors.push(`URL inválida para a fonte "${fonte.nome}": "${fonte.url}". Deve iniciar com http:// ou https://.`);
        }
      }
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
