import fs from "fs";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { ResearchPack, ResearchScore, ResearchQuestion, ResearchFact } from "../models/research-models";
import { validateResearchPack } from "./research-validator";

// Import prior engines & loaders
import { ArchitectService } from "../../content-architecture/engine/architect-service";
import { BriefLoader } from "../../briefs/brief-engine/brief-engine";
import { loadKnowledgeCore } from "../../knowledge/knowledge-loader";
import { loadInventory } from "../../inventory/inventory-loader";
import { loadCompetitors } from "../../competitors/competitor-loader";
import { loadSerpData } from "../../serp/serp-loader";
import { loadKeywordsData } from "../../keywords/keyword-loader";

// Paths for default files
const ENTITIES_PATH = path.join(process.cwd(), "organic-traffic-os", "research-pack", "entities", "entities.json");
const QUESTIONS_PATH = path.join(process.cwd(), "organic-traffic-os", "research-pack", "questions", "questions.json");
const REFERENCES_PATH = path.join(process.cwd(), "organic-traffic-os", "research-pack", "references", "references.json");
const FACTS_PATH = path.join(process.cwd(), "organic-traffic-os", "research-pack", "sources", "facts.json");
const STORE_DIR = path.join(process.cwd(), "organic-traffic-os", "research-pack", "packs");

function ensureStoreExists() {
  if (!fs.existsSync(STORE_DIR)) {
    fs.mkdirSync(STORE_DIR, { recursive: true });
  }
}

/**
 * Calculates a complete Research Score across 6 dimensions.
 */
export function calculateResearchScore(pack: Partial<ResearchPack>): ResearchScore {
  // 1. Cobertura (amount of topicos designed)
  const topics = pack.topicos || [];
  let cobertura = 0;
  if (topics.length >= 4) cobertura = 100;
  else if (topics.length >= 2) cobertura = 80;
  else if (topics.length >= 1) cobertura = 50;
  else cobertura = 20;

  // 2. Quantidade de fontes (source count)
  const sources = pack.fontes || [];
  let quantidade_fontes = 0;
  if (sources.length >= 4) quantidade_fontes = 100;
  else if (sources.length >= 2) quantidade_fontes = 80;
  else if (sources.length >= 1) quantidade_fontes = 50;
  else quantidade_fontes = 10;

  // 3. Diversidade de fontes
  const types = new Set(sources.map(s => s.tipo));
  let diversidade_fontes = 0;
  if (types.size >= 4) diversidade_fontes = 100;
  else if (types.size >= 3) diversidade_fontes = 90;
  else if (types.size >= 2) diversidade_fontes = 75;
  else if (types.size >= 1) diversidade_fontes = 50;
  else diversidade_fontes = 10;

  // 4. Contexto (length / completeness of aggregated overview)
  const ctxLen = (pack.contexto || "").length;
  let contexto = 0;
  if (ctxLen > 800) contexto = 100;
  else if (ctxLen > 400) contexto = 85;
  else if (ctxLen > 150) contexto = 60;
  else if (ctxLen > 0) contexto = 40;
  else contexto = 10;

  // 5. Entidades (amount of covered mandatory entities)
  const ents = pack.entidades || [];
  let entidades = 0;
  if (ents.length >= 4) entidades = 100;
  else if (ents.length >= 2) entidades = 80;
  else if (ents.length >= 1) entidades = 55;
  else entidades = 20;

  // 6. Perguntas (amount of SEO queries mapped)
  const queries = pack.perguntas || [];
  let perguntas = 0;
  if (queries.length >= 4) perguntas = 100;
  else if (queries.length >= 2) perguntas = 80;
  else if (queries.length >= 1) perguntas = 55;
  else perguntas = 20;

  // Weighted score calculation
  const geral = Math.round(
    cobertura * 0.20 +
    quantidade_fontes * 0.15 +
    diversidade_fontes * 0.15 +
    contexto * 0.20 +
    entidades * 0.15 +
    perguntas * 0.15
  );

  return {
    cobertura,
    quantidade_fontes,
    diversidade_fontes,
    contexto,
    entidades,
    perguntas,
    geral
  };
}

export class ResearchComposer {

  /**
   * Generates a comprehensive ResearchPack from a Blueprint ID.
   */
  public static async composePack(blueprintId: string, blogId: string = "passacumaru"): Promise<ResearchPack> {
    ensureStoreExists();

    // 1. Load Blueprint and corresponding Briefing
    const blueprint = ArchitectService.getBlueprint(blueprintId);
    if (!blueprint) {
      throw new Error(`Blueprint com ID '${blueprintId}' não foi localizado.`);
    }

    const brief = BriefLoader.load(blueprint.brief_id);
    if (!brief) {
      throw new Error(`Briefing correspondente '${blueprint.brief_id}' não localizado.`);
    }

    // 2. Load other databases to offer maximum contextual intelligence
    const knowledge = loadKnowledgeCore(blogId);
    const inventory = loadInventory(blogId);
    const competitors = loadCompetitors();
    const serpData = loadSerpData();
    const keywordsData = loadKeywordsData();

    // Load local seed registries for fallbacks / additions
    let catalogEntities: any[] = [];
    if (fs.existsSync(ENTITIES_PATH)) {
      try { catalogEntities = JSON.parse(fs.readFileSync(ENTITIES_PATH, "utf-8")); } catch {}
    }

    let catalogQuestions: any[] = [];
    if (fs.existsSync(QUESTIONS_PATH)) {
      try { catalogQuestions = JSON.parse(fs.readFileSync(QUESTIONS_PATH, "utf-8")); } catch {}
    }

    let catalogReferences: any[] = [];
    if (fs.existsSync(REFERENCES_PATH)) {
      try { catalogReferences = JSON.parse(fs.readFileSync(REFERENCES_PATH, "utf-8")); } catch {}
    }

    let catalogFacts: any[] = [];
    if (fs.existsSync(FACTS_PATH)) {
      try { catalogFacts = JSON.parse(fs.readFileSync(FACTS_PATH, "utf-8")); } catch {}
    }

    // Default structure template
    const defaultPackId = `pack-${blueprint.id.replace("blueprint-", "")}`;
    let pack: Partial<ResearchPack> = {
      id: defaultPackId,
      brief_id: brief.id,
      blueprint_id: blueprint.id,
      titulo: `Dossiê de Pesquisa: ${blueprint.titulo}`,
      objetivo: `Reunir conhecimento aprofundado, fatos verificados e termos obrigatórios para subsidiar a redação de "${blueprint.titulo}".`,
      contexto: "",
      entidades: [],
      perguntas: [],
      topicos: [],
      fontes: [],
      fatos: [],
      observacoes: "Dossiê estruturado automaticamente pelo Research Composer Engine V1.",
      status: "ready",
      versao: 1,
      criado_em: new Date().toISOString()
    };

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } }
        });

        const prompt = `
          Você é o Diretor de Pesquisa (Research Composer Engine V1) do Organic Traffic OS.
          Sua missão é reunir, consolidar e preparar um Dossiê de Pesquisa (Research Pack) completo e unificado para apoiar a redação de um conteúdo de altíssimo nível.

          Você deve mesclar as orientações do Blueprint de conteúdo, do Briefing, e enriquecer com fatos técnicos, entidades governamentais, links oficiais e perguntas da SERP.

          REGRAS IMPORTANTES:
          - Elimine informações repetidas (duplicadas).
          - Agrupe o contexto de forma fluida e ultra-profissional.
          - Liste links legítimos.
          - Identifique fatos confiáveis informando sua origem específica.

          CONVITE / CONTEXTO GERAL:
          - Título do Conteúdo: "${blueprint.titulo}"
          - Silo/Cluster Semântico: "${blueprint.cluster}"
          - Categoria: "${blueprint.categoria}"
          - Objetivo de Negócio: "${blueprint.objetivo}"
          - Tipo de Conteúdo: "${blueprint.tipo_de_conteudo}"
          - Estrutura Recomendada do Blueprint: ${JSON.stringify(blueprint.estrutura)}
          - Palavras-chave do Briefing: Principal: "${brief.seo?.keyword_principal || ""}", Secundárias: ${JSON.stringify(brief.seo?.keywords_secundarias || [])}

          CATÁLOGOS LOCAIS DE SEMENTE (Use para complementar ou enriquecer se fizer sentido):
          - Entidades Disponíveis: ${JSON.stringify(catalogEntities)}
          - Perguntas Mapeadas: ${JSON.stringify(catalogQuestions)}
          - Fontes Disponíveis: ${JSON.stringify(catalogReferences)}
          - Fatos Verificados: ${JSON.stringify(catalogFacts)}

          Retorne EXCLUSIVAMENTE um objeto JSON válido contendo a estrutura abaixo, preenchida de forma inteligente em português. Não adicione textos fora do JSON.

          JSON SCHEMA DE RETORNO:
          {
            "contexto": "Resumo analítico amplo conectando o tema à necessidade do usuário na SERP, cruzando com dados da nossa base de conhecimento.",
            "entidades": ["Nome da Entidade 1", "Nome da Entidade 2"],
            "perguntas": [
              { "pergunta": "Pergunta específica?", "tipo": "principal", "origem": "SERP / GSC" },
              { "pergunta": "Outra pergunta?", "tipo": "secundária", "origem": "People Also Ask" }
            ],
            "topicos": [
              {
                "titulo": "Título da Seção",
                "secao": "H2",
                "instrucoes_de_pesquisa": "Diretrizes e dados exatos a serem apresentados nesta seção para superar concorrentes.",
                "fontes_recomendadas": ["URL oficial relevante"]
              }
            ],
            "fontes": [
              {
                "nome": "Nome Legível do Portal ou Lei",
                "url": "https://url.oficial.gov.br",
                "tipo": "oficial",
                "observacoes": "Explicação do que encontrar aqui."
              }
            ],
            "fatos": [
              {
                "descricao": "Fato técnico incontestável, ex: alíquotas, prazos legais.",
                "origem": "Constituição Federal / Diário Oficial",
                "nivel_confianca": "alta",
                "necessita_validacao": false
              }
            ],
            "observacoes": "Qualquer observação de pesquisa adicional."
          }
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json"
          }
        });

        const rawText = response.text;
        if (rawText) {
          const parsed = JSON.parse(rawText.trim());
          pack = {
            ...pack,
            contexto: parsed.contexto || pack.contexto,
            entidades: parsed.entidades || pack.entidades,
            perguntas: parsed.perguntas || pack.perguntas,
            topicos: parsed.topicos || pack.topicos,
            fontes: parsed.fontes || pack.fontes,
            fatos: parsed.fatos || pack.fatos,
            observacoes: parsed.observacoes || pack.observacoes
          };
        }
      } catch (err) {
        console.error("Erro na chamada do Gemini API para Research Pack. Utilizando fallback algorítmico:", err);
        pack = this.compileAlgorithmicFallback(blueprint, brief, catalogEntities, catalogQuestions, catalogReferences, catalogFacts, pack);
      }
    } else {
      pack = this.compileAlgorithmicFallback(blueprint, brief, catalogEntities, catalogQuestions, catalogReferences, catalogFacts, pack);
    }

    // Clean duplicate entities
    if (pack.entidades) {
      const uniq = new Set<string>();
      pack.entidades.forEach(e => uniq.add(e.trim()));
      pack.entidades = Array.from(uniq);
    }

    // Clean duplicate questions
    if (pack.perguntas) {
      const seen = new Set<string>();
      const cleanQ: ResearchQuestion[] = [];
      pack.perguntas.forEach(q => {
        const norm = q.pergunta.toLowerCase().trim();
        if (!seen.has(norm)) {
          seen.add(norm);
          cleanQ.push(q);
        }
      });
      pack.perguntas = cleanQ;
    }

    // Clean duplicate facts
    if (pack.fatos) {
      const seenF = new Set<string>();
      const cleanF: ResearchFact[] = [];
      pack.fatos.forEach(f => {
        const norm = f.descricao.toLowerCase().trim();
        if (!seenF.has(norm)) {
          seenF.add(norm);
          cleanF.push(f);
        }
      });
      pack.fatos = cleanF;
    }

    // Ensure status is correctly typed
    pack.status = "ready";

    // Recalculate score and audit validation
    const compiledPack = pack as ResearchPack;
    compiledPack.score = calculateResearchScore(compiledPack);
    compiledPack.validation = validateResearchPack(compiledPack);

    // Save snapshot of the pack
    const savePath = path.join(STORE_DIR, `${compiledPack.id}.json`);
    fs.writeFileSync(savePath, JSON.stringify(compiledPack, null, 2), "utf-8");

    return compiledPack;
  }

  private static compileAlgorithmicFallback(
    blueprint: any,
    brief: any,
    catalogEntities: any[],
    catalogQuestions: any[],
    catalogReferences: any[],
    catalogFacts: any[],
    basePack: Partial<ResearchPack>
  ): Partial<ResearchPack> {
    // Context builder
    const context = `Dossiê técnico consolidando a intenção de busca principal ("${brief.search_intent?.intencao_principal || "Informativa"}") para a palavra-chave "${brief.seo?.keyword_principal || blueprint.titulo}". Este dossiê unifica dados do Silo Editorial "${blueprint.cluster}" e foi preparado para garantir que todos os sub-tópicos do Blueprint estrutural possuam respaldo legal, normativo e empírico.`;

    // Entities - select catalog entities that match words in title/cluster
    const titleWords = (blueprint.titulo + " " + blueprint.cluster).toLowerCase();
    const entidades: string[] = [];
    catalogEntities.forEach((ent: any) => {
      if (titleWords.includes(ent.nome.toLowerCase()) || titleWords.includes(ent.categoria.toLowerCase())) {
        entidades.push(ent.nome);
      }
    });
    // Fallback if none matched
    if (entidades.length === 0 && catalogEntities.length > 0) {
      entidades.push(catalogEntities[0].nome);
      entidades.push(catalogEntities[1].nome);
    }

    // Questions - grab primary or matching ones
    const questions: ResearchQuestion[] = [];
    catalogQuestions.forEach((q: any) => {
      questions.push({
        pergunta: q.pergunta,
        tipo: q.tipo,
        origem: q.origem || "SEO Catalog"
      });
    });

    // Fontes / References
    const fontes: any[] = [];
    catalogReferences.forEach((ref: any) => {
      fontes.push({
        nome: ref.nome,
        url: ref.url,
        tipo: ref.tipo,
        observacoes: ref.observacoes
      });
    });

    // Fatos / Facts
    const fatos: ResearchFact[] = [];
    catalogFacts.forEach((f: any) => {
      fatos.push({
        descricao: f.descricao,
        origem: f.origem,
        nivel_confianca: f.nivel_confianca || "alta",
        necessita_validacao: f.necessita_validacao || false
      });
    });

    // Topics matching blueprint structure
    const topicos = (blueprint.estrutura || []).map((s: any) => {
      return {
        titulo: s.titulo,
        secao: s.secao,
        instrucoes_de_pesquisa: `Pesquisar dados estatísticos consolidados e detalhar as diretrizes do manual de redação: ${s.instrucoes_de_escrita || ""}`,
        fontes_recomendadas: fontes.map(fo => fo.url).slice(0, 1)
      };
    });

    return {
      ...basePack,
      contexto: context,
      entidades,
      perguntas: questions,
      fontes,
      fatos,
      topicos
    };
  }
}
