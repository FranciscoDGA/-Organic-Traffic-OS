import fs from "fs";
import path from "path";
import { ResearchPack, ResearchVersion } from "../models/research-models";
import { ResearchComposer, calculateResearchScore } from "./research-composer";
import { validateResearchPack } from "./research-validator";

const STORE_DIR = path.join(process.cwd(), "organic-traffic-os", "research-pack", "packs");

function ensureStoreExists() {
  if (!fs.existsSync(STORE_DIR)) {
    fs.mkdirSync(STORE_DIR, { recursive: true });
  }
}

/**
 * Domain service for managing, loading, composing, saving and updating Research Packs.
 */
export class ResearchService {

  /**
   * Generates a new Research Pack based on an editorial Blueprint ID.
   */
  public static async generatePack(blueprintId: string, blogId: string = "passacumaru"): Promise<ResearchPack> {
    return ResearchComposer.composePack(blueprintId, blogId);
  }

  /**
   * Loads a specific Research Pack by its unique ID.
   */
  public static getPack(id: string): ResearchPack | null {
    ensureStoreExists();
    const filePath = path.join(STORE_DIR, `${id}.json`);
    if (!fs.existsSync(filePath)) return null;

    try {
      const raw = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(raw);
    } catch (e) {
      console.error(`Erro ao carregar o Research Pack '${id}':`, e);
      return null;
    }
  }

  /**
   * Lists all existing research packs inside the store.
   */
  public static getAllPacks(): ResearchPack[] {
    ensureStoreExists();
    try {
      const files = fs.readdirSync(STORE_DIR).filter(f => f.endsWith(".json"));
      const packs: ResearchPack[] = [];
      files.forEach(f => {
        const raw = fs.readFileSync(path.join(STORE_DIR, f), "utf-8");
        try {
          packs.push(JSON.parse(raw));
        } catch (err) {
          console.error(`Erro ao parsear arquivo de Research Pack ${f}:`, err);
        }
      });
      return packs.sort((a, b) => new Date(b.criado_em).getTime() - new Date(a.criado_em).getTime());
    } catch (e) {
      console.error("Erro ao listar Research Packs:", e);
      return [];
    }
  }

  /**
   * Updates a Research Pack and commits a historical snapshot to its version system.
   */
  public static updatePack(id: string, updatedData: Partial<ResearchPack>, autor: string = "Editor de Pesquisa"): ResearchPack {
    ensureStoreExists();
    const existing = this.getPack(id);
    if (!existing) {
      throw new Error(`Research Pack com ID '${id}' não foi localizado para atualização.`);
    }

    // Capture snapshot for historical versioning
    const previousSnapshot = { ...existing };
    delete previousSnapshot.versions; // avoid deep nesting

    const currentVersionNum = existing.versao || 1;
    const newVersionNum = currentVersionNum + 1;

    const newVersionRecord: ResearchVersion = {
      versao: currentVersionNum,
      data_snapshot: existing.atualizado_em || existing.criado_em,
      autor: existing.autor || "Sistema",
      mudancas: `Research Pack atualizado. Versão promovida de v${currentVersionNum} para v${newVersionNum}.`,
      pack_snapshot: previousSnapshot
    };

    const merged: ResearchPack = {
      ...existing,
      ...updatedData,
      id: existing.id, // preserve ID
      brief_id: existing.brief_id, // preserve mapping
      blueprint_id: existing.blueprint_id, // preserve mapping
      versao: newVersionNum,
      atualizado_em: new Date().toISOString(),
      versions: [...(existing.versions || []), newVersionRecord]
    };

    // Re-score
    merged.score = calculateResearchScore(merged);

    // Re-validate
    merged.validation = validateResearchPack(merged);

    const savePath = path.join(STORE_DIR, `${merged.id}.json`);
    fs.writeFileSync(savePath, JSON.stringify(merged, null, 2), "utf-8");

    return merged;
  }
}
export { calculateResearchScore, validateResearchPack };
