export interface ResearchFact {
  descricao: string;
  origem: string;
  nivel_confianca: "alta" | "média" | "baixa" | string;
  necessita_validacao: boolean;
}

export interface ResearchQuestion {
  pergunta: string;
  tipo: "principal" | "secundária" | "relacionada" | string;
  origem: string;
}

export interface ResearchScore {
  cobertura: number; // 0-100
  quantidade_fontes: number; // 0-100
  diversidade_fontes: number; // 0-100
  contexto: number; // 0-100
  entidades: number; // 0-100
  perguntas: number; // 0-100
  geral: number; // Weighted average of the above
}

export interface ResearchValidation {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface ResearchVersion {
  versao: number;
  data_snapshot: string;
  autor: string;
  mudancas: string;
  pack_snapshot: any;
}

export interface ResearchPack {
  id: string;
  brief_id: string;
  blueprint_id: string;
  titulo: string;
  objetivo: string;
  contexto: string; // Dossier summary and aggregate context
  entidades: string[]; // List of mandatory entities
  perguntas: ResearchQuestion[];
  topicos: {
    titulo: string;
    secao: string;
    instrucoes_de_pesquisa: string;
    fontes_recomendadas: string[];
  }[];
  fontes: {
    nome: string;
    url: string;
    tipo: "oficial" | "documentação" | "institucional" | "norma" | "outro" | string;
    observacoes?: string;
  }[];
  fatos: ResearchFact[];
  observacoes: string;
  status: "draft" | "ready" | string;
  autor: string;
  versao: number;
  score: ResearchScore;
  validation: ResearchValidation;
  criado_em: string;
  atualizado_em?: string;
  versions?: ResearchVersion[];
}
