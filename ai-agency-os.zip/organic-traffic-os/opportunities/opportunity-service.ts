import fs from "fs";
import path from "path";
import { Opportunity } from "./models/opportunity-model";
import { OpportunityEngine } from "./engine/opportunity-engine";

const CACHE_DIR = path.join(process.cwd(), "organic-traffic-os", "opportunities", "cache");
const OPPORTUNITIES_FILE = path.join(CACHE_DIR, "opportunities.json");

export class OpportunityService {
  /**
   * Triggers the discovery engine to run and generate a new batch of opportunities.
   */
  public static async generateOpportunities(blogId: string = "passacumaru"): Promise<Opportunity[]> {
    const result = await OpportunityEngine.runDiscovery(blogId);
    return result.opportunities;
  }

  /**
   * Returns all currently stored opportunities.
   */
  public static getOpportunities(): Opportunity[] {
    if (!fs.existsSync(OPPORTUNITIES_FILE)) {
      return [];
    }
    try {
      const data = fs.readFileSync(OPPORTUNITIES_FILE, "utf-8");
      return JSON.parse(data) || [];
    } catch (err) {
      console.error("Erro ao ler arquivo de oportunidades:", err);
      return [];
    }
  }

  /**
   * Filters opportunities by category (case insensitive, partial match).
   */
  public static getOpportunitiesByCategory(category: string): Opportunity[] {
    const all = this.getOpportunities();
    if (!category) return all;
    const lower = category.toLowerCase().trim();
    return all.filter(o => o.categoria.toLowerCase().includes(lower));
  }

  /**
   * Filters opportunities by priority (case insensitive).
   */
  public static getOpportunitiesByPriority(priority: string): Opportunity[] {
    const all = this.getOpportunities();
    if (!priority) return all;
    const lower = priority.toLowerCase().trim();
    return all.filter(o => o.prioridade.toLowerCase() === lower);
  }

  /**
   * Filters opportunities by cluster (case insensitive, partial match).
   */
  public static getOpportunitiesByCluster(cluster: string): Opportunity[] {
    const all = this.getOpportunities();
    if (!cluster) return all;
    const lower = cluster.toLowerCase().trim();
    return all.filter(o => o.cluster.toLowerCase().includes(lower));
  }

  /**
   * Filters opportunities by entity (case insensitive, partial match).
   */
  public static getOpportunitiesByEntity(entity: string): Opportunity[] {
    const all = this.getOpportunities();
    if (!entity) return all;
    const lower = entity.toLowerCase().trim();
    return all.filter(o => (o.entidade || "").toLowerCase().includes(lower));
  }

  /**
   * Returns only "alta" or "critica" priority opportunities.
   */
  public static getHighPriorityOpportunities(): Opportunity[] {
    const all = this.getOpportunities();
    return all.filter(o => o.prioridade === "alta" || o.prioridade === "critica");
  }
}

export default OpportunityService;
