import fs from "fs";
import path from "path";
import { Opportunity } from "../models/opportunity-model";
import { OpportunityRanking } from "../ranking/opportunity-ranking";
import { OpportunityValidator } from "../validators/opportunity-validator";
import { loadKnowledgeCore } from "../../knowledge/knowledge-loader";
import { loadInventory } from "../../inventory/inventory-loader";
import { loadCompetitors } from "../../competitors/competitor-loader";
import { loadSerpData } from "../../serp/serp-loader";
import { loadKeywordsData } from "../../keywords/keyword-loader";

const CACHE_DIR = path.join(process.cwd(), "organic-traffic-os", "opportunities", "cache");
const OPPORTUNITIES_FILE = path.join(CACHE_DIR, "opportunities.json");
const ENGINE_LOGS_FILE = path.join(CACHE_DIR, "engine-logs.json");

export interface EngineLogEntry {
  timestamp: string;
  duracaoMs: number;
  fontesConsultadas: string[];
  totalOportunidadesGeradas: number;
  motivosResumo: Record<string, number>;
  errosRegistrados: string[];
  ausenciaDeDados: string[];
}

export class OpportunityEngine {
  private static ensureCacheExists() {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    if (!fs.existsSync(OPPORTUNITIES_FILE)) {
      fs.writeFileSync(OPPORTUNITIES_FILE, JSON.stringify([], null, 2), "utf-8");
    }
    if (!fs.existsSync(ENGINE_LOGS_FILE)) {
      fs.writeFileSync(ENGINE_LOGS_FILE, JSON.stringify([], null, 2), "utf-8");
    }
  }

  /**
   * Executa a análise inteligente do ecossistema de dados SEO e gera as oportunidades.
   */
  public static async runDiscovery(blogId: string = "passacumaru"): Promise<{ opportunities: Opportunity[]; logs: EngineLogEntry }> {
    const startTime = Date.now();
    this.ensureCacheExists();

    const fontesConsultadas: string[] = [];
    const errosRegistrados: string[] = [];
    const ausenciaDeDados: string[] = [];

    // 1. Carregar dados de todas as fontes disponíveis de forma resiliente
    let knowledge: any = null;
    let inventory: any = null;
    let competitors: any = null;
    let keywordsData: any = null;
    let serpData: any = null;
    let collectorsResults: any[] = [];

    // --- Fontes 1: Knowledge Core ---
    try {
      knowledge = loadKnowledgeCore(blogId);
      fontesConsultadas.push("Knowledge Core");
      if (!knowledge || !knowledge.categorias || knowledge.categorias.length === 0) {
        ausenciaDeDados.push("Knowledge Core (Sem categorias cadastradas)");
      }
    } catch (err: any) {
      errosRegistrados.push(`Erro ao ler Knowledge Core: ${err.message || err}`);
      ausenciaDeDados.push("Knowledge Core (Falha de Leitura)");
    }

    // --- Fontes 2: Content Inventory ---
    try {
      inventory = loadInventory(blogId);
      fontesConsultadas.push("Content Inventory");
      if (!inventory || !inventory.index || inventory.index.length === 0) {
        ausenciaDeDados.push("Content Inventory (Sem conteúdos indexados)");
      }
    } catch (err: any) {
      errosRegistrados.push(`Erro ao ler Content Inventory: ${err.message || err}`);
      ausenciaDeDados.push("Content Inventory (Falha de Leitura)");
    }

    // --- Fontes 3: Competitors Intelligence ---
    try {
      competitors = loadCompetitors();
      fontesConsultadas.push("Competitors Intelligence");
      if (!competitors || !competitors.competitors || competitors.competitors.length === 0) {
        ausenciaDeDados.push("Competitors Intelligence (Sem concorrentes mapeados)");
      }
    } catch (err: any) {
      errosRegistrados.push(`Erro ao ler Competitors Intelligence: ${err.message || err}`);
      ausenciaDeDados.push("Competitors Intelligence (Falha de Leitura)");
    }

    // --- Fontes 4: Keywords Intelligence ---
    try {
      keywordsData = loadKeywordsData();
      fontesConsultadas.push("Keywords Intelligence");
      if (!keywordsData || !keywordsData.keywords || keywordsData.keywords.length === 0) {
        ausenciaDeDados.push("Keywords Intelligence (Sem palavras-chave cadastradas)");
      }
    } catch (err: any) {
      errosRegistrados.push(`Erro ao ler Keywords Intelligence: ${err.message || err}`);
      ausenciaDeDados.push("Keywords Intelligence (Falha de Leitura)");
    }

    // --- Fontes 5: SERP Intelligence ---
    try {
      serpData = loadSerpData();
      fontesConsultadas.push("SERP Intelligence");
      if (!serpData || !serpData.queries || serpData.queries.length === 0) {
        ausenciaDeDados.push("SERP Intelligence (Sem análises de SERP)");
      }
    } catch (err: any) {
      errosRegistrados.push(`Erro ao ler SERP Intelligence: ${err.message || err}`);
      ausenciaDeDados.push("SERP Intelligence (Falha de Leitura)");
    }

    // --- Fontes 6: Collectors Results ---
    try {
      const collectorsResultsPath = path.join(process.cwd(), "organic-traffic-os", "collectors", "cache", "results.json");
      if (fs.existsSync(collectorsResultsPath)) {
        collectorsResults = JSON.parse(fs.readFileSync(collectorsResultsPath, "utf-8"));
        fontesConsultadas.push("Research Collectors");
        if (collectorsResults.length === 0) {
          ausenciaDeDados.push("Research Collectors (Vazio/Sem dados coletados)");
        }
      } else {
        ausenciaDeDados.push("Research Collectors (Arquivo inexistente)");
      }
    } catch (err: any) {
      errosRegistrados.push(`Erro ao ler coletores: ${err.message || err}`);
      ausenciaDeDados.push("Research Collectors (Falha de Leitura)");
    }

    // Lista final de oportunidades geradas
    const opportunities: Opportunity[] = [];
    const motivosResumo: Record<string, number> = {};

    // Deducao de categorias e clusters padrão para resiliência
    const getDefaultCategory = (): string => {
      if (knowledge && Array.isArray(knowledge.categorias) && knowledge.categorias.length > 0) {
        return knowledge.categorias[0].nome || knowledge.categorias[0].name || "Geral";
      }
      return "Concursos";
    };

    // 2. Extrair candidatos de oportunidades dos dados existentes

    // --- CANDIDATOS GRUPO A: Concorrentes (Gaps e Oportunidades Concorrentes) ---
    if (competitors && Array.isArray(competitors.opportunities)) {
      competitors.opportunities.forEach((item: any, idx: number) => {
        const title = item.tema || item.keyword || item.titulo || `Oportunidade Concorrente ${idx}`;
        const kw = item.keyword || item.tema || "";
        const cat = item.categoria || getDefaultCategory();
        const cluster = item.cluster || cat;

        const scoreObj = OpportunityRanking.calculate(
          title, kw, cat, cluster, "novo_artigo", "Informacional", "concorrentes",
          knowledge, inventory, competitors, keywordsData
        );

        const opp: Opportunity = {
          id: `opp-comp-${Math.random().toString(36).substring(2, 11)}`,
          titulo: title,
          categoria: cat,
          cluster: cluster,
          entidade: item.entidade || "Geral",
          tipo: "novo_artigo",
          intencao: "Informacional",
          prioridade: "media", // será atualizada pelo score
          score: scoreObj.score,
          origem: "concorrentes",
          motivo: scoreObj.reason,
          status: "descoberta",
          criado_em: new Date().toISOString()
        };

        opp.prioridade = this.deducePriority(opp.score);

        // Validar e enfilar
        const val = OpportunityValidator.validar(opp, inventory, knowledge, opportunities);
        if (val.isValid) {
          opportunities.push(opp);
          motivosResumo[opp.motivo] = (motivosResumo[opp.motivo] || 0) + 1;
        } else {
          // Log de descarte
          console.log(`Oportunidade de Concorrente descartada por validação: ${val.errors.join("; ")}`);
        }
      });
    }

    // --- CANDIDATOS GRUPO B: Keywords Intelligence ---
    if (keywordsData && Array.isArray(keywordsData.keywords)) {
      keywordsData.keywords.forEach((item: any) => {
        const kwText = item.palavra || item.keyword || "";
        if (!kwText) return;

        const title = item.tituloSugerido || `Guia Completo de SEO: ${kwText}`;
        const cat = item.categoria || getDefaultCategory();
        const cluster = item.cluster || cat;
        const intent = item.intencao || "Informacional";

        // Determinar tipo: se a keyword está no inventário mas tem score baixo, vira "otimizacao"
        let tipo = "novo_artigo";
        const alreadyInInventory = inventory?.index?.find((invItem: any) => {
          const invKw = (invItem.palavraChave || invItem.keyword || "").toLowerCase().trim();
          return invKw === kwText.toLowerCase().trim();
        });

        if (alreadyInInventory) {
          tipo = "otimizacao";
        } else if (item.isPillar || item.status === "pilar") {
          tipo = "reforco_pilar";
        }

        const scoreObj = OpportunityRanking.calculate(
          title, kwText, cat, cluster, tipo, intent, "keywords",
          knowledge, inventory, competitors, keywordsData
        );

        const opp: Opportunity = {
          id: `opp-kw-${Math.random().toString(36).substring(2, 11)}`,
          titulo: title,
          categoria: cat,
          cluster: cluster,
          entidade: item.entidade || "Geral",
          tipo,
          intencao: intent,
          prioridade: "media",
          score: scoreObj.score,
          origem: "keywords",
          motivo: scoreObj.reason,
          status: "descoberta",
          criado_em: new Date().toISOString()
        };

        opp.prioridade = this.deducePriority(opp.score);

        const val = OpportunityValidator.validar(opp, inventory, knowledge, opportunities);
        if (val.isValid) {
          opportunities.push(opp);
          motivosResumo[opp.motivo] = (motivosResumo[opp.motivo] || 0) + 1;
        } else {
          console.log(`Oportunidade de Keyword descartada por validação: ${val.errors.join("; ")}`);
        }
      });
    }

    // --- CANDIDATOS GRUPO C: SERP Intelligence ---
    if (serpData && Array.isArray(serpData.opportunities)) {
      serpData.opportunities.forEach((item: any) => {
        const title = item.titulo || item.query || "";
        if (!title) return;
        const kw = item.keyword || item.query || "";
        const cat = item.categoria || getDefaultCategory();
        const cluster = item.cluster || cat;
        const intent = item.intent || "Informacional";

        const scoreObj = OpportunityRanking.calculate(
          title, kw, cat, cluster, "novo_artigo", intent, "serp",
          knowledge, inventory, competitors, keywordsData
        );

        const opp: Opportunity = {
          id: `opp-serp-${Math.random().toString(36).substring(2, 11)}`,
          titulo: title,
          categoria: cat,
          cluster: cluster,
          entidade: item.entidade || "Geral",
          tipo: "novo_artigo",
          intencao: intent,
          prioridade: "media",
          score: scoreObj.score,
          origem: "serp",
          motivo: scoreObj.reason,
          status: "descoberta",
          criado_em: new Date().toISOString()
        };

        opp.prioridade = this.deducePriority(opp.score);

        const val = OpportunityValidator.validar(opp, inventory, knowledge, opportunities);
        if (val.isValid) {
          opportunities.push(opp);
          motivosResumo[opp.motivo] = (motivosResumo[opp.motivo] || 0) + 1;
        } else {
          console.log(`Oportunidade de SERP descartada por validação: ${val.errors.join("; ")}`);
        }
      });
    }

    // --- CANDIDATOS GRUPO D: Collectors (RSS / Manuais fresquinhas) ---
    if (collectorsResults && Array.isArray(collectorsResults)) {
      collectorsResults.forEach((item: any) => {
        // Se a coleta deu certo
        if (item.status === "sucesso" && item.conteudo) {
          if (item.tipo === "rss") {
            const feedItems = item.conteudo.itens || item.conteudo.entries || [];
            feedItems.slice(0, 5).forEach((entry: any) => {
              const title = entry.titulo || entry.title || "";
              if (!title) return;

              // Tentar deduzir keyword curta
              const kw = title.split(" ").slice(0, 3).join(" ");
              const cat = getDefaultCategory();
              const cluster = "Notícias Frescas";

              const scoreObj = OpportunityRanking.calculate(
                title, kw, cat, cluster, "novo_artigo", "Informacional", "collectors",
                knowledge, inventory, competitors, keywordsData
              );

              const opp: Opportunity = {
                id: `opp-coll-${Math.random().toString(36).substring(2, 11)}`,
                titulo: title,
                categoria: cat,
                cluster: cluster,
                entidade: "Atualidades",
                tipo: "novo_artigo",
                intencao: "Informacional",
                prioridade: "media",
                score: scoreObj.score,
                origem: "collectors",
                motivo: scoreObj.reason,
                status: "descoberta",
                criado_em: new Date().toISOString()
              };

              opp.prioridade = this.deducePriority(opp.score);

              const val = OpportunityValidator.validar(opp, inventory, knowledge, opportunities);
              if (val.isValid) {
                opportunities.push(opp);
                motivosResumo[opp.motivo] = (motivosResumo[opp.motivo] || 0) + 1;
              }
            });
          } else if (item.tipo === "manual") {
            const title = item.conteudo.titulo || "";
            if (!title) return;
            const kw = title.split(" ").slice(0, 3).join(" ");
            const cat = item.conteudo.categoria || getDefaultCategory();
            const cluster = cat;

            const scoreObj = OpportunityRanking.calculate(
              title, kw, cat, cluster, "novo_artigo", "Informacional", "collectors",
              knowledge, inventory, competitors, keywordsData
            );

            const opp: Opportunity = {
              id: `opp-coll-${Math.random().toString(36).substring(2, 11)}`,
              titulo: title,
              categoria: cat,
              cluster: cluster,
              entidade: "Atualidades",
              tipo: "novo_artigo",
              intencao: "Informacional",
              prioridade: "media",
              score: scoreObj.score,
              origem: "collectors",
              motivo: scoreObj.reason,
              status: "descoberta",
              criado_em: new Date().toISOString()
            };

            opp.prioridade = this.deducePriority(opp.score);

            const val = OpportunityValidator.validar(opp, inventory, knowledge, opportunities);
            if (val.isValid) {
              opportunities.push(opp);
              motivosResumo[opp.motivo] = (motivosResumo[opp.motivo] || 0) + 1;
            }
          }
        }
      });
    }

    // 3. Ordenar todas as oportunidades geradas de forma decrescente pelo score
    opportunities.sort((a, b) => b.score - a.score);

    const duracaoMs = Date.now() - startTime;

    // 4. Criar registro de logs estruturado
    const logEntry: EngineLogEntry = {
      timestamp: new Date().toISOString(),
      duracaoMs,
      fontesConsultadas,
      totalOportunidadesGeradas: opportunities.length,
      motivosResumo,
      errosRegistrados,
      ausenciaDeDados
    };

    // 5. Salvar resultados e logs em cache de forma durável
    fs.writeFileSync(OPPORTUNITIES_FILE, JSON.stringify(opportunities, null, 2), "utf-8");

    try {
      const logsContent = fs.readFileSync(ENGINE_LOGS_FILE, "utf-8");
      const logsList: EngineLogEntry[] = JSON.parse(logsContent);
      logsList.unshift(logEntry);
      // Limitar a 100 execuções registradas de log
      if (logsList.length > 100) logsList.pop();
      fs.writeFileSync(ENGINE_LOGS_FILE, JSON.stringify(logsList, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao escrever log da Opportunity Engine:", e);
    }

    return {
      opportunities,
      logs: logEntry
    };
  }

  private static deducePriority(score: number): "baixa" | "media" | "alta" | "critica" {
    if (score >= 85) return "critica";
    if (score >= 70) return "alta";
    if (score >= 50) return "media";
    return "baixa";
  }

  /**
   * Retorna os últimos logs de execução da Engine.
   */
  public static getLogs(): EngineLogEntry[] {
    this.ensureCacheExists();
    try {
      return JSON.parse(fs.readFileSync(ENGINE_LOGS_FILE, "utf-8"));
    } catch {
      return [];
    }
  }
}
