export interface Opportunity {
  id: string;
  titulo: string;
  categoria: string;
  cluster: string;
  entidade: string;
  tipo: "novo_artigo" | "otimizacao" | "reforco_pilar" | string;
  intencao: string; // "Informacional" | "Comercial" | "Transacional" etc.
  intencao_original?: string; // backup in case of accents
  prioridade: "baixa" | "media" | "alta" | "critica" | string;
  score: number; // 0 a 100
  origem: string; // e.g. "concorrentes" | "keywords" | "serp" | "collectors" | "trends"
  motivo: string; // e.g. "Keyword relevante com baixa cobertura dos concorrentes"
  status: "descoberta" | "analise" | "aprovado" | "rejeitado" | "producao" | string;
  criado_em: string; // ISO string
}
