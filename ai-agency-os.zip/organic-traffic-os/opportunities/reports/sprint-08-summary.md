# Sprint 08 Summary — Opportunity Discovery Engine V1

## 1. OBJETIVO & MISSÃO
O principal objetivo da **Sprint 08** é construir a primeira **Engine de Decisão** oficial do **Organic Traffic OS**. 
Esta engine não cria os artigos de blog por si só; em vez disso, ela atua como um cérebro analítico e editorial para decidir **O QUE vale a pena produzir**, priorizando e organizando oportunidades de conteúdo com base em dados de múltiplos módulos.

---

## 2. ARQUITETURA
O módulo de oportunidades foi implementado sob o diretório `organic-traffic-os/opportunities/` com a seguinte estrutura modular:

```text
organic-traffic-os/opportunities/
├── cache/
│   ├── engine-logs.json         # Histórico detalhado de execução e logs de auditoria
│   └── opportunities.json       # Oportunidades consolidadas e salvas persistentemente
├── engine/
│   └── opportunity-engine.ts    # Motor analítico que cruza informações do ecossistema
├── models/
│   └── opportunity-model.ts     # Modelo/interface TypeScript de uma Oportunidade
├── ranking/
│   └── opportunity-ranking.ts   # Engine de cálculo matemático de pontuação (Score 0-100)
├── reports/
│   └── sprint-08-summary.md     # Documentação oficial da sprint (Este arquivo)
├── rules/
│   └── opportunity-rules.ts     # Regras de negócio e boosts aplicados ao ranqueamento
├── validators/
│   └── opportunity-validator.ts # Validador estrito de dados, integridade e regras de negócio
└── opportunity-service.ts       # Camada de serviços para geração, consulta e filtros rápidos
```

---

## 3. WORKFLOW INTELIGENTE DE ENTRADA
A engine une 6 bases de dados para tomar decisões semânticas. O fluxo funciona da seguinte forma:

1. **Knowledge Core**: Determina o nicho, as categorias do blog, o perfil da persona e os produtos relacionados.
2. **Content Inventory**: Analisa os artigos já publicados para evitar canibalização de palavras-chave e identificar clusters com pouca cobertura.
3. **Competitors Intelligence**: Identifica fraquezas estruturais dos concorrentes direto em nichos para buscar brechas (gaps).
4. **SERP Intelligence**: Analisa a intenção e os recursos especiais de busca exibidos pelo Google (PAA, Snippets, FAQs) para cada termo.
5. **Keywords Intelligence**: Fornece o banco inteligente de palavras-chave estruturadas e o volume semântico.
6. **Research Collectors**: Alimenta a engine com tópicos manuais inseridos e notícias quentes de feeds RSS.
7. **Opportunity Engine**: Consolida os candidatos das 6 fontes, descarta duplicatas e valida o formato.
8. **Opportunity Ranking**: Avalia 8 fatores estratégicos mais os boosts de regras adicionais para atribuir um Score final de 0 a 100.
9. **Editorial Dashboard**: Exibe o mapeamento ordenado e priorizado das oportunidades prontas para produção.

---

## 4. SISTEMA DE RANKING (SCORING)
O score final (0 a 100) é calculado pela ponderação de **8 fatores-chave** combinados com **regra de boosts**:

### 8 Fatores Estruturais:
1. **Relevância para o blog (15%)**: Valida se o tema se encaixa nas categorias do Knowledge Core.
2. **Intenção de busca (10%)**: Dá maior valor para intenções transacionais e comerciais.
3. **Quantidade de conteúdo existente no cluster (15%)**: Prioriza clusters novos (greenfields) que ainda não foram abordados.
4. **Cobertura dos concorrentes (15%)**: Prioriza termos onde os concorrentes possuem fraquezas ou cobertura baixa.
5. **Cobertura do PassaCumaru (15%)**: Prioriza termos onde nosso blog ainda não possui nenhum artigo.
6. **Potencial de monetização (10%)**: Cruza o tema com produtos ou ofertas afiliadas configuradas.
7. **Importância estratégica (10%)**: Lê o nível de prioridade estratégica do termo no banco de keywords.
8. **Freshness (10%)**: Dá pontuação maior para tendências novas vindas dos coletores.

---

## 5. NUNCA PARAR POR FALTA DE DADOS (RESILIÊNCIA)
Em conformidade com os requisitos da sprint, a engine é **totalmente resiliente**:
- Se alguma das fontes estiver vazia ou com falha de leitura de arquivo JSON, a engine captura a exceção, adiciona no campo `ausenciaDeDados` do log, mas **continua o processamento** com as demais fontes disponíveis.
- Um histórico detalhado é salvo no arquivo de cache `/organic-traffic-os/opportunities/cache/engine-logs.json`.

---

## 6. COMO ADICIONAR NOVAS REGRAS
As regras de negócio que governam a elegibilidade e aplicam aumentos de prioridade (boosts) estão concentradas no arquivo:
`/organic-traffic-os/opportunities/rules/opportunity-rules.ts`

### Passo-a-passo para adicionar uma nova regra:

1. **Abra o arquivo** `organic-traffic-os/opportunities/rules/opportunity-rules.ts`.
2. **Adicione um novo método estático** na classe `OpportunityRules` para calcular a nova regra ou o boost correspondente.
   * *Exemplo: Regra para impulsionar artigos sazonais (Natal, Black Friday).*
   ```typescript
   public static getSazonalBoost(titulo: string): number {
     const normalized = titulo.toLowerCase();
     if (normalized.includes("black friday") || normalized.includes("natal") || normalized.includes("promoção")) {
       return 20; // Aplica um boost de +20 pontos no score
     }
     return 0;
   }
   ```
3. **Chame a regra no motor de ranqueamento** em `organic-traffic-os/opportunities/ranking/opportunity-ranking.ts`.
   ```typescript
   // Dentro do método calculate:
   const sazonalBoost = OpportunityRules.getSazonalBoost(titulo);
   boostsApplied += sazonalBoost;
   ```
4. **Adicione a lógica de rejeição/filtragem estrita** (caso a regra impeça a criação) dentro de:
   `organic-traffic-os/opportunities/validators/opportunity-validator.ts`
   ```typescript
   // Exemplo de regra estrita que invalida a oportunidade:
   if (opp.titulo.toLowerCase().includes("spam")) {
     errors.push("Regra estrita: Artigo contém palavras proibidas.");
   }
   ```
