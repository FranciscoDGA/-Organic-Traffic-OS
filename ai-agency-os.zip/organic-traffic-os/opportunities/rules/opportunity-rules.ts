import { Opportunity } from "../models/opportunity-model";
import { ConsolidatedInventory } from "../../inventory/inventory-loader";
import { ConsolidatedKnowledge } from "../../knowledge/knowledge-loader";
import { ConsolidatedKeywordData } from "../../keywords/keyword-loader";

export class OpportunityRules {
  /**
   * Rule 1: Nunca sugerir artigo duplicado
   * Retorna true se a oportunidade for duplicada de algum conteúdo existente no inventário
   * ou se for duplicada de uma lista de oportunidades já geradas.
   */
  public static isDuplicate(
    titulo: string, 
    keyword: string, 
    inventory: ConsolidatedInventory, 
    existingOpps: Opportunity[] = []
  ): { isDuplicate: boolean; reason?: string } {
    const normalizedTitle = titulo.toLowerCase().trim();
    const normalizedKeyword = keyword.toLowerCase().trim();

    // 1. Verificar no inventário existente
    if (inventory && Array.isArray(inventory.index)) {
      for (const item of inventory.index) {
        const itemTitle = (item.titulo || "").toLowerCase().trim();
        const itemKw = (item.palavraChave || item.keyword || item.palavra_chave || "").toLowerCase().trim();
        
        if (itemTitle === normalizedTitle && itemTitle.length > 0) {
          return { isDuplicate: true, reason: `Título igual ao conteúdo publicado: "${item.titulo}"` };
        }
        if (normalizedKeyword && itemKw === normalizedKeyword) {
          return { isDuplicate: true, reason: `Keyword "${keyword}" já coberta pelo artigo: "${item.titulo}"` };
        }
      }
    }

    // 2. Verificar nas oportunidades já geradas nesta execução
    for (const opp of existingOpps) {
      const oppTitle = opp.titulo.toLowerCase().trim();
      if (oppTitle === normalizedTitle && oppTitle.length > 0) {
        return { isDuplicate: true, reason: `Título já gerado em outra oportunidade: "${opp.titulo}"` };
      }
    }

    return { isDuplicate: false };
  }

  /**
   * Rule 2: Nunca sugerir conteúdo fora do nicho
   * Retorna true se a categoria não pertence às categorias permitidas no Knowledge Core
   */
  public static isOutOfNiche(
    categoria: string, 
    knowledge: ConsolidatedKnowledge
  ): boolean {
    if (!categoria) return false;
    if (!knowledge || !knowledge.categorias || knowledge.categorias.length === 0) {
      return false; // se vazio, passa (Engine continua funcionando de forma resiliente)
    }

    const normalizedCat = categoria.toLowerCase().trim();
    const isMatch = knowledge.categorias.some(cat => {
      const catName = (cat.nome || cat.name || cat.id || cat.titulo || "").toLowerCase().trim();
      return catName === normalizedCat;
    });
    
    return !isMatch;
  }

  /**
   * Rule 3: Priorizar conteúdos pilares
   * Aplica boost de score para conteúdos identificados como pilares estratégicos
   */
  public static getPillarBoost(tipo: string, cluster: string, knowledge: ConsolidatedKnowledge): number {
    let boost = 0;
    if (tipo === "reforco_pilar") {
      boost += 20;
    }

    if (!knowledge) return boost;

    // Verificar se o cluster é listado como categoria ou foco editorial estratégico
    const normalizedCluster = (cluster || "").toLowerCase().trim();
    const editorial = knowledge.editorial;
    if (editorial && editorial.focoEstrategico) {
      const focos = Array.isArray(editorial.focoEstrategico) 
        ? editorial.focoEstrategico 
        : [editorial.focoEstrategico];
      
      if (focos.some((f: string) => f.toLowerCase().includes(normalizedCluster))) {
        boost += 15;
      }
    }

    return boost;
  }

  /**
   * Rule 4: Priorizar clusters incompletos
   * Compara palavras-chave existentes de cada cluster com conteúdos publicados no inventário.
   * Se o cluster tiver pouca cobertura (menos de 30% das keywords cobertas), ganha boost!
   */
  public static getClusterIncompletenessBoost(
    cluster: string,
    keywordData: ConsolidatedKeywordData,
    inventory: ConsolidatedInventory
  ): number {
    if (!cluster) return 0;
    if (!keywordData || !Array.isArray(keywordData.keywords)) return 0;
    if (!inventory || !Array.isArray(inventory.index)) return 0;

    const normalizedCluster = cluster.toLowerCase().trim();

    // 1. Achar palavras do cluster
    const clusterKeywords = keywordData.keywords.filter(kw => 
      (kw.cluster || kw.grupo || "").toLowerCase().trim() === normalizedCluster
    );

    if (clusterKeywords.length === 0) return 0;

    // 2. Achar quantas dessas palavras estão no inventário
    let coveredCount = 0;
    clusterKeywords.forEach(kw => {
      const kwText = kw.palavra || kw.keyword || kw.palavra_chave || "";
      if (!kwText) return;
      const isCovered = inventory.index.some(item => {
        const itemKw = (item.palavraChave || item.keyword || item.palavra_chave || "").toLowerCase().trim();
        const itemTitle = (item.titulo || "").toLowerCase();
        return itemKw === kwText.toLowerCase().trim() || itemTitle.includes(kwText.toLowerCase());
      });
      if (isCovered) coveredCount++;
    });

    const coverageRatio = coveredCount / clusterKeywords.length;

    // Se a cobertura for baixa (cluster incompleto), ganha boost alto
    if (coverageRatio === 0) {
      return 25; // Cluster virgem/incompleto, excelente oportunidade!
    } else if (coverageRatio < 0.3) {
      return 15;
    } else if (coverageRatio < 0.6) {
      return 5;
    }

    return 0; // Cluster bem coberto, sem boost extra
  }

  /**
   * Rule 5: Priorizar perguntas recorrentes
   * Boost se o título ou a keyword for uma pergunta direta (PAA, FAQ, etc.)
   */
  public static getQuestionBoost(titulo: string, keyword: string, keywordData: ConsolidatedKeywordData): number {
    let boost = 0;
    const isQuestionText = (text: string) => {
      if (!text) return false;
      const lower = text.toLowerCase();
      return lower.startsWith("como") || 
             lower.startsWith("o que") || 
             lower.startsWith("por que") || 
             lower.startsWith("onde") || 
             lower.startsWith("qual") || 
             lower.startsWith("quais") || 
             lower.includes("?");
    };

    if (isQuestionText(titulo) || isQuestionText(keyword)) {
      boost += 15;
    }

    if (!keywordData || !Array.isArray(keywordData.questions)) return boost;

    // Se estiver explicitamente cadastrado na lista de perguntas
    const normalizedKw = keyword.toLowerCase().trim();
    if (normalizedKw) {
      const existsInQuestions = keywordData.questions.some(q => {
        const questionText = (q.pergunta || q.question || "").toLowerCase().trim();
        return questionText === normalizedKw || questionText.includes(normalizedKw);
      });

      if (existsInQuestions) {
        boost += 10;
      }
    }

    return boost;
  }
}
