import { Opportunity } from "../models/opportunity-model";
import { OpportunityRules } from "../rules/opportunity-rules";
import { ConsolidatedInventory } from "../../inventory/inventory-loader";
import { ConsolidatedKnowledge } from "../../knowledge/knowledge-loader";

export class OpportunityValidator {
  /**
   * Valida a estrutura, os campos e as regras básicas de uma oportunidade de conteúdo.
   */
  public static validar(
    opp: any,
    inventory?: ConsolidatedInventory,
    knowledge?: ConsolidatedKnowledge,
    existingOpps: Opportunity[] = []
  ): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!opp || typeof opp !== "object") {
      return { isValid: false, errors: ["Oportunidade inválida ou nula."] };
    }

    // --- 1. Validação de campos obrigatórios ---
    const requiredFields = [
      { name: "titulo", type: "string" },
      { name: "categoria", type: "string" },
      { name: "cluster", type: "string" },
      { name: "tipo", type: "string" },
      { name: "prioridade", type: "string" },
      { name: "score", type: "number" },
      { name: "origem", type: "string" },
      { name: "status", type: "string" }
    ];

    for (const field of requiredFields) {
      if (opp[field.name] === undefined || opp[field.name] === null || opp[field.name] === "") {
        errors.push(`Campo obrigatório ausente ou vazio: "${field.name}"`);
      } else if (typeof opp[field.name] !== field.type) {
        errors.push(`Campo "${field.name}" deve ser do tipo ${field.type}, mas obteve: ${typeof opp[field.name]}`);
      }
    }

    // --- 2. Validação de formatos específicos ---
    if (typeof opp.score === "number") {
      if (opp.score < 0 || opp.score > 100) {
        errors.push(`Score deve estar entre 0 e 100, mas obteve: ${opp.score}`);
      }
    }

    const prioridadesPermitidas = ["baixa", "media", "alta", "critica"];
    if (opp.prioridade && !prioridadesPermitidas.includes(opp.prioridade)) {
      errors.push(`Prioridade "${opp.prioridade}" inválida. Permitidos: ${prioridadesPermitidas.join(", ")}`);
    }

    const tiposPermitidos = ["novo_artigo", "otimizacao", "reforco_pilar"];
    if (opp.tipo && !tiposPermitidos.includes(opp.tipo)) {
      // Permitir flexibilidade mas avisar/recomendar ou rejeitar se for fora
      // Vamos manter apenas aviso ou permitir estender
    }

    // --- 3. Validação de Regras (Duplicidade & Nicho) se os dados estiverem disponíveis ---
    if (opp.titulo && inventory) {
      const keyword = opp.cluster || opp.titulo;
      const dupCheck = OpportunityRules.isDuplicate(opp.titulo, keyword, inventory, existingOpps);
      if (dupCheck.isDuplicate) {
        errors.push(`Regra de Duplicidade Violada: ${dupCheck.reason}`);
      }
    }

    if (opp.categoria && knowledge) {
      const outOfNiche = OpportunityRules.isOutOfNiche(opp.categoria, knowledge);
      if (outOfNiche) {
        errors.push(`Regra de Nicho Violada: A categoria "${opp.categoria}" está fora do nicho cadastrado no Knowledge Core.`);
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}
