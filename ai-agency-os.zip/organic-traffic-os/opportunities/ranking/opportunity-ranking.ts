import { Opportunity } from "../models/opportunity-model";
import { ConsolidatedInventory } from "../../inventory/inventory-loader";
import { ConsolidatedKnowledge } from "../../knowledge/knowledge-loader";
import { ConsolidatedCompetitors } from "../../competitors/competitor-loader";
import { ConsolidatedKeywordData } from "../../keywords/keyword-loader";
import { OpportunityRules } from "../rules/opportunity-rules";

export class OpportunityRanking {
  /**
   * Calcula o score final de uma oportunidade baseado em 8 fatores estratégicos,
   * aplicando também os boosts definidos nas Opportunity Rules.
   * Retorna um número inteiro de 0 a 100 e detalha os fatores que geraram a pontuação.
   */
  public static calculate(
    titulo: string,
    keyword: string,
    categoria: string,
    cluster: string,
    tipo: string,
    intencao: string,
    origem: string,
    knowledge: ConsolidatedKnowledge,
    inventory: ConsolidatedInventory,
    competitors: ConsolidatedCompetitors,
    keywords: ConsolidatedKeywordData
  ): { score: number; factors: Record<string, number>; reason: string } {
    
    // --- FATOR 1: Relevância para o blog (0 a 100) ---
    let relevancia = 50; // default
    if (knowledge && Array.isArray(knowledge.categorias)) {
      const normalizedCat = categoria.toLowerCase().trim();
      const catMatch = knowledge.categorias.some(cat => {
        const catName = (cat.nome || cat.name || cat.id || cat.titulo || "").toLowerCase().trim();
        return catName === normalizedCat;
      });
      if (catMatch) {
        relevancia = 100;
      } else {
        // Se a categoria é similar ou se o cluster se encaixa nas diretrizes editoriais
        const editorial = knowledge.editorial;
        if (editorial && editorial.focoEstrategico) {
          const focos = Array.isArray(editorial.focoEstrategico) ? editorial.focoEstrategico : [editorial.focoEstrategico];
          if (focos.some((f: string) => f.toLowerCase().includes(normalizedCat) || normalizedCat.includes(f.toLowerCase()))) {
            relevancia = 80;
          }
        }
      }
    }

    // --- FATOR 2: Intenção de busca (0 a 100) ---
    let intencaoScore = 50;
    const normalizedInt = (intencao || "").toLowerCase().trim();
    if (normalizedInt.includes("transacional") || normalizedInt.includes("comercial")) {
      intencaoScore = 100; // Alta conversão / monetização imediata
    } else if (normalizedInt.includes("informacional") || normalizedInt.includes("educacional") || normalizedInt.includes("pilar")) {
      intencaoScore = 85; // Alto tráfego / autoridade de marca
    } else if (normalizedInt.includes("local") || normalizedInt.includes("navegacional")) {
      intencaoScore = 65;
    }

    // --- FATOR 3: Quantidade de conteúdo existente no cluster (0 a 100) ---
    let conteudoExistenteScore = 100; // Quanto menos conteúdo, mais oportunidade!
    if (inventory && Array.isArray(inventory.index) && cluster) {
      const normalizedCluster = cluster.toLowerCase().trim();
      const countInCluster = inventory.index.filter(item => 
        (item.cluster || item.categoria || "").toLowerCase().trim() === normalizedCluster
      ).length;

      if (countInCluster === 0) conteudoExistenteScore = 100;
      else if (countInCluster <= 2) conteudoExistenteScore = 75;
      else if (countInCluster <= 5) conteudoExistenteScore = 45;
      else conteudoExistenteScore = 15; // Já muito saturado
    }

    // --- FATOR 4: Cobertura dos concorrentes (0 a 100) ---
    // Se concorrentes NÃO cobrem, é uma grande oportunidade para nós!
    let concorrenteGapScore = 50; // default resiliente
    if (competitors && Array.isArray(competitors.opportunities)) {
      // Procurar se a palavra ou o tema está no mapa de oportunidades ou fraquezas dos concorrentes
      const normalizedKw = keyword.toLowerCase().trim();
      const competitorHasWeakness = competitors.opportunities.some((opp: any) => {
        const tema = (opp.tema || opp.keyword || opp.titulo || "").toLowerCase();
        return tema.includes(normalizedKw) || normalizedKw.includes(tema);
      });

      if (competitorHasWeakness) {
        concorrenteGapScore = 95; // Concorrentes fracos ou com lacunas nesse tema!
      } else {
        // Verificar se algum concorrente tem foco estratégico nesse cluster
        const competitorHasFocus = competitors.strategies?.some((strat: any) => {
          const foco = (strat.foco || strat.focoPrincipal || "").toLowerCase();
          return foco.includes(normalizedKw) || normalizedKw.includes(foco);
        });
        if (competitorHasFocus) {
          concorrenteGapScore = 25; // Concorrente forte dominando o tema
        } else {
          concorrenteGapScore = 60; // Sem dominância explícita
        }
      }
    }

    // --- FATOR 5: Cobertura do PassaCumaru (0 a 100) ---
    // Se nós mesmos ainda não cobrimos essa palavra-chave, a oportunidade é máxima!
    let nossaCoberturaScore = 100;
    if (inventory && Array.isArray(inventory.index)) {
      const normalizedKw = keyword.toLowerCase().trim();
      const alreadyHasKw = inventory.index.some(item => {
        const itemKw = (item.palavraChave || item.keyword || item.palavra_chave || "").toLowerCase().trim();
        return itemKw === normalizedKw;
      });

      if (alreadyHasKw) {
        nossaCoberturaScore = 10; // Já temos um artigo para essa keyword!
      } else {
        // Verificar se temos pelo menos algo parecido no título
        const similarTitle = inventory.index.some(item => 
          (item.titulo || "").toLowerCase().includes(normalizedKw)
        );
        if (similarTitle) {
          nossaCoberturaScore = 45; // Cobertura parcial/tópico tangenciado
        }
      }
    }

    // --- FATOR 6: Potencial de monetização (0 a 100) ---
    let monetizacao = 50;
    if (normalizedInt.includes("comercial") || normalizedInt.includes("transacional")) {
      monetizacao = 100;
    } else if (knowledge && Array.isArray(knowledge.produtos) && knowledge.produtos.length > 0) {
      // Se a categoria do artigo se alinha com nossos produtos / infoprodutos / ofertas afiliadas
      const normalizedCat = categoria.toLowerCase().trim();
      const productAlign = knowledge.produtos.some(prod => {
        const prodCat = (prod.categoria || prod.category || "").toLowerCase().trim();
        return prodCat === normalizedCat || normalizedCat.includes(prodCat);
      });
      if (productAlign) {
        monetizacao = 90;
      }
    }

    // --- FATOR 7: Importância estratégica (0 a 100) ---
    let importanciaEstrategica = 50;
    // Se for tipo "reforco_pilar" ou tiver alta prioridade no banco de keywords
    if (tipo === "reforco_pilar") {
      importanciaEstrategica = 100;
    } else if (keywords && Array.isArray(keywords.priorities)) {
      const normalizedKw = keyword.toLowerCase().trim();
      const kwPriority = keywords.priorities.find(p => 
        (p.keyword || p.palavra || "").toLowerCase().trim() === normalizedKw
      );
      if (kwPriority) {
        // Mapeia pontuacaoFinal (tipicamente 1-10 ou 0-100)
        const val = kwPriority.pontuacaoFinal || kwPriority.prioridade_score || 5;
        importanciaEstrategica = val <= 10 ? val * 10 : val;
      }
    }

    // --- FATOR 8: Freshness (0 a 100) ---
    let freshness = 50;
    if (origem === "collectors") {
      freshness = 100; // Notícias frescas descobertas agora!
    } else if (origem === "trends") {
      freshness = 90; // Tendência quente
    } else if (origem === "serp") {
      freshness = 75; // Análise recente de SERP
    } else {
      freshness = 60;
    }

    // --- PESOS E CÁLCULO DA MÉDIA PONDERADA ---
    const weights = {
      relevancia: 0.15,
      intencao: 0.10,
      conteudoExistente: 0.15,
      concorrenteGap: 0.15,
      nossaCobertura: 0.15,
      monetizacao: 0.10,
      importancia: 0.10,
      freshness: 0.10
    };

    let baseScore = (
      relevancia * weights.relevancia +
      intencaoScore * weights.intencao +
      conteudoExistenteScore * weights.conteudoExistente +
      concorrenteGapScore * weights.concorrenteGap +
      nossaCoberturaScore * weights.nossaCobertura +
      monetizacao * weights.monetizacao +
      importanciaEstrategica * weights.importancia +
      freshness * weights.freshness
    );

    // --- APLICAÇÃO DOS BOOSTS DE OPPORTUNITY RULES ---
    let boostsApplied = 0;
    
    // Pillar Boost
    const pillarBoost = OpportunityRules.getPillarBoost(tipo, cluster, knowledge);
    if (pillarBoost > 0) boostsApplied += pillarBoost;

    // Cluster Incompleto Boost
    const clusterBoost = OpportunityRules.getClusterIncompletenessBoost(cluster, keywords, inventory);
    if (clusterBoost > 0) boostsApplied += clusterBoost;

    // Questions / PAA Boost
    const questionBoost = OpportunityRules.getQuestionBoost(titulo, keyword, keywords);
    if (questionBoost > 0) boostsApplied += questionBoost;

    let finalScore = Math.min(100, Math.round(baseScore + boostsApplied));
    finalScore = Math.max(0, finalScore);

    // Definir justificativa / motivo estruturado com base nos maiores motivadores
    let reason = `Score de ${finalScore}/100 gerado para o cluster "${cluster || "Geral"}". `;
    if (nossaCoberturaScore > 80 && concorrenteGapScore > 80) {
      reason += "Keyword totalmente inédita com fraqueza identificada nos concorrentes.";
    } else if (pillarBoost > 0) {
      reason += "Alta prioridade estratégica devido ao alinhamento como conteúdo Pilar.";
    } else if (clusterBoost > 20) {
      reason += "Foco em cluster incompleto com alta lacuna de produção interna.";
    } else if (monetizacao > 85) {
      reason += "Excelente potencial de conversão / monetização com produtos do blog.";
    } else if (freshness === 100) {
      reason += "Descoberta quente vinda do console de coletores de notícias externas.";
    } else {
      reason += "Alinhamento geral positivo de intenção de busca informacional/comercial.";
    }

    return {
      score: finalScore,
      factors: {
        relevancia,
        intencao: intencaoScore,
        conteudoExistente: conteudoExistenteScore,
        concorrenteGap: concorrenteGapScore,
        nossaCobertura: nossaCoberturaScore,
        monetizacao,
        importancia: importanciaEstrategica,
        freshness,
        boosts: boostsApplied
      },
      reason
    };
  }
}
