import { Connector, SearchQuery, SearchMetrics, SearchHistory } from "../base/connector";

export class MockConnector implements Connector {
  id = "mock-connector";
  nome = "Mock Connector (Dados Simulados)";
  versao = "1.0.0";
  status: "ativo" | "inativo" | "falha" = "ativo";

  async autenticar(): Promise<boolean> {
    return true;
  }

  async validar(): Promise<boolean> {
    return true;
  }

  async sincronizar(): Promise<{ queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] }> {
    const rawData = {
      timestamp: new Date().toISOString(),
      queries: [
        {
          query: "concurso prefeitura de cumaru do norte",
          pagina: "/blog/concurso-prefeitura-cumaru-do-norte",
          pais: "br",
          idioma: "pt",
          dispositivo: "mobile",
          periodo: "30d"
        },
        {
          query: "gabarito concurso cumaru",
          pagina: "/blog/gabarito-concurso-cumaru",
          pais: "br",
          idioma: "pt",
          dispositivo: "desktop",
          periodo: "30d"
        },
        {
          query: "prefeito de cumaru do norte",
          pagina: "/blog/prefeito-cumaru-norte",
          pais: "br",
          idioma: "pt",
          dispositivo: "mobile",
          periodo: "30d"
        },
        {
          query: "melhores pontos turisticos cumaru",
          pagina: "/blog/turismo-cumaru-do-norte",
          pais: "br",
          idioma: "pt",
          dispositivo: "desktop",
          periodo: "30d"
        },
        {
          query: "o que fazer em cumaru do norte",
          pagina: "/blog/guia-turistico-cumaru-norte",
          pais: "br",
          idioma: "pt",
          dispositivo: "mobile",
          periodo: "30d"
        }
      ],
      metrics: [
        {
          query: "concurso prefeitura de cumaru do norte",
          pagina: "/blog/concurso-prefeitura-cumaru-do-norte",
          impressoes: 12500,
          cliques: 2100,
          ctr: 0.168,
          posicao_media: 1.2,
          variacao: 0.1,
          conversor_leads: 12, // Baixa conversão (12/2100 = 0.57%) -> Alta posição + baixa conversão
          ultima_atualizacao: new Date().toISOString()
        },
        {
          query: "gabarito concurso cumaru",
          pagina: "/blog/gabarito-concurso-cumaru",
          impressoes: 8400,
          cliques: 120, // Baixo CTR (120/8400 = 1.4%) -> Alta impressão + baixo CTR
          ctr: 0.014,
          posicao_media: 3.4,
          variacao: -0.5,
          conversor_leads: 15,
          ultima_atualizacao: new Date().toISOString()
        },
        {
          query: "prefeito de cumaru do norte",
          pagina: "/blog/prefeito-cumaru-norte",
          impressoes: 1500, // Queda acentuada de impressões
          cliques: 450,
          ctr: 0.3,
          posicao_media: 2.1,
          variacao: -3.2, // Posição caindo e impressões caindo -> Queda de impressões
          conversor_leads: 45,
          ultima_atualizacao: new Date().toISOString()
        },
        {
          query: "melhores pontos turisticos cumaru",
          pagina: "/blog/turismo-cumaru-do-norte",
          impressoes: 3500, // Consulta emergente (muito tráfego recente)
          cliques: 850,
          ctr: 0.24,
          posicao_media: 8.5, // Posição baixa mas crescendo
          variacao: 4.2, // Variação positiva forte -> Consulta emergente
          conversor_leads: 110,
          ultima_atualizacao: new Date().toISOString()
        },
        {
          query: "o que fazer em cumaru do norte",
          pagina: "/blog/guia-turistico-cumaru-norte",
          impressoes: 5200, // Conteúdo promissor
          cliques: 1100,
          ctr: 0.211,
          posicao_media: 4.8, // Quase no topo, ótima oportunidade de impulsionar
          variacao: 1.5,
          conversor_leads: 180,
          ultima_atualizacao: new Date().toISOString()
        }
      ],
      history: [
        { data: "2026-06-28", query: "concurso prefeitura de cumaru do norte", impressoes: 12000, cliques: 2000, ctr: 0.166, posicao_media: 1.3 },
        { data: "2026-06-29", query: "concurso prefeitura de cumaru do norte", impressoes: 12200, cliques: 2050, ctr: 0.168, posicao_media: 1.2 },
        { data: "2026-06-30", query: "concurso prefeitura de cumaru do norte", impressoes: 12400, cliques: 2080, ctr: 0.167, posicao_media: 1.2 },
        { data: "2026-07-01", query: "concurso prefeitura de cumaru do norte", impressoes: 12500, cliques: 2100, ctr: 0.168, posicao_media: 1.2 },
        { data: "2026-06-28", query: "gabarito concurso cumaru", impressoes: 8000, cliques: 100, ctr: 0.012, posicao_media: 2.9 },
        { data: "2026-06-29", query: "gabarito concurso cumaru", impressoes: 8100, cliques: 105, ctr: 0.013, posicao_media: 3.1 },
        { data: "2026-06-30", query: "gabarito concurso cumaru", impressoes: 8300, cliques: 115, ctr: 0.014, posicao_media: 3.3 },
        { data: "2026-07-01", query: "gabarito concurso cumaru", impressoes: 8400, cliques: 120, ctr: 0.014, posicao_media: 3.4 }
      ]
    };
    return this.normalizar(rawData);
  }

  normalizar(dadosBrutos: any): { queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] } {
    const queries: SearchQuery[] = dadosBrutos.queries.map((q: any) => ({
      query: q.query,
      pagina: q.pagina,
      pais: q.pais,
      idioma: q.idioma,
      dispositivo: q.dispositivo,
      periodo: q.periodo
    }));

    const metrics: SearchMetrics[] = dadosBrutos.metrics.map((m: any) => ({
      query: m.query,
      pagina: m.pagina,
      impressoes: m.impressoes,
      cliques: m.cliques,
      ctr: m.ctr,
      posicao_media: m.posicao_media,
      variacao: m.variacao,
      conversor_leads: m.conversor_leads,
      conversao_leads: m.cliques > 0 ? Number((m.conversor_leads / m.cliques).toFixed(4)) : 0,
      ultima_atualizacao: m.ultima_atualizacao
    }));

    const history: SearchHistory[] = dadosBrutos.history.map((h: any) => ({
      data: h.data,
      query: h.query,
      impressoes: h.impressoes,
      cliques: h.cliques,
      ctr: h.ctr,
      posicao_media: h.posicao_media
    }));

    return { queries, metrics, history };
  }
}
