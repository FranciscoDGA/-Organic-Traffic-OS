import * as fs from "fs";
import * as path from "path";
import { SearchQuery, SearchMetrics, SearchHistory, SearchOpportunity } from "../base/connector";

export class ConnectorCache {
  private cacheDir = path.join(process.cwd(), "organic-traffic-os", "connectors", "cache");

  constructor() {
    if (!fs.existsSync(this.cacheDir)) {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    }
  }

  private getFilePath(filename: string): string {
    return path.join(this.cacheDir, filename);
  }

  private readJSON<T>(filename: string, defaultValue: T): T {
    const filePath = this.getFilePath(filename);
    if (!fs.existsSync(filePath)) {
      this.writeJSON(filename, defaultValue);
      return defaultValue;
    }
    try {
      const data = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(data) as T;
    } catch (err) {
      console.error(`Erro ao ler cache ${filename}:`, err);
      return defaultValue;
    }
  }

  private writeJSON<T>(filename: string, data: T): void {
    const filePath = this.getFilePath(filename);
    try {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
    } catch (err) {
      console.error(`Erro ao gravar cache ${filename}:`, err);
    }
  }

  // Queries
  getQueries(): SearchQuery[] {
    return this.readJSON<SearchQuery[]>("search-query.json", []);
  }

  saveQueries(queries: SearchQuery[]): void {
    this.writeJSON("search-query.json", queries);
  }

  // Metrics
  getMetrics(): SearchMetrics[] {
    return this.readJSON<SearchMetrics[]>("search-metrics.json", []);
  }

  saveMetrics(metrics: SearchMetrics[]): void {
    this.writeJSON("search-metrics.json", metrics);
  }

  // History
  getHistory(): SearchHistory[] {
    return this.readJSON<SearchHistory[]>("search-history.json", []);
  }

  saveHistory(history: SearchHistory[]): void {
    this.writeJSON("search-history.json", history);
  }

  // Opportunities
  getOpportunities(): SearchOpportunity[] {
    return this.readJSON<SearchOpportunity[]>("search-opportunities.json", []);
  }

  saveOpportunities(opportunities: SearchOpportunity[]): void {
    this.writeJSON("search-opportunities.json", opportunities);
  }

  // Clear cache completely
  clearAll(): void {
    this.saveQueries([]);
    this.saveMetrics([]);
    this.saveHistory([]);
    this.saveOpportunities([]);
  }
}
export const connectorCache = new ConnectorCache();
