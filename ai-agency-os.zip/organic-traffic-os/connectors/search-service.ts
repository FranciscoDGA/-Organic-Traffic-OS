import { connectorManager } from "./base/connector-manager";
import { searchIntelligenceEngine } from "./search-intelligence-engine";
import { connectorCache } from "./cache/connector-cache";
import { SearchQuery, SearchMetrics, SearchHistory, SearchOpportunity } from "./base/connector";
import { ManualConnector } from "./manual/manual-connector";

export class SearchService {
  
  async sincronizar(): Promise<{
    success: boolean;
    connectorsSynced: string[];
    queriesProcessed: number;
    metricsProcessed: number;
    historyProcessed: number;
    opportunitiesGenerated: number;
  }> {
    // 1. Obter todos os conectores ativos ou reativá-los se possível
    // Para garantir que o Mock e o Manual funcionem, vamos deixá-los ativos se estiverem marcados como inativos ou falhas por qualquer motivo
    const mockConn = connectorManager.getConnector("mock-connector");
    const manualConn = connectorManager.getConnector("manual-connector");
    
    if (mockConn && mockConn.status !== "ativo") {
      await connectorManager.setStatus("mock-connector", "ativo");
    }
    if (manualConn && manualConn.status !== "ativo") {
      await connectorManager.setStatus("manual-connector", "ativo");
    }

    // 2. Coletar dados de todos os conectores ativos
    const activeConnectors = connectorManager.listConnectors().filter(c => c.status === "ativo");
    
    let allQueries: SearchQuery[] = [];
    let allMetrics: SearchMetrics[] = [];
    let allHistory: SearchHistory[] = [];
    const syncedIds: string[] = [];

    for (const connector of activeConnectors) {
      try {
        console.log(`[Search Service] Sincronizando conector ativo: ${connector.id}`);
        const data = await connector.sincronizar();
        allQueries = allQueries.concat(data.queries);
        allMetrics = allMetrics.concat(data.metrics);
        allHistory = allHistory.concat(data.history);
        syncedIds.push(connector.id);
      } catch (err) {
        console.error(`[Search Service] Erro ao sincronizar conector ${connector.id}:`, err);
        connectorManager.logFailure(connector.id, String(err));
      }
    }

    // 3. Processar e consolidar os dados coletados na Search Intelligence Engine
    const stats = await searchIntelligenceEngine.processSyncData(allQueries, allMetrics, allHistory);

    return {
      success: true,
      connectorsSynced: syncedIds,
      ...stats
    };
  }

  buscarConsultas(): SearchQuery[] {
    return connectorCache.getQueries();
  }

  buscarMetricas(): SearchMetrics[] {
    return connectorCache.getMetrics();
  }

  buscarOportunidades(): SearchOpportunity[] {
    return connectorCache.getOpportunities();
  }

  buscarHistorico(): SearchHistory[] {
    return connectorCache.getHistory();
  }

  async adicionarEntradaManual(query: SearchQuery, metrics: SearchMetrics, history: SearchHistory): Promise<void> {
    const manualConnector = connectorManager.getConnector("manual-connector") as ManualConnector;
    if (!manualConnector) {
      throw new Error("Manual Connector não está disponível.");
    }
    
    manualConnector.addManualEntry(query, metrics, history);
    
    // Forçar resincronização automática para reprocessar oportunidades
    await this.sincronizar();
  }

  async alterarStatusConector(id: string, ativo: boolean): Promise<boolean> {
    const status = ativo ? "ativo" : "inativo";
    return connectorManager.setStatus(id, status);
  }

  listarConectores() {
    return connectorManager.listConnectors().map(c => ({
      id: c.id,
      nome: c.nome,
      versao: c.versao,
      status: c.status,
      erros: connectorManager.getFailures(c.id)
    }));
  }
}

export const searchService = new SearchService();
