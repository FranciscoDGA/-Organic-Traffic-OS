import { Connector, SearchQuery, SearchMetrics, SearchHistory } from "../base/connector";

export class BingWebmasterConnector implements Connector {
  id = "bing-webmaster";
  nome = "Bing Webmaster Tools";
  versao = "1.0.0";
  status: "ativo" | "inativo" | "falha" = "inativo";

  async autenticar(): Promise<boolean> {
    const apiKey = process.env.BING_WEBMASTER_API_KEY;
    
    if (!apiKey) {
      console.warn("[Bing Webmaster Connector] Falha na autenticação: Chave de API ausente em variáveis de ambiente.");
      this.status = "falha";
      return false;
    }
    
    this.status = "ativo";
    return true;
  }

  async validar(): Promise<boolean> {
    if (this.status !== "ativo") {
      return this.autenticar();
    }
    return true;
  }

  async sincronizar(): Promise<{ queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] }> {
    const isValid = await this.validar();
    if (!isValid) {
      throw new Error("Bing Webmaster Connector não autenticado ou configurado corretamente.");
    }

    const rawData = {
      queries: [],
      metrics: [],
      history: []
    };

    return this.normalizar(rawData);
  }

  normalizar(dadosBrutos: any): { queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] } {
    return {
      queries: dadosBrutos.queries || [],
      metrics: dadosBrutos.metrics || [],
      history: dadosBrutos.history || []
    };
  }
}
