import { Connector } from "./connector";
import { MockConnector } from "../mock/mock-connector";
import { ManualConnector } from "../manual/manual-connector";
import { GoogleSearchConsoleConnector } from "../google-search-console/google-search-console-connector";
import { GoogleTrendsConnector } from "../google-trends/google-trends-connector";
import { BingWebmasterConnector } from "../bing-webmaster/bing-webmaster-connector";

export class ConnectorManager {
  private connectors: Map<string, Connector> = new Map();
  private failures: Map<string, { timestamp: string; error: string }[]> = new Map();

  constructor() {
    // Instanciar conectores por padrão
    this.register(new MockConnector());
    this.register(new ManualConnector());
    this.register(new GoogleSearchConsoleConnector());
    this.register(new GoogleTrendsConnector());
    this.register(new BingWebmasterConnector());
  }

  register(connector: Connector): void {
    this.connectors.set(connector.id, connector);
    if (!this.failures.has(connector.id)) {
      this.failures.set(connector.id, []);
    }
    console.log(`[Connector Manager] Conector registrado: ${connector.nome} [v${connector.versao}]`);
  }

  getConnector(id: string): Connector | undefined {
    return this.connectors.get(id);
  }

  listConnectors(): Connector[] {
    return Array.from(this.connectors.values());
  }

  async setStatus(id: string, status: "ativo" | "inativo"): Promise<boolean> {
    const connector = this.connectors.get(id);
    if (!connector) return false;
    
    if (status === "ativo") {
      try {
        const authed = await connector.autenticar();
        if (authed) {
          connector.status = "ativo";
          return true;
        } else {
          connector.status = "falha";
          this.logFailure(id, "Falha na autenticação ao tentar ativar.");
          return false;
        }
      } catch (err: any) {
        connector.status = "falha";
        this.logFailure(id, err.message || "Erro desconhecido durante ativação.");
        return false;
      }
    } else {
      connector.status = "inativo";
      return true;
    }
  }

  logFailure(id: string, errorMsg: string): void {
    const list = this.failures.get(id) || [];
    list.unshift({
      timestamp: new Date().toISOString(),
      error: errorMsg
    });
    // Limitar histórico de erros a 10
    if (list.length > 10) list.pop();
    this.failures.set(id, list);
  }

  getFailures(id: string): { timestamp: string; error: string }[] {
    return this.failures.get(id) || [];
  }

  async syncConnector(id: string): Promise<any> {
    const connector = this.connectors.get(id);
    if (!connector) {
      throw new Error(`Conector '${id}' não encontrado.`);
    }

    if (connector.status !== "ativo") {
      const activated = await this.setStatus(id, "ativo");
      if (!activated) {
        throw new Error(`Não foi possível sincronizar o conector '${id}': falha na ativação/autenticação.`);
      }
    }

    try {
      console.log(`[Connector Manager] Iniciando sincronização para: ${connector.nome}`);
      const data = await connector.sincronizar();
      return data;
    } catch (err: any) {
      connector.status = "falha";
      this.logFailure(id, err.message || "Erro desconhecido durante sincronização.");
      throw err;
    }
  }

  async syncAllActive(): Promise<{ id: string; success: boolean; error?: string }[]> {
    const results = [];
    for (const connector of this.listConnectors()) {
      if (connector.status === "ativo") {
        try {
          await this.syncConnector(connector.id);
          results.push({ id: connector.id, success: true });
        } catch (err: any) {
          results.push({ id: connector.id, success: false, error: err.message });
        }
      }
    }
    return results;
  }
}

export const connectorManager = new ConnectorManager();
