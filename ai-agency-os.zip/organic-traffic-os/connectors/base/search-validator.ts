import { SearchQuery, SearchMetrics, SearchHistory, SearchOpportunity } from "./connector";

export class SearchValidator {
  
  static validateQueries(queries: SearchQuery[]): { valid: SearchQuery[]; invalid: any[]; errors: string[] } {
    const valid: SearchQuery[] = [];
    const invalid: any[] = [];
    const errors: string[] = [];
    const seen = new Set<string>();

    for (const q of queries) {
      if (!q.query || typeof q.query !== "string") {
        errors.push(`Query inválida ou vazia: ${JSON.stringify(q)}`);
        invalid.push(q);
        continue;
      }
      if (!q.pagina || typeof q.pagina !== "string") {
        errors.push(`Página inválida para query '${q.query}'`);
        invalid.push(q);
        continue;
      }
      
      const key = `${q.query.toLowerCase()}|${q.pagina.toLowerCase()}`;
      if (seen.has(key)) {
        errors.push(`Duplicidade de Query/Página encontrada para: '${q.query}'`);
        invalid.push(q);
        continue;
      }

      seen.add(key);
      valid.push({
        query: q.query.toLowerCase().trim(),
        pagina: q.pagina.trim(),
        pais: q.pais || "br",
        idioma: q.idioma || "pt",
        dispositivo: q.dispositivo || "all",
        periodo: q.periodo || "30d"
      });
    }

    return { valid, invalid, errors };
  }

  static validateMetrics(metrics: SearchMetrics[]): { valid: SearchMetrics[]; invalid: any[]; errors: string[] } {
    const valid: SearchMetrics[] = [];
    const invalid: any[] = [];
    const errors: string[] = [];
    const seen = new Set<string>();

    for (const m of metrics) {
      if (!m.query || typeof m.query !== "string") {
        errors.push(`Métrica sem query definida: ${JSON.stringify(m)}`);
        invalid.push(m);
        continue;
      }
      if (m.impressoes < 0 || typeof m.impressoes !== "number") {
        errors.push(`Impressões inválidas para a query '${m.query}': ${m.impressoes}`);
        invalid.push(m);
        continue;
      }
      if (m.cliques < 0 || typeof m.cliques !== "number") {
        errors.push(`Cliques inválidos para a query '${m.query}': ${m.cliques}`);
        invalid.push(m);
        continue;
      }
      if (m.ctr < 0 || m.ctr > 1 || typeof m.ctr !== "number") {
        errors.push(`CTR inválido para a query '${m.query}': ${m.ctr} (Deve ser entre 0 e 1)`);
        invalid.push(m);
        continue;
      }
      if (typeof m.posicao_media !== "number" || m.posicao_media < 1) {
        errors.push(`Posição média inválida para a query '${m.query}': ${m.posicao_media} (Deve ser >= 1)`);
        invalid.push(m);
        continue;
      }

      const key = `${m.query.toLowerCase()}|${m.pagina.toLowerCase()}`;
      if (seen.has(key)) {
        errors.push(`Métrica duplicada para a mesma Query/Página: '${m.query}'`);
        invalid.push(m);
        continue;
      }

      seen.add(key);
      valid.push({
        query: m.query.toLowerCase().trim(),
        pagina: m.pagina.trim(),
        impressoes: Math.round(m.impressoes),
        cliques: Math.round(m.cliques),
        ctr: Number(m.ctr.toFixed(4)),
        posicao_media: Number(m.posicao_media.toFixed(2)),
        variacao: Number((m.variacao || 0).toFixed(2)),
        conversor_leads: Math.round(m.conversor_leads || 0),
        conversao_leads: m.cliques > 0 ? Number(((m.conversor_leads || 0) / m.cliques).toFixed(4)) : 0,
        ultima_atualizacao: m.ultima_atualizacao || new Date().toISOString()
      });
    }

    return { valid, invalid, errors };
  }

  static validateHistory(history: SearchHistory[]): { valid: SearchHistory[]; invalid: any[]; errors: string[] } {
    const valid: SearchHistory[] = [];
    const invalid: any[] = [];
    const errors: string[] = [];
    const seen = new Set<string>();

    for (const h of history) {
      if (!h.data || isNaN(Date.parse(h.data))) {
        errors.push(`Data histórica inválida: ${h.data}`);
        invalid.push(h);
        continue;
      }
      if (!h.query || typeof h.query !== "string") {
        errors.push(`Query histórica vazia`);
        invalid.push(h);
        continue;
      }

      const key = `${h.data}|${h.query.toLowerCase()}`;
      if (seen.has(key)) {
        errors.push(`Registro histórico duplicado para data e query: '${h.data}' - '${h.query}'`);
        invalid.push(h);
        continue;
      }

      seen.add(key);
      valid.push({
        data: h.data,
        query: h.query.toLowerCase().trim(),
        impressoes: Math.round(h.impressoes || 0),
        cliques: Math.round(h.cliques || 0),
        ctr: Number((h.ctr || 0).toFixed(4)),
        posicao_media: Number((h.posicao_media || 1).toFixed(2))
      });
    }

    return { valid, invalid, errors };
  }
}
