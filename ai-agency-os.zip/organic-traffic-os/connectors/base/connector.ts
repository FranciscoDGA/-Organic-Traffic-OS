export interface SearchQuery {
  query: string;
  pagina: string;
  pais: string;
  idioma: string;
  dispositivo: string;
  periodo: string;
}

export interface SearchMetrics {
  query: string;
  pagina: string;
  impressoes: number;
  cliques: number;
  ctr: number;
  posicao_media: number;
  variacao: number;
  conversor_leads: number; // Cliques que converteram em leads
  conversao_leads: number; // Porcentagem de conversão (conversor_leads / cliques)
  ultima_atualizacao: string;
}

export interface SearchHistory {
  data: string;
  query: string;
  impressoes: number;
  cliques: number;
  ctr: number;
  posicao_media: number;
}

export interface SearchOpportunity {
  id: string;
  query: string;
  pagina: string;
  tipo: "alta_impressao_baixo_ctr" | "alta_posicao_baixa_conversao" | "queda_impressoes" | "consulta_emergente" | "conteudo_promissor";
  descricao: string;
  impacto: "alto" | "medio" | "baixo";
  metrica_atual: string;
  metrica_esperada: string;
  acao_recomendada: string;
  status: "identificada" | "em_progresso" | "resolvida";
  criado_em: string;
}

export interface Connector {
  id: string;
  nome: string;
  versao: string;
  status: "ativo" | "inativo" | "falha";
  autenticar(): Promise<boolean>;
  validar(): Promise<boolean>;
  sincronizar(): Promise<{ queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] }>;
  normalizar(dadosBrutos: any): { queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] };
}
