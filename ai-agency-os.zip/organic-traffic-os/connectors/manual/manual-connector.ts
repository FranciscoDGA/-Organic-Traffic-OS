import { Connector, SearchQuery, SearchMetrics, SearchHistory } from "../base/connector";

export class ManualConnector implements Connector {
  id = "manual-connector";
  nome = "Manual Connector (Entradas Manuais)";
  versao = "1.0.0";
  status: "ativo" | "inativo" | "falha" = "ativo";

  // In-memory list or simple loaded state that the UI can populate
  private manualQueries: SearchQuery[] = [
    {
      query: "simulado concurso cumaru do norte",
      pagina: "/blog/simulado-concurso-cumaru",
      pais: "br",
      idioma: "pt",
      dispositivo: "all",
      periodo: "manual"
    },
    {
      query: "edital concurso prefeitura de cumaru",
      pagina: "/blog/edital-concurso-cumaru-norte",
      pais: "br",
      idioma: "pt",
      dispositivo: "all",
      periodo: "manual"
    }
  ];

  private manualMetrics: SearchMetrics[] = [
    {
      query: "simulado concurso cumaru do norte",
      pagina: "/blog/simulado-concurso-cumaru",
      impressoes: 4500,
      cliques: 980,
      ctr: 0.217,
      posicao_media: 2.3,
      variacao: 0.5,
      conversor_leads: 320, // 32.6% conversão
      conversao_leads: 0.326,
      ultima_atualizacao: new Date().toISOString()
    },
    {
      query: "edital concurso prefeitura de cumaru",
      pagina: "/blog/edital-concurso-cumaru-norte",
      impressoes: 6200,
      cliques: 2400,
      ctr: 0.387,
      posicao_media: 1.1,
      variacao: 0.1,
      conversor_leads: 580, // 24.1% conversão
      conversao_leads: 0.241,
      ultima_atualizacao: new Date().toISOString()
    }
  ];

  private manualHistory: SearchHistory[] = [
    { data: "2026-07-01", query: "simulado concurso cumaru do norte", impressoes: 4500, cliques: 980, ctr: 0.217, posicao_media: 2.3 },
    { data: "2026-07-01", query: "edital concurso prefeitura de cumaru", impressoes: 6200, cliques: 2400, ctr: 0.387, posicao_media: 1.1 }
  ];

  async autenticar(): Promise<boolean> {
    return true; // Manual inputs require no external token
  }

  async validar(): Promise<boolean> {
    return true;
  }

  // Permite adicionar entradas manualmente no runtime
  addManualEntry(query: SearchQuery, metrics: SearchMetrics, history: SearchHistory) {
    // Avoid duplicates
    this.manualQueries = this.manualQueries.filter(q => q.query !== query.query);
    this.manualMetrics = this.manualMetrics.filter(m => m.query !== metrics.query);
    this.manualHistory = this.manualHistory.filter(h => h.query !== history.query || h.data !== history.data);

    this.manualQueries.push(query);
    this.manualMetrics.push(metrics);
    this.manualHistory.push(history);
  }

  async sincronizar(): Promise<{ queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] }> {
    return this.normalizar({
      queries: this.manualQueries,
      metrics: this.manualMetrics,
      history: this.manualHistory
    });
  }

  normalizar(dadosBrutos: any): { queries: SearchQuery[]; metrics: SearchMetrics[]; history: SearchHistory[] } {
    return {
      queries: dadosBrutos.queries || [],
      metrics: (dadosBrutos.metrics || []).map((m: any) => ({
        ...m,
        conversao_leads: m.cliques > 0 ? Number((m.conversor_leads / m.cliques).toFixed(4)) : 0
      })),
      history: dadosBrutos.history || []
    };
  }
}
