import { SearchQuery, SearchMetrics, SearchHistory, SearchOpportunity } from "./base/connector";
import { SearchValidator } from "./base/search-validator";
import { connectorCache } from "./cache/connector-cache";

export class SearchIntelligenceEngine {
  
  async processSyncData(
    queriesList: SearchQuery[],
    metricsList: SearchMetrics[],
    historyList: SearchHistory[]
  ): Promise<{
    queriesProcessed: number;
    metricsProcessed: number;
    historyProcessed: number;
    opportunitiesGenerated: number;
  }> {
    // 1. Validar entradas para remover duplicados e sanitizar campos
    const valQueries = SearchValidator.validateQueries(queriesList);
    const valMetrics = SearchValidator.validateMetrics(metricsList);
    const valHistory = SearchValidator.validateHistory(historyList);

    // Logs de avisos e erros durante a validação
    if (valQueries.errors.length > 0) {
      console.warn(`[Search Intelligence] Avisos de validação de queries:\n`, valQueries.errors.join("\n"));
    }
    if (valMetrics.errors.length > 0) {
      console.warn(`[Search Intelligence] Avisos de validação de métricas:\n`, valMetrics.errors.join("\n"));
    }
    if (valHistory.errors.length > 0) {
      console.warn(`[Search Intelligence] Avisos de validação de histórico:\n`, valHistory.errors.join("\n"));
    }

    // 2. Mesclar com dados existentes no cache local
    const existingQueries = connectorCache.getQueries();
    const existingMetrics = connectorCache.getMetrics();
    const existingHistory = connectorCache.getHistory();

    // Mesclar queries (usando query + pagina como chave única)
    const mergedQueriesMap = new Map<string, SearchQuery>();
    for (const q of [...existingQueries, ...valQueries.valid]) {
      mergedQueriesMap.set(`${q.query}|${q.pagina}`, q);
    }
    const finalQueries = Array.from(mergedQueriesMap.values());

    // Mesclar métricas (query + pagina como chave)
    const mergedMetricsMap = new Map<string, SearchMetrics>();
    for (const m of [...existingMetrics, ...valMetrics.valid]) {
      mergedMetricsMap.set(`${m.query}|${m.pagina}`, m);
    }
    const finalMetrics = Array.from(mergedMetricsMap.values());

    // Mesclar histórico (data + query como chave)
    const mergedHistoryMap = new Map<string, SearchHistory>();
    for (const h of [...existingHistory, ...valHistory.valid]) {
      mergedHistoryMap.set(`${h.data}|${h.query}`, h);
    }
    const finalHistory = Array.from(mergedHistoryMap.values());

    // Gravar dados consolidados de volta no Cache
    connectorCache.saveQueries(finalQueries);
    connectorCache.saveMetrics(finalMetrics);
    connectorCache.saveHistory(finalHistory);

    // 3. Gerar Oportunidades Inteligentes com base em regras
    const generatedOpportunities = this.generateOpportunities(finalMetrics);
    connectorCache.saveOpportunities(generatedOpportunities);

    return {
      queriesProcessed: finalQueries.length,
      metricsProcessed: finalMetrics.length,
      historyProcessed: finalHistory.length,
      opportunitiesGenerated: generatedOpportunities.length
    };
  }

  private generateOpportunities(metrics: SearchMetrics[]): SearchOpportunity[] {
    const opportunities: SearchOpportunity[] = [];

    for (const m of metrics) {
      // Regra 1: Alta impressão + baixo CTR
      // Definição: Mais de 4000 impressões, mas CTR menor que 3%
      if (m.impressoes > 4000 && m.ctr < 0.03) {
        opportunities.push({
          id: `opp-ctr-${m.query.replace(/\s+/g, "-")}`,
          query: m.query,
          pagina: m.pagina,
          tipo: "alta_impressao_baixo_ctr",
          descricao: `A palavra-chave '${m.query}' tem alta visibilidade (${m.impressoes} impressões), mas CTR extremamente baixo de ${(m.ctr * 100).toFixed(1)}%.`,
          impacto: "alto",
          metrica_atual: `CTR: ${(m.ctr * 100).toFixed(1)}% | Impressões: ${m.impressoes}`,
          metrica_esperada: `CTR > 8.0%`,
          acao_recomendada: `Reescrever o Title de SEO e a Meta Description para aumentar a atratividade do clique. Adicione elementos emocionais, gatilhos de urgência ou colchetes descritivos.`,
          status: "identificada",
          criado_em: new Date().toISOString()
        });
      }

      // Regra 2: Alta posição + baixa conversão de leads
      // Definição: Posição média menor que 3.0 (top 3) e taxa de conversão menor que 1.5%
      if (m.posicao_media <= 3.0 && m.cliques > 100 && m.conversao_leads < 0.015) {
        opportunities.push({
          id: `opp-conv-${m.query.replace(/\s+/g, "-")}`,
          query: m.query,
          pagina: m.pagina,
          tipo: "alta_posicao_baixa_conversao",
          descricao: `A página ranqueia no topo para '${m.query}' (${m.cliques} cliques), mas a conversão em leads está muito baixa (${(m.conversao_leads * 100).toFixed(2)}%).`,
          impacto: "alto",
          metrica_atual: `Conversão: ${(m.conversao_leads * 100).toFixed(2)}% | Cliques: ${m.cliques}`,
          metrica_esperada: `Conversão > 5.0%`,
          acao_recomendada: `Revisar os CTAs internos da página. Otimizar as chamadas de conversão para Simulados Locais de Cumaru do Norte, colocar caixas de captura flutuantes e banners logo após o primeiro H2.`,
          status: "identificada",
          criado_em: new Date().toISOString()
        });
      }

      // Regra 3: Queda acentuada de impressões
      // Definição: variação negativa acentuada (menor que -2.0) ou queda direta
      if (m.variacao < -2.0) {
        opportunities.push({
          id: `opp-decay-${m.query.replace(/\s+/g, "-")}`,
          query: m.query,
          pagina: m.pagina,
          tipo: "queda_impressoes",
          descricao: `Detecção de decaimento orgânico para '${m.query}'. Queda brusca de posicionamento/visibilidade de ${m.variacao} posições na SERP.`,
          impacto: "medio",
          metrica_atual: `Variação de Posição: ${m.variacao}`,
          metrica_esperada: `Variação Positiva (Estabilidade)`,
          acao_recomendada: `Atualizar o conteúdo do post! Adicionar novas seções de perguntas frequentes (FAQs), atualizar dados desatualizados (ex: datas de editais, taxas) e garantir que a palavra-chave pilar esteja no primeiro parágrafo.`,
          status: "identificada",
          criado_em: new Date().toISOString()
        });
      }

      // Regra 4: Consultas emergentes (Variação positiva alta com bom potencial)
      if (m.variacao > 3.0 && m.posicao_media > 5) {
        opportunities.push({
          id: `opp-emerge-${m.query.replace(/\s+/g, "-")}`,
          query: m.query,
          pagina: m.pagina,
          tipo: "consulta_emergente",
          descricao: `A consulta '${m.query}' está em forte tendência de alta (+${m.variacao} posições) e atualmente ocupa a posição ${m.posicao_media}.`,
          impacto: "medio",
          metrica_atual: `Variação: +${m.variacao} | Posição: ${m.posicao_media}`,
          metrica_esperada: `Top 3 do Google`,
          acao_recomendada: `Melhorar a autoridade do post. Criar links internos a partir de outros artigos populares e fortalecer as semânticas relacionadas.`,
          status: "identificada",
          criado_em: new Date().toISOString()
        });
      }

      // Regra 5: Conteúdos promissores
      // Definição: Posição entre 4.0 e 10.0 (está no final da 1ª página) com impressões decentes (> 1500)
      if (m.posicao_media >= 4.0 && m.posicao_media <= 10.0 && m.impressoes > 1500) {
        opportunities.push({
          id: `opp-promising-${m.query.replace(/\s+/g, "-")}`,
          query: m.query,
          pagina: m.pagina,
          tipo: "conteudo_promissor",
          descricao: `Conteúdo de alta relevância com potencial imediato. '${m.query}' está na posição ${m.posicao_media} (final da primeira página do Google).`,
          impacto: "alto",
          metrica_atual: `Posição: ${m.posicao_media} | Impressões: ${m.impressoes}`,
          metrica_esperada: `Posição < 3.0`,
          acao_recomendada: `Fazer otimização on-page estrita: adicionar imagens com ALT descritivos, aumentar o tempo de permanência do usuário incluindo tabelas ricas e otimizar velocidade de carregamento deste post específico.`,
          status: "identificada",
          criado_em: new Date().toISOString()
        });
      }
    }

    return opportunities;
  }
}

export const searchIntelligenceEngine = new SearchIntelligenceEngine();
