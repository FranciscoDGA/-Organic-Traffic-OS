export interface ContentDocument {
  content_id: string; // ID Principal do Conteúdo
  asset_id: string;   // ID do Ativo de Conteúdo de origem
  titulo: string;
  slug: string;
  tipo: string;       // Formato do ativo (ex: artigo, faq, quiz...)
  versao: string;     // Versão de publicação
  status: "preparado" | "revisado" | "pronto_para_publicar";
  idioma: string;     // ex: "pt-BR"
  autor: string;      // ex: "Redator IA - PassaCumaru"
  created_at: string;
  updated_at: string;
  corpo_formatado: string; // Saída gerada pelo Renderer selecionado
  seo: {
    titulo_seo: string;
    meta_descricao: string;
    palavras_chave: string[];
    canonical_url: string;
    open_graph: {
      og_title: string;
      og_description: string;
      og_type: string;
    };
  };
  schema_org: any; // Schema estruturado JSON-LD
  assets_relacionados: string[]; // IDs de ativos conectados para silagem
}

export interface PublishManifest {
  content_id: string;
  versao: string;
  destino: "WordPress" | "Next.js" | "HTML" | "Markdown" | "CMS Headless" | "JSON" | "RSS" | "PDF";
  renderer: "html" | "markdown" | "json" | "wordpress" | "nextjs";
  status: "sucesso" | "pendente" | "falha";
  checksum: string;
}

export interface PublishingPackage {
  documento: ContentDocument;
  metadados: {
    tempo_estimado_leitura_minutos: number;
    densidade_palavras_chave: Record<string, number>;
    contagem_palavras: number;
    data_preparacao: string;
  };
  seo: ContentDocument["seo"];
  schema: any;
  assets_relacionados: any[];
  manifest: PublishManifest;
}
