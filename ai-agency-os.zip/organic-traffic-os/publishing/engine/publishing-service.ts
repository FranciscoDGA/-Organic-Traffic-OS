import * as fs from "fs";
import * as path from "path";
import { PublishingPackage } from "../formats/types";
import { AssetService } from "../../assets/engine/asset-service";
import { VisibilityService } from "../../visibility/engine/visibility-service";
import { StrategyService } from "../../strategy/engine/strategy-service";
import { PublishingEngine } from "./publishing-engine";
import { PublishingValidator } from "../validators/publishing-validator";

export class PublishingService {
  private static exportsDir = path.join(process.cwd(), "organic-traffic-os/publishing/exports");
  private static indexFilePath = path.join(this.exportsDir, "packages.json");

  private static ensureDirectoryExists() {
    if (!fs.existsSync(this.exportsDir)) {
      fs.mkdirSync(this.exportsDir, { recursive: true });
    }
  }

  /**
   * Retorna todas as publicações preparadas no sistema.
   */
  public static getPublications(): PublishingPackage[] {
    this.ensureDirectoryExists();
    try {
      if (fs.existsSync(this.indexFilePath)) {
        const raw = fs.readFileSync(this.indexFilePath, "utf-8");
        return JSON.parse(raw || "[]");
      }
    } catch (e) {
      console.error("Erro ao ler índice de publicações preparadas:", e);
    }
    return [];
  }

  /**
   * Busca uma publicação preparada pelo seu id de conteúdo (content_id).
   */
  public static getPublicationById(contentId: string): PublishingPackage | null {
    const publications = this.getPublications();
    return publications.find(p => p.documento.content_id === contentId) || null;
  }

  /**
   * Prepara um novo pacote de publicação baseado em um Ativo e Destino.
   */
  public static async preparePublication(
    assetId: string,
    destino: "WordPress" | "Next.js" | "HTML" | "Markdown" | "CMS Headless" | "JSON" | "RSS" | "PDF"
  ): Promise<PublishingPackage> {
    this.ensureDirectoryExists();

    // 1. Carregar Ativo
    const asset = AssetService.getAssetById(assetId);
    if (!asset) {
      throw new Error(`Ativo com ID '${assetId}' não encontrado.`);
    }

    // 2. Tentar buscar Visibilidade correspondente (pelo título ou ID do rascunho)
    let visibilityReport = null;
    try {
      const reports = VisibilityService.getReports();
      // Encontrar relatório correspondente ao ativo pelo título ou rascunho
      visibilityReport = reports.find(r => 
        r.original_title?.toLowerCase() === asset.titulo.toLowerCase() ||
        r.id === asset.content_id
      ) || (reports.length > 0 ? reports[0] : null); // Fallback para o mais recente se não achar exato
    } catch (e) {
      console.warn("Aviso ao buscar relatório de visibilidade correspondente:", e);
    }

    // 3. Tentar buscar Estratégia ativa
    let strategy = null;
    try {
      const strategies = StrategyService.getStrategies();
      strategy = strategies && strategies.length > 0 ? strategies[0] : null;
    } catch (e) {
      console.warn("Aviso ao buscar estratégia ativa:", e);
    }

    // 4. Rodar o motor de preparação
    const pkg = PublishingEngine.prepare(asset, visibilityReport, strategy, destino);

    // 5. Mapear relações estruturais de silos no documento
    try {
      const relations = AssetService.getAllRelations();
      const connectedAssetIds: string[] = [];
      const connectedAssetsInfo: any[] = [];

      relations.forEach(rel => {
        if (rel.source_asset_id === asset.id) {
          connectedAssetIds.push(rel.target_asset_id);
          const targetAsset = AssetService.getAssetById(rel.target_asset_id);
          if (targetAsset) {
            connectedAssetsInfo.push({
              id: targetAsset.id,
              titulo: targetAsset.titulo,
              tipo: targetAsset.tipo,
              relacao: rel.tipo_relacao
            });
          }
        } else if (rel.target_asset_id === asset.id) {
          connectedAssetIds.push(rel.source_asset_id);
          const sourceAsset = AssetService.getAssetById(rel.source_asset_id);
          if (sourceAsset) {
            connectedAssetsInfo.push({
              id: sourceAsset.id,
              titulo: sourceAsset.titulo,
              tipo: sourceAsset.tipo,
              relacao: `inversa-${rel.tipo_relacao}`
            });
          }
        }
      });

      pkg.documento.assets_relacionados = connectedAssetIds;
      pkg.assets_relacionados = connectedAssetsInfo;
    } catch (e) {
      console.warn("Aviso ao carregar conexões de silos do ativo:", e);
    }

    // 6. Validar o pacote gerado
    const validation = PublishingValidator.validate(pkg);
    if (!validation.valido) {
      console.warn(`Aviso de validação no pacote de publicação: ${validation.errosCriticos} erros críticos identificados.`);
    }

    // 7. Salvar pacote no índice geral
    const publications = this.getPublications();
    
    // Se já existir publicação antiga para o mesmo ativo e destino, podemos remover ou atualizar
    const filtered = publications.filter(p => 
      !(p.documento.asset_id === asset.id && p.manifest.destino === destino)
    );
    
    filtered.unshift(pkg);
    fs.writeFileSync(this.indexFilePath, JSON.stringify(filtered, null, 2), "utf-8");

    // Salvar também em arquivo individual de auditoria/export para visualização estática do usuário
    const individualFileName = `${pkg.documento.content_id}_${destino.toLowerCase().replace(/[^a-z0-9]/g, "_")}.json`;
    const individualPath = path.join(this.exportsDir, individualFileName);
    fs.writeFileSync(individualPath, JSON.stringify(pkg, null, 2), "utf-8");

    return pkg;
  }

  /**
   * Exclui uma publicação preparada do sistema por ID de Conteúdo (content_id).
   */
  public static deletePublication(contentId: string): boolean {
    const publications = this.getPublications();
    const filtered = publications.filter(p => p.documento.content_id !== contentId);
    if (publications.length === filtered.length) return false;

    fs.writeFileSync(this.indexFilePath, JSON.stringify(filtered, null, 2), "utf-8");

    // Tentar excluir arquivos individuais também se houver
    try {
      const files = fs.readdirSync(this.exportsDir);
      files.forEach(f => {
        if (f.startsWith(contentId) && f.endsWith(".json")) {
          fs.unlinkSync(path.join(this.exportsDir, f));
        }
      });
    } catch (e) {
      console.error("Erro ao limpar arquivos individuais da publicação deletada:", e);
    }

    return true;
  }

  /**
   * Promove ou atualiza o status de prontidão de uma publicação.
   */
  public static updateStatus(contentId: string, status: "preparado" | "revisado" | "pronto_para_publicar"): boolean {
    const publications = this.getPublications();
    const index = publications.findIndex(p => p.documento.content_id === contentId);
    if (index === -1) return false;

    publications[index].documento.status = status;
    publications[index].documento.updated_at = new Date().toISOString();
    fs.writeFileSync(this.indexFilePath, JSON.stringify(publications, null, 2), "utf-8");
    return true;
  }

  /**
   * Incrementa manualmente a versão operacional do pacote preparado de publicação.
   */
  public static versionPublication(contentId: string): PublishingPackage {
    const publications = this.getPublications();
    const index = publications.findIndex(p => p.documento.content_id === contentId);
    if (index === -1) {
      throw new Error(`Publicação '${contentId}' não encontrada para versionamento.`);
    }

    const currentVersion = parseFloat(publications[index].documento.versao || "1.0");
    const nextVersion = (currentVersion + 0.1).toFixed(1);

    publications[index].documento.versao = nextVersion;
    publications[index].manifest.versao = nextVersion;
    publications[index].documento.updated_at = new Date().toISOString();

    fs.writeFileSync(this.indexFilePath, JSON.stringify(publications, null, 2), "utf-8");
    return publications[index];
  }
}
