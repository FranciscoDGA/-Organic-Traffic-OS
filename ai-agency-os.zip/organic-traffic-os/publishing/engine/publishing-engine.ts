import { Asset } from "../../assets/types/asset-types";
import { FullVisibilityReport } from "../../visibility/engine/visibility-service";
import { Strategy } from "../../strategy/engine/strategy-validator";
import { ContentDocument, PublishManifest, PublishingPackage } from "../formats/types";
import { HTMLRenderer } from "../renderers/html-renderer";
import { MarkdownRenderer } from "../renderers/markdown-renderer";
import { JSONRenderer } from "../renderers/json-renderer";
import { FutureWordPressRenderer } from "../renderers/future-wordpress-renderer";
import { FutureNextJSRenderer } from "../renderers/future-nextjs-renderer";

export class PublishingEngine {
  /**
   * Prepara um pacote completo de publicação (PublishingPackage) a partir de um Ativo, Visibilidade e Estratégia.
   */
  public static prepare(
    asset: Asset,
    visibility: FullVisibilityReport | null,
    strategy: Strategy | null,
    destino: "WordPress" | "Next.js" | "HTML" | "Markdown" | "CMS Headless" | "JSON" | "RSS" | "PDF" = "HTML"
  ): PublishingPackage {
    const content_id = `pub_${asset.id}_${Date.now().toString().slice(-4)}`;
    
    // 1. Selecionar o renderer correto e gerar o corpo formatado
    let renderer: PublishManifest["renderer"] = "html";
    let corpo_formatado = "";

    if (destino === "HTML") {
      renderer = "html";
      corpo_formatado = HTMLRenderer.render(asset);
    } else if (destino === "Markdown" || destino === "RSS" || destino === "PDF") {
      renderer = "markdown";
      corpo_formatado = MarkdownRenderer.render(asset);
    } else if (destino === "JSON" || destino === "CMS Headless") {
      renderer = "json";
      corpo_formatado = JSONRenderer.render(asset);
    } else if (destino === "WordPress") {
      renderer = "wordpress";
      corpo_formatado = FutureWordPressRenderer.render(asset);
    } else if (destino === "Next.js") {
      renderer = "nextjs";
      corpo_formatado = FutureNextJSRenderer.render(asset);
    } else {
      renderer = "html";
      corpo_formatado = HTMLRenderer.render(asset);
    }

    // 2. Definir o slug amigável de URL
    let slug = asset.titulo
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // Remover acentos
      .replace(/[^a-z0-9\s-]/g, "")    // Remover caracteres especiais
      .replace(/\s+/g, "-")            // Espaços para hifens
      .replace(/-+/g, "-")             // Evitar hifens seguidos
      .trim();
    if (!slug) slug = `ativo-conteudo-${asset.id}`;

    // 3. Estruturar bloco SEO e Metadados
    const palavras_chave = ["concursos", "estudos", "passacumaru", asset.tipo];

    const titulo_seo = visibility?.meta_title 
      ? visibility.meta_title 
      : `${asset.titulo} | PassaCumaru`;

    const meta_descricao = visibility?.meta_description 
      ? visibility.meta_description 
      : `${asset.objetivo || 'Estude com o melhor conteúdo preparatório para concursos federais e estaduais no PassaCumaru.'} Versão atualizada de estudos.`;

    const canonical_url = `https://passacumaru.com.br/blog/${slug}`;

    // 4. Estruturar Schema Markup (JSON-LD)
    const schema_org: any = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": asset.titulo,
      "description": asset.objetivo || "Conteúdo preparatório para concurso público",
      "publisher": {
        "@type": "Organization",
        "name": "PassaCumaru",
        "logo": {
          "@type": "ImageObject",
          "url": "https://passacumaru.com.br/logo.png"
        }
      }
    };

    if (asset.tipo === "artigo") {
      schema_org["@type"] = "Article";
      schema_org["headline"] = asset.titulo;
      schema_org["author"] = {
        "@type": "Person",
        "name": "Redator IA - PassaCumaru"
      };
      schema_org["datePublished"] = asset.criado_em;
      schema_org["dateModified"] = asset.atualizado_em;
    } else if (asset.tipo === "faq" && asset.estrutura?.perguntas) {
      schema_org["@type"] = "FAQPage";
      schema_org["mainEntity"] = asset.estrutura.perguntas.map((p: any) => ({
        "@type": "Question",
        "name": p.pergunta,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": p.resposta
        }
      }));
    } else if (asset.tipo === "quiz" || asset.tipo === "simulado") {
      schema_org["@type"] = "Quiz";
      schema_org["name"] = asset.titulo;
      schema_org["about"] = {
        "@type": "Thing",
        "name": "Estudo para Concurso Público"
      };
    }

    // 5. Calcular métricas do documento (contagem de palavras, leitura, densidade)
    const textoCompleto = typeof asset.estrutura === "object" 
      ? JSON.stringify(asset.estrutura) 
      : (asset.estrutura || "");
    
    // Limpeza rápida para estimar contagem
    const palavras = textoCompleto.split(/\s+/).filter(p => p.length > 2);
    const contagem_palavras = Math.max(120, palavras.length);
    const tempo_estimado_leitura_minutos = Math.max(1, Math.ceil(contagem_palavras / 200));

    // Calcular densidade de palavras-chave simples
    const densidade_palavras_chave: Record<string, number> = {};
    palavras_chave.forEach(kw => {
      const regex = new RegExp(`\\b${kw}\\b`, "gi");
      const matches = textoCompleto.match(regex);
      const contagem = matches ? matches.length : 0;
      densidade_palavras_chave[kw] = contagem_palavras > 0 
        ? parseFloat(((contagem / contagem_palavras) * 100).toFixed(2)) 
        : 0;
    });

    // 6. Criar Documento Principal de Conteúdo (content-document.json fields)
    const documento: ContentDocument = {
      content_id,
      asset_id: asset.id,
      titulo: asset.titulo,
      slug,
      tipo: asset.tipo,
      versao: asset.versao || "1.0",
      status: "preparado",
      idioma: "pt-BR",
      autor: strategy?.persona 
        ? `PassaCumaru Persona (${strategy.persona})`
        : "Redator IA - PassaCumaru",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      corpo_formatado,
      seo: {
        titulo_seo,
        meta_descricao,
        palavras_chave,
        canonical_url,
        open_graph: {
          og_title: titulo_seo,
          og_description: meta_descricao,
          og_type: asset.tipo === "artigo" ? "article" : "website"
        }
      },
      schema_org,
      assets_relacionados: [] // Será populado pelo service carregando silos
    };

    // 7. Gerar checksum simples para o manifest
    const rawDataForHash = JSON.stringify(documento);
    let hash = 0;
    for (let i = 0; i < rawDataForHash.length; i++) {
      const char = rawDataForHash.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0; // Converter para inteiro 32bit
    }
    const checksum = `sha256_${Math.abs(hash).toString(16)}`;

    // 8. Criar Manifest de Publicação (publish-manifest.json fields)
    const manifest: PublishManifest = {
      content_id,
      versao: documento.versao,
      destino,
      renderer,
      status: "sucesso",
      checksum
    };

    return {
      documento,
      metadados: {
        tempo_estimado_leitura_minutos,
        densidade_palavras_chave,
        contagem_palavras,
        data_preparacao: new Date().toISOString()
      },
      seo: documento.seo,
      schema: schema_org,
      assets_relacionados: [],
      manifest
    };
  }
}
