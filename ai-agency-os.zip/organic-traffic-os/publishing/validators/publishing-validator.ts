import { ContentDocument, PublishingPackage } from "../formats/types";

export interface PublishingValidationIssue {
  tipo: "critico" | "aviso" | "info";
  campo: string;
  mensagem: string;
}

export interface PublishingValidationReport {
  valido: boolean;
  errosCriticos: number;
  avisos: number;
  problemas: PublishingValidationIssue[];
}

export class PublishingValidator {
  static validate(pkg: PublishingPackage): PublishingValidationReport {
    const problemas: PublishingValidationIssue[] = [];
    const doc = pkg.documento;

    // 1. Validar Campos Obrigatórios (Documento Principal)
    if (!doc.content_id) {
      problemas.push({ tipo: "critico", campo: "content_id", mensagem: "O campo 'content_id' está ausente ou vazio." });
    }
    if (!doc.asset_id) {
      problemas.push({ tipo: "critico", campo: "asset_id", mensagem: "O campo 'asset_id' está ausente ou vazio." });
    }
    if (!doc.titulo || doc.titulo.trim() === "") {
      problemas.push({ tipo: "critico", campo: "titulo", mensagem: "O título da publicação é obrigatório." });
    }

    // 2. Validar Slug (Formato URL Amigável)
    if (!doc.slug || doc.slug.trim() === "") {
      problemas.push({ tipo: "critico", campo: "slug", mensagem: "O slug da URL está vazio." });
    } else {
      const slugRegex = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
      if (!slugRegex.test(doc.slug)) {
        problemas.push({
          tipo: "critico",
          campo: "slug",
          mensagem: `Slug inválido: "${doc.slug}". Deve conter apenas letras minúsculas, números e hifens (ex: "direito-administrativo-concurso").`
        });
      }
    }

    // 3. Validar Metadados e SEO
    const seo = doc.seo;
    if (!seo) {
      problemas.push({ tipo: "critico", campo: "seo", mensagem: "O bloco de metadados SEO é obrigatório." });
    } else {
      if (!seo.titulo_seo || seo.titulo_seo.trim() === "") {
        problemas.push({ tipo: "critico", campo: "seo.titulo_seo", mensagem: "O título SEO está vazio." });
      } else if (seo.titulo_seo.length > 60) {
        problemas.push({ tipo: "aviso", campo: "seo.titulo_seo", mensagem: `Título SEO é muito longo (${seo.titulo_seo.length} caracteres). Ideal é até 60.` });
      }

      if (!seo.meta_descricao || seo.meta_descricao.trim() === "") {
        problemas.push({ tipo: "critico", campo: "seo.meta_descricao", mensagem: "A meta descrição está vazia." });
      } else if (seo.meta_descricao.length < 110 || seo.meta_descricao.length > 160) {
        problemas.push({
          tipo: "aviso",
          campo: "seo.meta_descricao",
          mensagem: `Meta descrição com ${seo.meta_descricao.length} caracteres. O ideal é entre 110 e 160 para melhor exibição na SERP.`
        });
      }

      if (!seo.palavras_chave || seo.palavras_chave.length === 0) {
        problemas.push({ tipo: "aviso", campo: "seo.palavras_chave", mensagem: "A publicação não possui palavras-chave principais associadas." });
      }
    }

    // 4. Validar Schema Markup (JSON-LD)
    if (!doc.schema_org) {
      problemas.push({ tipo: "aviso", campo: "schema_org", mensagem: "Schema.org estruturado não foi injetado nesta publicação." });
    } else if (!doc.schema_org["@context"] || !doc.schema_org["@type"]) {
      problemas.push({ tipo: "aviso", campo: "schema_org", mensagem: "O Schema.org estruturado parece estar em formato inválido ou incompleto." });
    }

    // 5. Validar Corpo Formatado (HTML/Markdown Renderizado)
    if (!doc.corpo_formatado || doc.corpo_formatado.trim() === "") {
      problemas.push({ tipo: "critico", campo: "corpo_formatado", mensagem: "O corpo de conteúdo renderizado está totalmente vazio." });
    }

    // 6. Validar Links Internos e de Silos
    if (doc.tipo === "pagina_pilar" && (!doc.assets_relacionados || doc.assets_relacionados.length === 0)) {
      problemas.push({
        tipo: "aviso",
        campo: "assets_relacionados",
        mensagem: "Esta é uma Página Pilar, mas nenhum ativo satélite foi linkado para fins de estruturação de silo."
      });
    }

    const errosCriticos = problemas.filter(p => p.tipo === "critico").length;
    const avisos = problemas.filter(p => p.tipo === "aviso").length;

    return {
      valido: errosCriticos === 0,
      errosCriticos,
      avisos,
      problemas
    };
  }
}
