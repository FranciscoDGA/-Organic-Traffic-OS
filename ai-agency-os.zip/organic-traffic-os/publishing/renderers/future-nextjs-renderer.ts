import { Asset } from "../../assets/types/asset-types";

export class FutureNextJSRenderer {
  static render(asset: Asset): string {
    const { tipo, titulo, estrutura } = asset;
    
    let tsx = `// Next.js Static Generation Component\n`;
    tsx += `// Gerado em: ${new Date().toLocaleDateString()}\n`;
    tsx += `// Ativo de origem: ${asset.id}\n\n`;
    tsx += `import React from 'react';\n`;
    tsx += `import Head from 'next/head';\n\n`;
    tsx += `export default function PageComponent() {\n`;
    tsx += `  return (\n`;
    tsx += `    <div className="max-w-4xl mx-auto px-4 py-8 font-sans">\n`;
    tsx += `      <Head>\n`;
    tsx += `        <title>${titulo} | PassaCumaru Concursos</title>\n`;
    tsx += `        <meta name="description" content="${asset.objetivo?.replace(/"/g, '\\"') || 'Conteúdo de estudos para concurso.'}" />\n`;
    tsx += `      </Head>\n\n`;

    if (!estrutura) {
      tsx += `      <h1 className="text-3xl font-bold mb-4">${titulo}</h1>\n`;
      tsx += `      <p>Estrutura não definida.</p>\n`;
      tsx += `    </div>\n  );\n}`;
      return tsx;
    }

    switch (tipo) {
      case "artigo":
        tsx += `      <article className="prose lg:prose-xl dark:prose-invert">\n`;
        tsx += `        <h1 className="text-4xl font-extrabold tracking-tight mb-6">${estrutura.h1 || titulo}</h1>\n`;
        if (estrutura.introducao) {
          tsx += `        <p className="text-xl text-slate-400 italic mb-8 border-l-4 border-cyan-500 pl-4">${estrutura.introducao}</p>\n`;
        }
        if (estrutura.secoes && Array.isArray(estrutura.secoes)) {
          estrutura.secoes.forEach((sec: any, i: number) => {
            tsx += `        <section key={${i}} className="mb-8">\n`;
            tsx += `          <h2 className="text-2xl font-bold mb-3">${sec.subtitulo}</h2>\n`;
            tsx += `          <p className="text-slate-300 leading-relaxed">${sec.texto}</p>\n`;
            tsx += `        </section>\n`;
          });
        }
        if (estrutura.conclusao) {
          tsx += `        <section className="mt-8 pt-6 border-t border-slate-850">\n`;
          tsx += `          <h2 className="text-2xl font-bold mb-3">Conclusão</h2>\n`;
          tsx += `          <p className="text-slate-300 leading-relaxed">${estrutura.conclusao}</p>\n`;
          tsx += `        </section>\n`;
        }
        tsx += `      </article>\n`;
        if (estrutura.cta) {
          tsx += `\n      <div className="mt-12 p-6 bg-slate-900 rounded-2xl border border-cyan-500/20 text-center">\n`;
          tsx += `        <h3 className="text-xl font-bold mb-3">${estrutura.cta.texto}</h3>\n`;
          tsx += `        <a href="${estrutura.cta.destino || '#'}" className="inline-block bg-cyan-500 text-slate-950 font-bold px-6 py-3 rounded-lg hover:bg-cyan-400 transition-colors">\n`;
          tsx += `          Acessar Agora\n`;
          tsx += `        </a>\n`;
          tsx += `      </div>\n`;
        }
        break;

      case "simulado":
        tsx += `      <h1 className="text-3xl font-bold mb-2">${titulo}</h1>\n`;
        if (estrutura.edital_referencia) {
          tsx += `      <span className="inline-block bg-emerald-500/10 text-emerald-400 font-mono text-xs px-2.5 py-1 rounded border border-emerald-500/20 mb-6">Edital: ${estrutura.edital_referencia}</span>\n`;
        }
        tsx += `      <div className="space-y-6">\n`;
        if (estrutura.questoes && Array.isArray(estrutura.questoes)) {
          estrutura.questoes.forEach((q: any, i: number) => {
            tsx += `        <div key={${i}} className="p-6 bg-slate-900 rounded-xl border border-slate-800">\n`;
            tsx += `          <p className="font-semibold text-lg text-white mb-4">Questão ${i + 1}: { \`${q.enunciado.replace(/`/g, '\\`').replace(/\$/g, '\\$')}\` }</p>\n`;
            tsx += `          <div className="space-y-2">\n`;
            if (q.opcoes && typeof q.opcoes === "object") {
              Object.entries(q.opcoes).forEach(([letra, texto]: [string, any]) => {
                tsx += `            <label className="flex items-start gap-3 p-3 bg-slate-950/40 rounded-lg border border-slate-850 hover:bg-slate-950/80 cursor-pointer">\n`;
                tsx += `              <input type="radio" name="q-${i}" className="mt-1" />\n`;
                tsx += `              <span><strong>${letra})</strong> { \`${texto.replace(/`/g, '\\`').replace(/\$/g, '\\$')}\` }</span>\n`;
                tsx += `            </label>\n`;
              });
            }
            tsx += `          </div>\n`;
            tsx += `        </div>\n`;
          });
        }
        tsx += `      </div>\n`;
        break;

      default:
        tsx += `      <h1 className="text-3xl font-extrabold mb-4">${titulo}</h1>\n`;
        tsx += `      <p className="text-slate-400 mb-6">Esse formato de componente de visualização "${tipo}" utiliza os dados abaixo para renderização dinâmica no Next.js (SSG ou SSR):</p>\n`;
        tsx += `      <pre className="bg-slate-950 p-4 rounded-xl overflow-x-auto text-xs text-cyan-400"><code>{JSON.stringify(${JSON.stringify(estrutura)}, null, 2)}</code></pre>\n`;
        break;
    }

    tsx += `    </div>\n`;
    tsx += `  );\n`;
    tsx += `}\n`;
    return tsx;
  }
}
