import { Asset } from "../../assets/types/asset-types";

export class HTMLRenderer {
  static render(asset: Asset): string {
    const { tipo, titulo, estrutura } = asset;
    let html = `<!-- Ativo de Conteúdo: ${titulo} (${tipo}) -->\n`;
    html += `<article class="organic-publish-content" data-asset-id="${asset.id}">\n`;

    if (!estrutura) {
      html += `  <h1>${titulo}</h1>\n  <p>Conteúdo sem estrutura definida.</p>\n`;
      html += `</article>`;
      return html;
    }

    switch (tipo) {
      case "artigo":
        html += `  <header>\n    <h1>${estrutura.h1 || titulo}</h1>\n`;
        if (estrutura.introducao) {
          html += `    <p class="lead">${estrutura.introducao}</p>\n`;
        }
        html += `  </header>\n\n  <div class="content-body">\n`;
        if (estrutura.secoes && Array.isArray(estrutura.secoes)) {
          estrutura.secoes.forEach((sec: any) => {
            html += `    <section>\n      <h2>${sec.subtitulo}</h2>\n      <p>${sec.texto}</p>\n    </section>\n`;
          });
        }
        if (estrutura.conclusao) {
          html += `    <section class="conclusao">\n      <h2>Conclusão</h2>\n      <p>${estrutura.conclusao}</p>\n    </section>\n`;
        }
        html += `  </div>\n`;
        if (estrutura.cta) {
          html += `\n  <aside class="cta-box">\n    <h3>${estrutura.cta.texto}</h3>\n    <a href="${estrutura.cta.destino || '#'}" class="cta-button">Acessar Agora</a>\n  </aside>\n`;
        }
        break;

      case "pagina_pilar":
        html += `  <header>\n    <h1>Página Pilar: ${estrutura.tema_principal || titulo}</h1>\n`;
        if (estrutura.resumo_autoridade) {
          html += `    <p class="authority-summary">${estrutura.resumo_autoridade}</p>\n`;
        }
        html += `  </header>\n\n  <div class="pillar-modules">\n`;
        if (estrutura.modulos && Array.isArray(estrutura.modulos)) {
          estrutura.modulos.forEach((mod: any, idx: number) => {
            html += `    <div class="pillar-module" id="modulo-${idx + 1}">\n`;
            html += `      <h2>${idx + 1}. ${mod.titulo_modulo}</h2>\n`;
            html += `      <p>${mod.descricao}</p>\n`;
            if (mod.links_satelite_sugeridos && Array.isArray(mod.links_satelite_sugeridos)) {
              html += `      <ul class="satellite-links">\n`;
              mod.links_satelite_sugeridos.forEach((link: string) => {
                html += `        <li>Artigo Relacionado: <a href="/${link}">${link}</a></li>\n`;
              });
              html += `      </ul>\n`;
            }
            html += `    </div>\n`;
          });
        }
        html += `  </div>\n`;
        break;

      case "faq":
        html += `  <header>\n    <h1>Perguntas Frequentes (FAQ)</h1>\n  </header>\n\n  <div class="faq-accordion" itemscope itemtype="https://schema.org/FAQPage">\n`;
        if (estrutura.perguntas && Array.isArray(estrutura.perguntas)) {
          estrutura.perguntas.forEach((faq: any, idx: number) => {
            html += `    <div class="faq-item" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question" id="faq-${idx + 1}">\n`;
            html += `      <h3 itemprop="name">${faq.pergunta}</h3>\n`;
            html += `      <div itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">\n`;
            html += `        <p itemprop="text">${faq.resposta}</p>\n`;
            html += `      </div>\n    </div>\n`;
          });
        }
        html += `  </div>\n`;
        break;

      case "landing":
        html += `  <div class="landing-hero">\n    <h1>${estrutura.hero_titulo || titulo}</h1>\n`;
        if (estrutura.hero_subtitulo) {
          html += `    <p class="subtitle">${estrutura.hero_subtitulo}</p>\n`;
        }
        html += `  </div>\n\n  <div class="landing-features">\n    <h2>O que você vai receber</h2>\n    <ul>\n`;
        if (estrutura.beneficios && Array.isArray(estrutura.beneficios)) {
          estrutura.beneficios.forEach((ben: string) => {
            html += `      <li>${ben}</li>\n`;
          });
        }
        html += `    </ul>\n  </div>\n`;
        if (estrutura.prova_social) {
          html += `\n  <blockquote class="testimonial">\n    <p>"${estrutura.prova_social.depoimento}"</p>\n    <cite>— ${estrutura.prova_social.autor}, ${estrutura.prova_social.cargo}</cite>\n  </blockquote>\n`;
        }
        html += `\n  <div class="cta-action">\n    <a href="#leads" class="btn-primary">${estrutura.cta_botao || "Começar Agora"}</a>\n  </div>\n`;
        break;

      case "quiz":
        html += `  <header>\n    <h1>Quiz: ${estrutura.titulo_quiz || titulo}</h1>\n  </header>\n\n  <div class="quiz-container">\n`;
        if (estrutura.questoes && Array.isArray(estrutura.questoes)) {
          estrutura.questoes.forEach((q: any, idx: number) => {
            html += `    <div class="quiz-question" id="pergunta-${idx + 1}">\n`;
            html += `      <h3>${idx + 1}. ${q.pergunta}</h3>\n`;
            html += `      <ul class="options">\n`;
            if (q.opcoes && Array.isArray(q.opcoes)) {
              q.opcoes.forEach((op: string, oIdx: number) => {
                const isGabarito = oIdx === q.gabarito_index ? ' data-correct="true"' : '';
                html += `        <li${isGabarito}>${op}</li>\n`;
              });
            }
            html += `      </ul>\n`;
            if (q.feedback) {
              html += `      <p class="feedback" style="display:none;"><strong>Explicação:</strong> ${q.feedback}</p>\n`;
            }
            html += `    </div>\n`;
          });
        }
        html += `  </div>\n`;
        break;

      case "checklist":
        html += `  <header>\n    <h1>Checklist: ${estrutura.nome_lista || titulo}</h1>\n  </header>\n\n  <div class="checklist-container">\n`;
        if (estrutura.fases && Array.isArray(estrutura.fases)) {
          estrutura.fases.forEach((fase: any, fIdx: number) => {
            html += `    <div class="checklist-phase">\n      <h2>Fase: ${fase.fase_nome}</h2>\n      <ul class="checklist-items">\n`;
            if (fase.itens && Array.isArray(fase.itens)) {
              fase.itens.forEach((it: any, iIdx: number) => {
                html += `        <li class="checklist-item" data-importance="${it.importancia || 'media'}">\n`;
                html += `          <label>\n            <input type="checkbox" />\n`;
                html += `            <strong>${it.tarefa}</strong>\n`;
                if (it.dica_de_execucao) {
                  html += `            <span class="tip">${it.dica_de_execucao}</span>\n`;
                }
                html += `          </label>\n        </li>\n`;
              });
            }
            html += `      </ul>\n    </div>\n`;
          });
        }
        html += `  </div>\n`;
        break;

      case "glossario":
        html += `  <header>\n    <h1>Glossário Explicativo</h1>\n  </header>\n\n  <div class="glossary-terms">\n`;
        if (estrutura.termos && Array.isArray(estrutura.termos)) {
          estrutura.termos.forEach((term: any) => {
            html += `    <div class="glossary-item" id="term-${term.termo.toLowerCase().replace(/[^a-z0-9]/g, '-')}">\n`;
            html += `      <span class="letter-badge">${term.letra || 'A'}</span>\n`;
            html += `      <h2>${term.termo}</h2>\n`;
            html += `      <p class="definition">${term.significado}</p>\n`;
            if (term.contexto_uso) {
              html += `      <p class="context font-italic"><strong>Contexto de Prova:</strong> ${term.contexto_uso}</p>\n`;
            }
            html += `    </div>\n`;
          });
        }
        html += `  </div>\n`;
        break;

      case "simulado":
        html += `  <header>\n    <h1>Simulado Completo: ${titulo}</h1>\n`;
        if (estrutura.edital_referencia) {
          html += `    <div class="exam-reference">Foco Edital: <strong>${estrutura.edital_referencia}</strong></div>\n`;
        }
        html += `  </header>\n\n  <div class="simulado-questions">\n`;
        if (estrutura.questoes && Array.isArray(estrutura.questoes)) {
          estrutura.questoes.forEach((q: any, idx: number) => {
            html += `    <div class="exam-question" id="questao-${idx + 1}">\n`;
            html += `      <p class="statement"><strong>Questão ${idx + 1}:</strong> ${q.enunciado}</p>\n`;
            html += `      <ol class="options" type="A">\n`;
            if (q.opcoes && typeof q.opcoes === "object") {
              Object.entries(q.opcoes).forEach(([letra, texto]) => {
                const isGabarito = letra === q.gabarito ? ' class="correct-option"' : '';
                html += `        <li${isGabarito} data-value="${letra}"><strong>${letra})</strong> ${texto}</li>\n`;
              });
            }
            html += `      </ol>\n`;
            if (q.explicacao) {
              html += `      <div class="explanation-box" style="display:none;">\n`;
              html += `        <p><strong>Gabarito: ${q.gabarito}</strong></p>\n`;
              html += `        <p>${q.explicacao}</p>\n`;
              html += `      </div>\n`;
            }
            html += `    </div>\n`;
          });
        }
        html += `  </div>\n`;
        break;

      default:
        html += `  <h1>${titulo}</h1>\n`;
        html += `  <pre class="raw-structure">${JSON.stringify(estrutura, null, 2)}</pre>\n`;
        break;
    }

    html += `</article>`;
    return html;
  }
}
