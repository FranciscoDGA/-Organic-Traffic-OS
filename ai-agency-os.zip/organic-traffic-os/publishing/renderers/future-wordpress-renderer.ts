import { Asset } from "../../assets/types/asset-types";

export class FutureWordPressRenderer {
  static render(asset: Asset): string {
    const { tipo, titulo, estrutura } = asset;
    let blocks = `<!-- Giga-Silo WordPress Gutemberg Ready Block Format -->\n`;
    blocks += `<!-- Ativo: ${titulo} | Formato: ${tipo} -->\n\n`;

    if (!estrutura) {
      blocks += `<!-- wp:paragraph -->\n<p>Conteúdo sem estrutura definida.</p>\n<!-- /wp:paragraph -->`;
      return blocks;
    }

    switch (tipo) {
      case "artigo":
        blocks += `<!-- wp:heading {"level":1} -->\n<h1>${estrutura.h1 || titulo}</h1>\n<!-- /wp:heading -->\n\n`;
        if (estrutura.introducao) {
          blocks += `<!-- wp:paragraph {"className":"is-style-lead"} -->\n<p class="is-style-lead">${estrutura.introducao}</p>\n<!-- /wp:paragraph -->\n\n`;
        }
        if (estrutura.secoes && Array.isArray(estrutura.secoes)) {
          estrutura.secoes.forEach((sec: any) => {
            blocks += `<!-- wp:heading {"level":2} -->\n<h2>${sec.subtitulo}</h2>\n<!-- /wp:heading -->\n\n`;
            blocks += `<!-- wp:paragraph -->\n<p>${sec.texto}</p>\n<!-- /wp:paragraph -->\n\n`;
          });
        }
        if (estrutura.conclusao) {
          blocks += `<!-- wp:heading {"level":2} -->\n<h2>Conclusão</h2>\n<!-- /wp:heading -->\n\n`;
          blocks += `<!-- wp:paragraph -->\n<p>${estrutura.conclusao}</p>\n<!-- /wp:paragraph -->\n\n`;
        }
        if (estrutura.cta) {
          blocks += `<!-- wp:group {"backgroundColor":"cyan-bluish-gray","layout":{"type":"constrained"}} -->\n`;
          blocks += `<div class="wp-block-group has-cyan-bluish-gray-background-color">\n`;
          blocks += `  <!-- wp:heading {"level":3} -->\n  <h3>${estrutura.cta.texto}</h3>\n  <!-- /wp:heading -->\n`;
          blocks += `  <!-- wp:button -->\n`;
          blocks += `  <div class="wp-block-button"><a class="wp-block-button__link" href="${estrutura.cta.destino || '#'}">Acessar Agora</a></div>\n`;
          blocks += `  <!-- /wp:button -->\n`;
          blocks += `</div>\n<!-- /wp:group -->\n`;
        }
        break;

      case "faq":
        blocks += `<!-- wp:heading {"level":1} -->\n<h1>Perguntas Frequentes</h1>\n<!-- /wp:heading -->\n\n`;
        if (estrutura.perguntas && Array.isArray(estrutura.perguntas)) {
          estrutura.perguntas.forEach((faq: any) => {
            blocks += `<!-- wp:group {"className":"wp-faq-block"} -->\n<div class="wp-block-group wp-faq-block">\n`;
            blocks += `  <!-- wp:heading {"level":3} -->\n  <h3>${faq.pergunta}</h3>\n  <!-- /wp:heading -->\n`;
            blocks += `  <!-- wp:paragraph -->\n  <p>${faq.resposta}</p>\n  <!-- /wp:paragraph -->\n`;
            blocks += `</div>\n<!-- /wp:group -->\n\n`;
          });
        }
        break;

      default:
        // Renderizador genérico de blocos Gutenberg para os demais tipos
        blocks += `<!-- wp:heading {"level":1} -->\n<h1>${titulo}</h1>\n<!-- /wp:heading -->\n\n`;
        blocks += `<!-- wp:paragraph -->\n<p>Este é um pacote de publicação preparado para o WordPress. O formato "${tipo}" será injetado no banco de dados via REST API do WordPress (V2/posts) com os metadados abaixo:</p>\n<!-- /wp:paragraph -->\n\n`;
        blocks += `<!-- wp:code -->\n<pre class="wp-block-code"><code>${JSON.stringify(estrutura, null, 2)}</code></pre>\n<!-- /wp:code -->`;
        break;
    }

    return blocks;
  }
}
