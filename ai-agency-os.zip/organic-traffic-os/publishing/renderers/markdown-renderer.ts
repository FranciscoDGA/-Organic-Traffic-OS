import { Asset } from "../../assets/types/asset-types";

export class MarkdownRenderer {
  static render(asset: Asset): string {
    const { tipo, titulo, estrutura } = asset;
    let md = `---\n`;
    md += `title: "${titulo.replace(/"/g, '\\"')}"\n`;
    md += `type: "${tipo}"\n`;
    md += `asset_id: "${asset.id}"\n`;
    md += `date_rendered: "${new Date().toISOString()}"\n`;
    md += `---\n\n`;

    if (!estrutura) {
      md += `# ${titulo}\n\nConteúdo sem estrutura definida.\n`;
      return md;
    }

    switch (tipo) {
      case "artigo":
        md += `# ${estrutura.h1 || titulo}\n\n`;
        if (estrutura.introducao) {
          md += `> ${estrutura.introducao}\n\n`;
        }
        if (estrutura.secoes && Array.isArray(estrutura.secoes)) {
          estrutura.secoes.forEach((sec: any) => {
            md += `## ${sec.subtitulo}\n\n${sec.texto}\n\n`;
          });
        }
        if (estrutura.conclusao) {
          md += `## Conclusão\n\n${estrutura.conclusao}\n\n`;
        }
        if (estrutura.cta) {
          md += `---\n\n### 📢 ${estrutura.cta.texto}\n\n[👉 Clique aqui para Acessar Agora](${estrutura.cta.destino || "#"})\n\n`;
        }
        break;

      case "pagina_pilar":
        md += `# Página Pilar: ${estrutura.tema_principal || titulo}\n\n`;
        if (estrutura.resumo_autoridade) {
          md += `## Resumo de Autoridade\n\n${estrutura.resumo_autoridade}\n\n`;
        }
        md += `## Módulos de Silagem\n\n`;
        if (estrutura.modulos && Array.isArray(estrutura.modulos)) {
          estrutura.modulos.forEach((mod: any, idx: number) => {
            md += `### ${idx + 1}. ${mod.titulo_modulo}\n\n`;
            md += `${mod.descricao}\n\n`;
            if (mod.links_satelite_sugeridos && Array.isArray(mod.links_satelite_sugeridos)) {
              md += `*Artigos satélites sugeridos para este silo:*\n`;
              mod.links_satelite_sugeridos.forEach((link: string) => {
                md += `- [${link}](/${link})\n`;
              });
              md += `\n`;
            }
          });
        }
        break;

      case "faq":
        md += `# Perguntas Frequentes (FAQ) — ${titulo}\n\n`;
        if (estrutura.perguntas && Array.isArray(estrutura.perguntas)) {
          estrutura.perguntas.forEach((faq: any, idx: number) => {
            md += `### Q: ${faq.pergunta}\n\n`;
            md += `**A:** ${faq.resposta}\n\n`;
          });
        }
        break;

      case "landing":
        md += `# Landing Page: ${estrutura.hero_titulo || titulo}\n\n`;
        if (estrutura.hero_subtitulo) {
          md += `### *${estrutura.hero_subtitulo}*\n\n`;
        }
        md += `## Benefícios e Entregas\n\n`;
        if (estrutura.beneficios && Array.isArray(estrutura.beneficios)) {
          estrutura.beneficios.forEach((ben: string) => {
            md += `- ✅ ${ben}\n`;
          });
          md += `\n`;
        }
        if (estrutura.prova_social) {
          md += `> "${estrutura.prova_social.depoimento}"\n`;
          md += `> \n`;
          md += `> — *${estrutura.prova_social.autor}, ${estrutura.prova_social.cargo}*\n\n`;
        }
        md += `[🚀 **${estrutura.cta_botao || "Começar Agora"}**](#leads)\n\n`;
        break;

      case "quiz":
        md += `# Quiz: ${estrutura.titulo_quiz || titulo}\n\n`;
        if (estrutura.questoes && Array.isArray(estrutura.questoes)) {
          estrutura.questoes.forEach((q: any, idx: number) => {
            md += `### ${idx + 1}. ${q.pergunta}\n\n`;
            if (q.opcoes && Array.isArray(q.opcoes)) {
              q.opcoes.forEach((op: string, oIdx: number) => {
                const marker = oIdx === q.gabarito_index ? "[x] (Correta)" : "[ ]";
                md += `- ${marker} ${op}\n`;
              });
            }
            md += `\n`;
            if (q.feedback) {
              md += `> **Explicação:** ${q.feedback}\n\n`;
            }
          });
        }
        break;

      case "checklist":
        md += `# Checklist: ${estrutura.nome_lista || titulo}\n\n`;
        if (estrutura.fases && Array.isArray(estrutura.fases)) {
          estrutura.fases.forEach((fase: any) => {
            md += `## Fase: ${fase.fase_nome}\n\n`;
            if (fase.itens && Array.isArray(fase.itens)) {
              fase.itens.forEach((it: any) => {
                md += `- [ ] **${it.tarefa}** *(Importância: ${it.importancia || "media"})*\n`;
                if (it.dica_de_execucao) {
                  md += `  *Dica:* ${it.dica_de_execucao}\n`;
                }
              });
              md += `\n`;
            }
          });
        }
        break;

      case "glossario":
        md += `# Glossário Explicativo — ${titulo}\n\n`;
        if (estrutura.termos && Array.isArray(estrutura.termos)) {
          estrutura.termos.forEach((term: any) => {
            md += `## [${term.letra || "A"}] ${term.termo}\n\n`;
            md += `**Definição:** ${term.significado}\n\n`;
            if (term.contexto_uso) {
              md += `*Contexto recomendado para Concursos:* ${term.contexto_uso}\n\n`;
            }
          });
        }
        break;

      case "simulado":
        md += `# Simulado de Concurso: ${titulo}\n\n`;
        if (estrutura.edital_referencia) {
          md += `*Edital de Referência:* **${estrutura.edital_referencia}**\n\n`;
        }
        if (estrutura.questoes && Array.isArray(estrutura.questoes)) {
          estrutura.questoes.forEach((q: any, idx: number) => {
            md += `### Questão ${idx + 1}\n\n`;
            md += `${q.enunciado}\n\n`;
            if (q.opcoes && typeof q.opcoes === "object") {
              Object.entries(q.opcoes).forEach(([letra, texto]) => {
                md += `- **${letra})** ${texto}\n`;
              });
            }
            md += `\n`;
            if (q.explicacao) {
              md += `<details>\n<summary>🔍 Ver Gabarito e Explicação</summary>\n\n`;
              md += `**Gabarito Oficial:** **${q.gabarito}**\n\n`;
              md += `${q.explicacao}\n`;
              md += `</details>\n\n`;
            }
          });
        }
        break;

      default:
        md += `# ${titulo}\n\n`;
        md += `\`\`\`json\n${JSON.stringify(estrutura, null, 2)}\n\`\`\`\n`;
        break;
    }

    return md;
  }
}
