import { Asset } from "../../assets/types/asset-types";

export class JSONRenderer {
  static render(asset: Asset): string {
    return JSON.stringify({
      informacao_sistema: {
        plataforma: "Organic Traffic OS",
        sprint: 24,
        foco_pedagogico: "PassaCumaru"
      },
      ativo: {
        id: asset.id,
        content_id: asset.content_id,
        tipo: asset.tipo,
        titulo: asset.titulo,
        versao: asset.versao,
        atualizado_em: asset.atualizado_em,
        estrutura: asset.estrutura
      }
    }, null, 2);
  }
}
