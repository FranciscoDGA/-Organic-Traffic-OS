import * as fs from "fs";
import * as path from "path";
import { VisibilityEngine, VisibilityReport } from "./visibility-engine";

export interface FullVisibilityReport extends VisibilityReport {
  original_title: string;
  original_content: string;
}

export class VisibilityService {
  private static reportsFilePath = path.join(
    process.cwd(),
    "organic-traffic-os/visibility/reports/visibility-report.json"
  );

  /**
   * Executa a otimização de visibilidade, salva o laudo no arquivo JSON e retorna o laudo gerado.
   */
  public static async optimize(
    draftId: string,
    title: string,
    content: string,
    briefContext?: string,
    blueprintContext?: string,
    strategyContext?: string,
    factsContext?: string,
    sourcesContext?: string
  ): Promise<FullVisibilityReport> {
    // Chamar o motor de inteligência/heurísticas
    const baseReport = await VisibilityEngine.optimize(
      draftId,
      title,
      content,
      briefContext,
      blueprintContext,
      strategyContext,
      factsContext,
      sourcesContext
    );

    const fullReport: FullVisibilityReport = {
      ...baseReport,
      original_title: title,
      original_content: content,
    };

    // Salvar no arquivo de histórico de laudos
    try {
      let reports: FullVisibilityReport[] = [];
      if (fs.existsSync(this.reportsFilePath)) {
        const raw = fs.readFileSync(this.reportsFilePath, "utf-8");
        reports = JSON.parse(raw || "[]");
      }

      // Remover duplicatas antigas do mesmo draft se houver, ou manter histórico.
      // Vamos adicionar ao início para que os mais novos apareçam primeiro.
      reports.unshift(fullReport);

      fs.writeFileSync(this.reportsFilePath, JSON.stringify(reports, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar relatório de visibilidade:", e);
    }

    return fullReport;
  }

  /**
   * Retorna todo o histórico de relatórios cadastrados.
   */
  public static getReports(): FullVisibilityReport[] {
    try {
      if (fs.existsSync(this.reportsFilePath)) {
        const raw = fs.readFileSync(this.reportsFilePath, "utf-8");
        return JSON.parse(raw || "[]");
      }
    } catch (e) {
      console.error("Erro ao ler relatórios de visibilidade:", e);
    }
    return [];
  }

  /**
   * Busca um relatório por id específico.
   */
  public static getReportById(reportId: string): FullVisibilityReport | null {
    const reports = this.getReports();
    return reports.find(r => r.id === reportId) || null;
  }

  /**
   * Compara a versão original com a versão otimizada de um determinado relatório.
   */
  public static compare(reportId: string) {
    const report = this.getReportById(reportId);
    if (!report) {
      throw new Error(`Relatório com ID ${reportId} não encontrado.`);
    }

    return {
      id: report.id,
      draft_id: report.draft_id,
      original: {
        title: report.original_title,
        content: report.original_content,
      },
      optimized: {
        title: report.optimized_title,
        content: report.optimized_content,
        meta_title: report.meta_title,
        meta_description: report.meta_description,
        slug: report.slug,
        schema_json_ld: report.schema_json_ld,
      },
      scores: {
        seo: report.seo_score,
        ai: report.ai_visibility_score,
        schema: report.schema_score,
        snippet: report.snippet_score,
        overall: report.overall_score,
      },
    };
  }
}
