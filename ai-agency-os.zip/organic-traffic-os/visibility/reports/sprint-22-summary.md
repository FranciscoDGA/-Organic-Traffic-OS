# Sprint 22 — Visibility Optimization Engine V1

## Objetivo do Motor
O **Visibility Optimization Engine V1** (Sprint 22) é responsável por receber os rascunhos de artigos já refinados pelo *Natural Language Engine* e otimizá-los não só para mecanismos de pesquisa tradicionais (como Google e Bing), mas principalmente para a era de descobertas e citações assistidas por IA (**AI Overviews**, **ChatGPT**, **Claude**, **Gemini**, **Perplexity** e **Copilot**).

Seu objetivo é maximizar as taxas de citação, indexabilidade, escaneabilidade conceitual e relevância, garantindo a permanência intacta dos fatos e da intenção de busca.

---

## Arquitetura e Estrutura de Arquivos

O ecossistema do Visibility Optimization está estruturado sob `/organic-traffic-os/visibility/`:

```bash
organic-traffic-os/visibility/
├── engine/
│   ├── visibility-engine.ts       # Motor de otimização estrutural e textual via Gemini/Fallback local
│   └── visibility-service.ts      # Orquestrador de relatórios de visibilidade, histórico e persistência
├── seo/
│   └── seo-rules.json             # Regras de indexação tradicional, Metas, Slug, Canonical e Headings
├── ai/
│   └── ai-visibility-rules.json   # Regras de legibilidade de IA (parágrafos curtos, perguntas explícitas)
├── schema/
│   └── schema-rules.json          # Mapeamento e guias de geração JSON-LD estruturado
├── snippets/
│   └── snippet-rules.json         # Diretrizes de otimização de snippets (People Also Ask, AI Summaries)
├── metadata/                      # Configurações de integração e metatags
├── reports/
│   ├── visibility-report.json     # Banco de laudos de visibilidade gerados
│   └── sprint-22-summary.md       # Esta documentação da Sprint 22
└── validators/
    └── visibility-validator.ts    # Validador de integridade e conformidade de visibilidade (SEO & IA)
```

---

## Estratégia de Otimização Multicanal

### 1. SEO Tradicional (`seo/seo-rules.json`)
Foco nos rastreadores clássicos e indexação hierárquica estável:
- **Heading Hierarchy**: Garantia de `H1` único contendo a palavra-chave e ordenação perfeita de subtópicos (`H2` e `H3`).
- **Metatags Persuasivas**: Meta Title limitado de 50-60 caracteres e Meta Description de 140-160 caracteres contendo chamada de clique.
- **Slug Otimizado**: Slugs simples, minúsculos, sem acentos, com foco na palavra-chave.
- **Open Graph / Twitter Cards**: Metadados estruturados para visualização de links em redes sociais de forma enriquecida.

### 2. AI Visibility (`ai-visibility-rules.json`)
Preparação do conteúdo para leitura, fragmentação e recomendação por LLMs:
- **Questions & Answers**: Inserção de perguntas explícitas de alta frequência de pesquisa, respondidas em até 3 linhas logo abaixo.
- **Micro-parágrafos**: Divisão do texto em blocos de até 4 linhas para facilitar a tokenização e extração de parágrafos pelos summarizers de IA.
- **Entities & Concepts**: Nomes claros e links contextualizados para ajudar o LLM a mapear as entidades no Grafo de Conhecimento.

### 3. Schema Markup (`schema/schema-rules.json`)
Inserção de código JSON-LD estruturado e válido semanticamente:
- **FAQPage**: Para expor as seções de perguntas e respostas nativamente na SERP do Google.
- **Article**: Detalhes do autor, data, marca PassaCumaru e editora.
- **LocalBusiness / Organization / Breadcrumb**: Quando aplicável, contextualiza a localização regional.

### 4. Snippet Dominance (`snippets/snippet-rules.json`)
Modelagem especial de blocos de informação para:
- **Featured Snippets**: Resumos e listas sequenciais prontas para extração.
- **People Also Ask (PAA)**: Respostas objetivas para interrogações comuns do público.
- **AI Summaries**: Boletins condensados ao fim do texto para servir de base direta aos assistentes virtuais.

---

## Salvaguarda Editorial (Preservação Absoluta)

O motor opera sob limites invioláveis:
1. **Fatos Sagrados**: Dados numéricos, datas de concursos, prazos de pagamento de IPTU, e nomes de editais são checados pelo `VisibilityValidator` e não podem ser alterados ou omitidos.
2. **Estratégia Mantida**: A palavra-chave e foco de nicho do briefing permanecem intocados.
3. **CTA Intacta**: Links de destino e chamadas de fechamento permanecem 100% idênticos.

---

## Como Utilizar (Endpoints API)

- **POST `/api/organic-os/visibility/optimize`**: Recebe o ID do rascunho refinado e gera uma versão otimizada com um laudo de visibilidade e metadados.
- **GET `/api/organic-os/visibility/reports`**: Retorna a lista histórica de laudos estruturados.
- **POST `/api/organic-os/visibility/compare`**: Permite comparar detalhadamente a versão original com a otimizada.
