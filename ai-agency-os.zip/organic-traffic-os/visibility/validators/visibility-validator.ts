export interface VisibilityValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  details: {
    seoValid: boolean;
    aiValid: boolean;
    schemaValid: boolean;
    metadataValid: boolean;
    linksValid: boolean;
    entitiesValid: boolean;
    factsPreserved: boolean;
    ctaMaintained: boolean;
    sectionsIntact: boolean;
  };
}

export class VisibilityValidator {
  /**
   * Realiza a validação estrita do texto otimizado para visibilidade em relação ao original,
   * garantindo conformidade com regras de SEO, IA, schemas, metadados e salvaguarda editorial.
   */
  public static validate(
    originalText: string,
    optimizedText: string,
    metadata?: {
      title?: string;
      meta_title?: string;
      meta_description?: string;
      slug?: string;
      schema_json_ld?: string;
    }
  ): VisibilityValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!originalText || originalText.trim().length < 10) {
      errors.push("Texto de entrada inválido ou muito curto para validação.");
    }
    if (!optimizedText || optimizedText.trim().length < 10) {
      errors.push("Texto otimizado de saída inválido ou vazio.");
    }

    // 1. Salvaguarda Editorial: Preservação de Fatos (Números)
    const originalNumbers = (originalText.match(/\d+([.,]\d+)*/g) || []) as string[];
    const optimizedNumbers = (optimizedText.match(/\d+([.,]\d+)*/g) || []) as string[];

    const missingNumbers = originalNumbers.filter(num => !optimizedNumbers.includes(num));
    const uniqueMissingNumbers = Array.from(new Set(missingNumbers));

    let factsPreserved = true;
    if (uniqueMissingNumbers.length > 0) {
      warnings.push(`Fatos numéricos potencialmente alterados. Números ausentes na versão otimizada: ${uniqueMissingNumbers.join(", ")}`);
      if (uniqueMissingNumbers.length > 3) {
        factsPreserved = false;
        errors.push("Violação crítica de integridade de fatos: Muitos dados numéricos ou estatísticas originais sumiram.");
      }
    }

    // 2. Salvaguarda Editorial: CTA e Links Importantes
    const originalCTATerms = ["cta", "chamada para ação", "inscreva-se", "acesse", "cadastre", "clique"];
    const originalHasCTA = originalCTATerms.some(term => originalText.toLowerCase().includes(term));
    const optimizedHasCTA = originalCTATerms.some(term => optimizedText.toLowerCase().includes(term));

    let ctaMaintained = true;
    if (originalHasCTA && !optimizedHasCTA) {
      ctaMaintained = false;
      warnings.push("O CTA (Call to Action) original do rascunho pode ter sido removido ou enfraquecido na versão otimizada.");
    }

    // 3. Salvaguarda Editorial: Preservação de Seções e Estrutura de H2/H3
    const originalH2s = (originalText.match(/^##\s+.+$/gm) || []).map(h => h.replace(/^##\s+/, "").trim().toLowerCase());
    const optimizedH2s = (optimizedText.match(/^##\s+.+$/gm) || []).map(h => h.replace(/^##\s+/, "").trim().toLowerCase());

    // Se seções inteiras sumirem
    const missingH2s = originalH2s.filter(oh => !optimizedH2s.some(th => th.includes(oh) || oh.includes(th)));
    let sectionsIntact = true;
    if (missingH2s.length > 0) {
      warnings.push(`Alguns subtópicos originais sofreram alteração drástica de nomenclatura ou sumiram: ${missingH2s.join(", ")}`);
      if (missingH2s.length > 2) {
        sectionsIntact = false;
        errors.push("Violação de estrutura: Seções essenciais do texto original foram removidas.");
      }
    }

    // 4. SEO Validation
    let seoValid = true;
    if (metadata) {
      if (metadata.meta_title) {
        const titleLen = metadata.meta_title.length;
        if (titleLen < 30 || titleLen > 70) {
          warnings.push(`SEO: O Meta Title otimizado possui tamanho fora do recomendado (recomendado: 40-65 caracteres, atual: ${titleLen} caracteres).`);
        }
      } else {
        warnings.push("SEO: Meta Title ausente nos metadados de visibilidade.");
      }

      if (metadata.meta_description) {
        const descLen = metadata.meta_description.length;
        if (descLen < 110 || descLen > 180) {
          warnings.push(`SEO: A Meta Description otimizada possui tamanho fora do recomendado (recomendado: 140-160 caracteres, atual: ${descLen} caracteres).`);
        }
      } else {
        warnings.push("SEO: Meta Description ausente nos metadados de visibilidade.");
      }

      if (metadata.slug) {
        const slugPattern = /^[a-z0-9-]+$/;
        if (!slugPattern.test(metadata.slug)) {
          seoValid = false;
          errors.push(`SEO: O slug gerado ("${metadata.slug}") é inválido. Deve conter apenas minúsculas, números e hifens.`);
        }
      } else {
        seoValid = false;
        errors.push("SEO: O slug amigável da página é obrigatório e está ausente.");
      }
    }

    // 5. AI Validation
    // AI Visibility valoriza perguntas explícitas e parágrafos curtos
    let aiValid = true;
    const questions = optimizedText.match(/\?(\s|$)/g) || [];
    if (questions.length < 1) {
      warnings.push("AI Visibility: O texto otimizado não possui perguntas explícitas marcadas com interrogação, reduzindo chances de People Also Ask e IA.");
    }

    // Parágrafos muito longos (>150 palavras) são ruins para leitores e IA
    const paragraphs = optimizedText.split(/\n+/).filter(p => p.trim().length > 40 && !p.trim().startsWith("#"));
    const longParagraphs = paragraphs.filter(p => p.split(/\s+/).length > 150);
    if (longParagraphs.length > 1) {
      warnings.push(`AI Visibility: Há ${longParagraphs.length} parágrafos longos (>150 palavras). Parágrafos mais curtos facilitam o consumo por LLMs.`);
    }

    // 6. Schema JSON-LD Validation
    let schemaValid = true;
    if (metadata && metadata.schema_json_ld) {
      try {
        const parsed = JSON.parse(metadata.schema_json_ld);
        if (!parsed["@context"] || !parsed["@type"]) {
          schemaValid = false;
          errors.push("Schema: O bloco JSON-LD não possui campos obrigatórios como '@context' ou '@type'.");
        }
      } catch (e) {
        schemaValid = false;
        errors.push("Schema: O bloco de marcação estruturada JSON-LD gerado possui sintaxe JSON inválida.");
      }
    } else {
      warnings.push("Schema: Nenhum bloco de marcação JSON-LD gerado para este conteúdo.");
    }

    // 7. Metadata (Open Graph e Twitter Cards)
    let metadataValid = true;
    const hasOG = optimizedText.toLowerCase().includes("og:title") || optimizedText.toLowerCase().includes("property=\"og:") || (metadata && metadata.meta_title);
    if (!hasOG) {
      metadataValid = false;
      warnings.push("Metadados: Tags de Open Graph não configuradas.");
    }

    // 8. Links Verification
    let linksValid = true;
    // Verificar se links externos e termos como 'https://' estão presentes
    const hasLinks = optimizedText.includes("http://") || optimizedText.includes("https://") || optimizedText.includes("](") || originalText.includes("http://") || originalText.includes("https://");
    if (!hasLinks) {
      warnings.push("Links: O texto não possui links internos ou externos, o que limita a transferência de autoridade de página.");
    }

    // 9. Entidades Verification
    let entitiesValid = true;
    // Checa se termos chaves ou marcas originais se mantiveram
    const originalTitleWords = (metadata?.title || "").split(/\s+/).filter(w => w.length > 4);
    const missingTitleWords = originalTitleWords.filter(w => !optimizedText.toLowerCase().includes(w.toLowerCase()));
    if (missingTitleWords.length > 2) {
      entitiesValid = false;
      warnings.push(`Entidades: Algumas palavras chaves do título original parecem ausentes no corpo do texto: ${missingTitleWords.join(", ")}`);
    }

    const valid = errors.length === 0;

    return {
      valid,
      errors,
      warnings,
      details: {
        seoValid,
        aiValid,
        schemaValid,
        metadataValid,
        linksValid,
        entitiesValid,
        factsPreserved,
        ctaMaintained,
        sectionsIntact
      }
    };
  }
}
