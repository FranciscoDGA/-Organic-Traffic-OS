import fs from "fs";
import path from "path";

export interface Keyword {
  id: string;
  keyword: string;
  idioma: string;
  categoria: string;
  cluster: string;
  entidade: string;
  status: "mapeado" | "planejado" | "em_andamento" | "publicado" | string;
}

export interface KeywordIntent {
  keywordId: string;
  intencao: "Informacional" | "Comercial" | "Transacional" | "Local" | "Navegacional" | "Educacional" | string;
  observacoes: string;
}

export interface KeywordPriority {
  keywordId: string;
  impacto: number; // 1-10
  esforco: number; // 1-10
  potencial: number; // 1-10
  urgencia: number; // 1-10
  competicao: number; // 1-10
  valorEstrategico: number; // 1-10
  pontuacaoFinal: number; // Calculated
}

export interface Cluster {
  id: string;
  nome: string;
  descrição: string;
  categoria: string;
  palavraPrincipal: string;
  palavrasSecundárias: string[];
  objetivo: string;
  status: "ativo" | "planejado" | "pausado" | string;
}

export interface Entity {
  id: string;
  nome: string;
  categoria: "Prefeituras" | "Bancas" | "Cidades" | "Estados" | "Leis" | "Órgãos" | "Disciplinas" | "Concursos" | "Instituições" | string;
  aliases: string[];
  descricao: string;
}

export interface Question {
  id: string;
  keywordId?: string;
  pergunta: string;
  categoria: string;
  respostaSugestao: string;
}

export interface Longtail {
  id: string;
  keywordId: string;
  keyword: string;
  volumeEstimado: number;
  dificuldade: number;
}

export interface Opportunity {
  id: string;
  tema: string;
  prioridade: "Baixa" | "Média" | "Alta" | "Crítica" | string;
  cluster: string;
  motivo: string;
  potencial: "Baixo" | "Médio" | "Alto" | "Explosivo" | string;
  status: "Planejado" | "Em andamento" | "Publicado" | string;
}

const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "keywords");

// Ensure base dir exists
function ensureDir() {
  if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true });
  }
}

// Helper to read JSON safely
function readJsonFile<T>(filename: string): T[] {
  ensureDir();
  const filePath = path.join(baseDir, filename);
  if (!fs.existsSync(filePath)) {
    return [];
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch (err) {
    console.error(`Error reading ${filename}:`, err);
    return [];
  }
}

// Helper to write JSON safely
function writeJsonFile<T>(filename: string, data: T[]) {
  ensureDir();
  const filePath = path.join(baseDir, filename);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error(`Error writing ${filename}:`, err);
  }
}

/**
 * Calculates priority score out of 10.
 * A high priority keyword has high impact, high potential, high strategic value, high urgency,
 * combined with low effort and low organic competition.
 */
export function calculatePriorityScore(p: Omit<KeywordPriority, "pontuacaoFinal">): number {
  const benefit = (p.impacto * 1.5) + (p.potencial * 1.5) + (p.valorEstrategico * 2.0) + p.urgencia;
  const cost = (p.esforco * 0.8) + (p.competicao * 0.7);
  // Max possible benefit: 9 * 1.5 + 9 * 1.5 + 9 * 2.0 + 9 = 54 + 9 = 63.
  // We offset and scale to get a beautiful, realistic 1-10 range
  let score = (benefit - cost) / 5;
  if (score > 10) score = 10;
  if (score < 1) score = 1;
  return Number(score.toFixed(1));
}

/**
 * Registers a new keyword alongside its intent and priority
 */
export function registerKeyword(
  kw: Omit<Keyword, "id">,
  intent: Omit<KeywordIntent, "keywordId">,
  priority: Omit<KeywordPriority, "keywordId" | "pontuacaoFinal">
): { keyword: Keyword; intent: KeywordIntent; priority: KeywordPriority } {
  const keywords = readJsonFile<Keyword>("keyword.json");
  const intents = readJsonFile<KeywordIntent>("keyword-intent.json");
  const priorities = readJsonFile<KeywordPriority>("keyword-priority.json");

  const newId = `kw-${Date.now()}`;

  const newKeyword: Keyword = {
    id: newId,
    keyword: kw.keyword.trim(),
    idioma: kw.idioma || "pt-BR",
    categoria: kw.categoria || "Geral",
    cluster: kw.cluster || "Sem Cluster",
    entidade: kw.entidade || "Sem Entidade",
    status: kw.status || "mapeado"
  };

  const newIntent: KeywordIntent = {
    keywordId: newId,
    intencao: intent.intencao || "Informacional",
    observacoes: intent.observacoes || ""
  };

  const finalScore = calculatePriorityScore({
    keywordId: newId,
    ...priority
  });

  const newPriority: KeywordPriority = {
    keywordId: newId,
    ...priority,
    pontuacaoFinal: finalScore
  };

  keywords.push(newKeyword);
  intents.push(newIntent);
  priorities.push(newPriority);

  writeJsonFile("keyword.json", keywords);
  writeJsonFile("keyword-intent.json", intents);
  writeJsonFile("keyword-priority.json", priorities);

  return {
    keyword: newKeyword,
    intent: newIntent,
    priority: newPriority
  };
}

/**
 * Registers or updates a Cluster
 */
export function registerCluster(cl: Omit<Cluster, "id"> & { id?: string }): Cluster {
  const clusters = readJsonFile<Cluster>("clusters.json");
  let resolvedCluster: Cluster;

  if (cl.id) {
    const idx = clusters.findIndex(c => c.id === cl.id);
    if (idx !== -1) {
      resolvedCluster = {
        ...clusters[idx],
        nome: cl.nome,
        descrição: cl.descrição,
        categoria: cl.categoria,
        palavraPrincipal: cl.palavraPrincipal,
        palavrasSecundárias: cl.palavrasSecundárias || [],
        objetivo: cl.objetivo,
        status: cl.status
      };
      clusters[idx] = resolvedCluster;
    } else {
      resolvedCluster = { id: cl.id, ...cl } as Cluster;
      clusters.push(resolvedCluster);
    }
  } else {
    const newId = `cl-${Date.now()}`;
    resolvedCluster = {
      id: newId,
      nome: cl.nome,
      descrição: cl.descrição,
      categoria: cl.categoria,
      palavraPrincipal: cl.palavraPrincipal,
      palavrasSecundárias: cl.palavrasSecundárias || [],
      objetivo: cl.objetivo,
      status: cl.status || "planejado"
    };
    clusters.push(resolvedCluster);
  }

  writeJsonFile("clusters.json", clusters);
  return resolvedCluster;
}

/**
 * Registers or updates an Entity
 */
export function registerEntity(ent: Omit<Entity, "id"> & { id?: string }): Entity {
  const entities = readJsonFile<Entity>("entities.json");
  let resolvedEntity: Entity;

  if (ent.id) {
    const idx = entities.findIndex(e => e.id === ent.id);
    if (idx !== -1) {
      resolvedEntity = {
        ...entities[idx],
        nome: ent.nome,
        categoria: ent.categoria,
        aliases: ent.aliases || [],
        descricao: ent.descricao
      };
      entities[idx] = resolvedEntity;
    } else {
      resolvedEntity = { id: ent.id, ...ent } as Entity;
      entities.push(resolvedEntity);
    }
  } else {
    const newId = `ent-${Date.now()}`;
    resolvedEntity = {
      id: newId,
      nome: ent.nome,
      categoria: ent.categoria,
      aliases: ent.aliases || [],
      descricao: ent.descricao
    };
    entities.push(resolvedEntity);
  }

  writeJsonFile("entities.json", entities);
  return resolvedEntity;
}

/**
 * Registers a new Question
 */
export function registerQuestion(q: Omit<Question, "id">): Question {
  const questions = readJsonFile<Question>("questions.json");
  const newId = `q-${Date.now()}`;

  const newQuestion: Question = {
    id: newId,
    keywordId: q.keywordId,
    pergunta: q.pergunta.trim(),
    categoria: q.categoria || "Geral",
    respostaSugestao: q.respostaSugestao || ""
  };

  questions.push(newQuestion);
  writeJsonFile("questions.json", questions);
  return newQuestion;
}

/**
 * Registers a new Longtail variation
 */
export function registerLongtail(lt: Omit<Longtail, "id">): Longtail {
  const longtails = readJsonFile<Longtail>("longtails.json");
  const newId = `lt-${Date.now()}`;

  const newLongtail: Longtail = {
    id: newId,
    keywordId: lt.keywordId,
    keyword: lt.keyword.trim(),
    volumeEstimado: lt.volumeEstimado || 0,
    dificuldade: lt.dificuldade || 0
  };

  longtails.push(newLongtail);
  writeJsonFile("longtails.json", longtails);
  return newLongtail;
}

/**
 * Registers editorial opportunity
 */
export function registerOpportunity(op: Omit<Opportunity, "id">): Opportunity {
  const opportunities = readJsonFile<Opportunity>("opportunities.json");
  const newId = `op-${Date.now()}`;

  const newOp: Opportunity = {
    id: newId,
    tema: op.tema.trim(),
    prioridade: op.prioridade || "Média",
    cluster: op.cluster || "Sem Cluster",
    motivo: op.motivo || "",
    potencial: op.potencial || "Médio",
    status: op.status || "Planejado"
  };

  opportunities.push(newOp);
  writeJsonFile("opportunities.json", opportunities);
  return newOp;
}
