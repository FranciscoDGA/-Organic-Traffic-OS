import fs from "fs";
import path from "path";
import { validateKeywordsData, KeywordValidationResult } from "./keyword-validator";

export interface ConsolidatedKeywordData {
  keywords: any[];
  intents: any[];
  priorities: any[];
  clusters: any[];
  entities: any[];
  questions: any[];
  longtails: any[];
  opportunities: any[];
  metadata: {
    totalKeywords: number;
    totalClusters: number;
    totalEntities: number;
    totalQuestions: number;
    totalLongtails: number;
    totalOpportunities: number;
    intentDistribution: Record<string, number>;
    statusCounts: Record<string, number>;
    priorityAverages: {
      impacto: number;
      esforco: number;
      potencial: number;
      urgencia: number;
      competicao: number;
      valorEstrategico: number;
      pontuacaoFinal: number;
    };
    entityCategoryCounts: Record<string, number>;
    validation: KeywordValidationResult;
    lastUpdated: string;
  };
}

export function loadKeywordsData(): ConsolidatedKeywordData {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "keywords");

  const files = {
    keywords: "keyword.json",
    intents: "keyword-intent.json",
    priorities: "keyword-priority.json",
    clusters: "clusters.json",
    entities: "entities.json",
    questions: "questions.json",
    longtails: "longtails.json",
    opportunities: "opportunities.json"
  };

  let keywords: any[] = [];
  let intents: any[] = [];
  let priorities: any[] = [];
  let clusters: any[] = [];
  let entities: any[] = [];
  let questions: any[] = [];
  let longtails: any[] = [];
  let opportunities: any[] = [];

  const readJson = (filename: string): any[] => {
    const filePath = path.join(baseDir, filename);
    if (fs.existsSync(filePath)) {
      try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
      } catch (err) {
        console.error(`Error reading or parsing ${filename}:`, err);
      }
    }
    return [];
  };

  keywords = readJson(files.keywords);
  intents = readJson(files.intents);
  priorities = readJson(files.priorities);
  clusters = readJson(files.clusters);
  entities = readJson(files.entities);
  questions = readJson(files.questions);
  longtails = readJson(files.longtails);
  opportunities = readJson(files.opportunities);

  // Run validation
  const validation = validateKeywordsData();

  // Aggregate Metrics
  const intentDistribution: Record<string, number> = {
    "Informacional": 0,
    "Comercial": 0,
    "Transacional": 0,
    "Local": 0,
    "Navegacional": 0,
    "Educacional": 0
  };

  intents.forEach((item: any) => {
    if (item.intencao) {
      intentDistribution[item.intencao] = (intentDistribution[item.intencao] || 0) + 1;
    }
  });

  const statusCounts: Record<string, number> = {};
  keywords.forEach((kw: any) => {
    if (kw.status) {
      statusCounts[kw.status] = (statusCounts[kw.status] || 0) + 1;
    }
  });

  // Calculate average priorities
  let sumImpacto = 0;
  let sumEsforco = 0;
  let sumPotencial = 0;
  let sumUrgencia = 0;
  let sumCompeticao = 0;
  let sumValorEstrategico = 0;
  let sumPontuacaoFinal = 0;
  const pCount = priorities.length;

  priorities.forEach((p: any) => {
    sumImpacto += p.impacto || 0;
    sumEsforco += p.esforco || 0;
    sumPotencial += p.potencial || 0;
    sumUrgencia += p.urgencia || 0;
    sumCompeticao += p.competicao || 0;
    sumValorEstrategico += p.valorEstrategico || 0;
    sumPontuacaoFinal += p.pontuacaoFinal || 0;
  });

  const priorityAverages = {
    impacto: pCount > 0 ? Number((sumImpacto / pCount).toFixed(1)) : 0,
    esforco: pCount > 0 ? Number((sumEsforco / pCount).toFixed(1)) : 0,
    potencial: pCount > 0 ? Number((sumPotencial / pCount).toFixed(1)) : 0,
    urgencia: pCount > 0 ? Number((sumUrgencia / pCount).toFixed(1)) : 0,
    competicao: pCount > 0 ? Number((sumCompeticao / pCount).toFixed(1)) : 0,
    valorEstrategico: pCount > 0 ? Number((sumValorEstrategico / pCount).toFixed(1)) : 0,
    pontuacaoFinal: pCount > 0 ? Number((sumPontuacaoFinal / pCount).toFixed(1)) : 0
  };

  const entityCategoryCounts: Record<string, number> = {};
  entities.forEach((ent: any) => {
    if (ent.categoria) {
      entityCategoryCounts[ent.categoria] = (entityCategoryCounts[ent.categoria] || 0) + 1;
    }
  });

  return {
    keywords,
    intents,
    priorities,
    clusters,
    entities,
    questions,
    longtails,
    opportunities,
    metadata: {
      totalKeywords: keywords.length,
      totalClusters: clusters.length,
      totalEntities: entities.length,
      totalQuestions: questions.length,
      totalLongtails: longtails.length,
      totalOpportunities: opportunities.length,
      intentDistribution,
      statusCounts,
      priorityAverages,
      entityCategoryCounts,
      validation,
      lastUpdated: new Date().toISOString()
    }
  };
}
