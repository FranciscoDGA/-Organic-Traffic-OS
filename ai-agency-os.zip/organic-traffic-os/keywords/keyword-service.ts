import { loadKeywordsData, ConsolidatedKeywordData } from "./keyword-loader";

export class KeywordService {
  private static cachedData: ConsolidatedKeywordData | null = null;
  private static lastCacheTime: number = 0;
  private static CACHE_DURATION = 5000; // 5 seconds cache

  private static getData(): ConsolidatedKeywordData {
    const now = Date.now();
    if (!this.cachedData || now - this.lastCacheTime > this.CACHE_DURATION) {
      this.cachedData = loadKeywordsData();
      this.lastCacheTime = now;
    }
    return this.cachedData;
  }

  /**
   * Clears the cache to force a reload
   */
  public static clearCache() {
    this.cachedData = null;
    this.lastCacheTime = 0;
  }

  /**
   * Search and filter keywords
   */
  public static searchKeywords(query?: string, cluster?: string, entity?: string, status?: string): any[] {
    const data = this.getData();
    let result = data.keywords.map(kw => {
      const intent = data.intents.find(i => i.keywordId === kw.id);
      const priority = data.priorities.find(p => p.keywordId === kw.id);
      const longtails = data.longtails.filter(lt => lt.keywordId === kw.id);
      const questions = data.questions.filter(q => q.keywordId === kw.id);

      return {
        ...kw,
        intencao: intent ? intent.intencao : "Não definida",
        observacoes: intent ? intent.observacoes : "",
        prioridade: priority || {
          impacto: 0,
          esforco: 0,
          potencial: 0,
          urgencia: 0,
          competicao: 0,
          valorEstrategico: 0,
          pontuacaoFinal: 0
        },
        longtails,
        questions
      };
    });

    if (query) {
      const lowerQuery = query.toLowerCase();
      result = result.filter(r => 
        r.keyword.toLowerCase().includes(lowerQuery) || 
        r.categoria.toLowerCase().includes(lowerQuery)
      );
    }

    if (cluster) {
      result = result.filter(r => r.cluster === cluster);
    }

    if (entity) {
      result = result.filter(r => r.entidade === entity);
    }

    if (status) {
      result = result.filter(r => r.status === status);
    }

    return result;
  }

  /**
   * Find a single keyword by id
   */
  public static getKeywordById(id: string): any | null {
    const keywords = this.searchKeywords();
    return keywords.find(k => k.id === id) || null;
  }

  /**
   * Search and filter clusters
   */
  public static searchClusters(query?: string, category?: string, status?: string): any[] {
    const data = this.getData();
    let result = data.clusters.map(cl => {
      // Connect keywords belonging to this cluster
      const associatedKeywords = data.keywords.filter(k => k.cluster === cl.nome);
      return {
        ...cl,
        keywordCount: associatedKeywords.length,
        keywords: associatedKeywords
      };
    });

    if (query) {
      const lowerQuery = query.toLowerCase();
      result = result.filter(r => 
        r.nome.toLowerCase().includes(lowerQuery) || 
        r.descrição.toLowerCase().includes(lowerQuery)
      );
    }

    if (category) {
      result = result.filter(r => r.categoria === category);
    }

    if (status) {
      result = result.filter(r => r.status === status);
    }

    return result;
  }

  /**
   * Search and filter entities
   */
  public static searchEntities(query?: string, category?: string): any[] {
    const data = this.getData();
    let result = data.entities.map(ent => {
      const associatedKeywords = data.keywords.filter(k => k.entidade === ent.nome);
      return {
        ...ent,
        keywordCount: associatedKeywords.length,
        keywords: associatedKeywords
      };
    });

    if (query) {
      const lowerQuery = query.toLowerCase();
      result = result.filter(r => 
        r.nome.toLowerCase().includes(lowerQuery) || 
        r.descricao.toLowerCase().includes(lowerQuery) ||
        r.aliases.some((a: string) => a.toLowerCase().includes(lowerQuery))
      );
    }

    if (category) {
      result = result.filter(r => r.categoria === category);
    }

    return result;
  }

  /**
   * Search questions
   */
  public static searchQuestions(query?: string, category?: string): any[] {
    const data = this.getData();
    let result = data.questions.map(q => {
      const associatedKeyword = data.keywords.find(k => k.id === q.keywordId);
      return {
        ...q,
        keywordText: associatedKeyword ? associatedKeyword.keyword : null
      };
    });

    if (query) {
      const lowerQuery = query.toLowerCase();
      result = result.filter(r => 
        r.pergunta.toLowerCase().includes(lowerQuery) ||
        r.respostaSugestao.toLowerCase().includes(lowerQuery)
      );
    }

    if (category) {
      result = result.filter(r => r.categoria === category);
    }

    return result;
  }

  /**
   * Search opportunities
   */
  public static searchOpportunities(query?: string, priority?: string, status?: string): any[] {
    const data = this.getData();
    let result = [...data.opportunities];

    if (query) {
      const lowerQuery = query.toLowerCase();
      result = result.filter(r => 
        r.tema.toLowerCase().includes(lowerQuery) ||
        r.motivo.toLowerCase().includes(lowerQuery) ||
        r.cluster.toLowerCase().includes(lowerQuery)
      );
    }

    if (priority) {
      result = result.filter(r => r.prioridade === priority);
    }

    if (status) {
      result = result.filter(r => r.status === status);
    }

    return result;
  }
}
