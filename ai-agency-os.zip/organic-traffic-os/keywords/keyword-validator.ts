import fs from "fs";
import path from "path";

export interface KeywordValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export function validateKeywordsData(): KeywordValidationResult {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "keywords");
  const errors: string[] = [];
  const warnings: string[] = [];

  const files = {
    keywords: "keyword.json",
    intents: "keyword-intent.json",
    priorities: "keyword-priority.json",
    clusters: "clusters.json",
    entities: "entities.json",
    questions: "questions.json",
    longtails: "longtails.json",
    opportunities: "opportunities.json"
  };

  // Helper to validate file existence and basic structure
  const checkFile = (filename: string): any[] | null => {
    const filePath = path.join(baseDir, filename);
    if (!fs.existsSync(filePath)) {
      errors.push(`Arquivo obrigatório ausente: ${filename}`);
      return null;
    }
    try {
      const content = fs.readFileSync(filePath, "utf-8");
      const parsed = JSON.parse(content);
      if (!Array.isArray(parsed)) {
        errors.push(`Formato inválido em ${filename}: Esperado um array de objetos.`);
        return null;
      }
      return parsed;
    } catch (err: any) {
      errors.push(`Falha ao ler ou analisar JSON em ${filename}: ${err.message}`);
      return null;
    }
  };

  // 1. Validate keyword.json
  const keywords = checkFile(files.keywords);
  const keywordIds = new Set<string>();
  const keywordTexts = new Set<string>();
  if (keywords) {
    keywords.forEach((kw: any, index: number) => {
      if (!kw.id) {
        errors.push(`[keyword.json] Entrada no índice ${index} está sem o campo obrigatório 'id'.`);
      } else {
        if (keywordIds.has(kw.id)) {
          errors.push(`[keyword.json] ID duplicado encontrado: ${kw.id}`);
        }
        keywordIds.add(kw.id);
      }

      if (!kw.keyword) {
        errors.push(`[keyword.json] Entrada no índice ${index} está sem a palavra-chave ('keyword').`);
      } else {
        const lowerKw = kw.keyword.trim().toLowerCase();
        if (keywordTexts.has(lowerKw)) {
          warnings.push(`[keyword.json] Palavra-chave repetida observada: "${kw.keyword}"`);
        }
        keywordTexts.add(lowerKw);
      }

      if (!kw.status) {
        errors.push(`[keyword.json] Entrada ${kw.id || index} sem status.`);
      }
    });
  }

  // 2. Validate keyword-intent.json
  const intents = checkFile(files.intents);
  if (intents) {
    const intentKeywordIds = new Set<string>();
    const validIntents = ["Informacional", "Comercial", "Transacional", "Local", "Navegacional", "Educacional"];
    intents.forEach((item: any, index: number) => {
      if (!item.keywordId) {
        errors.push(`[keyword-intent.json] Entrada no índice ${index} sem 'keywordId'.`);
      } else {
        if (intentKeywordIds.has(item.keywordId)) {
          errors.push(`[keyword-intent.json] keywordId duplicado encontrado: ${item.keywordId}`);
        }
        intentKeywordIds.add(item.keywordId);
        if (keywords && !keywordIds.has(item.keywordId)) {
          warnings.push(`[keyword-intent.json] keywordId "${item.keywordId}" refere-se a uma palavra-chave inexistente.`);
        }
      }

      if (!item.intencao) {
        errors.push(`[keyword-intent.json] Entrada para keywordId ${item.keywordId || index} sem classificação de 'intencao'.`);
      } else if (!validIntents.includes(item.intencao)) {
        warnings.push(`[keyword-intent.json] Intenção de busca incomum ou inválida: "${item.intencao}". Válidas: ${validIntents.join(", ")}`);
      }
    });
  }

  // 3. Validate keyword-priority.json
  const priorities = checkFile(files.priorities);
  if (priorities) {
    const priorityKeywordIds = new Set<string>();
    priorities.forEach((item: any, index: number) => {
      if (!item.keywordId) {
        errors.push(`[keyword-priority.json] Entrada no índice ${index} sem 'keywordId'.`);
      } else {
        if (priorityKeywordIds.has(item.keywordId)) {
          errors.push(`[keyword-priority.json] keywordId duplicado encontrado: ${item.keywordId}`);
        }
        priorityKeywordIds.add(item.keywordId);
      }

      const numericFields = ["impacto", "esforco", "potencial", "urgencia", "competicao", "valorEstrategico"];
      numericFields.forEach(field => {
        if (typeof item[field] !== "number" || item[field] < 1 || item[field] > 10) {
          warnings.push(`[keyword-priority.json] Campo de pontuação '${field}' para ${item.keywordId || index} deve ser um número entre 1 e 10. Atual: ${item[field]}`);
        }
      });
    });
  }

  // 4. Validate clusters.json
  const clusters = checkFile(files.clusters);
  if (clusters) {
    const clusterIds = new Set<string>();
    const clusterNames = new Set<string>();
    clusters.forEach((cluster: any, index: number) => {
      if (!cluster.id) {
        errors.push(`[clusters.json] Entrada no índice ${index} sem 'id'.`);
      } else {
        if (clusterIds.has(cluster.id)) {
          errors.push(`[clusters.json] ID duplicado encontrado: ${cluster.id}`);
        }
        clusterIds.add(cluster.id);
      }

      if (!cluster.nome) {
        errors.push(`[clusters.json] Entrada no índice ${index} sem 'nome'.`);
      } else {
        if (clusterNames.has(cluster.nome)) {
          warnings.push(`[clusters.json] Nome de cluster duplicado: "${cluster.nome}"`);
        }
        clusterNames.add(cluster.nome);
      }

      if (!cluster.palavraPrincipal) {
        errors.push(`[clusters.json] Cluster "${cluster.nome || index}" sem palavra principal.`);
      }
    });
  }

  // 5. Validate entities.json
  const entities = checkFile(files.entities);
  if (entities) {
    const entityIds = new Set<string>();
    const validCategories = ["Prefeituras", "Bancas", "Cidades", "Estados", "Leis", "Órgãos", "Disciplinas", "Concursos", "Instituições"];
    entities.forEach((entity: any, index: number) => {
      if (!entity.id) {
        errors.push(`[entities.json] Entrada no índice ${index} sem 'id'.`);
      } else {
        if (entityIds.has(entity.id)) {
          errors.push(`[entities.json] ID duplicado encontrado: ${entity.id}`);
        }
        entityIds.add(entity.id);
      }

      if (!entity.nome) {
        errors.push(`[entities.json] Entrada no índice ${index} sem 'nome'.`);
      }

      if (!entity.categoria) {
        errors.push(`[entities.json] Entrada "${entity.nome || index}" sem 'categoria'.`);
      } else if (!validCategories.includes(entity.categoria)) {
        warnings.push(`[entities.json] Categoria de entidade incomum: "${entity.categoria}".`);
      }
    });
  }

  // 6. Validate questions.json
  const questions = checkFile(files.questions);
  if (questions) {
    const questionIds = new Set<string>();
    questions.forEach((q: any, index: number) => {
      if (!q.id) {
        errors.push(`[questions.json] Entrada no índice ${index} sem 'id'.`);
      } else {
        if (questionIds.has(q.id)) {
          errors.push(`[questions.json] ID duplicado encontrado: ${q.id}`);
        }
        questionIds.add(q.id);
      }

      if (!q.pergunta) {
        errors.push(`[questions.json] Entrada no índice ${index} sem a pergunta real.`);
      }
    });
  }

  // 7. Validate longtails.json
  const longtails = checkFile(files.longtails);
  if (longtails) {
    const ltIds = new Set<string>();
    longtails.forEach((lt: any, index: number) => {
      if (!lt.id) {
        errors.push(`[longtails.json] Entrada no índice ${index} sem 'id'.`);
      } else {
        if (ltIds.has(lt.id)) {
          errors.push(`[longtails.json] ID duplicado encontrado: ${lt.id}`);
        }
        ltIds.add(lt.id);
      }

      if (!lt.keyword) {
        errors.push(`[longtails.json] Entrada no índice ${index} sem a palavra-chave cauda longa.`);
      }
    });
  }

  // 8. Validate opportunities.json
  const opportunities = checkFile(files.opportunities);
  if (opportunities) {
    const opIds = new Set<string>();
    opportunities.forEach((op: any, index: number) => {
      if (!op.id) {
        errors.push(`[opportunities.json] Entrada no índice ${index} sem 'id'.`);
      } else {
        if (opIds.has(op.id)) {
          errors.push(`[opportunities.json] ID de oportunidade duplicado: ${op.id}`);
        }
        opIds.add(op.id);
      }

      if (!op.tema) {
        errors.push(`[opportunities.json] Oportunidade no índice ${index} sem o 'tema'.`);
      }
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
