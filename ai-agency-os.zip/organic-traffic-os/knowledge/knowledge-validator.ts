import fs from "fs";
import path from "path";

export interface ValidationReport {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  checkedFiles: string[];
}

export function validateKnowledgeCore(blogId: string = "passacumaru"): ValidationReport {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "blogs", blogId);
  const errors: string[] = [];
  const warnings: string[] = [];
  const checkedFiles: string[] = [];

  const requiredFiles = [
    { key: "01-blog-profile.json", requiredFields: ["id", "nome", "slug", "dominio", "descricao"] },
    { key: "02-target-audience.json", isArray: true, requiredFields: ["perfil", "idade_media", "objetivos", "dores"] },
    { key: "03-editorial-guidelines.json", requiredFields: ["tom_de_voz", "linguagem", "nivel_tecnico"] },
    { key: "04-categories.json", isArray: true, requiredFields: ["id", "nome", "slug"] },
    { key: "05-products.json", isArray: true, requiredFields: ["nome", "descricao", "categoria", "status"] },
    { key: "06-content-rules.json", requiredFields: ["regras_editoriais"] },
    { key: "07-writing-style.json", requiredFields: ["quantidade_palavras", "estrutura_padrao"] },
    { key: "08-seo-rules.json", requiredFields: ["meta_title", "meta_description", "slug"] },
    { key: "09-knowledge-index.json", requiredFields: ["blog_id", "version", "files"] }
  ];

  if (!fs.existsSync(baseDir)) {
    errors.push(`Directory not found for blogId "${blogId}": ${baseDir}`);
    return { isValid: false, errors, warnings, checkedFiles };
  }

  requiredFiles.forEach((fileReq) => {
    const filePath = path.join(baseDir, fileReq.key);
    checkedFiles.push(fileReq.key);

    if (!fs.existsSync(filePath)) {
      errors.push(`Mandatory file missing: ${fileReq.key}`);
      return;
    }

    try {
      const rawContent = fs.readFileSync(filePath, "utf-8");
      const data = JSON.parse(rawContent);

      // Array check
      if (fileReq.isArray && !Array.isArray(data)) {
        errors.push(`File ${fileReq.key} should contain a JSON array but found ${typeof data}`);
        return;
      }

      // Fields check
      if (fileReq.isArray) {
        // Validate array entries
        const items = data as any[];
        items.forEach((item, index) => {
          fileReq.requiredFields.forEach((field) => {
            if (item[field] === undefined || item[field] === null || item[field] === "") {
              errors.push(`File ${fileReq.key} item at index ${index} is missing required field: "${field}"`);
            }
          });
        });

        // Check for duplicates
        if (fileReq.key === "04-categories.json") {
          const slugs = items.map(c => c.slug);
          const duplicates = slugs.filter((slug, idx) => slugs.indexOf(slug) !== idx);
          if (duplicates.length > 0) {
            errors.push(`Duplicate categories found with slug(s): ${Array.from(new Set(duplicates)).join(", ")}`);
          }
        }
        if (fileReq.key === "05-products.json") {
          const names = items.map(p => p.nome);
          const duplicates = names.filter((name, idx) => names.indexOf(name) !== idx);
          if (duplicates.length > 0) {
            errors.push(`Duplicate products found with name(s): ${Array.from(new Set(duplicates)).join(", ")}`);
          }
        }
      } else {
        // Validate object fields
        fileReq.requiredFields.forEach((field) => {
          if (data[field] === undefined || data[field] === null || data[field] === "") {
            errors.push(`File ${fileReq.key} is missing required field: "${field}"`);
          }
        });
      }

    } catch (err: any) {
      errors.push(`File ${fileReq.key} contains invalid JSON content: ${err.message || err}`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    checkedFiles
  };
}
