import fs from "fs";
import path from "path";
import { validateKnowledgeCore } from "./knowledge-validator";

export interface ConsolidatedKnowledge {
  blog: any;
  publico: any[];
  editorial: any;
  categorias: any[];
  produtos: any[];
  regras: any;
  writingStyle: any;
  seo: any;
  metadata: {
    isValid: boolean;
    errors: string[];
    lastUpdated: string;
    fileCount: number;
    blogId: string;
  };
}

export function loadKnowledgeCore(blogId: string = "passacumaru"): ConsolidatedKnowledge {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "blogs", blogId);

  const fileMap = {
    profile: "01-blog-profile.json",
    audience: "02-target-audience.json",
    editorial: "03-editorial-guidelines.json",
    categories: "04-categories.json",
    products: "05-products.json",
    rules: "06-content-rules.json",
    style: "07-writing-style.json",
    seo: "08-seo-rules.json",
    index: "09-knowledge-index.json"
  };

  const result: Partial<ConsolidatedKnowledge> = {
    blog: null,
    publico: [],
    editorial: null,
    categorias: [],
    produtos: [],
    regras: null,
    writingStyle: null,
    seo: null
  };

  const validationResult = validateKnowledgeCore(blogId);
  const fileCount = Object.values(fileMap).filter(filename => 
    fs.existsSync(path.join(baseDir, filename))
  ).length;

  try {
    const profilePath = path.join(baseDir, fileMap.profile);
    if (fs.existsSync(profilePath)) {
      result.blog = JSON.parse(fs.readFileSync(profilePath, "utf-8"));
    }

    const audiencePath = path.join(baseDir, fileMap.audience);
    if (fs.existsSync(audiencePath)) {
      result.publico = JSON.parse(fs.readFileSync(audiencePath, "utf-8"));
    }

    const editorialPath = path.join(baseDir, fileMap.editorial);
    if (fs.existsSync(editorialPath)) {
      result.editorial = JSON.parse(fs.readFileSync(editorialPath, "utf-8"));
    }

    const categoriesPath = path.join(baseDir, fileMap.categories);
    if (fs.existsSync(categoriesPath)) {
      result.categorias = JSON.parse(fs.readFileSync(categoriesPath, "utf-8"));
    }

    const productsPath = path.join(baseDir, fileMap.products);
    if (fs.existsSync(productsPath)) {
      result.produtos = JSON.parse(fs.readFileSync(productsPath, "utf-8"));
    }

    const rulesPath = path.join(baseDir, fileMap.rules);
    if (fs.existsSync(rulesPath)) {
      result.regras = JSON.parse(fs.readFileSync(rulesPath, "utf-8"));
    }

    const stylePath = path.join(baseDir, fileMap.style);
    if (fs.existsSync(stylePath)) {
      result.writingStyle = JSON.parse(fs.readFileSync(stylePath, "utf-8"));
    }

    const seoPath = path.join(baseDir, fileMap.seo);
    if (fs.existsSync(seoPath)) {
      result.seo = JSON.parse(fs.readFileSync(seoPath, "utf-8"));
    }

  } catch (error: any) {
    console.error("Error loading knowledge files:", error);
    validationResult.isValid = false;
    validationResult.errors.push(`Parse error during loading: ${error.message || error}`);
  }

  return {
    blog: result.blog,
    publico: result.publico || [],
    editorial: result.editorial,
    categorias: result.categorias || [],
    produtos: result.produtos || [],
    regras: result.regras,
    writingStyle: result.writingStyle,
    seo: result.seo,
    metadata: {
      isValid: validationResult.isValid,
      errors: validationResult.errors,
      lastUpdated: new Date().toISOString(),
      fileCount,
      blogId
    }
  };
}
