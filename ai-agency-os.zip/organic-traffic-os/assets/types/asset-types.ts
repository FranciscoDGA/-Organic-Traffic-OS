export interface AssetTypeDefinition {
  id: string; // e.g. "artigo", "pagina_pilar", "faq", "landing", "quiz", "checklist", "glossario", "simulado", "tabela", "linha_do_tempo", "newsletter", "ebook", "pagina_categoria"
  nome: string;
  descricao: string;
  melhorIntencao: string[]; // e.g. ["Informacional", "Transacional"]
  objetivoPadrao: string;
}

export interface AssetRelation {
  id: string;
  source_asset_id: string; // e.g. parent "pagina_pilar"
  target_asset_id: string; // e.g. child "artigo", "faq", "quiz"
  tipo_relacao: string; // "pilar-satelite", "satelite-faq", "faq-quiz", "quiz-simulado", "simulado-material"
}

export interface Asset {
  id: string;
  content_id: string; // ID da oportunidade (Opportunity ID)
  tipo: string; // Id do tipo de ativo (e.g., "artigo", "faq", "quiz"...)
  titulo: string;
  status: "rascunho_estruturado" | "aprovado" | "revisado";
  versao: string; // e.g. "1.0"
  formato: string; // Detalhes do formato estruturado
  objetivo: string;
  publico: string;
  // Campos extras para a estrutura de dados gerada
  estrutura: any; // Armazena a estrutura específica de cada tipo (JSON com perguntas, tópicos, etc)
  criado_em: string;
  atualizado_em: string;
}

export interface SelectorReasoning {
  selectedType: string;
  intencaoDeBusca: string;
  estrategiaNicho: string;
  justificativa: string;
  score_adequacao: number;
}
