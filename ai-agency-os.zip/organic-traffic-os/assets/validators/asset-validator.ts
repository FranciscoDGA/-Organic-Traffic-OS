import * as fs from "fs";
import * as path from "path";
import { Asset, AssetRelation } from "../types/asset-types";
import { OpportunityService } from "../../opportunities/opportunity-service";

export interface ValidationIssue {
  type: "critical" | "warning" | "info";
  ruleId: string;
  field: string;
  message: string;
}

export interface ValidationReport {
  assetId: string;
  valid: boolean;
  issues: ValidationIssue[];
}

export class AssetValidator {
  /**
   * Executa auditoria estrita em um único ativo.
   */
  public static validateAsset(asset: Asset, allAssets: Asset[]): ValidationReport {
    const issues: ValidationIssue[] = [];

    // 1. Validar cabeçalho geral
    if (!asset.id) {
      issues.push({
        type: "critical",
        ruleId: "VAL-HEADER-ID",
        field: "id",
        message: "O ID do ativo é obrigatório."
      });
    }

    if (!asset.titulo || asset.titulo.trim() === "") {
      issues.push({
        type: "critical",
        ruleId: "VAL-HEADER-TITLE",
        field: "titulo",
        message: "O título do ativo não pode ser vazio."
      });
    }

    if (!asset.tipo) {
      issues.push({
        type: "critical",
        ruleId: "VAL-HEADER-TYPE",
        field: "tipo",
        message: "O tipo de ativo deve ser definido."
      });
    }

    // 2. Validar Dependência (Oportunidade)
    if (!asset.content_id) {
      issues.push({
        type: "warning",
        ruleId: "VAL-DEP-UNLINKED",
        field: "content_id",
        message: "Ativo não está vinculado a nenhuma oportunidade de busca cadastrada."
      });
    } else {
      const opportunities = OpportunityService.getOpportunities();
      const oppExists = opportunities.some(o => o.id === asset.content_id);
      if (!oppExists) {
        issues.push({
          type: "warning",
          ruleId: "VAL-DEP-NOTFOUND",
          field: "content_id",
          message: `O ID de oportunidade '${asset.content_id}' vinculado a este ativo não foi localizado no cache de oportunidades.`
        });
      }
    }

    // 3. Validar Estrutura de Conteúdo Específica do Tipo
    const est = asset.estrutura;
    if (!est) {
      issues.push({
        type: "critical",
        ruleId: "VAL-STRUCT-EMPTY",
        field: "estrutura",
        message: "A estrutura de conteúdo está vazia ou corrompida."
      });
    } else {
      this.validateTypeSpecificStructure(asset.tipo, est, issues);
    }

    // 4. Validar Relacionamentos (procura referências órfãs que usem este ativo)
    const relations = this.getAssetRelationsLocal(asset.id, allAssets);
    if (asset.tipo === "pagina_pilar" && relations.length === 0) {
      issues.push({
        type: "info",
        ruleId: "VAL-REL-PILLAR-SOLO",
        field: "relacionamentos",
        message: "Esta Página Pilar não possui nenhum artigo satélite ou recurso vinculado."
      });
    }

    const isValid = !issues.some(i => i.type === "critical");

    return {
      assetId: asset.id,
      valid: isValid,
      issues
    };
  }

  /**
   * Realiza validação estrita baseada nas chaves de estrutura esperadas para os 13 tipos.
   */
  private static validateTypeSpecificStructure(tipo: string, est: any, issues: ValidationIssue[]) {
    switch (tipo) {
      case "artigo":
        if (!est.h1) {
          issues.push({ type: "critical", ruleId: "STRUCT-ART-H1", field: "estrutura.h1", message: "Artigo de blog requer título H1 estruturado." });
        }
        if (!est.introducao) {
          issues.push({ type: "warning", ruleId: "STRUCT-ART-INTRO", field: "estrutura.introducao", message: "Artigo de blog deve conter uma introdução chamativa." });
        }
        if (!est.secoes || !Array.isArray(est.secoes) || est.secoes.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-ART-SECTIONS", field: "estrutura.secoes", message: "Artigo requer pelo menos uma seção de conteúdo estruturada." });
        }
        if (!est.cta || !est.cta.texto) {
          issues.push({ type: "warning", ruleId: "STRUCT-ART-CTA", field: "estrutura.cta", message: "Recomenda-se adicionar uma chamada para ação (CTA) ao fim do artigo." });
        }
        break;

      case "pagina_pilar":
        if (!est.tema_principal) {
          issues.push({ type: "critical", ruleId: "STRUCT-PIL-TEMA", field: "estrutura.tema_principal", message: "Pillar page requer tema principal unificado." });
        }
        if (!est.modulos || !Array.isArray(est.modulos) || est.modulos.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-PIL-MODULOS", field: "estrutura.modulos", message: "Pillar page requer múltiplos módulos de organização de silos." });
        }
        break;

      case "faq":
        if (!est.perguntas || !Array.isArray(est.perguntas) || est.perguntas.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-FAQ-LIST", field: "estrutura.perguntas", message: "O formato FAQ requer uma lista de perguntas e respostas cadastradas." });
        } else {
          est.perguntas.forEach((p: any, idx: number) => {
            if (!p.pergunta || !p.resposta) {
              issues.push({ type: "critical", ruleId: `STRUCT-FAQ-ITEM-${idx}`, field: `estrutura.perguntas[${idx}]`, message: "Toda pergunta do FAQ precisa conter pergunta e resposta completas." });
            }
          });
        }
        break;

      case "landing":
        if (!est.hero_titulo) {
          issues.push({ type: "critical", ruleId: "STRUCT-LD-HERO", field: "estrutura.hero_titulo", message: "Landing page requer título de destaque (Hero Title)." });
        }
        if (!est.beneficios || !Array.isArray(est.beneficios) || est.beneficios.length === 0) {
          issues.push({ type: "warning", ruleId: "STRUCT-LD-BENEFITS", field: "estrutura.beneficios", message: "Landing page deve conter uma lista de benefícios convincentes." });
        }
        if (!est.cta_botao) {
          issues.push({ type: "critical", ruleId: "STRUCT-LD-CTABTN", field: "estrutura.cta_botao", message: "Landing page necessita de rótulo para botão de CTA principal." });
        }
        break;

      case "quiz":
        if (!est.questoes || !Array.isArray(est.questoes) || est.questoes.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-QUIZ-QUESTIONS", field: "estrutura.questoes", message: "Quiz de engajamento requer questões configuradas." });
        } else {
          est.questoes.forEach((q: any, idx: number) => {
            if (!q.pergunta || !q.opcoes || !Array.isArray(q.opcoes) || q.gabarito_index === undefined) {
              issues.push({ type: "critical", ruleId: `STRUCT-QUIZ-Q-${idx}`, field: `estrutura.questoes[${idx}]`, message: "Questões do Quiz requerem enunciado, opções (array) e índice correto de gabarito." });
            }
          });
        }
        break;

      case "checklist":
        if (!est.fases || !Array.isArray(est.fases) || est.fases.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-CHKLST-PHASES", field: "estrutura.fases", message: "Checklist tático requer fases de execução listadas." });
        }
        break;

      case "glossario":
        if (!est.termos || !Array.isArray(est.termos) || est.termos.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-GLOS-TERMS", field: "estrutura.termos", message: "Glossário requer termos de dicionário e significados." });
        }
        break;

      case "simulado":
        if (!est.questoes || !Array.isArray(est.questoes) || est.questoes.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-SIM-QUESTIONS", field: "estrutura.questoes", message: "Simulado preparatório requer questões completas configuradas." });
        } else {
          est.questoes.forEach((q: any, idx: number) => {
            if (!q.enunciado || !q.opcoes || !q.gabarito) {
              issues.push({ type: "critical", ruleId: `STRUCT-SIM-Q-${idx}`, field: `estrutura.questoes[${idx}]`, message: "Questões de simulado devem conter enunciado, alternativas rotuladas de A-E e letra do gabarito." });
            }
          });
        }
        break;

      case "tabela":
        if (!est.colunas || !Array.isArray(est.colunas) || est.colunas.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-TAB-COLUMNS", field: "estrutura.colunas", message: "Tabelas comparativas exigem colunas de cabeçalho." });
        }
        if (!est.linhas || !Array.isArray(est.linhas) || est.linhas.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-TAB-ROWS", field: "estrutura.linhas", message: "Tabelas comparativas necessitam de linhas com valores associados." });
        }
        break;

      case "linha_do_tempo":
        if (!est.marcos || !Array.isArray(est.marcos) || est.marcos.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-TIME-MARKS", field: "estrutura.marcos", message: "Linhas do tempo requerem múltiplos marcos cronológicos." });
        }
        break;

      case "newsletter":
        if (!est.assunto_email) {
          issues.push({ type: "critical", ruleId: "STRUCT-NEWS-SUBJ", field: "estrutura.assunto_email", message: "Newsletters requerem linha de assunto persuasiva para e-mail." });
        }
        if (!est.corpo) {
          issues.push({ type: "critical", ruleId: "STRUCT-NEWS-BODY", field: "estrutura.corpo", message: "O corpo do e-mail da newsletter não pode ser vazio." });
        }
        break;

      case "ebook":
        if (!est.capa_titulo) {
          issues.push({ type: "critical", ruleId: "STRUCT-EBK-TITLE", field: "estrutura.capa_titulo", message: "O e-book requer título de capa principal." });
        }
        if (!est.capitulos || !Array.isArray(est.capitulos) || est.capitulos.length === 0) {
          issues.push({ type: "critical", ruleId: "STRUCT-EBK-CHAPS", field: "estrutura.capitulos", message: "O e-book deve listar capítulos e resumos estruturados correspondentes." });
        }
        break;

      case "pagina_categoria":
        if (!est.nome_categoria) {
          issues.push({ type: "critical", ruleId: "STRUCT-CAT-NAME", field: "estrutura.nome_categoria", message: "Páginas de Categoria exigem nome de categoria explícito." });
        }
        if (!est.links_silo_recomendados || !Array.isArray(est.links_silo_recomendados)) {
          issues.push({ type: "warning", ruleId: "STRUCT-CAT-SILO", field: "estrutura.links_silo_recomendados", message: "Recomenda-se adicionar links recomendados para fortalecer silos." });
        }
        break;
    }
  }

  /**
   * Helper local para buscar relações que usem este ativo de ID.
   */
  private static getAssetRelationsLocal(assetId: string, allAssets: Asset[]): AssetRelation[] {
    try {
      const filePath = path.join(process.cwd(), "organic-traffic-os/assets/library/asset-relations.json");
      if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath, "utf-8");
        const parsed = JSON.parse(data || "{}");
        const list: AssetRelation[] = parsed.relations || [];
        return list.filter(r => r.source_asset_id === assetId || r.target_asset_id === assetId);
      }
    } catch (e) {
      console.warn("Aviso ao buscar relações locais:", e);
    }
    return [];
  }
}
