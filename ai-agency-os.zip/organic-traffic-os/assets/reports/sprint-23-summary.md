# SPRINT 23 — RELATÓRIO DO MOTOR DE GERAÇÃO DE ATIVOS (CONTENT ASSET ENGINE V1)

## OBJETIVO ALCANÇADO
Transformamos o **Organic Traffic OS** em uma plataforma de geração de **ativos digitais de conteúdo**, superando a barreira de criação exclusiva de artigos. O sistema agora compreende a intenção de busca do usuário e seleciona cirurgicamente o formato de ativo mais adequado, gerando estruturas completas em formato JSON enriquecido.

---

## 1. BIBLIOTECA DE ATIVOS (ASSET LIBRARY)
A biblioteca centralizada é persistida em `organic-traffic-os/assets/library/asset.json`. Cada ativo é indexado contendo cabeçalhos de controle estratégico e o corpo estrutural (`estrutura`) contendo as chaves necessárias para montagem futura.

### Campos do Ativo (`Asset`)
- **`id`**: Identificador exclusivo de rastreamento do ativo.
- **`content_id`**: Identificador da oportunidade editorial de origem (garante rastreabilidade ponta-a-ponta).
- **`tipo`**: O ID correspondente ao formato do ativo (ex: `checklist`, `simulado`, `quiz`).
- **`titulo`**: Título otimizado para atração orgânica.
- **`status`**: Estágio atual do ativo (`rascunho_estruturado` | `aprovado` | `revisado`).
- **`versao`**: Número decimal incremental de controle de iterações (ex: `1.0`, `1.1`).
- **`formato`**: Rótulo descritivo do modelo gerado e pontuação de adequação.
- **`objetivo`**: Objetivo mercadológico específico do funil.
- **`publico`**: Persona alvo prioritária do blog.
- **`estrutura`**: Objeto estrutural customizado para cada tipo de ativo.

---

## 2. OS 13 TIPOS DE ATIVOS REGISTRADOS (ASSET TYPES)
Mapeados no arquivo mestre de configuração `organic-traffic-os/assets/library/asset-types.json`:

1. **Artigo de Blog (`artigo`)**: Foco em dúvidas gerais, focado no topo e meio do funil de SEO.
2. **Página Pilar (`pagina_pilar`)**: Hub central de autoridade temática de silo de links.
3. **FAQ (`faq`)**: Perguntas frequentes para capturar rich snippets e *People Also Ask* (PAA).
4. **Landing Page (`landing`)**: Página de conversão otimizada de alta persuasão (fundo de funil).
5. **Quiz Interativo (`quiz`)**: Engajamento lúdico, diagnósticos e extensão de tempo de permanência (*dwell time*).
6. **Checklist Passo-a-Passo (`checklist`)**: Roteiros e listas de ação imediatas de alta utilidade.
7. **Glossário de Termos (`glossario`)**: Definições enciclopédicas de jargões técnicos do nicho do blog.
8. **Simulado Prático (`simulado`)**: Questões e resoluções completas com gabarito comentado focado em exames.
9. **Tabela Comparativa (`tabela`)**: Comparações lado-a-lado de recursos e tabelas de prós e contras de utilitários.
10. **Linha do Tempo (`linha_do_tempo`)**: Cronologias de editais, prazos ou marcos históricos organizados.
11. **Conteúdo para Newsletter (`newsletter`)**: Boletins personalizados, resumos semanais de novidades por e-mail.
12. **E-book (`ebook`)**: Recompensa rica de alta densidade estruturada em capítulos temáticos.
13. **Página de Categoria Otimizada (`pagina_categoria`)**: Indexador de categoria taxionômica otimizada para buscadores.

---

## 3. SELEÇÃO INTELIGENTE (ASSET SELECTOR)
O motor `AssetSelector` escolhe o melhor formato cruzando:
- **Intenção de Busca**: Cruzamento semântico (Informacional, Comercial, Transacional, Navegacional, Investigativa) com as tags ideais dos tipos de ativos.
- **Inteligência Artificial (Gemini 3.5)**: Quando configurado, analisa o título, contexto da oportunidade, motivações e metas da estratégia para definir o formato de maior impacto e formular uma justificativa detalhada em português.
- **Heurística Fallback**: Algoritmo robusto baseado em padrões de palavras-chave no título caso a API esteja indisponível.

---

## 4. RELACIONAMENTOS DE ATIVOS (ASSET RELATIONS)
A fiação relacional é salva em `organic-traffic-os/assets/library/asset-relations.json` permitindo conectar múltiplos ativos de forma modular para consolidar a hierarquia de conteúdo (Siloing):

```
       [Página Pilar (Pillar Page)]
                  │
        ┌─────────┴─────────┐
        ▼                   ▼
    [Artigo 1]          [Artigo 2] (Satélites)
        │                   │
        ▼                   ▼
     [FAQ 1]            [Quiz 1]
                            │
                            ▼
                       [Simulado 1]
                            │
                            ▼
                    [E-book / Material]
```

O serviço permite criar, auditar e remover conexões programaticamente através de chaves relacionais específicas como `pilar-satelite`, `satelite-faq`, `faq-quiz`, `quiz-simulado`, `simulado-material`.

---

## 5. VERSIONAMENTO ROBUSTO (VERSIONING ENGINE)
Sempre que um ativo de ID existente for re-editado ou re-gerado por mudança na estratégia, o sistema:
1. Localiza a versão atual (ex: `1.0`).
2. Executa nova chamada inteligente mantendo o identificador mestre.
3. Incrementa a versão em `+0.1` (ex: `1.1`), atualiza a estrutura de conteúdo e o timestamp `atualizado_em`, retendo histórico operacional livre de quebras relacionais.
