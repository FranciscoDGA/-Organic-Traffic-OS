import { GoogleGenAI } from "@google/genai";
import { SelectorReasoning } from "../types/asset-types";

// Fallback scoring rules for intents
const INTENT_MAPPING: Record<string, string[]> = {
  informacional: ["artigo", "pagina_pilar", "faq", "glossario", "simulado", "linha_do_tempo", "ebook"],
  comercial: ["tabela", "quiz", "landing", "ebook", "newsletter"],
  transacional: ["landing", "checklist", "newsletter"],
  navegacional: ["faq", "glossario", "pagina_categoria"],
  investigativa: ["tabela", "artigo"]
};

export class AssetSelector {
  private static getAiClient(): GoogleGenAI | null {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }

  /**
   * Escolhe automaticamente o tipo de ativo mais adequado com base na intenção de busca e estratégia.
   */
  public static async selectAssetType(
    opportunity: any,
    strategyContext?: any,
    blueprintContext?: any
  ): Promise<SelectorReasoning> {
    const ai = this.getAiClient();
    const intent = (opportunity.intencao || "Informacional").toLowerCase().trim();

    if (ai) {
      try {
        const prompt = `
Você é o especialista em Estratégia de Conteúdo e SEO do Organic Traffic OS.
Sua missão é analisar uma Oportunidade Editorial, o contexto da Estratégia e do Blueprint, e decidir qual é o tipo de ativo digital de conteúdo (Asset Type) mais adequado a ser gerado.

Os 13 tipos de ativos permitidos são EXCLUSIVAMENTE estes IDs:
1. "artigo" - Artigo de Blog (Melhor para Dúvidas Gerais, Guias Práticos, Informacional)
2. "pagina_pilar" - Página Pilar / Pillar Page (Melhor para grandes temas abrangentes que conectam vários sub-artigos)
3. "faq" - FAQ / Perguntas Frequentes (Melhor para interrogações curtas e diretas, PAA e AI Overviews)
4. "landing" - Landing Page (Melhor para ofertas de conversão de leads, e-books, consultoria, Transacional)
5. "quiz" - Quiz Interativo (Melhor para engajamento, auto-avaliação, diversão ou diagnósticos)
6. "checklist" - Checklist / Passo a Passo (Melhor para guias acionáveis de execução de tarefas)
7. "glossario" - Glossário de Termos (Melhor para termos técnicos, jargões específicos e conceitos de busca enciclopédica)
8. "simulado" - Simulado / Teste Prático (Melhor para preparação de exames, provas, testes de competências)
9. "tabela" - Tabela Comparativa (Melhor para comparações, prós e contras, fichas técnicas, Investigativa/Comercial)
10. "linha_do_tempo" - Linha do Tempo / Timeline (Melhor para cronologias, processos históricos, prazos de concursos ou editais)
11. "newsletter" - Conteúdo para Newsletter (Melhor para atualizações rápidas, resumos de notícias ou boletins por e-mail)
12. "ebook" - E-book (Estrutura) (Melhor para aprofundamento literário denso, isca digital valiosa)
13. "pagina_categoria" - Página de Categoria (Melhor para organizar taxonomia e silos de links)

---
DADOS DE ENTRADA:
Oportunidade:
- Título: "${opportunity.titulo}"
- Categoria: "${opportunity.categoria}"
- Cluster: "${opportunity.cluster}"
- Intenção de Busca: "${opportunity.intencao}"
- Motivo de Criação: "${opportunity.motivo}"
- Prioridade: "${opportunity.prioridade}"

Estratégia do Blog (Contexto):
${strategyContext ? JSON.stringify(strategyContext, null, 2) : "Nenhuma estratégia específica fornecida."}

Blueprint Temático (Contexto):
${blueprintContext ? JSON.stringify(blueprintContext, null, 2) : "Nenhum blueprint de arquitetura fornecido."}

---
REGRAS DE DECISÃO:
1. Estude o Título e a Intenção de Busca. Se houver palavras como "comparar", "melhor vs pior", "diferença entre", selecione "tabela".
2. Se o título indica termos de dicionário, jargões ou "o que significa", selecione "glossario".
3. Se o título indica "cronograma", "prazos", "datas", "quando acontece", selecione "linha_do_tempo".
4. Se o título indica "passo a passo", "como fazer", "roteiro", selecione "checklist".
5. Se for um tema de preparação para exames/concursos como "questões de simulado", selecione "simulado".
6. Se a intenção for estritamente Transacional com foco em captura, prefira "landing".
7. Explique a justificativa detalhadamente em português, abordando a adequação ao funil.

Retorne APENAS um objeto JSON válido, sem markdown de bloco de código (\`\`\`json etc) e sem caracteres extras, contendo:
{
  "selectedType": "id_do_tipo_selecionado_aqui",
  "intencaoDeBusca": "breve análise da intenção de busca identificada",
  "estrategiaNicho": "como esse ativo se conecta com a estratégia de nicho do blog",
  "justificativa": "justificativa detalhada da escolha do formato de conteúdo",
  "score_adequacao": 95
}
`.trim();

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
        });

        const text = response.text || "";
        // Limpar possíveis blocos de markdown no output do gemini
        const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();
        const parsed = JSON.parse(cleanText);

        // Validar se o tipo retornado é um dos válidos
        const validTypes = [
          "artigo", "pagina_pilar", "faq", "landing", "quiz", "checklist",
          "glossario", "simulado", "tabela", "linha_do_tempo", "newsletter",
          "ebook", "pagina_categoria"
        ];
        if (!validTypes.includes(parsed.selectedType)) {
          parsed.selectedType = "artigo"; // fallback seguro
        }

        return parsed;
      } catch (err) {
        console.error("Erro na seleção de ativo por IA (Gemini):", err);
        // Continuar para o fallback heurístico
      }
    }

    // Heurístico Fallback (Sem chave API ou se houver erro)
    let selectedType = "artigo";
    let score = 70;
    let justificativa = "Selecionado por algoritmo heurístico baseado na intenção de busca principal.";

    // Analisar padrões no título
    const titleLower = (opportunity.titulo || "").toLowerCase();
    
    if (titleLower.includes("diferença") || titleLower.includes("melhor") || titleLower.includes("vs") || titleLower.includes("comparativo") || titleLower.includes("tabela")) {
      selectedType = "tabela";
      score = 90;
      justificativa = "O título sugere uma comparação de recursos, preços ou prós e contras, tornando a Tabela Comparativa o formato ideal para facilitar a escolha do usuário.";
    } else if (titleLower.includes("questões") || titleLower.includes("simulado") || titleLower.includes("prova") || titleLower.includes("teste")) {
      selectedType = "simulado";
      score = 95;
      justificativa = "A intenção é nitidamente de prática e auto-avaliação para um concurso ou exame, sugerindo a geração de um Simulado de questões comentadas.";
    } else if (titleLower.includes("cronograma") || titleLower.includes("calendário") || titleLower.includes("datas") || titleLower.includes("prazos") || titleLower.includes("história") || titleLower.includes("linha do tempo")) {
      selectedType = "linha_do_tempo";
      score = 92;
      justificativa = "O assunto demanda o acompanhamento de uma sequência de marcos temporais, tornando a Linha do Tempo o formato de escaneabilidade superior.";
    } else if (titleLower.includes("passo a passo") || titleLower.includes("como") || titleLower.includes("roteiro") || titleLower.includes("checklist") || titleLower.includes("guia prático")) {
      selectedType = "checklist";
      score = 88;
      justificativa = "Por requerer execução tática estruturada, o formato de Checklist Passo a Passo fornece utilidade imediata de alta conversão.";
    } else if (titleLower.includes("o que é") || titleLower.includes("significado") || titleLower.includes("termo") || titleLower.includes("definição")) {
      selectedType = "glossario";
      score = 85;
      justificativa = "Assunto focado em terminologia ou jargão setorial, ideal para indexar em um Glossário de Termos de consulta enciclopédica.";
    } else if (titleLower.includes("perguntas") || titleLower.includes("dúvidas") || titleLower.includes("faq")) {
      selectedType = "faq";
      score = 90;
      justificativa = "A oportunidade é focada em resolver interrogações explícitas e rápidas, sendo ideal para uma estrutura de FAQ.";
    } else if (intent === "transacional") {
      selectedType = "landing";
      score = 85;
      justificativa = "Uma oportunidade com intenção transacional expressa é idealmente capturada através de uma Landing Page com cópia persuasiva.";
    } else if (intent === "comercial") {
      selectedType = "quiz";
      score = 80;
      justificativa = "Ideal para guiar a qualificação comercial do usuário através de um Quiz de diagnóstico.";
    } else if (opportunity.tipo === "reforco_pilar") {
      selectedType = "pagina_pilar";
      score = 95;
      justificativa = "Indicado para reforçar o cluster de conteúdo, criando um hub agregador exaustivo (Pillar Page).";
    }

    return {
      selectedType,
      intencaoDeBusca: `Intenção identificada como '${opportunity.intencao}' baseada nos metadados de descoberta.`,
      estrategiaNicho: `Alinhado com a categoria '${opportunity.categoria}' para fortalecer o cluster '${opportunity.cluster}'.`,
      justificativa,
      score_adequacao: score
    };
  }
}
