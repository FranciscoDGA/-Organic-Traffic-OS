import { AssetEngine } from "./asset-engine";
import { AssetValidator } from "../validators/asset-validator";
import { Asset, AssetRelation } from "../types/asset-types";
import { OpportunityService } from "../../opportunities/opportunity-service";

export class AssetService {
  /**
   * Retorna toda a biblioteca de ativos cadastrados no JSON.
   */
  public static getAllAssets(): Asset[] {
    return AssetEngine.getAssets();
  }

  /**
   * Busca um ativo específico por ID.
   */
  public static getAssetById(id: string): Asset | null {
    const assets = this.getAllAssets();
    return assets.find(a => a.id === id) || null;
  }

  /**
   * Cria um novo ativo estruturado de conteúdo, validando e salvando na biblioteca.
   */
  public static async createAsset(
    opportunityId: string,
    forcedType?: string,
    strategyContext?: any,
    blueprintContext?: any
  ): Promise<Asset> {
    // 1. Obter oportunidade de origem
    const opportunities = OpportunityService.getOpportunities();
    const opportunity = opportunities.find(o => o.id === opportunityId);

    if (!opportunity) {
      throw new Error(`Oportunidade editorial com ID '${opportunityId}' não encontrada.`);
    }

    // 2. Chamar o motor para gerar a estrutura de conteúdo
    const newAsset = await AssetEngine.generateAsset(opportunity, strategyContext, blueprintContext, forcedType);

    // 3. Salvar na biblioteca
    const assets = this.getAllAssets();
    assets.unshift(newAsset); // Adicionar no início para listagem recente
    AssetEngine.saveAssets(assets);

    return newAsset;
  }

  /**
   * Cria um relacionamento estruturado entre dois ativos existentes.
   */
  public static createRelation(
    sourceId: string,
    targetId: string,
    relationType: string
  ): AssetRelation {
    const assets = this.getAllAssets();
    const sourceExists = assets.some(a => a.id === sourceId);
    const targetExists = assets.some(a => a.id === targetId);

    if (!sourceExists || !targetExists) {
      throw new Error("Ambos os ativos de origem e destino devem existir para estabelecer uma relação.");
    }

    const newRelation: AssetRelation = {
      id: `rel-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      source_asset_id: sourceId,
      target_asset_id: targetId,
      tipo_relacao: relationType
    };

    const relations = AssetEngine.getRelations();
    relations.push(newRelation);
    AssetEngine.saveRelations(relations);

    return newRelation;
  }

  /**
   * Retorna todas as relações de ativos cadastradas.
   */
  public static getAllRelations(): AssetRelation[] {
    return AssetEngine.getRelations();
  }

  /**
   * Remove uma relação por ID.
   */
  public static deleteRelation(relationId: string): boolean {
    const relations = AssetEngine.getRelations();
    const filtered = relations.filter(r => r.id !== relationId);
    if (relations.length === filtered.length) return false;
    AssetEngine.saveRelations(filtered);
    return true;
  }

  /**
   * Remove um ativo por ID (e todas as suas relações correspondentes).
   */
  public static deleteAsset(assetId: string): boolean {
    const assets = this.getAllAssets();
    const filteredAssets = assets.filter(a => a.id !== assetId);
    if (assets.length === filteredAssets.length) return false;

    AssetEngine.saveAssets(filteredAssets);

    // Limpar relações associadas
    const relations = AssetEngine.getRelations();
    const filteredRelations = relations.filter(
      r => r.source_asset_id !== assetId && r.target_asset_id !== assetId
    );
    AssetEngine.saveRelations(filteredRelations);

    return true;
  }

  /**
   * Versiona um ativo existente, duplicando/atualizando e incrementando a versão programaticamente.
   */
  public static async versionAsset(
    assetId: string,
    strategyContext?: any,
    blueprintContext?: any
  ): Promise<Asset> {
    const assets = this.getAllAssets();
    const index = assets.findIndex(a => a.id === assetId);

    if (index === -1) {
      throw new Error(`Ativo com ID '${assetId}' não encontrado para versionamento.`);
    }

    const currentAsset = assets[index];
    const opportunities = OpportunityService.getOpportunities();
    const opportunity = opportunities.find(o => o.id === currentAsset.content_id) || {
      id: currentAsset.content_id,
      titulo: currentAsset.titulo,
      motivo: "Re-versionamento preventivo de ativos",
      intencao: "Informacional"
    };

    // Incrementar versão decimal (ex: 1.0 -> 1.1 -> 1.2)
    const currentVersionNum = parseFloat(currentAsset.versao || "1.0");
    const nextVersion = (currentVersionNum + 0.1).toFixed(1);

    // Gerar nova estrutura de conteúdo
    const freshAsset = await AssetEngine.generateAsset(
      opportunity,
      strategyContext,
      blueprintContext,
      currentAsset.tipo
    );

    // Preservar o mesmo ID, mas atualizar a versão e o timestamp
    currentAsset.versao = nextVersion;
    currentAsset.estrutura = freshAsset.estrutura;
    currentAsset.formato = freshAsset.formato;
    currentAsset.atualizado_em = new Date().toISOString();

    assets[index] = currentAsset;
    AssetEngine.saveAssets(assets);

    return currentAsset;
  }
}
export default AssetService;
