import * as fs from "fs";
import * as path from "path";
import { GoogleGenAI } from "@google/genai";
import { AssetSelector } from "./asset-selector";
import { Asset, AssetRelation } from "../types/asset-types";

export class AssetEngine {
  private static assetsFilePath = path.join(
    process.cwd(),
    "organic-traffic-os/assets/library/asset.json"
  );
  
  private static relationsFilePath = path.join(
    process.cwd(),
    "organic-traffic-os/assets/library/asset-relations.json"
  );

  private static getAiClient(): GoogleGenAI | null {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }

  /**
   * Gera a estrutura completa de um ativo de conteúdo com base na oportunidade e tipo.
   */
  public static async generateAsset(
    opportunity: any,
    strategyContext?: any,
    blueprintContext?: any,
    forcedType?: string
  ): Promise<Asset> {
    // 1. Selecionar o tipo de ativo (automático ou forçado)
    let selectedType = forcedType;
    let justification = "Definido manualmente pelo estrategista editorial.";
    let score = 100;

    if (!selectedType) {
      const selection = await AssetSelector.selectAssetType(opportunity, strategyContext, blueprintContext);
      selectedType = selection.selectedType;
      justification = selection.justificativa;
      score = selection.score_adequacao;
    }

    // 2. Definir dados fundamentais de cabeçalho
    const assetId = `asset-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const title = opportunity.titulo || "Ativo de Conteúdo";
    
    // Obter objetivos e públicos padrão
    const typesConfig = this.getAssetTypesConfig();
    const typeDef = typesConfig.find((t: any) => t.id === selectedType);
    const objetivo = typeDef ? typeDef.objetivoPadrao : "Fornecer conteúdo estruturado e de alta conversão.";
    const publico = strategyContext?.personas?.[0]?.nome || "Concurseiros, estudantes e candidatos de concursos públicos do Brasil.";

    // 3. Gerar a estrutura de conteúdo (Inteligente por Gemini ou fallback local)
    const estrutura = await this.generateStructureContent(selectedType, title, opportunity, justification);

    // 4. Montar o objeto final de ativo
    const newAsset: Asset = {
      id: assetId,
      content_id: opportunity.id || "op-unlinked",
      tipo: selectedType,
      titulo: title,
      status: "rascunho_estruturado",
      versao: "1.0",
      formato: `Estrutura de dados enriquecida para formato '${selectedType}' (Score de adequação: ${score}%)`,
      objetivo,
      publico,
      estrutura,
      criado_em: new Date().toISOString(),
      atualizado_em: new Date().toISOString()
    };

    return newAsset;
  }

  /**
   * Comunica-se com o Gemini ou gera programaticamente a estrutura específica do tipo de ativo.
   */
  private static async generateStructureContent(
    tipo: string,
    titulo: string,
    opportunity: any,
    justification: string
  ): Promise<any> {
    const ai = this.getAiClient();
    if (ai) {
      try {
        const prompt = `
Você é o principal redator e engenheiro de conteúdo do portal PassaCumaru (especializado em Concursos Públicos, Editais, Vagas Administrativas, Legislação e Preparação de Candidatos).
Sua missão é gerar a ESTRUTURA de conteúdo detalhada e preenchida em formato JSON para o ativo "${titulo}" do tipo de formato "${tipo}".

A oportunidade original tem o motivo: "${opportunity.motivo}" e contexto de intenção "${opportunity.intencao}".
A justificativa de escolha do formato foi: "${justification}".

Gere dados específicos, completos, extremamente realistas e ricos em português do Brasil (nada de placeholders genéricos).

Estruture o JSON final dependendo exclusivamente do formato "${tipo}":

Se o tipo for "artigo":
{
  "h1": "Título principal otimizado para clique",
  "introducao": "Texto introdutório estimulante de 3 a 4 linhas",
  "secoes": [
    { "subtitulo": "Seção H2 - 1", "texto": "Parágrafos aprofundados" },
    { "subtitulo": "Seção H2 - 2", "texto": "Parágrafos aprofundados" }
  ],
  "conclusao": "Texto de encerramento resumindo aprendizados",
  "cta": { "texto": "Texto chamativo de conversão", "destino": "/simulados/concursos" }
}

Se o tipo for "pagina_pilar":
{
  "tema_principal": "Tema central exaustivo",
  "resumo_autoridade": "Texto estabelecendo autoridade de domínio",
  "modulos": [
    { "titulo_modulo": "Módulo 1", "descricao": "Abordagem teórica de base", "links_satelite_sugeridos": ["id-artigo-1", "id-artigo-2"] },
    { "titulo_modulo": "Módulo 2", "descricao": "Lei seca e doutrina", "links_satelite_sugeridos": ["id-artigo-3"] }
  ],
  "estrutura_silagem": "Mapa de silos de interligação de links internos"
}

Se o tipo for "faq":
{
  "perguntas": [
    { "pergunta": "Pergunta frequente 1 realista?", "resposta": "Resposta direta e assertiva de até 3 linhas pronta para featured snippet." },
    { "pergunta": "Pergunta frequente 2 realista?", "resposta": "Resposta direta e assertiva de até 3 linhas pronta para featured snippet." },
    { "pergunta": "Pergunta frequente 3 realista?", "resposta": "Resposta direta e assertiva de até 3 linhas pronta para featured snippet." }
  ]
}

Se o tipo for "landing":
{
  "hero_titulo": "Título de conversão forte e persuasivo",
  "hero_subtitulo": "Oferta de valor complementar e irresistível",
  "beneficios": ["Benefício prático 1", "Benefício prático 2", "Benefício prático 3"],
  "prova_social": { "autor": "Nome do Aprovado", "cargo": "Analista do TRT", "depoimento": "O material do PassaCumaru foi o divisor de águas..." },
  "cta_botao": "Texto do botão de conversão"
}

Se o tipo for "quiz":
{
  "titulo_quiz": "Título interativo estimulante",
  "questoes": [
    {
      "pergunta": "Questão de quiz rápida?",
      "opcoes": ["Opção A", "Opção B", "Opção C", "Opção D"],
      "gabarito_index": 1,
      "feedback": "Justificativa didática curta."
    }
  ],
  "resultados": [
    { "min_score": 0, "max_score": 50, "titulo": "Nível Iniciante", "conselho": "Recomendamos ler as pillar pages de introdução." },
    { "min_score": 51, "max_score": 100, "titulo": "Nível Avançado", "conselho": "Pronto para os simulados avançados!" }
  ]
}

Se o tipo for "checklist":
{
  "nome_lista": "Título do Checklist",
  "fases": [
    {
      "fase_nome": "Fase 1: Preparativos",
      "itens": [
        { "tarefa": "Tarefa 1 detalhada", "importancia": "Alta", "dica_de_execucao": "Como executar essa tarefa perfeitamente" }
      ]
    }
  ]
}

Se o tipo for "glossario":
{
  "letras_disponiveis": ["A", "C", "D"],
  "termos": [
    { "termo": "Termo Técnico ou Sigla", "letra": "T", "significado": "Significado aprofundado do jargão público ou jurídico.", "contexto_uso": "Exemplo prático de como cai em prova ou aparece no edital." }
  ]
}

Se o tipo for "simulado":
{
  "edital_referencia": "Nome do Concurso / Ano (ex: Banco do Brasil 2026)",
  "questoes": [
    {
      "enunciado": "Enunciado completo, realista de questão de concurso (ex: direito administrativo, constitucional etc) simulando bancas como Cesgranrio, FGV ou FCC.",
      "opcoes": { "a": "Opção A", "b": "Opção B", "c": "Opção C", "d": "Opção D", "e": "Opção E" },
      "gabarito": "c",
      "explicacao_didatica": "Explicação completa e didática de cada alternativa com citação à lei seca se houver."
    }
  ]
}

Se o tipo for "tabela":
{
  "colunas": ["Característica", "Plano Grátis", "Plano Premium", "Plano Assinatura"],
  "linhas": [
    { "nome_linha": "Linha 1 comparada", "valores": ["Sem custos", "Apenas R$ 29/mês", "Assinatura vitalícia"] }
  ],
  "veredicto_especialista": "Recomendação final baseada no perfil do candidato."
}

Se o tipo for "linha_do_tempo":
{
  "marcos": [
    { "periodo": "Data ou Prazo", "evento": "Título do Marco Temporal", "detalhes": "O que ocorre nesta data e sua relevância prática.", "base_legal": "Artigo do edital ou lei de referência." }
  ]
}

Se o tipo for "newsletter":
{
  "assunto_email": "Assunto instigante de e-mail (com gatilhos de taxa de abertura)",
  "saudacao": "Olá, futuro concursado!",
  "corpo": "Texto caloroso, pessoal e dinâmico que introduz as novidades da semana e traz dicas de estudo de alta relevância.",
  "balas_destaque": ["Destaque da semana 1", "Destaque da semana 2"],
  "artigos_recomendados": ["/blog/artigo-novo-1", "/blog/artigo-novo-2"],
  "rodape": "Assinatura afetuosa da equipe PassaCumaru"
}

Se o tipo for "ebook":
{
  "capa_titulo": "Título Principal Impactante",
  "capa_subtitulo": "Subtítulo de Proposta de Valor",
  "capitulos": [
    { "numero": 1, "titulo_capitulo": "Nome do Capítulo 1", "resumo_conteudo": "Resumo de 3 a 4 linhas detalhando os tópicos teóricos abordados e metodologias sugeridas." }
  ]
}

Se o tipo for "pagina_categoria":
{
  "nome_categoria": "Nome da Categoria Otimizada",
  "introducao_seo": "Texto de introdução rico em palavras-chave sobre o assunto de categoria.",
  "subcategorias": ["Sub 1", "Sub 2"],
  "links_silo_recomendados": ["/categoria/concursos-federais", "/categoria/materias-de-direito"]
}

Retorne APENAS um objeto JSON válido correspondente, sem markdown de bloco de código (\`\`\`json etc) e sem caracteres extras.
`.trim();

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
        });

        const text = response.text || "";
        const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();
        return JSON.parse(cleanText);
      } catch (err) {
        console.error(`Erro ao gerar estrutura inteligente via Gemini para o tipo ${tipo}:`, err);
      }
    }

    // Programmatic Highly Realistic Fallback (no API key or JSON parse error)
    return this.generateProgrammaticFallback(tipo, titulo, opportunity);
  }

  /**
   * Gera programaticamente fallback de dados ultra realista e completo no idioma correto (Português).
   */
  private static generateProgrammaticFallback(tipo: string, titulo: string, opportunity: any): any {
    const subject = opportunity.cluster || opportunity.categoria || "Concursos Públicos";

    switch (tipo) {
      case "artigo":
        return {
          h1: `Guia Definitivo: Como se Preparar e Passar em ${titulo}`,
          introducao: `Se você está buscando estabilidade, excelentes remunerações e quer garantir a sua aprovação em ${subject}, este guia foi elaborado sob medida para você. Vamos destrinchar os principais pontos, metodologias de estudo e segredos práticos do edital.`,
          secoes: [
            {
              subtitulo: `1. O que é cobrado na prova de ${subject}?`,
              texto: `Para vencer a concorrência, o primeiro passo é mapear a banca examinadora. Geralmente, as disciplinas fundamentais cobrem direito administrativo, constitucional e conhecimentos específicos de ${subject}. Foque em realizar revisões de lei seca semanalmente.`
            },
            {
              subtitulo: `2. Cronograma de Estudos Altamente Eficiente`,
              texto: `Sugerimos dividir seu tempo de estudo em ciclos de 90 minutos por disciplina, revezando teoria, elaboração de resumos mentais e a resolução de pelo menos 30 questões de editais passados.`
            }
          ],
          conclusao: "Alcançar a aprovação requer persistência, foco no edital e materiais de alta qualidade direcionados. Comece a estudar hoje mesmo e mude de vida!",
          cta: {
            texto: "Clique aqui para baixar o nosso cronograma gratuito em PDF e acelerar sua aprovação!",
            destino: "/materiais/cronograma-estudos"
          }
        };

      case "pagina_pilar":
        return {
          tema_principal: `Silo Central de Conteúdo: Tudo sobre ${subject}`,
          resumo_autoridade: "Esta página pilar reúne os melhores materiais analíticos, leis esquematizadas e diretrizes de estudo elaborados pela equipe pedagógica do PassaCumaru. Aqui você encontra tudo que precisa em um só lugar.",
          modulos: [
            {
              titulo_modulo: "Fase de Planejamento de Estudos",
              descricao: "Aprenda a analisar a concorrência e montar seu ciclo inicial de disciplinas.",
              links_satelite_sugeridos: ["artigo-metodo-estudo", "artigo-organizar-ciclos"]
            },
            {
              titulo_modulo: "Dominando as Disciplinas de Base",
              descricao: "Aprofundamento em português para concursos, direito administrativo e informática básica.",
              links_satelite_sugeridos: ["artigo-direito-administrativo-simplificado", "artigo-portugues-cesgranrio"]
            }
          ],
          estrutura_silagem: "Estrutura de links em silo: Pilar Central links out to Satélites; Satélites link back to Pilar with rich anchors."
        };

      case "faq":
        return {
          perguntas: [
            {
              pergunta: `Qual é o prazo típico de validade do concurso para ${subject}?`,
              resposta: "A validade padrão é de 2 anos, prorrogável uma única vez por igual período, a critério da administração pública."
            },
            {
              pergunta: `Posso me inscrever em ${titulo} mesmo sem experiência na área?`,
              resposta: "Sim. A maioria das vagas exige apenas a certificação de escolaridade correspondente (nível médio ou superior), sem requisição de experiência profissional."
            },
            {
              pergunta: "Como funciona a pontuação por títulos em editais?",
              resposta: "A prova de títulos possui caráter estritamente classificatório. Ela soma pontos para pós-graduação, mestrado, doutorado ou tempo de serviço público anterior."
            }
          ]
        };

      case "landing":
        return {
          hero_titulo: `Acelere sua Nomeação em ${titulo} com o Nosso Método`,
          hero_subtitulo: "Garanta acesso ao material sintetizado focado 100% no edital vigente. Mais de 3.500 aprovados já validaram nosso sistema.",
          beneficios: [
            "Resumos focados apenas nas matérias recorrentes de concursos",
            "Banco de questões comentadas por professores especialistas",
            "Planilhas inteligentes de controle de revisões por ciclos"
          ],
          prova_social: {
            autor: "Mariana Souza de Oliveira",
            cargo: "Aprovada em 1º Lugar para Analista Técnico",
            depoimento: "Faltavam 3 meses para a prova e eu estava perdida. Com o roteiro estruturado do PassaCumaru, consegui estudar todo o conteúdo programático de forma cirúrgica e garantir a minha nomeação."
          },
          cta_botao: "Quero Garantir Meu Acesso com 40% de Desconto Agora"
        };

      case "quiz":
        return {
          titulo_quiz: `Teste de Nivelamento: Como estão seus conhecimentos em ${subject}?`,
          questoes: [
            {
              pergunta: "Qual princípio constitucional veda a nomeação de parentes em cargos de comissão (Súmula Vinculante 13 do STF)?",
              opcoes: [
                "Princípio da Eficiência",
                "Princípio da Impessoalidade (Nepotismo)",
                "Princípio da Publicidade",
                "Princípio da Autotutela"
              ],
              gabarito_index: 1,
              feedback: "O nepotismo fere frontalmente a impessoalidade e a moralidade administrativa, conforme entendimento sumulado do Supremo Tribunal Federal."
            },
            {
              pergunta: "A lei que regulamenta o processo administrativo no âmbito federal é a:",
              opcoes: [
                "Lei 8.112/90",
                "Lei 8.666/93",
                "Lei 9.784/99",
                "Lei 14.133/21"
              ],
              gabarito_index: 2,
              feedback: "A Lei 9.784/99 estabelece normas básicas sobre o processo administrativo na Administração Federal direta e indireta."
            }
          ],
          resultados: [
            {
              min_score: 0,
              max_score: 50,
              titulo: "Concurseiro Iniciante",
              conselho: "Você está no caminho certo, mas precisa consolidar a base teórica antes de focar apenas em simulados cronometrados."
            },
            {
              min_score: 51,
              max_score: 100,
              titulo: "Concurseiro Combatente Avançado",
              conselho: "Seu percentual de acertos é excelente! Continue lapidando detalhes através de lei seca e simulados de bancas específicas."
            }
          ]
        };

      case "checklist":
        return {
          nome_lista: `Checklist de Reta Final: O que fazer antes da prova de ${titulo}`,
          fases: [
            {
              fase_nome: "Semana Anterior à Prova (Revisão Cirúrgica)",
              itens: [
                {
                  tarefa: "Ler resumos esquematizados de Direito Administrativo",
                  importancia: "Alta",
                  dica_de_execucao: "Foque nos tópicos de Atos Administrativos, Poderes e Lei de Improbidade."
                },
                {
                  tarefa: "Imprimir o comprovante de local de prova e ensaiar o trajeto",
                  importancia: "Crítica",
                  dica_de_execucao: "Evite atrasos desastrosos. Calcule o tempo com margem de 1 hora de antecedência."
                }
              ]
            },
            {
              fase_nome: "Véspera e Dia da Prova",
              itens: [
                {
                  tarefa: "Fazer uma revisão leve pela manhã e descansar o restante do dia",
                  importancia: "Média",
                  dica_de_execucao: "Estudar pesado na véspera gera estresse e atrapalha a memória de longo prazo."
                }
              ]
            }
          ]
        };

      case "glossario":
        return {
          letras_disponiveis: ["A", "C", "D", "E"],
          termos: [
            {
              termo: "Ator de Cargo de Comissão",
              letra: "A",
              significado: "Cargo público de livre nomeação e exoneração por parte da autoridade competente, destinado a atribuições de chefia, direção e assessoramento.",
              contexto_uso: "Cai comumente em provas cobrando a diferença entre cargo em comissão (qualquer pessoa) e função de confiança (exclusiva de servidores de carreira)."
            },
            {
              termo: "Caducidade do Ato Administrativo",
              letra: "C",
              significado: "Extinção de um ato administrativo devido à superveniência de uma nova norma jurídica que torna incompatível a permanência dos efeitos do ato anterior.",
              contexto_uso: "Pegadinha clássica em provas de Direito Administrativo tentando confundir caducidade com cassação."
            }
          ]
        };

      case "simulado":
        return {
          edital_referencia: `Simulado Nacional Preparatório para ${titulo} (2026)`,
          questoes: [
            {
              enunciado: "No tocante aos Poderes Administrativos, o poder que concede à Administração Pública a prerrogativa de aplicar punições disciplinares a servidores que cometam infrações funcionais é denominado Poder:",
              opcoes: {
                a: "Hierárquico",
                b: "Disciplinar",
                c: "De Polícia",
                d: "Regulamentar",
                e: "Discricionário"
              },
              gabarito: "b",
              explicacao_didatica: "Gabarito: Letra B. O Poder Disciplinar é a faculdade de punir internamente as infrações funcionais dos servidores públicos. Embora decorra do Poder Hierárquico devido à relação de subordinação, a aplicação imediata da sanção é materialização do Poder Disciplinar."
            },
            {
              enunciado: "Conforme a Constituição Federal de 1988, a investidura em cargo ou emprego público depende de aprovação prévia em concurso público de provas ou de provas e títulos, ressalvadas as nomeações para cargo em comissão declarados em lei de livre nomeação e exoneração. O prazo máximo de validade das inscrições e homologação de concurso é de:",
              opcoes: {
                a: "Até um ano, prorrogável por igual período.",
                b: "Até dois anos, prorrogável uma vez por igual período.",
                c: "Até cinco anos, improrrogável.",
                d: "Indeterminado até o preenchimento total das vagas.",
                e: "De três anos, com prorrogação automática por decreto executivo."
              },
              gabarito: "b",
              explicacao_didatica: "Gabarito: Letra B. Conforme o artigo 37, inciso III da Constituição Federal de 1988, o concurso público terá validade de até dois anos, prorrogável uma vez por igual período."
            }
          ]
        };

      case "tabela":
        return {
          colunas: ["Critério de Análise", "Concurso Nível Médio", "Concurso Nível Superior", "Processo Seletivo Simples"],
          linhas: [
            {
              nome_linha: "Remuneração Inicial Média",
              valores: ["R$ 2.800 a R$ 5.200", "R$ 6.500 a R$ 22.000", "R$ 2.000 a R$ 4.500"]
            },
            {
              nome_linha: "Exigência de Experiência",
              valores: ["Raramente exigida", "Pode exigir inscrição em conselho", "Geralmente avalia apenas títulos"]
            },
            {
              nome_linha: "Estabilidade Profissional",
              valores: ["Sim (Regime Estatutário)", "Sim (Regime Estatutário)", "Não (Contrato temporário limitado)"]
            }
          ],
          veredicto_especialista: "Para quem está iniciando a jornada, focar em cargos de nível médio técnico é o atalho mais rápido para obter estabilidade financeira e continuar estudando para cargos de alto escalão."
        };

      case "linha_do_tempo":
        return {
          marcos: [
            {
              periodo: "Dia 1 (Publicação)",
              evento: "Divulgação do Edital de Concurso",
              detalhes: "O edital oficial é publicado no Diário Oficial. Inicia-se a contagem de todos os prazos legais.",
              base_legal: "Artigo 1º do Edital Normativo"
            },
            {
              periodo: "Dias 2 a 15",
              evento: "Período de Inscrições e Solicitação de Isenção",
              detalhes: "Candidatos de baixa renda ou doadores de medula óssea podem protocolar o pedido de isenção da taxa de inscrição.",
              base_legal: "Capítulo IV do Edital (Isenções)"
            },
            {
              periodo: "Dia 45",
              evento: "Divulgação do Cartão de Confirmação e Local de Provas",
              detalhes: "A banca publica as escolas, salas e horários em que cada candidato realizará a avaliação escrita.",
              base_legal: "Capítulo VII (Das Provas)"
            }
          ]
        };

      case "newsletter":
        return {
          assunto_email: "Edital Publicado! Salários de até R$ 9.800 e inscrições abertas esta semana 🚀",
          saudacao: "Olá, futuro servidor do PassaCumaru!",
          corpo: "O ritmo de editais no país está frenético e hoje trazemos uma notícia excelente: o edital de concursos federais foi assinado e disponibiliza centenas de vagas imediatas. Separamos abaixo as principais diretrizes, dicas de mentores aprovados e os links diretos para você se preparar de forma inteligente.",
          balas_destaque: [
            "Inscrições abrem na próxima segunda-feira com taxas reduzidas.",
            "Direito Administrativo representará 25% do peso total da prova de base.",
            "Simulado inédito de reta final liberado em nosso portal."
          ],
          artigos_recommendados: [
            "/blog/como-estudar-lei-seca-sem-dormir",
            "/blog/analise-completa-do-novo-edital-federal"
          ],
          rodape: "Sucesso nos estudos e conte sempre com o apoio da equipe pedagógica PassaCumaru!"
        };

      case "ebook":
        return {
          capa_titulo: "O Guia Secreto dos Concurseiros de Elite",
          capa_subtitulo: "As 7 Técnicas de Memorização e Engenharia Reversa para Dominar Qualquer Edital em Menos de 6 Meses",
          capitulos: [
            {
              numero: 1,
              titulo_capitulo: "A Mentalidade de Elite e a Desconstrução do Edital",
              resumo_conteudo: "Aprenda a analisar os pesos de cada matéria no edital para priorizar os tópicos mais rentáveis em termos de pontos. Técnicas de estudo reverso baseadas em estatísticas de bancas examinadoras."
            },
            {
              numero: 2,
              titulo_capitulo: "O Ciclo de Estudos Inteligente vs. Grade Horária Tradicional",
              resumo_conteudo: "Por que as grades fixas de escola falham para adultos concurseiros. Como organizar o cérebro com ciclos dinâmicos de estudo, revisões espaçadas de 24h/7d/30d e preenchimento de lacunas de erro."
            }
          ]
        };

      case "pagina_categoria":
        return {
          nome_categoria: "Dicas de Estudo e Preparação de Reta Final",
          introducao_seo: "Navegue pelo nosso acervo de matérias dedicadas a turbinar sua preparação física, controle de estresse, cronogramas de estudo estratégico de reta final e técnicas de chute consciente para o dia da prova.",
          subcategorias: ["Técnicas de Memorização", "Controle de Ansiedade", "Planejamento de Estudos"],
          links_silo_recomendados: [
            "/categoria/dicas-de-estudo/metodos-revisao",
            "/categoria/dicas-de-estudo/simulados-comentados"
          ]
        };

      default:
        return {
          titulo: titulo,
          descricao: `Ativo estruturado para '${titulo}'.`,
          contexto: "Gerado automaticamente por engine pedagógica."
        };
    }
  }

  /**
   * Retorna os tipos de ativos configurados em asset-types.json.
   */
  public static getAssetTypesConfig(): any[] {
    try {
      const data = fs.readFileSync(path.join(process.cwd(), "organic-traffic-os/assets/library/asset-types.json"), "utf-8");
      return JSON.parse(data).types || [];
    } catch (e) {
      console.error("Erro ao ler tipos de ativos:", e);
      return [];
    }
  }

  /**
   * Retorna todos os ativos armazenados na biblioteca asset.json.
   */
  public static getAssets(): Asset[] {
    try {
      if (fs.existsSync(this.assetsFilePath)) {
        const raw = fs.readFileSync(this.assetsFilePath, "utf-8");
        return JSON.parse(raw || "[]");
      }
    } catch (e) {
      console.error("Erro ao ler biblioteca de ativos:", e);
    }
    return [];
  }

  /**
   * Salva os ativos de volta no arquivo de biblioteca.
   */
  public static saveAssets(assets: Asset[]): void {
    try {
      fs.writeFileSync(this.assetsFilePath, JSON.stringify(assets, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar ativos na biblioteca:", e);
    }
  }

  /**
   * Retorna todas as relações cadastradas.
   */
  public static getRelations(): AssetRelation[] {
    try {
      if (fs.existsSync(this.relationsFilePath)) {
        const raw = fs.readFileSync(this.relationsFilePath, "utf-8");
        const parsed = JSON.parse(raw || "{}");
        return parsed.relations || [];
      }
    } catch (e) {
      console.error("Erro ao ler relações de ativos:", e);
    }
    return [];
  }

  /**
   * Salva as relações cadastrados de volta no arquivo de relações.
   */
  public static saveRelations(relations: AssetRelation[]): void {
    try {
      fs.writeFileSync(this.relationsFilePath, JSON.stringify({ relations }, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar relações de ativos:", e);
    }
  }
}
