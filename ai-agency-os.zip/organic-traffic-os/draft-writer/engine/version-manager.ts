import fs from "fs";
import path from "path";

export interface DraftContent {
  h1: string;
  introducao: string;
  h2: string;
  h3?: string;
  faq: string;
  conclusao: string;
  cta: string;
}

export interface DraftVersion {
  versao: string; // e.g. "1.0.0", "1.1.0"
  data: string;
  modelo_ia: string;
  prompt_utilizado: string;
  tempo_execucao: number;
  conteudo: DraftContent;
  diferencas?: string;
}

const VERSIONS_DIR = path.join(process.cwd(), "organic-traffic-os", "draft-writer", "versions");

function ensureVersionsDirExists() {
  if (!fs.existsSync(VERSIONS_DIR)) {
    fs.mkdirSync(VERSIONS_DIR, { recursive: true });
  }
}

export class VersionManager {
  /**
   * Registers a new version of a draft and computes differences from the previous version.
   */
  public static saveVersion(
    draftId: string,
    versionNum: string,
    modeloIa: string,
    prompt: string,
    tempoExec: number,
    conteudo: DraftContent
  ): DraftVersion {
    ensureVersionsDirExists();

    const previousVersion = this.getLatestVersion(draftId);
    let diferencas = "Primeira versão (Rascunho Inicial)";

    if (previousVersion) {
      diferencas = this.calculateDifferences(previousVersion.conteudo, conteudo);
    }

    const versionRecord: DraftVersion = {
      versao: versionNum,
      data: new Date().toISOString(),
      modelo_ia: modeloIa,
      prompt_utilizado: prompt,
      tempo_execucao: tempoExec,
      conteudo,
      diferencas
    };

    const filePath = path.join(VERSIONS_DIR, `${draftId}-v${versionNum}.json`);
    fs.writeFileSync(filePath, JSON.stringify(versionRecord, null, 2), "utf-8");

    return versionRecord;
  }

  /**
   * Retrieves all saved versions for a specific draft.
   */
  public static getVersions(draftId: string): DraftVersion[] {
    ensureVersionsDirExists();
    try {
      const files = fs.readdirSync(VERSIONS_DIR).filter(f => f.startsWith(`${draftId}-v`) && f.endsWith(".json"));
      const versions: DraftVersion[] = [];

      files.forEach(f => {
        try {
          const raw = fs.readFileSync(path.join(VERSIONS_DIR, f), "utf-8");
          versions.push(JSON.parse(raw));
        } catch (e) {
          console.error(`Erro ao carregar arquivo de versão ${f}:`, e);
        }
      });

      // Sort by version descending or date descending
      return versions.sort((a, b) => b.versao.localeCompare(a.versao, undefined, { numeric: true, sensitivity: 'base' }));
    } catch (err) {
      console.error("Erro ao listar versões:", err);
      return [];
    }
  }

  /**
   * Returns the most recent version of a draft, if any exists.
   */
  public static getLatestVersion(draftId: string): DraftVersion | null {
    const list = this.getVersions(draftId);
    return list.length > 0 ? list[0] : null;
  }

  /**
   * Computes a friendly human-readable summary of differences between two drafts.
   */
  public static calculateDifferences(prev: DraftContent, current: DraftContent): string {
    const diffs: string[] = [];

    // Title diff
    if (prev.h1 !== current.h1) {
      diffs.push(`Título modificado: de "${prev.h1}" para "${current.h1}".`);
    }

    // Section word-count comparison helper
    const checkSecDiff = (name: string, prevText: string, currText: string) => {
      const pCount = (prevText || "").trim().split(/\s+/).filter(Boolean).length;
      const cCount = (currText || "").trim().split(/\s+/).filter(Boolean).length;
      if (pCount !== cCount) {
        const diffCount = cCount - pCount;
        diffs.push(`Seção ${name}: ${diffCount > 0 ? "expandida em" : "reduzida em"} ${Math.abs(diffCount)} palavras (anterior: ${pCount}, atual: ${cCount}).`);
      } else if (prevText !== currText) {
        diffs.push(`Seção ${name}: reescrita sem alteração no volume de palavras.`);
      }
    };

    checkSecDiff("Introdução", prev.introducao, current.introducao);
    checkSecDiff("Desenvolvimento (H2)", prev.h2, current.h2);
    checkSecDiff("Subtópicos (H3)", prev.h3 || "", current.h3 || "");
    checkSecDiff("FAQ", prev.faq, current.faq);
    checkSecDiff("Conclusão", prev.conclusao, current.conclusao);

    // CTA diff
    if (prev.cta !== current.cta) {
      diffs.push("Chamada para ação (CTA) atualizada e otimizada.");
    }

    return diffs.length > 0 ? diffs.join(" ") : "Nenhuma alteração detectada no conteúdo.";
  }
}
