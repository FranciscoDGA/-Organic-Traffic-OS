import { DraftWriterEngine, DraftRecord } from "./draft-writer-engine";
import { VersionManager, DraftVersion, DraftContent } from "./version-manager";
import { DraftValidator, DraftValidationResult } from "../validators/draft-validator";
import { ArchitectService } from "../../content-architecture/engine/architect-service";
import { BriefService } from "../../briefs/brief-engine/brief-engine";

export class DraftService {
  /**
   * Generates a new draft based on brief, blueprint, research pack and strategy configurations.
   */
  public static async generateDraft(
    briefId: string,
    blueprintId: string,
    researchPackId: string,
    strategyId: string,
    blogId: string = "passacumaru"
  ): Promise<DraftRecord> {
    return DraftWriterEngine.generateDraft(briefId, blueprintId, researchPackId, strategyId, blogId);
  }

  /**
   * Retrieves an existing draft record by its ID.
   */
  public static getDraft(id: string): DraftRecord | null {
    return DraftWriterEngine.getDraftById(id);
  }

  /**
   * Retrieves all generated drafts.
   */
  public static getAllDrafts(): DraftRecord[] {
    return DraftWriterEngine.getAllDrafts();
  }

  /**
   * Saves a new historical version of an existing draft, incrementing its version.
   */
  public static saveNewVersion(
    draftId: string,
    autor: string = "Editor de Rascunhos",
    newContent: DraftContent
  ): DraftRecord {
    const existing = DraftWriterEngine.getDraftById(draftId);
    if (!existing) {
      throw new Error(`Rascunho com ID '${draftId}' não encontrado para versionamento.`);
    }

    const currentVersionNum = existing.versao || "1.0.0";
    const parts = currentVersionNum.split(".").map(Number);
    // Increment minor version (e.g., 1.0.0 -> 1.1.0)
    parts[1] = (parts[1] || 0) + 1;
    parts[2] = 0; // reset patch
    const nextVersionNum = parts.join(".");

    const elapsedStart = Date.now();
    
    // Register snapshot in VersionManager
    const savedVersion = VersionManager.saveVersion(
      draftId,
      nextVersionNum,
      existing.modelo_ia,
      `Revisão manual por ${autor}`,
      0.1, // mock quick saving execution time
      newContent
    );

    // Re-validate against blueprint & brief if they exist
    const blueprint = ArchitectService.getBlueprint(existing.blueprint_id);
    const brief = BriefService.getBrief(existing.brief_id);
    const auditResult = DraftValidator.validate(newContent, blueprint, brief);

    const updatedRecord: DraftRecord = {
      ...existing,
      versao: nextVersionNum,
      status: "Revisado",
      conteudo: newContent,
      audit: auditResult,
      tokens_entrada: existing.tokens_entrada, // carry over
      tokens_saida: existing.tokens_saida,
      tempo_execucao: parseFloat((existing.tempo_execucao + 0.1).toFixed(2))
    };

    DraftWriterEngine.saveDraftRecord(updatedRecord);
    return updatedRecord;
  }

  /**
   * Lists all historical versions of a draft.
   */
  public static getDraftVersions(draftId: string): DraftVersion[] {
    return VersionManager.getVersions(draftId);
  }

  /**
   * Deeply compares two versions of a draft and returns a detailed differential report.
   */
  public static compareVersions(draftId: string, versionA: string, versionB: string): {
    versionA: string;
    versionB: string;
    differences: string;
    summary: string;
  } {
    const versions = VersionManager.getVersions(draftId);
    const vA = versions.find(v => v.versao === versionA);
    const vB = versions.find(v => v.versao === versionB);

    if (!vA || !vB) {
      throw new Error(`As versões especificadas (${versionA}, ${versionB}) não foram localizadas para o rascunho '${draftId}'.`);
    }

    const differences = VersionManager.calculateDifferences(vA.conteudo, vB.conteudo);

    return {
      versionA,
      versionB,
      differences,
      summary: `Comparação das seções entre v${versionA} e v${versionB}.`
    };
  }
}
