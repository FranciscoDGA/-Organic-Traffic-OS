import { ContentBlueprint } from "../../content-architecture/models/blueprint-models";
import { EditorialBrief } from "../../briefs/models/brief-models";

export interface DraftValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  score: number; // 0 - 100
  checks: {
    secoes_completas: boolean;
    blueprint_seguido: boolean;
    entidades_presentes: string[];
    entidades_faltantes: string[];
    perguntas_respondidas: string[];
    perguntas_faltantes: string[];
    cta_valido: boolean;
  };
}

export class DraftValidator {
  /**
   * Performs deep verification on a draft content against its blueprint, brief, and strategic objectives.
   */
  public static validate(
    conteudo: {
      h1: string;
      introducao: string;
      h2: string;
      h3?: string;
      faq: string;
      conclusao: string;
      cta: string;
    },
    blueprint: ContentBlueprint | null,
    brief: EditorialBrief | null
  ): DraftValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    
    const checks = {
      secoes_completas: true,
      blueprint_seguido: true,
      entidades_presentes: [] as string[],
      entidades_faltantes: [] as string[],
      perguntas_respondidas: [] as string[],
      perguntas_faltantes: [] as string[],
      cta_valido: true
    };

    // 1. Check sections presence
    const requiredSections = {
      h1: "H1 / Título",
      introducao: "Introdução",
      h2: "H2 / Desenvolvimento",
      faq: "FAQ",
      conclusao: "Conclusão",
      cta: "CTA (Call to Action)"
    };

    let totalLength = 0;
    const fullTextParts: string[] = [];

    for (const [key, label] of Object.entries(requiredSections)) {
      const val = conteudo[key as keyof typeof requiredSections] || "";
      fullTextParts.push(val);
      if (!val || val.trim().length < 10) {
        errors.push(`A seção obrigatória '${label}' está vazia ou é curta demais.`);
        checks.secoes_completas = false;
      } else {
        totalLength += val.trim().split(/\s+/).length;
      }
    }

    if (conteudo.h3) {
      fullTextParts.push(conteudo.h3);
      totalLength += conteudo.h3.trim().split(/\s+/).length;
    }

    const fullText = fullTextParts.join(" ").toLowerCase();

    // 2. Blueprint checks (heading structure and suggestions)
    if (blueprint) {
      if (blueprint.estrutura && blueprint.estrutura.length > 0) {
        let matchedCount = 0;
        blueprint.estrutura.forEach(sec => {
          // Normalize section title
          const titleLower = sec.titulo.toLowerCase();
          // Check if section title is referenced or present in draft content
          if (fullText.includes(titleLower) || titleLower.split(/\s+/).some(w => w.length > 3 && fullText.includes(w))) {
            matchedCount++;
          }
        });

        const percentMatched = (matchedCount / blueprint.estrutura.length) * 100;
        if (percentMatched < 50) {
          warnings.push(`O rascunho seguiu apenas ${Math.round(percentMatched)}% da estrutura definida no Blueprint.`);
          checks.blueprint_seguido = false;
        }
      } else {
        warnings.push("O Blueprint fornecido não contém uma estrutura de seções configurada.");
      }
    } else {
      warnings.push("Blueprint ausente para validação estrutural estrita.");
      checks.blueprint_seguido = false;
    }

    // 3. Entities checking (E-A-T and Search Relevance)
    let targetEntities: string[] = [];
    if (brief && brief.entities && brief.entities.entidades_obrigatorias) {
      targetEntities = brief.entities.entidades_obrigatorias;
    } else if (blueprint && blueprint.componentes) {
      // Fallback: extract entities suggested in components
      targetEntities = blueprint.componentes.map(c => c.nome);
    }

    if (targetEntities.length > 0) {
      targetEntities.forEach(ent => {
        const entLower = ent.toLowerCase();
        if (fullText.includes(entLower)) {
          checks.entidades_presentes.push(ent);
        } else {
          checks.entidades_faltantes.push(ent);
        }
      });

      if (checks.entidades_faltantes.length > 0) {
        warnings.push(`Entidades obrigatórias ausentes no texto: ${checks.entidades_faltantes.join(", ")}`);
      }
    } else {
      // Add general placeholder verification to show functional E-A-T scanning
      const standardTechEntities = ["seo", "autoridade", "conteúdo", "conversão"];
      standardTechEntities.forEach(ent => {
        if (fullText.includes(ent)) {
          checks.entidades_presentes.push(ent);
        } else {
          checks.entidades_faltantes.push(ent);
        }
      });
    }

    // 4. Questions checking (SERP optimization)
    let targetQuestions: string[] = [];
    if (brief && brief.questions && brief.questions.perguntas_obrigatorias) {
      targetQuestions = brief.questions.perguntas_obrigatorias;
    }

    if (targetQuestions.length > 0) {
      targetQuestions.forEach(q => {
        const qClean = q.replace(/[?¿!¡]/g, "").toLowerCase().trim();
        // Check if question keywords or whole question is in draft
        const words = qClean.split(/\s+/).filter(w => w.length > 3);
        const matchScore = words.filter(w => fullText.includes(w)).length / words.length;
        
        if (matchScore >= 0.4 || fullText.includes(qClean)) {
          checks.perguntas_respondidas.push(q);
        } else {
          checks.perguntas_faltantes.push(q);
        }
      });

      if (checks.perguntas_faltantes.length > 0) {
        warnings.push(`Perguntas obrigatórias da SERP não respondidas: ${checks.perguntas_faltantes.slice(0, 3).join(", ")}`);
      }
    }

    // 5. CTA check
    if (!conteudo.cta || conteudo.cta.trim().length < 15) {
      errors.push("O CTA (Call to Action) está ausente ou é curto demais para gerar conversões.");
      checks.cta_valido = false;
    } else {
      // Standard strategic CTA checklist: must contain a call or action-driven context
      const strongVerbs = ["inscreva-se", "demonstração", "agende", "clique", "descubra", "baixe", "acesse", "fale", "teste", "conheça", "solicite", "comece"];
      const ctaLower = conteudo.cta.toLowerCase();
      const hasActionVerb = strongVerbs.some(verb => ctaLower.includes(verb));
      if (!hasActionVerb) {
        warnings.push("O CTA não parece conter verbos de ação direta recomendados para conversão.");
      }
    }

    // Calculate score
    let score = 100;
    score -= errors.length * 15;
    score -= warnings.length * 5;
    score -= checks.entidades_faltantes.length * 3;
    score -= checks.perguntas_faltantes.length * 4;
    score = Math.max(0, Math.min(100, score));

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      score,
      checks
    };
  }
}
