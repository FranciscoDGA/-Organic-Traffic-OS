import { GoogleGenAI, Type } from "@google/genai";
import { AudienceValidator } from "../validators/audience-validator";
import * as fs from "fs";
import * as path from "path";

// Lazily initialized Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

export interface AdaptationReport {
  id: string;
  draft_id: string;
  persona: string;
  nivel_tecnico: string;
  tom_atual: string;
  tom_recomendado: string;
  clareza: number;
  didatica: number;
  score: number;
  status: "Adequado" | "Requer Adaptação" | "Pendente";
  observacoes: string;
  recomendacoes: string[];
  scores_detalhados: {
    adequacao_ao_publico: number;
    clareza: number;
    didatica: number;
    tom_de_voz: number;
    consistencia: number;
    engajamento_potencial: number;
  };
  regras_validadas: Array<{
    ruleId: string;
    nome: string;
    pass: boolean;
    feedback: string;
  }>;
  data: string;
}

export class AudienceAdaptationEngine {
  /**
   * Executa a análise profunda de adequação ao público usando Inteligência Artificial (Gemini)
   * com fallback estruturado caso a API key não esteja disponível.
   */
  public static async analyzeDraft(
    draftId: string,
    title: string,
    content: string,
    personaId: string,
    qualityReportSummary?: string,
    knowledgeCoreContext?: string
  ): Promise<AdaptationReport> {
    const reportId = `ADAPT-REP-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    // 1. Carregar Regras e Pesos Locais para passar de contexto à IA
    let rawRules = "[]";
    let rawScores = "{}";
    let rawPersonas = "[]";

    try {
      const rulesPath = path.join(process.cwd(), "organic-traffic-os/audience-adaptation/rules/adaptation-rules.json");
      const scoresPath = path.join(process.cwd(), "organic-traffic-os/audience-adaptation/rules/adaptation-scores.json");
      const personasPath = path.join(process.cwd(), "organic-traffic-os/audience-adaptation/personas/personas.json");

      if (fs.existsSync(rulesPath)) rawRules = fs.readFileSync(rulesPath, "utf-8");
      if (fs.existsSync(scoresPath)) rawScores = fs.readFileSync(scoresPath, "utf-8");
      if (fs.existsSync(personasPath)) rawPersonas = fs.readFileSync(personasPath, "utf-8");
    } catch (e) {
      console.warn("Aviso ao ler arquivos de configuração do Audience Engine:", e);
    }

    const parsedPersonas = JSON.parse(rawPersonas).personas || [];
    const persona = parsedPersonas.find((p: any) => p.id === personaId) || {
      id: personaId,
      nome: "Leitor Geral Cumaru",
      nivel_tecnico: "Médio",
      tom_ideal: "Didático, direto e empático",
      descricao: "Morador ou interessado nas novidades e regras de Cumaru.",
      regras_foco: ["ADAPT-001", "ADAPT-004"]
    };

    // 2. Tentar rodar com o Gemini se configurado
    const ai = getGeminiClient();
    if (ai) {
      try {
        const systemPrompt = `Você é o Auditor Editorial Sênior do 'PassaCumaru', especializado em adequação de linguagem e Audience Adaptation.
Sua missão é avaliar se o Rascunho de Artigo fornecido se comunica perfeitamente com a Persona alvo descrita.
NÃO reescreva o texto. Seu único papel é avaliar clinicamente as dimensões de performance, validar as regras e emitir um Plano de Adaptação estruturado (recomendações específicas).

Siga os pesos de cálculo de score informados no JSON de critérios abaixo.
Gere a resposta rigorosamente no formato JSON com os campos correspondentes à interface AdaptationReport especificada.

Critérios e Pesos:
${rawScores}

Regras Estritas de Qualidade:
${rawRules}

Persona Alvo:
${JSON.stringify(persona, null, 2)}

Contexto do Knowledge Core:
${knowledgeCoreContext || "Nenhum contexto extra fornecido."}

Último Laudo de Qualidade (Quality Report Summary):
${qualityReportSummary || "Nenhum laudo anterior fornecido."}`;

        const userPrompt = `Por favor, analise o seguinte artigo rascunhado:

Título: ${title}
Rascunho de Texto:
"""
${content}
"""

Responda EXCLUSIVAMENTE em formato JSON que obedeça à estrutura:
{
  "nivel_tecnico": "Baixo | Médio | Alto",
  "tom_atual": "string (descrição do tom do rascunho atual)",
  "tom_recomendado": "string (descrição do tom ideal para a persona)",
  "clareza": 0-100,
  "didatica": 0-100,
  "score": 0-100 (computado baseando-se nos pesos das dimensões de performance),
  "status": "Adequado" | "Requer Adaptação",
  "observacoes": "string (crítica editorial sincera e detalhada)",
  "recomendacoes": [
    "string (recomendações de ajustes detalhados e acionáveis)"
  ],
  "scores_detalhados": {
    "adequacao_ao_publico": 0-100,
    "clareza": 0-100,
    "didatica": 0-100,
    "tom_de_voz": 0-100,
    "consistencia": 0-100,
    "engajamento_potencial": 0-100
  },
  "regras_validadas": [
    {
      "ruleId": "string (ADAPT-001, etc.)",
      "nome": "string",
      "pass": true | false,
      "feedback": "string (por que passou ou falhou detalhadamente)"
    }
  ]
}`;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: userPrompt,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json"
          }
        });

        const cleanJson = response.text?.trim() || "{}";
        const result = JSON.parse(cleanJson);

        return {
          id: reportId,
          draft_id: draftId,
          persona: personaId,
          nivel_tecnico: result.nivel_tecnico || "Médio",
          tom_atual: result.tom_atual || "Formal",
          tom_recomendado: result.tom_recomendado || persona.tom_ideal,
          clareza: typeof result.clareza === "number" ? result.clareza : 75,
          didatica: typeof result.didatica === "number" ? result.didatica : 75,
          score: typeof result.score === "number" ? result.score : 70,
          status: result.status || "Requer Adaptação",
          observacoes: result.observacoes || "Análise concluída pelo motor inteligente.",
          recomendacoes: Array.isArray(result.recomendacoes) ? result.recomendacoes : [],
          scores_detalhados: result.scores_detalhados || {
            adequacao_ao_publico: 70,
            clareza: 70,
            didatica: 70,
            tom_de_voz: 70,
            consistencia: 70,
            engajamento_potencial: 70
          },
          regras_validadas: Array.isArray(result.regras_validadas) ? result.regras_validadas : [],
          data: now
        };

      } catch (err) {
        console.error("Erro ao chamar o Gemini no Audience Engine, executando fallback:", err);
      }
    }

    // 3. Fallback determinístico offline (AudienceValidator + heurística estruturada)
    const valResult = AudienceValidator.validate(content, personaId, persona.tom_ideal, persona.nivel_tecnico);

    // Calcular notas locais simuladas baseadas nas validações
    const clarezaScore = valResult.details.structureCheck.longParagraphs > 0 ? 70 : 90;
    const didaticaScore = valResult.details.toneMatch;
    const adequacaoScore = valResult.details.techLevelMatch;

    const score = Math.round(
      (adequacaoScore * 25 + clarezaScore * 20 + didaticaScore * 20 + 80 * 15 + 85 * 10 + 75 * 10) / 100
    );

    const status = score >= 80 && valResult.valid ? "Adequado" : "Requer Adaptação";

    // Criar as regras validadas dinamicamente
    const parsedRules = JSON.parse(rawRules).rules || [];
    const regrasValidadas = parsedRules.map((rule: any) => {
      let pass = true;
      let feedback = "Aprovado: O texto cumpre a regra de forma satisfatória.";

      if (rule.id === "ADAPT-001" && personaId === "concurseiro-iniciante") {
        const hasTechnicalTerms = content.toLowerCase().includes("erga omnes") || content.toLowerCase().includes("jurisprudência");
        const hasExplanations = content.toLowerCase().includes("ou seja") || content.toLowerCase().includes("significa") || content.toLowerCase().includes("exemplo");
        if (hasTechnicalTerms && !hasExplanations) {
          pass = false;
          feedback = "Falhou: Termos técnicos avançados foram identificados sem as devidas conexões didáticas.";
        }
      }

      if (rule.id === "ADAPT-002" && (personaId === "concurseiro-iniciante" || personaId === "cidadao-comum")) {
        if (content.toLowerCase().includes("outrossim") || content.toLowerCase().includes("concomitante")) {
          pass = false;
          feedback = "Falhou: Presença de jargões obsoletos que atrapalham o leitor comum.";
        }
      }

      if (rule.id === "ADAPT-005") {
        if (valResult.details.structureCheck.longParagraphs > 1) {
          pass = false;
          feedback = `Falhou: Foram encontrados ${valResult.details.structureCheck.longParagraphs} parágrafos excessivamente longos.`;
        }
      }

      return {
        ruleId: rule.id,
        nome: rule.nome,
        pass,
        feedback
      };
    });

    // Recomendações geradas a partir do validador
    const recomendacoes: string[] = [];
    if (valResult.details.structureCheck.longParagraphs > 0) {
      recomendacoes.push("Quebrar os parágrafos com mais de 250 caracteres em blocos menores de 2 ou 3 frases.");
    }
    if (didaticaScore < 80) {
      recomendacoes.push("Tornar o tom mais amigável usando transições de facilitação, como 'vamos entender' ou 'veja como funciona'.");
    }
    if (adequacaoScore < 80) {
      recomendacoes.push("Substituir termos burocráticos ou jargões jurídicos/administrativos por sinônimos claros ou notas de rodapé explicativas.");
    }
    if (content.toLowerCase().indexOf("cumaru") === -1) {
      recomendacoes.push("Ancorar o artigo no cenário de Cumaru, citando a Prefeitura local, secretarias locais ou concursos da região.");
    }

    if (recomendacoes.length === 0) {
      recomendacoes.push("Nenhuma alteração crítica sugerida. O texto está em ótimo patamar para humanização direta.");
    }

    return {
      id: reportId,
      draft_id: draftId,
      persona: personaId,
      nivel_tecnico: adequacaoScore >= 80 ? "Médio" : "Alto",
      tom_atual: didaticaScore >= 80 ? "Didático" : "Muito formal / Acadêmico",
      tom_recomendado: persona.tom_ideal,
      clareza: clarezaScore,
      didatica: didaticaScore,
      score,
      status,
      observacoes: `Análise automatizada de adequação ao público-alvo '${persona.nome}' baseada em critérios estruturais e de tom de voz.`,
      recomendacoes,
      scores_detalhados: {
        adequacao_ao_publico: adequacaoScore,
        clareza: clarezaScore,
        didatica: didaticaScore,
        tom_de_voz: Math.round(didaticaScore * 0.9 + 10),
        consistencia: 85,
        engajamento_potencial: 75
      },
      regras_validadas: regrasValidadas,
      data: now
    };
  }
}
