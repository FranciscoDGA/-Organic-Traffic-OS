import * as fs from "fs";
import * as path from "path";
import { AudienceAdaptationEngine, AdaptationReport } from "./audience-adaptation-engine";

const REPORTS_FILE_PATH = path.join(process.cwd(), "organic-traffic-os/audience-adaptation/reports/adaptation-report.json");

export class AudienceService {
  /**
   * Retorna a lista de todos os relatórios de adaptação salvos.
   */
  public static getAllReports(): AdaptationReport[] {
    try {
      if (fs.existsSync(REPORTS_FILE_PATH)) {
        const fileContent = fs.readFileSync(REPORTS_FILE_PATH, "utf-8");
        return JSON.parse(fileContent) || [];
      }
    } catch (e) {
      console.error("Erro ao ler relatórios de adaptação:", e);
    }
    return [];
  }

  /**
   * Busca um relatório específico por ID.
   */
  public static getReportById(id: string): AdaptationReport | null {
    const reports = this.getAllReports();
    return reports.find((r) => r.id === id) || null;
  }

  /**
   * Salva um relatório de adaptação no banco (arquivo JSON).
   */
  public static saveReport(report: AdaptationReport): void {
    try {
      const reports = this.getAllReports();
      // Se já existir, substitui. Caso contrário, adiciona no topo.
      const index = reports.findIndex((r) => r.id === report.id);
      if (index !== -1) {
        reports[index] = report;
      } else {
        reports.unshift(report);
      }

      fs.writeFileSync(REPORTS_FILE_PATH, JSON.stringify(reports, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar relatório de adaptação:", e);
    }
  }

  /**
   * Executa a análise de um rascunho de artigo e salva o relatório resultante.
   */
  public static async analyzeDraftAndSave(
    draftId: string,
    title: string,
    content: string,
    personaId: string,
    qualityReportSummary?: string,
    knowledgeCoreContext?: string
  ): Promise<AdaptationReport> {
    const report = await AudienceAdaptationEngine.analyzeDraft(
      draftId,
      title,
      content,
      personaId,
      qualityReportSummary,
      knowledgeCoreContext
    );

    this.saveReport(report);
    return report;
  }

  /**
   * Compara duas versões de relatórios de adaptação (ex: uma versão antiga e uma corrigida).
   */
  public static compareReports(report1Id: string, report2Id: string) {
    const r1 = this.getReportById(report1Id);
    const r2 = this.getReportById(report2Id);

    if (!r1 || !r2) {
      throw new Error("Um ou ambos os relatórios para comparação não foram encontrados.");
    }

    const diffScore = r2.score - r1.score;
    const diffClareza = r2.clareza - r1.clareza;
    const diffDidatica = r2.didatica - r1.didatica;

    const metricsDiff: Record<string, number> = {};
    const keys = Object.keys(r1.scores_detalhados) as Array<keyof typeof r1.scores_detalhados>;
    keys.forEach((key) => {
      metricsDiff[key] = (r2.scores_detalhados[key] || 0) - (r1.scores_detalhados[key] || 0);
    });

    return {
      report1: { id: r1.id, score: r1.score, status: r1.status, data: r1.data },
      report2: { id: r2.id, score: r2.score, status: r2.status, data: r2.data },
      differences: {
        score_geral: diffScore,
        clareza: diffClareza,
        didatica: diffDidatica,
        metrics: metricsDiff
      }
    };
  }
}
