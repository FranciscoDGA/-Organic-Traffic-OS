export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  details: {
    personaValid: boolean;
    toneMatch: number; // 0 to 100
    techLevelMatch: number; // 0 to 100
    structureCheck: {
      longParagraphs: number;
      wordCount: number;
      paragraphsCount: number;
    };
  };
}

export class AudienceValidator {
  /**
   * Valida se o rascunho de texto está adequado à persona selecionada e cumpre os requisitos estruturais básicos.
   */
  public static validate(
    text: string,
    personaId: string,
    expectedTone: string,
    expectedTechLevel: string
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 1. Validar presença do texto
    if (!text || text.trim().length < 50) {
      errors.push("Rascunho muito curto ou vazio para validação de público.");
    }

    // 2. Validar Persona informada
    const validPersonas = ["concurseiro-iniciante", "concurseiro-avancado", "cidadao-comum"];
    const personaValid = validPersonas.includes(personaId);
    if (!personaValid) {
      errors.push(`Persona informada '${personaId}' não é reconhecida no sistema.`);
    }

    // 3. Estrutura - Conta parágrafos e parágrafos longos
    const paragraphs = text.split(/\n+/).map(p => p.trim()).filter(Boolean);
    let longParagraphs = 0;
    paragraphs.forEach((p) => {
      // Considera parágrafo longo se tiver mais de 250 caracteres
      if (p.length > 250) {
        longParagraphs++;
      }
    });

    const wordCount = text.split(/\s+/).filter(Boolean).length;

    // Critérios estruturais baseados na Persona
    if (personaId === "concurseiro-iniciante" || personaId === "cidadao-comum") {
      if (longParagraphs > 1) {
        warnings.push(`Detectamos ${longParagraphs} parágrafos longos. Rascunhos para iniciantes devem ter parágrafos mais curtos para melhor leitura móvel.`);
      }
    }

    // 4. Estimativa básica de nível técnico (heurística offline pré-AI)
    // Jargões típicos que aumentam complexidade jurídica/técnica
    const complexTerms = [
      "erga omnes", "jurisprudência", "dever constitucional", "mandato de segurança", 
      "autotutela", "discricionariedade", "vício de iniciativa", "vincularidade", 
      "supra-mencionado", "outrossim", "concomitante", "supracitado"
    ];

    let complexTermMatches = 0;
    complexTerms.forEach((term) => {
      const regex = new RegExp(`\\b${term}\\b`, "gi");
      const matches = text.match(regex);
      if (matches) {
        complexTermMatches += matches.length;
      }
    });

    let detectedTechLevel = "Baixo";
    if (complexTermMatches > 4) {
      detectedTechLevel = "Alto";
    } else if (complexTermMatches > 1) {
      detectedTechLevel = "Médio";
    }

    let techLevelMatch = 100;
    if (expectedTechLevel === "Baixo" && detectedTechLevel === "Alto") {
      techLevelMatch = 40;
      errors.push("Nível técnico detectado é muito alto para um público iniciante. Remova ou explique os jargões.");
    } else if (expectedTechLevel === "Baixo" && detectedTechLevel === "Médio") {
      techLevelMatch = 75;
      warnings.push("Nível técnico do texto está levemente elevado. Considere simplificar alguns termos.");
    } else if (expectedTechLevel === "Alto" && detectedTechLevel === "Baixo") {
      techLevelMatch = 60;
      warnings.push("O texto parece excessivamente simplório para um concurseiro avançado. Adicione embasamentos ou referências da lei.");
    }

    // 5. Verificação de Tom de Voz
    // Tom empático/didático vs objetivo/corporativo
    const friendlyTerms = ["veja bem", "vamos entender", "para facilitar", "imagine que", "você", "passo a passo", "dica", "exemplo"];
    let friendlyMatches = 0;
    friendlyTerms.forEach((term) => {
      const regex = new RegExp(`\\b${term}\\b`, "gi");
      const matches = text.match(regex);
      if (matches) {
        friendlyMatches += matches.length;
      }
    });

    let toneMatch = 100;
    if (expectedTone.toLowerCase().includes("didático") || expectedTone.toLowerCase().includes("acolhedor")) {
      if (friendlyMatches < 2) {
        toneMatch = 50;
        warnings.push("O tom atual parece muito formal ou impessoal. Adicione palavras de conexão mais amigáveis e acolhedoras.");
      }
    }

    const valid = errors.length === 0;

    return {
      valid,
      errors,
      warnings,
      details: {
        personaValid,
        toneMatch,
        techLevelMatch,
        structureCheck: {
          longParagraphs,
          wordCount,
          paragraphsCount: paragraphs.length,
        },
      },
    };
  }
}
