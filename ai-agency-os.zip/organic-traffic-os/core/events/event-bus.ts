import { CoreEvent, CoreLayer } from "../types";
import { AppLogger } from "../logs/app-logger";

export class EventBus {
  private static listeners: Map<string, Array<(event: CoreEvent) => void>> = new Map();

  static on(eventName: string, callback: (event: CoreEvent) => void) {
    if (!this.listeners.has(eventName)) {
      this.listeners.set(eventName, []);
    }
    this.listeners.get(eventName)!.push(callback);
  }

  static emit(eventName: string, layer: CoreLayer, sourceId: string, payload: any) {
    const event: CoreEvent = {
      id: `evt-${Math.random().toString(36).substring(2, 11)}`,
      timestamp: new Date().toISOString(),
      name: eventName,
      layer,
      sourceId,
      payload
    };
    
    AppLogger.log('INFO', layer, sourceId, `Evento emitido: ${eventName}`, payload);
    const callbacks = this.listeners.get(eventName) || [];
    for (const cb of callbacks) {
      try {
        cb(event);
      } catch (err) {
        console.error(`Erro ao disparar callback de evento '${eventName}':`, err);
      }
    }
  }
}
