import { LogSeverity, AppLogger } from "../common";

export interface CacheEntry<T = any> {
  key: string;
  data: T;
  timestamp: string;
  ttlMs: number;
}

export class KnowledgeCache {
  private static cache: Map<string, CacheEntry> = new Map();

  static set<T>(key: string, data: T, ttlMs = 600000): void {
    const entry: CacheEntry<T> = {
      key,
      data,
      timestamp: new Date().toISOString(),
      ttlMs
    };
    this.cache.set(key, entry);
    AppLogger.log(
      LogSeverity.DEBUG,
      "KNOWLEDGE",
      "cache",
      `Entrada de cache gravada para chave '${key}'. TTL: ${ttlMs}ms`
    );
  }

  static get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    const entryTime = new Date(entry.timestamp).getTime();
    if (Date.now() - entryTime > entry.ttlMs) {
      AppLogger.log(
        LogSeverity.DEBUG,
        "KNOWLEDGE",
        "cache",
        `Entrada de cache expirada para chave '${key}'`
      );
      this.cache.delete(key);
      return null;
    }

    AppLogger.log(
      LogSeverity.DEBUG,
      "KNOWLEDGE",
      "cache",
      `Hit de cache obtido com sucesso para chave '${key}'`
    );
    return entry.data as T;
  }

  static clear(): void {
    this.cache.clear();
    AppLogger.log(
      LogSeverity.INFO,
      "KNOWLEDGE",
      "cache",
      "Cache de conhecimento limpo completamente"
    );
  }
}
