import { KnowledgeRegistry } from "./knowledge-registry";
import { KnowledgeContext } from "./knowledge-context";
import { KnowledgeIndex } from "./knowledge-index";
import { LogSeverity, AppLogger, CoreException } from "../common";

export class KnowledgeLoader {
  static async loadProvider(id: string, context: KnowledgeContext): Promise<boolean> {
    const provider = KnowledgeRegistry.get(id);
    if (!provider) {
      throw new CoreException(`Provedor de Conhecimento '${id}' não encontrado no Registro.`, "knowledge", "ERR_KNOWLEDGE_PROVIDER_NOT_FOUND");
    }

    try {
      const success = await provider.load(context);
      return success;
    } catch (err: any) {
      throw new CoreException(
        `Falha ao carregar provedor de conhecimento '${id}': ${err.message}`,
        "knowledge",
        "ERR_KNOWLEDGE_LOAD_FAILED",
        err
      );
    }
  }

  static async fetchAllIndexes(): Promise<KnowledgeIndex[]> {
    const providers = KnowledgeRegistry.list();
    let aggregated: KnowledgeIndex[] = [];

    for (const p of providers) {
      try {
        const indexes = await p.getIndexes();
        aggregated = aggregated.concat(indexes);
      } catch (err: any) {
        AppLogger.log(
          LogSeverity.ERROR,
          "knowledge",
          p.id,
          `Erro ao carregar índices do provedor '${p.id}': ${err.message}`
        );
      }
    }

    return aggregated;
  }
}
