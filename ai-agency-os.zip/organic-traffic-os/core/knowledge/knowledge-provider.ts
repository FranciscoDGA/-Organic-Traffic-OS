import { LogSeverity, AppLogger, EventDispatcher } from "../common";
import { KnowledgeContext } from "./knowledge-context";
import { KnowledgeIndex } from "./knowledge-index";
import { KnowledgeResolver } from "./knowledge-resolver";

export abstract class KnowledgeProvider implements KnowledgeResolver {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;

  protected context: KnowledgeContext | null = null;
  protected isLoaded = false;

  async load(context: KnowledgeContext): Promise<boolean> {
    this.context = context;
    this.isLoaded = true;
    AppLogger.log(
      LogSeverity.INFO,
      "knowledge",
      this.id,
      `Provedor de Conhecimento '${this.name}' carregado para o escopo '${context.scope}'`
    );
    EventDispatcher.emit("knowledge:loaded", "knowledge", this.id, {
      providerId: this.id,
      scope: context.scope
    });
    return true;
  }

  abstract validate(): Promise<boolean>;
  abstract resolve(query: string, limit?: number): Promise<any[]>;
  abstract getIndexes(): Promise<KnowledgeIndex[]>;
}
