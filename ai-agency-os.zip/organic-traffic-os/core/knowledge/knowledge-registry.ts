import { KnowledgeProvider } from "./knowledge-provider";
import { LogSeverity, AppLogger } from "../common";

export class KnowledgeRegistry {
  private static providers: Map<string, KnowledgeProvider> = new Map();

  static register(provider: KnowledgeProvider): void {
    if (this.providers.has(provider.id)) {
      AppLogger.log(
        LogSeverity.WARNING,
        "KNOWLEDGE",
        provider.id,
        `Tentativa de registrar Provedor de Conhecimento duplicado '${provider.id}'. Substituindo.`
      );
    }
    this.providers.set(provider.id, provider);
    AppLogger.log(
      LogSeverity.INFO,
      "KNOWLEDGE",
      provider.id,
      `Provedor de Conhecimento '${provider.name}' [v${provider.version}] registrado com sucesso.`
    );
  }

  static get(id: string): KnowledgeProvider | undefined {
    return this.providers.get(id);
  }

  static list(): KnowledgeProvider[] {
    return Array.from(this.providers.values());
  }

  static clear(): void {
    this.providers.clear();
  }
}
