export interface KnowledgeResolver<T = any> {
  resolve(query: string, limit?: number): Promise<T[]>;
}
