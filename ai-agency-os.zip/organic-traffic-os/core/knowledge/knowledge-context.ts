export interface KnowledgeContext {
  userId?: string;
  projectId?: string;
  scope: string;
  tags?: string[];
  lastSync?: string;
}
