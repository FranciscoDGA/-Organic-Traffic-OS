import { KnowledgeProvider } from "./knowledge-provider";
import { KnowledgeIndex } from "./knowledge-index";

export class MockKnowledgeProvider extends KnowledgeProvider {
  readonly id: string;
  readonly name: string;
  readonly version = "1.0.0";

  private mockIndexes: KnowledgeIndex[] = [
    {
      documentId: "doc-cumaru-history",
      title: "Histórico Político e Social de Cumaru do Norte",
      summary: "Informações sobre criação do município, demografia e principais cargos públicos.",
      sourceType: "file",
      tags: ["cumaru", "historia", "concursos"],
      lastUpdated: new Date().toISOString()
    },
    {
      documentId: "doc-concurso-cumaru-rules",
      title: "Edital Consolidado de Concursos do Norte 2026",
      summary: "Regras gerais sobre as vagas abertas na Prefeitura de Cumaru do Norte.",
      sourceType: "database",
      tags: ["edital", "prefeitura", "cumaru"],
      lastUpdated: new Date().toISOString()
    }
  ];

  constructor(id: string, name: string) {
    super();
    this.id = id;
    this.name = name;
  }

  async validate(): Promise<boolean> {
    return true;
  }

  async getIndexes(): Promise<KnowledgeIndex[]> {
    return this.mockIndexes;
  }

  async resolve(query: string, limit = 5): Promise<any[]> {
    return this.mockIndexes
      .filter(idx => idx.title.toLowerCase().includes(query.toLowerCase()) || idx.tags.some(t => t.includes(query.toLowerCase())))
      .slice(0, limit);
  }
}
