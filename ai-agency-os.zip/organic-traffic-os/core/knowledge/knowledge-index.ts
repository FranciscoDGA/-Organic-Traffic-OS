export interface KnowledgeIndex {
  documentId: string;
  title: string;
  summary?: string;
  sourceType: "file" | "database" | "api" | "sitemap" | "competitor";
  tags: string[];
  tokensCount?: number;
  lastUpdated: string;
}
