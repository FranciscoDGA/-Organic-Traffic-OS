export interface EngineContext {
  modelName: string;
  temperature: number;
  maxTokens: number;
  systemInstruction?: string;
  additionalParams?: Record<string, any>;
}
