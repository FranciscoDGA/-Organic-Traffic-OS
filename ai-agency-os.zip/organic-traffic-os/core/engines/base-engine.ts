import { LogSeverity, AppLogger, EventDispatcher } from "../common";
import { EngineContext } from "./engine-context";
import { EngineResult } from "./engine-result";
import { CoreStatus } from "../types";

export abstract class BaseEngine {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;
  public status: CoreStatus = "idle";

  protected context: EngineContext | null = null;
  protected isInitialized = false;

  async initialize(context: EngineContext): Promise<boolean> {
    this.context = context;
    this.isInitialized = true;
    this.status = "active";
    AppLogger.log(
      LogSeverity.INFO,
      "engines",
      this.id,
      `Motor (Engine) '${this.name}' inicializado com modelo '${context.modelName}'`
    );
    EventDispatcher.emit("engine:initialized", "engines", this.id, {
      engineId: this.id,
      modelName: context.modelName
    });
    return true;
  }

  // Contract Methods Required by Sprint 26.1
  abstract analyze<T>(input: string, options?: Record<string, any>): Promise<EngineResult<T>>;
  abstract score(input: string, criteria?: Record<string, any>): Promise<number>;
  abstract recommend<T>(input: string, options?: Record<string, any>): Promise<T[]>;
}
