import { BaseEngine } from "./base-engine";
import { LogSeverity, AppLogger } from "../common";

export class EngineRegistry {
  private static engines: Map<string, BaseEngine> = new Map();

  static register(engine: BaseEngine): void {
    if (this.engines.has(engine.id)) {
      AppLogger.log(
        LogSeverity.WARNING,
        "ENGINES",
        engine.id,
        `Tentativa de registrar motor duplicado '${engine.id}'. Substituindo.`
      );
    }
    this.engines.set(engine.id, engine);
    AppLogger.log(
      LogSeverity.INFO,
      "ENGINES",
      engine.id,
      `Motor '${engine.name}' [v${engine.version}] registrado com sucesso.`
    );
  }

  static get(id: string): BaseEngine | undefined {
    return this.engines.get(id);
  }

  static list(): BaseEngine[] {
    return Array.from(this.engines.values());
  }

  static clear(): void {
    this.engines.clear();
  }
}
