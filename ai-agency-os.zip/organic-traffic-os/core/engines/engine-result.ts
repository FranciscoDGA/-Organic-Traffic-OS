export interface EngineResult<T = any> {
  success: boolean;
  timestamp: string;
  output?: T;
  rawText?: string;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    costUsd?: number;
  };
}
