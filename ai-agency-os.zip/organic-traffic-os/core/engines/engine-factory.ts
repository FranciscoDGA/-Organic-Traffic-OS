import { BaseEngine } from "./base-engine";
import { EngineResult } from "./engine-result";
import { EngineRegistry } from "./engine-registry";

export class MockArchitecturalEngine extends BaseEngine {
  readonly id: string;
  readonly name: string;
  readonly version = "1.0.0";

  constructor(id: string, name: string) {
    super();
    this.id = id;
    this.name = name;
  }

  async analyze<T>(input: string, options?: Record<string, any>): Promise<EngineResult<T>> {
    return {
      success: true,
      timestamp: new Date().toISOString(),
      rawText: `Resultado simulado de análise para: ${input}`,
      output: { simulated: true, prompt: input, options } as any,
      usage: {
        promptTokens: Math.round(input.length / 4),
        completionTokens: 20,
        totalTokens: Math.round(input.length / 4) + 20
      }
    };
  }

  async score(input: string, criteria?: Record<string, any>): Promise<number> {
    // Generate a deterministic score between 0 and 100 based on input length
    return Math.min(100, Math.max(0, 50 + (input.length % 51)));
  }

  async recommend<T>(input: string, options?: Record<string, any>): Promise<T[]> {
    return [
      { recommendation: "Otimizar cabeçalho H1 com palavra-chave principal.", priority: "high" } as any,
      { recommendation: "Adicionar tags alternativas (alt) nas imagens do corpo do texto.", priority: "medium" } as any
    ];
  }
}

export class EngineFactory {
  static createAndRegister(id: string, name: string): BaseEngine {
    const engine = new MockArchitecturalEngine(id, name);
    EngineRegistry.register(engine);
    return engine;
  }
}
