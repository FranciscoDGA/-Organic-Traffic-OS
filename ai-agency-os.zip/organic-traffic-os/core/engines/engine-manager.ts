import { EngineRegistry } from "./engine-registry";
import { BaseEngine } from "./base-engine";
import { EngineContext } from "./engine-context";
import { EngineResult } from "./engine-result";
import { LogSeverity, AppLogger, CoreException, EventDispatcher } from "../common";

export class EngineManager {
  private static activeContexts: Map<string, EngineContext> = new Map();

  static async initializeEngine(id: string, context: EngineContext): Promise<boolean> {
    const engine = EngineRegistry.get(id);
    if (!engine) {
      throw new CoreException(`Motor '${id}' não encontrado no Registro.`, "engines", "ERR_ENGINE_NOT_FOUND");
    }

    try {
      const success = await engine.initialize(context);
      if (success) {
        this.activeContexts.set(id, context);
      }
      return success;
    } catch (err: any) {
      throw new CoreException(
        `Falha ao inicializar motor '${id}': ${err.message}`,
        "engines",
        "ERR_ENGINE_INIT_FAILED",
        err
      );
    }
  }

  static async runAnalysis<T>(id: string, input: string, options?: Record<string, any>): Promise<EngineResult<T>> {
    const engine = EngineRegistry.get(id);
    if (!engine) {
      throw new CoreException(`Motor '${id}' não encontrado no Registro.`, "engines", "ERR_ENGINE_NOT_FOUND");
    }

    AppLogger.log(
      LogSeverity.INFO,
      "engines",
      id,
      `Iniciando análise no motor '${id}' para entrada de ${input.length} caracteres.`
    );

    const start = Date.now();
    try {
      const result = await engine.analyze<T>(input, options);
      const elapsedMs = Date.now() - start;

      AppLogger.log(
        result.success ? LogSeverity.INFO : LogSeverity.WARNING,
        "engines",
        id,
        `Análise finalizada no motor '${id}' em ${elapsedMs}ms.`
      );

      EventDispatcher.emit("engine:analyzed", "engines", id, {
        success: result.success,
        elapsedMs,
        usage: result.usage
      });

      return result;
    } catch (err: any) {
      const elapsedMs = Date.now() - start;
      AppLogger.log(
        LogSeverity.ERROR,
        "engines",
        id,
        `Falha na análise do motor '${id}': ${err.message}`
      );
      return {
        success: false,
        timestamp: new Date().toISOString(),
        error: {
          code: "ERR_ENGINE_EXECUTION_FAILED",
          message: err.message,
          details: err
        }
      };
    }
  }

  static getActiveContext(id: string): EngineContext | undefined {
    return this.activeContexts.get(id);
  }
}
