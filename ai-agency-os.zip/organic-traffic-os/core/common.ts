import { AppLogger as NewLogger } from "./logs/app-logger";
import { CoreException as NewException } from "./errors/core-exception";
import { EventBus as NewBus } from "./events/event-bus";
import { CoreLayer } from "./types";

export enum LogSeverity {
  INFO = "INFO",
  WARNING = "WARNING",
  ERROR = "ERROR",
  DEBUG = "DEBUG"
}

export interface LogMessage {
  timestamp: string;
  severity: LogSeverity;
  layer: string;
  sourceId: string;
  message: string;
  meta?: any;
}

export class AppLogger {
  static log(severity: LogSeverity, layer: string, sourceId: string, message: string, meta?: any) {
    NewLogger.log(severity as any, layer as CoreLayer, sourceId, message, meta);
  }

  static getLogs() {
    return NewLogger.getLogs();
  }

  static clearLogs(): void {
    NewLogger.clearLogs();
  }
}

export class CoreException extends NewException {
  constructor(
    message: string,
    layer: string,
    code: string,
    details?: any
  ) {
    super(message, layer as CoreLayer, code, details);
  }
}

export interface AppEvent {
  id: string;
  timestamp: string;
  name: string;
  layer: string;
  sourceId: string;
  payload: any;
}

export class EventDispatcher {
  static on(eventName: string, callback: (event: any) => void) {
    NewBus.on(eventName, callback);
  }

  static emit(eventName: string, layer: string, sourceId: string, payload: any) {
    NewBus.emit(eventName, layer as CoreLayer, sourceId, payload);
  }
}
