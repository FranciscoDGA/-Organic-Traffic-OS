export type CoreLayer = 'connectors' | 'knowledge' | 'engines' | 'agents' | 'workflows' | 'system';

export type CoreStatus = 'idle' | 'running' | 'completed' | 'failed' | 'paused' | 'cancelled' | 'active' | 'inactive' | 'error';

export interface CoreEvent {
  id: string;
  timestamp: string;
  name: string;
  layer: CoreLayer;
  sourceId: string;
  payload: any;
}

export interface CoreError {
  id: string;
  timestamp: string;
  layer: CoreLayer;
  code: string;
  message: string;
  details?: any;
}

export interface CoreLog {
  id: string;
  timestamp: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'DEBUG';
  layer: CoreLayer;
  sourceId: string;
  message: string;
  meta?: any;
}

export interface ConnectorDefinition {
  id: string;
  name: string;
  version: string;
  status: CoreStatus;
}

export interface KnowledgeDefinition {
  id: string;
  name: string;
  version: string;
  status: CoreStatus;
}

export interface EngineDefinition {
  id: string;
  name: string;
  version: string;
  status: CoreStatus;
}

export interface AgentDefinition {
  id: string;
  name: string;
  version: string;
  status: CoreStatus;
}

export interface WorkflowDefinition {
  id: string;
  name: string;
  version: string;
  steps: string[];
  status: CoreStatus;
}

export interface ExecutionContext {
  environment: 'sandbox' | 'production' | 'development';
  userId?: string;
  projectId?: string;
  variables: Record<string, any>;
}

export interface ExecutionResult<T = any> {
  success: boolean;
  timestamp: string;
  output?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  metrics?: {
    durationMs: number;
    tokensUsed?: number;
    costUsd?: number;
  };
}
