import { CoreLayer, CoreError } from "../types";
import { AppLogger } from "../logs/app-logger";

export class CoreException extends Error implements CoreError {
  public id: string;
  public timestamp: string;

  constructor(
    public override message: string,
    public layer: CoreLayer,
    public code: string,
    public details?: any
  ) {
    super(message);
    this.name = "CoreException";
    this.id = `err-${Math.random().toString(36).substring(2, 11)}`;
    this.timestamp = new Date().toISOString();
    
    AppLogger.log('ERROR', layer, code, message, { details, timestamp: this.timestamp });
  }
}
