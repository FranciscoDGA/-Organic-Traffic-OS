import { BaseWorkflow } from "./workflow-manager";
import { LogSeverity, AppLogger } from "../common";

export class WorkflowRegistry {
  private static workflows: Map<string, BaseWorkflow> = new Map();

  static register(workflow: BaseWorkflow): void {
    if (this.workflows.has(workflow.id)) {
      AppLogger.log(
        LogSeverity.WARNING,
        "WORKFLOWS",
        workflow.id,
        `Tentativa de registrar fluxo duplicado '${workflow.id}'. Substituindo.`
      );
    }
    this.workflows.set(workflow.id, workflow);
    AppLogger.log(
      LogSeverity.INFO,
      "WORKFLOWS",
      workflow.id,
      `Fluxo de Trabalho '${workflow.name}' [v${workflow.version}] registrado com sucesso.`
    );
  }

  static get(id: string): BaseWorkflow | undefined {
    return this.workflows.get(id);
  }

  static list(): BaseWorkflow[] {
    return Array.from(this.workflows.values());
  }

  static clear(): void {
    this.workflows.clear();
  }
}
