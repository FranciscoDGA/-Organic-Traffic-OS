import { WorkflowHistory } from "./workflow-history";

export interface WorkflowResult<T = any> {
  success: boolean;
  executionId: string;
  output?: T;
  history: WorkflowHistory[];
  durationMs: number;
  error?: string;
}
