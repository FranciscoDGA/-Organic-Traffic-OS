export interface WorkflowHistory {
  executionId: string;
  workflowId: string;
  stepName: string;
  status: "success" | "failed";
  durationMs: number;
  timestamp: string;
  errorMsg?: string;
}
