import { BaseWorkflow, WorkflowManager } from "./workflow-manager";
import { WorkflowState } from "./workflow-state";
import { WorkflowHistory } from "./workflow-history";
import { WorkflowResult } from "./workflow-result";
import { WorkflowRegistry } from "./workflow-registry";
import { LogSeverity, AppLogger, CoreException } from "../common";

export class WorkflowExecutor {
  static async execute(workflowId: string, initialVariables: Record<string, any> = {}): Promise<WorkflowResult> {
    const workflow = WorkflowRegistry.get(workflowId);
    if (!workflow) {
      throw new CoreException(`Fluxo de Trabalho '${workflowId}' não encontrado no Registro.`, "workflows", "ERR_WORKFLOW_NOT_FOUND");
    }

    // Call the workflow's execute method directly, ensuring single authority
    return workflow.execute(initialVariables);
  }
}

// Register a Mock Architectural Workflow so there is at least one ready to test/view
export class ArchitecturalSanityWorkflow extends BaseWorkflow {
  readonly id = "wf-sanity-check";
  readonly name = "Análise de Sanidade e Coerência Editorial";
  readonly version = "1.0.0";
  readonly steps = [
    "Carregar Dados do Planejamento",
    "Verificar Plágio e IA Slop",
    "Simular Ajuste SEO Adaptativo",
    "Validar Estrutura de Metadados"
  ];

  async execute(initialVariables: Record<string, any> = {}): Promise<WorkflowResult> {
    const executionId = `exe-${Math.random().toString(36).substring(2, 11)}`;
    const history: WorkflowHistory[] = [];
    const startTime = Date.now();

    const state = await this.start(executionId, initialVariables);
    WorkflowManager.registerExecution(state);

    let currentStep = 0;
    let failed = false;
    let errorMsg = "";

    while (currentStep < this.steps.length && !failed) {
      const stepName = this.steps[currentStep];
      AppLogger.log(
        LogSeverity.INFO,
        "workflows",
        this.id,
        `Iniciando Etapa ${currentStep + 1}/${this.steps.length}: '${stepName}'`
      );

      const stepStart = Date.now();
      try {
        const stepResult = await this.runStep(currentStep, state);
        const durationMs = Date.now() - stepStart;

        if (stepResult.success) {
          state.currentStepIndex = currentStep + 1;
          if (stepResult.outputVariables) {
            state.variables = { ...state.variables, ...stepResult.outputVariables };
          }
          history.push({
            executionId,
            workflowId: this.id,
            stepName,
            status: "success",
            durationMs,
            timestamp: new Date().toISOString()
          });
          currentStep++;
        } else {
          failed = true;
          errorMsg = stepResult.error || "Erro desconhecido na etapa.";
          history.push({
            executionId,
            workflowId: this.id,
            stepName,
            status: "failed",
            durationMs,
            timestamp: new Date().toISOString(),
            errorMsg
          });
        }
      } catch (err: any) {
        failed = true;
        errorMsg = err.message || "Exceção inesperada na etapa.";
        history.push({
          executionId,
          workflowId: this.id,
          stepName,
          status: "failed",
          durationMs: Date.now() - stepStart,
          timestamp: new Date().toISOString(),
          errorMsg
        });
      }
    }

    const totalDurationMs = Date.now() - startTime;
    await this.complete(!failed, state.variables, failed ? errorMsg : undefined);
    
    // Update active manager execution state
    WorkflowManager.updateExecutionState(executionId, {
      status: failed ? "failed" : (this.state?.status as any || "completed"),
      endedAt: new Date().toISOString()
    });

    return {
      success: !failed,
      executionId,
      output: state.variables,
      history,
      durationMs: totalDurationMs,
      error: failed ? errorMsg : undefined
    };
  }

  async runStep(stepIndex: number, state: WorkflowState): Promise<{ success: boolean; outputVariables?: Record<string, any>; error?: string }> {
    // Artificial latency for simulation realism
    await new Promise(resolve => setTimeout(resolve, 100));
    return {
      success: true,
      outputVariables: { [`step_${stepIndex}_completed`]: true }
    };
  }
}

// Register the sanity check workflow safely
const existingWf = WorkflowRegistry.get("wf-sanity-check");
if (!existingWf) {
  WorkflowRegistry.register(new ArchitecturalSanityWorkflow());
}
