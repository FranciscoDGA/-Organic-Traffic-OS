import { LogSeverity, AppLogger, EventDispatcher } from "../common";
import { WorkflowState } from "./workflow-state";
import { WorkflowResult } from "./workflow-result";

export abstract class BaseWorkflow {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;
  public abstract readonly steps: string[];

  protected state: WorkflowState | null = null;

  async start(executionId: string, initialVariables: Record<string, any> = {}): Promise<WorkflowState> {
    this.state = {
      workflowId: this.id,
      executionId,
      status: "running",
      currentStepIndex: 0,
      stepsCount: this.steps.length,
      variables: { ...initialVariables },
      startedAt: new Date().toISOString()
    };

    AppLogger.log(
      LogSeverity.INFO,
      "workflows",
      this.id,
      `Fluxo de Trabalho (Workflow) '${this.name}' iniciado. ID Execução: ${executionId}`
    );
    EventDispatcher.emit("workflow:started", "workflows", this.id, {
      workflowId: this.id,
      executionId
    });

    return this.state;
  }

  // Contract Methods Required by Sprint 26.1
  abstract execute(initialVariables: Record<string, any>): Promise<WorkflowResult>;
  
  async pause(): Promise<boolean> {
    if (this.state && this.state.status === "running") {
      this.state.status = "paused";
      AppLogger.log(LogSeverity.INFO, "workflows", this.id, `Workflow '${this.name}' pausado.`);
      return true;
    }
    return false;
  }

  async resume(): Promise<boolean> {
    if (this.state && this.state.status === "paused") {
      this.state.status = "running";
      AppLogger.log(LogSeverity.INFO, "workflows", this.id, `Workflow '${this.name}' retomado.`);
      return true;
    }
    return false;
  }

  async cancel(): Promise<boolean> {
    if (this.state && (this.state.status === "running" || this.state.status === "paused")) {
      this.state.status = "cancelled";
      this.state.endedAt = new Date().toISOString();
      AppLogger.log(LogSeverity.INFO, "workflows", this.id, `Workflow '${this.name}' cancelado.`);
      return true;
    }
    return false;
  }

  abstract runStep(stepIndex: number, state: WorkflowState): Promise<{ success: boolean; outputVariables?: Record<string, any>; error?: string }>;

  async complete(success: boolean, finalOutput?: any, errorMsg?: string): Promise<WorkflowState> {
    if (this.state) {
      this.state.status = success ? "completed" : "failed";
      this.state.endedAt = new Date().toISOString();
      if (finalOutput) {
        this.state.variables["_finalOutput"] = finalOutput;
      }
      if (errorMsg) {
        this.state.variables["_errorMsg"] = errorMsg;
      }
    }

    AppLogger.log(
      success ? LogSeverity.INFO : LogSeverity.ERROR,
      "workflows",
      this.id,
      `Fluxo de Trabalho '${this.name}' finalizado com status: ${this.state?.status}`
    );
    EventDispatcher.emit("workflow:completed", "workflows", this.id, {
      workflowId: this.id,
      executionId: this.state?.executionId,
      status: this.state?.status
    });

    return this.state!;
  }
}

export class WorkflowManager {
  private static activeExecutions: Map<string, WorkflowState> = new Map();

  static registerExecution(state: WorkflowState): void {
    this.activeExecutions.set(state.executionId, state);
  }

  static getExecutionState(executionId: string): WorkflowState | undefined {
    return this.activeExecutions.get(executionId);
  }

  static updateExecutionState(executionId: string, updates: Partial<WorkflowState>): void {
    const existing = this.activeExecutions.get(executionId);
    if (existing) {
      this.activeExecutions.set(executionId, { ...existing, ...updates });
    }
  }

  static listActiveExecutions(): WorkflowState[] {
    return Array.from(this.activeExecutions.values());
  }
}
