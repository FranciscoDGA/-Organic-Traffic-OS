export interface WorkflowState {
  workflowId: string;
  executionId: string;
  status: "idle" | "running" | "completed" | "failed" | "paused" | "cancelled";
  currentStepIndex: number;
  stepsCount: number;
  variables: Record<string, any>;
  startedAt?: string;
  endedAt?: string;
}
