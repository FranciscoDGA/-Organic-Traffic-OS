import { ConnectorFactory } from "./connectors/connector-factory";
import { KnowledgeRegistry } from "./knowledge/knowledge-registry";
import { MockKnowledgeProvider } from "./knowledge/knowledge-provider-mock";
import { EngineFactory } from "./engines/engine-factory";
import { AgentFactory } from "./agents/agent-factory";
import { AgentRegistry } from "./agents/agent-registry";
import { DiscoveryAgent } from "./agents/discovery-agent/discovery-agent";
import { WorkflowRegistry } from "./workflows/workflow-registry";
import { ArchitecturalSanityWorkflow } from "./workflows/workflow-executor";
import { AppLogger, LogSeverity } from "./common";

export function seedArchitecture() {
  AppLogger.log(LogSeverity.INFO, "SYSTEM", "core", "Iniciando semeadura da infraestrutura arquitetural do EPIC 03...");

  // 1. Connectors (Layer 1)
  ConnectorFactory.createAndRegister("conn-google-search-console", "Google Search Console API");
  ConnectorFactory.createAndRegister("conn-google-trends", "Google Trends Platform");
  ConnectorFactory.createAndRegister("conn-bing-webmaster", "Bing Webmaster Pro");
  ConnectorFactory.createAndRegister("conn-manual-entry", "Manual Sheet Importer");

  // 2. Knowledge Providers (Layer 2)
  KnowledgeRegistry.register(new MockKnowledgeProvider("kp-concursos-municipais", "Banco de Concursos Municipais"));
  KnowledgeRegistry.register(new MockKnowledgeProvider("kp-historico-serp", "Logs de Evolução Histórica de SERP"));
  KnowledgeRegistry.register(new MockKnowledgeProvider("kp-diretrizes-seo", "Diretrizes de SEO On-Page da Marca"));

  // 3. Engines (Layer 3)
  EngineFactory.createAndRegister("eng-gemini-2.5-flash", "Gemini 2.5 Flash Engine");
  EngineFactory.createAndRegister("eng-gemini-2.5-pro", "Gemini 2.5 Pro (Precision Editing)");
  EngineFactory.createAndRegister("eng-seo-score-analyzer", "Motor de Regras Estáticas de SEO");

  // 4. Agents (Layer 4)
  AgentFactory.createAndRegister("agt-seo-auditor", "Agente Auditor de SEO");
  AgentFactory.createAndRegister("agt-editorial-copywriter", "Agente Copywriter Editorial");
  AgentFactory.createAndRegister("agt-fact-checker", "Agente Verificador de Fatos de Cumaru");

  // Real functional agent for Sprint 26.2
  const discAgent = new DiscoveryAgent();
  discAgent.initialize({
    agentId: "discovery-agent",
    role: "Editorial Opportunity Finder",
    persona: "SEO Specialist & Cumaru do Norte Contest expert"
  }).then(() => {
    AgentRegistry.register(discAgent);
  }).catch(err => {
    console.error("Failed to initialize DiscoveryAgent in seed:", err);
  });

  // 5. Workflows (Layer 5)
  // Register has been done on file import of ArchitecturalSanityWorkflow, but let's ensure redundancy is safe
  const wf = new ArchitecturalSanityWorkflow();
  if (!WorkflowRegistry.get(wf.id)) {
    WorkflowRegistry.register(wf);
  }

  AppLogger.log(LogSeverity.INFO, "SYSTEM", "core", "Infraestrutura do EPIC 03 semeada com absoluto sucesso!");
}
