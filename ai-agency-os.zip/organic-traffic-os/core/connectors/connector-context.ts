export interface ConnectorContext {
  connectionString?: string;
  authToken?: string;
  additionalHeaders?: Record<string, string>;
  timeoutMs?: number;
  environment: "sandbox" | "production" | "development";
  customConfig?: Record<string, any>;
}
