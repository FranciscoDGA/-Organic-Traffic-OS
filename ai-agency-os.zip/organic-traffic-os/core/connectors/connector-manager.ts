import { ConnectorRegistry } from "./connector-registry";
import { BaseConnector } from "./base-connector";
import { ConnectorContext } from "./connector-context";
import { ConnectorResult } from "./connector-result";
import { LogSeverity, AppLogger, CoreException, EventDispatcher } from "../common";

export class ConnectorManager {
  private static activeContexts: Map<string, ConnectorContext> = new Map();

  static async initializeConnector(id: string, context: ConnectorContext): Promise<boolean> {
    const connector = ConnectorRegistry.get(id);
    if (!connector) {
      throw new CoreException(`Conector '${id}' não encontrado no Registro.`, "connectors", "ERR_CONNECTOR_NOT_FOUND");
    }

    try {
      const success = await connector.initialize(context);
      if (success) {
        this.activeContexts.set(id, context);
      }
      return success;
    } catch (err: any) {
      throw new CoreException(
        `Falha ao inicializar conector '${id}': ${err.message}`,
        "connectors",
        "ERR_CONNECTOR_INIT_FAILED",
        err
      );
    }
  }

  static async testConnection(id: string): Promise<boolean> {
    const connector = ConnectorRegistry.get(id);
    if (!connector) {
      throw new CoreException(`Conector '${id}' não encontrado no Registro.`, "connectors", "ERR_CONNECTOR_NOT_FOUND");
    }

    const start = Date.now();
    try {
      const connected = await connector.connect();
      const validated = await connector.validate();
      const isOk = connected && validated;
      
      AppLogger.log(
        isOk ? LogSeverity.INFO : LogSeverity.WARNING,
        "connectors",
        id,
        `Teste de conexão para conector '${id}' finalizado em ${Date.now() - start}ms. Status: ${isOk ? "Ativo" : "Inativo"}`
      );
      return isOk;
    } catch (err: any) {
      AppLogger.log(
        LogSeverity.ERROR,
        "connectors",
        id,
        `Erro durante teste de conexão para o conector '${id}': ${err.message}`
      );
      return false;
    }
  }

  static async executeAction<T>(connectorId: string, action: string, params?: Record<string, any>): Promise<ConnectorResult<T>> {
    const connector = ConnectorRegistry.get(connectorId);
    if (!connector) {
      throw new CoreException(`Conector '${connectorId}' não encontrado no Registro.`, "connectors", "ERR_CONNECTOR_NOT_FOUND");
    }

    AppLogger.log(
      LogSeverity.INFO,
      "connectors",
      connectorId,
      `Executando ação '${action}' no conector '${connectorId}'`
    );

    const start = Date.now();
    try {
      const result = await connector.execute<T>(action, params);
      const latencyMs = Date.now() - start;
      
      // Update result latency if not set
      if (result.metrics) {
        result.metrics.latencyMs = latencyMs;
      }

      EventDispatcher.emit("connector:action_executed", "connectors", connectorId, {
        action,
        success: result.success,
        latencyMs
      });

      return result;
    } catch (err: any) {
      const latencyMs = Date.now() - start;
      AppLogger.log(LogSeverity.ERROR, "connectors", connectorId, `Falha catastrófica ao executar ação '${action}': ${err.message}`);
      return {
        success: false,
        timestamp: new Date().toISOString(),
        error: {
          code: "ERR_CONNECTOR_EXECUTION_FAILED",
          message: err.message,
          details: err
        },
        metrics: { latencyMs }
      };
    }
  }

  static getActiveContext(id: string): ConnectorContext | undefined {
    return this.activeContexts.get(id);
  }
}
