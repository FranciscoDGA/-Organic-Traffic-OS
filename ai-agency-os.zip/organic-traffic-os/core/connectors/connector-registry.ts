import { BaseConnector } from "./base-connector";
import { LogSeverity, AppLogger } from "../common";

export class ConnectorRegistry {
  private static connectors: Map<string, BaseConnector> = new Map();

  static register(connector: BaseConnector): void {
    if (this.connectors.has(connector.id)) {
      AppLogger.log(
        LogSeverity.WARNING,
        "CONNECTORS",
        connector.id,
        `Tentativa de registrar conector duplicado '${connector.id}'. Substituindo.`
      );
    }
    this.connectors.set(connector.id, connector);
    AppLogger.log(
      LogSeverity.INFO,
      "CONNECTORS",
      connector.id,
      `Conector '${connector.name}' [v${connector.version}] registrado com sucesso.`
    );
  }

  static get(id: string): BaseConnector | undefined {
    return this.connectors.get(id);
  }

  static list(): BaseConnector[] {
    return Array.from(this.connectors.values());
  }

  static clear(): void {
    this.connectors.clear();
  }
}
