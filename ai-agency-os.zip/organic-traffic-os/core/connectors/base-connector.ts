import { LogSeverity, AppLogger, EventDispatcher } from "../common";
import { ConnectorContext } from "./connector-context";
import { ConnectorResult } from "./connector-result";
import { CoreStatus } from "../types";

export abstract class BaseConnector {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;
  public status: CoreStatus = "idle";
  
  protected context: ConnectorContext | null = null;
  protected isInitialized = false;

  async initialize(context: ConnectorContext): Promise<boolean> {
    this.context = context;
    this.isInitialized = true;
    this.status = "active";
    AppLogger.log(
      LogSeverity.INFO,
      "connectors",
      this.id,
      `Conector '${this.name}' inicializado no ambiente '${context.environment}'`
    );
    EventDispatcher.emit("connector:initialized", "connectors", this.id, {
      connectorId: this.id,
      environment: context.environment
    });
    return true;
  }

  // Contract Methods Required by Sprint 26.1
  abstract connect(): Promise<boolean>;
  abstract validate(): Promise<boolean>;
  abstract execute<T>(action: string, params?: Record<string, any>): Promise<ConnectorResult<T>>;
  abstract normalize<T>(rawData: any): T;

  protected createSuccessResult<T>(data: T, latencyMs: number, bytesProcessed?: number): ConnectorResult<T> {
    return {
      success: true,
      timestamp: new Date().toISOString(),
      data,
      metrics: { latencyMs, bytesProcessed }
    };
  }

  protected createErrorResult(code: string, message: string, latencyMs: number, details?: any): ConnectorResult {
    return {
      success: false,
      timestamp: new Date().toISOString(),
      error: { code, message, details },
      metrics: { latencyMs }
    };
  }
}
