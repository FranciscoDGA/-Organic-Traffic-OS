import { BaseConnector } from "./base-connector";
import { ConnectorContext } from "./connector-context";
import { ConnectorResult } from "./connector-result";
import { ConnectorRegistry } from "./connector-registry";

export class MockArchitecturalConnector extends BaseConnector {
  readonly id: string;
  readonly name: string;
  readonly version: string = "1.0.0";

  constructor(id: string, name: string) {
    super();
    this.id = id;
    this.name = name;
  }

  async connect(): Promise<boolean> {
    this.status = "active";
    return true;
  }

  async validate(): Promise<boolean> {
    return true;
  }

  async execute<T>(action: string, params?: Record<string, any>): Promise<ConnectorResult<T>> {
    const start = Date.now();
    const mockData = { simulated: true, action, params };
    const normalized = this.normalize<T>(mockData);
    return this.createSuccessResult(normalized, Date.now() - start);
  }

  normalize<T>(rawData: any): T {
    return rawData as T;
  }
}

export class ConnectorFactory {
  static createAndRegister(id: string, name: string): BaseConnector {
    const connector = new MockArchitecturalConnector(id, name);
    ConnectorRegistry.register(connector);
    return connector;
  }
}
