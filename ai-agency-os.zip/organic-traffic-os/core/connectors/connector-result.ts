export interface ConnectorResult<T = any> {
  success: boolean;
  timestamp: string;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  metrics?: {
    latencyMs: number;
    bytesProcessed?: number;
  };
}
