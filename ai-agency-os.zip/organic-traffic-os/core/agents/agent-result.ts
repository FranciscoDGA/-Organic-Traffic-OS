export interface AgentResult<T = any> {
  success: boolean;
  timestamp: string;
  agentId: string;
  finalAnswer?: T;
  rawLogs?: string[];
  stepsCount: number;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}
