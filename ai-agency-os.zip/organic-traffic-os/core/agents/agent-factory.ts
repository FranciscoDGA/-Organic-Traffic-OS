import { BaseAgent } from "./base-agent";
import { AgentResult } from "./agent-result";
import { AgentRegistry } from "./agent-registry";

export class MockArchitecturalAgent extends BaseAgent {
  readonly id: string;
  readonly name: string;
  readonly version = "1.0.0";

  constructor(id: string, name: string) {
    super();
    this.id = id;
    this.name = name;
  }

  async validate(): Promise<boolean> {
    return true;
  }

  async execute<T>(goal: string): Promise<AgentResult<T>> {
    this.status = "running";
    const res: AgentResult<T> = {
      success: true,
      timestamp: new Date().toISOString(),
      agentId: this.id,
      stepsCount: 3,
      rawLogs: [
        "Passo 1: Analisando objetivo e planejando ações estruturadas...",
        "Passo 2: Resolvendo dependências semânticas e dados de contexto...",
        "Passo 3: Consolidando resultado final do Agente."
      ],
      finalAnswer: { simulated: true, goal, status: "completed" } as any
    };
    this.status = "idle";
    return res;
  }

  async report<T>(result: AgentResult<T>): Promise<string> {
    return `[Relatório do Agente ${this.name} - v${this.version}]: O objetivo foi concluído com sucesso. Resposta Final: ${JSON.stringify(result.finalAnswer)}`;
  }
}

export class AgentFactory {
  static createAndRegister(id: string, name: string): BaseAgent {
    const agent = new MockArchitecturalAgent(id, name);
    AgentRegistry.register(agent);
    return agent;
  }
}
