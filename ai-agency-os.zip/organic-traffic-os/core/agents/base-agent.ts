import { LogSeverity, AppLogger, EventDispatcher } from "../common";
import { AgentContext } from "./agent-context";
import { AgentResult } from "./agent-result";
import { CoreStatus } from "../types";

export abstract class BaseAgent {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;
  public status: CoreStatus = "idle";

  protected context: AgentContext | null = null;
  protected isInitialized = false;

  async initialize(context: AgentContext): Promise<boolean> {
    this.context = context;
    this.isInitialized = true;
    this.status = "active";
    AppLogger.log(
      LogSeverity.INFO,
      "agents",
      this.id,
      `Agente '${this.name}' inicializado com papel '${context.role}'`
    );
    EventDispatcher.emit("agent:initialized", "agents", this.id, {
      agentId: this.id,
      role: context.role
    });
    return true;
  }

  // Contract Methods Required by Sprint 26.1
  abstract execute<T>(goal: string): Promise<AgentResult<T>>;
  abstract validate(): Promise<boolean>;
  abstract report<T>(result: AgentResult<T>): Promise<string>;
}
