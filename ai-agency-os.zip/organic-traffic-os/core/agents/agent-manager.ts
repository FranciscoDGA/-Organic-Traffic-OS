import { AgentRegistry } from "./agent-registry";
import { BaseAgent } from "./base-agent";
import { AgentContext } from "./agent-context";
import { AgentResult } from "./agent-result";
import { LogSeverity, AppLogger, CoreException, EventDispatcher } from "../common";

export class AgentManager {
  private static activeContexts: Map<string, AgentContext> = new Map();

  static async initializeAgent(id: string, context: AgentContext): Promise<boolean> {
    const agent = AgentRegistry.get(id);
    if (!agent) {
      throw new CoreException(`Agente '${id}' não encontrado no Registro.`, "agents", "ERR_AGENT_NOT_FOUND");
    }

    try {
      const success = await agent.initialize(context);
      if (success) {
        this.activeContexts.set(id, context);
      }
      return success;
    } catch (err: any) {
      throw new CoreException(
        `Falha ao inicializar agente '${id}': ${err.message}`,
        "agents",
        "ERR_AGENT_INIT_FAILED",
        err
      );
    }
  }

  static async runAgent<T>(id: string, goal: string): Promise<AgentResult<T>> {
    const agent = AgentRegistry.get(id);
    if (!agent) {
      throw new CoreException(`Agente '${id}' não encontrado no Registro.`, "agents", "ERR_AGENT_NOT_FOUND");
    }

    AppLogger.log(
      LogSeverity.INFO,
      "agents",
      id,
      `Agente '${id}' iniciando execução do objetivo: '${goal}'`
    );

    const start = Date.now();
    try {
      const result = await agent.execute<T>(goal);
      const elapsedMs = Date.now() - start;

      AppLogger.log(
        result.success ? LogSeverity.INFO : LogSeverity.WARNING,
        "agents",
        id,
        `Agente '${id}' finalizou execução em ${elapsedMs}ms com ${result.stepsCount} etapas.`
      );

      EventDispatcher.emit("agent:completed", "agents", id, {
        success: result.success,
        elapsedMs,
        stepsCount: result.stepsCount
      });

      return result;
    } catch (err: any) {
      const elapsedMs = Date.now() - start;
      AppLogger.log(
        LogSeverity.ERROR,
        "agents",
        id,
        `Falha na execução do agente '${id}': ${err.message}`
      );
      return {
        success: false,
        timestamp: new Date().toISOString(),
        agentId: id,
        stepsCount: 1,
        error: {
          code: "ERR_AGENT_EXECUTION_FAILED",
          message: err.message,
          details: err
        }
      };
    }
  }

  static getActiveContext(id: string): AgentContext | undefined {
    return this.activeContexts.get(id);
  }
}
