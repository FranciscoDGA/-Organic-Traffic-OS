import { BaseAgent } from "./base-agent";
import { LogSeverity, AppLogger } from "../common";

export class AgentRegistry {
  private static agents: Map<string, BaseAgent> = new Map();

  static register(agent: BaseAgent): void {
    if (this.agents.has(agent.id)) {
      AppLogger.log(
        LogSeverity.WARNING,
        "AGENTS",
        agent.id,
        `Tentativa de registrar agente duplicado '${agent.id}'. Substituindo.`
      );
    }
    this.agents.set(agent.id, agent);
    AppLogger.log(
      LogSeverity.INFO,
      "AGENTS",
      agent.id,
      `Agente '${agent.name}' [v${agent.version}] registrado com sucesso.`
    );
  }

  static get(id: string): BaseAgent | undefined {
    return this.agents.get(id);
  }

  static list(): BaseAgent[] {
    return Array.from(this.agents.values());
  }

  static clear(): void {
    this.agents.clear();
  }
}
