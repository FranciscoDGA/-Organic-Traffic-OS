import { DiscoveryInput } from "./discovery-agent.types";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export class DiscoveryAgentValidator {
  static validateInput(input: any): ValidationResult {
    const errors: string[] = [];

    if (!input) {
      errors.push("Payload de entrada é obrigatório.");
      return { isValid: false, errors };
    }

    if (typeof input.blog_id !== "string" || !input.blog_id.trim()) {
      errors.push("O campo 'blog_id' deve ser uma string preenchida.");
    }

    if (typeof input.topic !== "string" || !input.topic.trim()) {
      errors.push("O campo 'topic' deve ser uma string preenchida.");
    }

    if (input.mode !== "manual" && input.mode !== "mock" && input.mode !== "pipeline") {
      errors.push("O campo 'mode' deve ser um dos valores: 'manual', 'mock', 'pipeline'.");
    }

    if (input.limit !== undefined) {
      if (typeof input.limit !== "number" || input.limit <= 0 || !Number.isInteger(input.limit)) {
        errors.push("O campo 'limit' deve ser um número inteiro maior que zero se fornecido.");
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}
