export interface DiscoveryInput {
  blog_id: string;
  topic: string;
  mode: "manual" | "mock" | "pipeline";
  limit?: number;
}

export interface DiscoveryOpportunity {
  id: string;
  title: string;
  type: string;
  category: string;
  cluster: string;
  intent: string;
  priority: "high" | "medium" | "low";
  score: number;
  reason: string;
  source: string;
  confidence: number;
  next_step: string;
}

export interface DiscoverySummary {
  totalOpportunities: number;
  highPriorityCount: number;
  mediumPriorityCount: number;
  lowPriorityCount: number;
  avgConfidence: number;
  sourcesAnalyzed: string[];
}

export interface DiscoveryOutput {
  agent: "discovery-agent";
  blog_id: string;
  topic: string;
  opportunities: DiscoveryOpportunity[];
  summary: DiscoverySummary;
  warnings: string[];
  created_at: string;
}
