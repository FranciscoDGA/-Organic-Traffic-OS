import { BaseAgent } from "../base-agent";
import { AgentContext } from "../agent-context";
import { AgentResult } from "../agent-result";
import { DiscoveryInput, DiscoveryOutput } from "./discovery-agent.types";
import { DiscoveryAgentService } from "./discovery-agent.service";
import { DiscoveryAgentValidator } from "./discovery-agent.validator";
import { LogSeverity, AppLogger, EventDispatcher } from "../../common";

export class DiscoveryAgent extends BaseAgent {
  public readonly id = "discovery-agent";
  public readonly name = "Discovery Agent";
  public readonly version = "1.0.0";

  /**
   * Executa a busca de oportunidades por meio do DiscoveryAgentService
   */
  async execute<T>(goal: string): Promise<AgentResult<T>> {
    const startTime = Date.now();
    this.status = "running";
    AppLogger.log(
      LogSeverity.INFO,
      "agents",
      this.id,
      `Iniciando execução do DiscoveryAgent. Meta: '${goal}'`
    );

    let input: DiscoveryInput;

    try {
      // Tentar interpretar a meta como JSON contendo os parâmetros estruturados
      if (goal.trim().startsWith("{")) {
        input = JSON.parse(goal);
      } else {
        // Fallback robusto se for texto simples
        input = {
          blog_id: "passacumaru",
          topic: goal || "Concurso Prefeitura de Cumaru do Norte",
          mode: "pipeline",
          limit: 20
        };
      }
    } catch (err: any) {
      AppLogger.log(
        LogSeverity.WARNING,
        "agents",
        this.id,
        `Não foi possível decodificar meta como JSON. Usando valores padrões para '${goal}': ${err.message}`
      );
      input = {
        blog_id: "passacumaru",
        topic: goal || "Concurso Prefeitura de Cumaru do Norte",
        mode: "pipeline",
        limit: 20
      };
    }

    try {
      // Chamar o serviço principal
      const discoveryResult = await DiscoveryAgentService.runDiscovery(input);

      this.status = "completed";
      AppLogger.log(
        LogSeverity.INFO,
        "agents",
        this.id,
        `Execução do DiscoveryAgent finalizada com sucesso. Oportunidades: ${discoveryResult.opportunities.length}`
      );

      return {
        success: true,
        timestamp: new Date().toISOString(),
        agentId: this.id,
        finalAnswer: discoveryResult as unknown as T,
        stepsCount: 5,
        rawLogs: [
          `Consulta de Knowledge para o blog ${input.blog_id}`,
          `Varredura de inventário atual`,
          `Cruzamento de SERP e keywords cadastrados`,
          `Aplicação das regras editoriais da banca IVIN`,
          `Geração do relatório final de oportunidades`
        ]
      };
    } catch (err: any) {
      this.status = "failed";
      AppLogger.log(
        LogSeverity.ERROR,
        "agents",
        this.id,
        `Falha catastrófica na execução do DiscoveryAgent: ${err.message}`
      );

      return {
        success: false,
        timestamp: new Date().toISOString(),
        agentId: this.id,
        stepsCount: 2,
        error: {
          code: "DISCOVERY_EXECUTION_FAILED",
          message: err.message || "Erro desconhecido durante a descoberta de oportunidades",
          details: err
        }
      };
    }
  }

  /**
   * Valida as configurações básicas do agente antes da execução
   */
  async validate(): Promise<boolean> {
    AppLogger.log(LogSeverity.INFO, "agents", this.id, "Validando estado e prontidão do DiscoveryAgent");
    if (!this.isInitialized) {
      AppLogger.log(LogSeverity.ERROR, "agents", this.id, "Agente não inicializado.");
      return false;
    }
    return true;
  }

  /**
   * Gera uma versão em Markdown do relatório final de oportunidades
   */
  async report<T>(result: AgentResult<T>): Promise<string> {
    if (!result.success || !result.finalAnswer) {
      return `### Relatório do Discovery Agent\n\n**Status:** Falha\n**Erro:** ${result.error?.message || "Sem detalhes"}`;
    }

    const output = result.finalAnswer as unknown as DiscoveryOutput;
    const { opportunities, summary, warnings } = output;

    let md = `# Relatório Consolidado de Oportunidades Editoriais — PassaCumaru\n\n`;
    md += `**Tema de Busca:** ${output.topic}\n`;
    md += `**Data de Execução:** ${new Date(output.created_at).toLocaleString("pt-BR")}\n`;
    md += `**Versão do Agente:** ${this.version}\n\n`;

    md += `## 📊 Resumo de Descoberta\n\n`;
    md += `- **Total de Oportunidades:** ${summary.totalOpportunities}\n`;
    md += `- **Alta Prioridade:** 🔥 ${summary.highPriorityCount}\n`;
    md += `- **Média Prioridade:** ⚡ ${summary.mediumPriorityCount}\n`;
    md += `- **Baixa Prioridade:** 💤 ${summary.lowPriorityCount}\n`;
    md += `- **Grau Médio de Confiança:** ${(summary.avgConfidence * 100).toFixed(0)}%\n`;
    md += `- **Fontes Analisadas:** ${summary.sourcesAnalyzed.join(", ")}\n\n`;

    if (warnings.length > 0) {
      md += `### ⚠️ Alertas / Observações\n\n`;
      warnings.forEach(w => {
        md += `- ${w}\n`;
      });
      md += `\n`;
    }

    md += `## 🎯 Lista de Oportunidades Priorizadas\n\n`;
    md += `| Título | Tipo | Prioridade | Score | Confiança | Origem |\n`;
    md += `| :--- | :---: | :---: | :---: | :---: | :---: |\n`;

    opportunities.forEach(op => {
      const priorityEmoji = op.priority === "high" ? "🔴 Alta" : op.priority === "medium" ? "🟡 Média" : "🟢 Baixa";
      md += `| **${op.title}** | \`${op.type}\` | ${priorityEmoji} | \`${op.score}/100\` | ${(op.confidence * 100).toFixed(0)}% | ${op.source} |\n`;
    });

    md += `\n\n### Detalhamento por Oportunidade\n\n`;
    opportunities.forEach((op, index) => {
      md += `#### ${index + 1}. ${op.title}\n`;
      md += `- **ID:** \`${op.id}\`\n`;
      md += `- **Categoria:** ${op.category} | **Cluster Semântico:** ${op.cluster}\n`;
      md += `- **Intenção de Busca:** \`${op.intent}\`\n`;
      md += `- **Justificativa Editorial:** ${op.reason}\n`;
      md += `- **Próxima Ação:** *${op.next_step}*\n\n`;
    });

    return md;
  }
}
