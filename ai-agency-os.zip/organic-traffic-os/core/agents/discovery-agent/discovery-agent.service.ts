import fs from "fs";
import path from "path";
import { DiscoveryInput, DiscoveryOutput, DiscoveryOpportunity, DiscoverySummary } from "./discovery-agent.types";
import { DiscoveryAgentValidator } from "./discovery-agent.validator";
import { loadKnowledgeCore } from "../../../knowledge/knowledge-loader";
import { loadInventory } from "../../../inventory/inventory-loader";
import { loadKeywordsData } from "../../../keywords/keyword-loader";
import { loadSerpData } from "../../../serp/serp-loader";
import { LogSeverity, AppLogger, EventDispatcher } from "../../common";

export class DiscoveryAgentService {
  private static historyFile = path.join(process.cwd(), "organic-traffic-os", "core", "agents", "discovery-agent", "history.json");

  /**
   * Executa a descoberta de oportunidades de conteúdo autônomo
   */
  static async runDiscovery(input: DiscoveryInput): Promise<DiscoveryOutput> {
    const startTime = Date.now();
    AppLogger.log(
      LogSeverity.INFO,
      "agents",
      "discovery-agent",
      `Iniciando execução do Discovery Agent para o blog '${input.blog_id}' com tema '${input.topic}' em modo '${input.mode}'`
    );

    // 1. Validar Entrada
    const validation = DiscoveryAgentValidator.validateInput(input);
    if (!validation.isValid) {
      AppLogger.log(
        LogSeverity.ERROR,
        "agents",
        "discovery-agent",
        `Falha na validação de entrada: ${validation.errors.join(", ")}`
      );
      throw new Error(`Entrada inválida: ${validation.errors.join("; ")}`);
    }

    const blogId = input.blog_id;
    const topic = input.topic;
    const mode = input.mode;
    const limit = input.limit || 20;

    let opportunities: DiscoveryOpportunity[] = [];
    const warnings: string[] = [];
    const sourcesAnalyzed: string[] = ["Knowledge Layer", "Rules Config"];

    // 2. Carregar dados das camadas L2 (Knowledge) e L3 (Engines) se modo for pipeline ou mock
    if (mode === "pipeline") {
      try {
        AppLogger.log(LogSeverity.INFO, "agents", "discovery-agent", "Consultando L2 Knowledge...");
        const knowledge = loadKnowledgeCore(blogId);
        sourcesAnalyzed.push("L2 Knowledge Core");

        AppLogger.log(LogSeverity.INFO, "agents", "discovery-agent", "Consultando L3 Inventory Engine...");
        const inventory = loadInventory(blogId);
        sourcesAnalyzed.push("L3 Inventory Engine");

        AppLogger.log(LogSeverity.INFO, "agents", "discovery-agent", "Consultando L3 Keywords Engine...");
        const keywordsData = loadKeywordsData();
        sourcesAnalyzed.push("L3 Keywords Engine");

        AppLogger.log(LogSeverity.INFO, "agents", "discovery-agent", "Consultando L3 SERP Engine...");
        const serpData = loadSerpData();
        sourcesAnalyzed.push("L3 SERP Engine");

        // Extrair oportunidades reais das lacunas do inventário (gaps)
        if (inventory.gaps && inventory.gaps.length > 0) {
          inventory.gaps.forEach((gap: any, idx: number) => {
            opportunities.push({
              id: `op-gap-${idx}-${Date.now()}`,
              title: gap.palavraChave || gap.titulo || `Guia de Conteúdo sobre ${topic}`,
              type: "new_article",
              category: gap.categoria || "Concursos",
              cluster: gap.cluster || "Geral",
              intent: "informational",
              priority: "high",
              score: 85,
              reason: gap.justificativa || "Identificado como lacuna ausente no inventário editorial contra concorrentes.",
              source: "Inventory Gaps",
              confidence: 0.9,
              next_step: "Gerar briefing premium focado em preencher essa lacuna de autoridade tópica."
            });
          });
        }

        // Extrair de palavras-chave pendentes ou sugeridas
        if (keywordsData.keywords && keywordsData.keywords.length > 0) {
          keywordsData.keywords.filter((k: any) => k.status === "sugerida" || k.status === "planejada").slice(0, 10).forEach((k: any, idx: number) => {
            opportunities.push({
              id: `op-kw-${idx}-${Date.now()}`,
              title: `Guia definitivo: ${k.palavraChave || k.nome}`,
              type: "new_article",
              category: k.categoria || "Estudo",
              cluster: k.cluster || "Dicas",
              intent: "educational",
              priority: "medium",
              score: 75,
              reason: `Palavra-chave registrada com alta intenção estratégica mas ainda sem publicação correspondente.`,
              source: "Keywords Database",
              confidence: 0.85,
              next_step: "Enviar para planejamento de calendário editorial."
            });
          });
        }

        // Extrair perguntas recorrentes
        if (keywordsData.questions && keywordsData.questions.length > 0) {
          keywordsData.questions.slice(0, 5).forEach((q: any, idx: number) => {
            opportunities.push({
              id: `op-q-${idx}-${Date.now()}`,
              title: q.pergunta,
              type: "new_article",
              category: q.categoria || "Perguntas Frequentes",
              cluster: q.cluster || "Dúvidas",
              intent: "educational",
              priority: "medium",
              score: 70,
              reason: "Dúvida altamente recorrente mapeada de comunidades ou fóruns.",
              source: "Recurrent Questions",
              confidence: 0.8,
              next_step: "Criar artigo curto em formato Q&A para faturar featured snippets."
            });
          });
        }

        // Se a lista estiver vazia por falta de dados reais estruturados, adiciona os fallbacks baseados em Cumaru/IVIN
        if (opportunities.length === 0) {
          warnings.push("Dados das engines retornaram vazios ou insuficientes. Gerando sugestões híbridas automáticas baseadas em regras de negócio.");
          opportunities = this.getFallbackOpportunities(topic);
        }

      } catch (err: any) {
        warnings.push(`Erro ao acessar camadas integradas: ${err.message}. Alternando para simulação de pipeline segura.`);
        opportunities = this.getFallbackOpportunities(topic);
      }
    } else {
      // Modos 'mock' ou 'manual'
      sourcesAnalyzed.push("Mocks Inteligentes");
      opportunities = this.getFallbackOpportunities(topic);
    }

    // 3. Aplicar as Regras de Descoberta (Priorização e Scoring)
    opportunities = this.scoreAndPrioritize(opportunities, topic);

    // Evitar duplicados
    const uniqueTitles = new Set<string>();
    opportunities = opportunities.filter(op => {
      const lowerTitle = op.title.toLowerCase().trim();
      if (uniqueTitles.has(lowerTitle)) {
        return false;
      }
      uniqueTitles.add(lowerTitle);
      return true;
    });

    // Limitar quantidade conforme input
    opportunities = opportunities.slice(0, limit);

    // 4. Calcular Métricas de Resumo
    const highPriorityCount = opportunities.filter(op => op.priority === "high").length;
    const mediumPriorityCount = opportunities.filter(op => op.priority === "medium").length;
    const lowPriorityCount = opportunities.filter(op => op.priority === "low").length;
    const avgConfidence = opportunities.length > 0 
      ? parseFloat((opportunities.reduce((sum, op) => sum + op.confidence, 0) / opportunities.length).toFixed(2))
      : 0;

    const summary: DiscoverySummary = {
      totalOpportunities: opportunities.length,
      highPriorityCount,
      mediumPriorityCount,
      lowPriorityCount,
      avgConfidence,
      sourcesAnalyzed
    };

    const durationMs = Date.now() - startTime;
    AppLogger.log(
      LogSeverity.INFO,
      "agents",
      "discovery-agent",
      `Processamento concluído em ${durationMs}ms. Total de oportunidades: ${opportunities.length}.`
    );

    const output: DiscoveryOutput = {
      agent: "discovery-agent",
      blog_id: blogId,
      topic: topic,
      opportunities,
      summary,
      warnings,
      created_at: new Date().toISOString()
    };

    // Emitir evento de execução bem-sucedida
    EventDispatcher.emit("agent:discovery:completed", "agents", "discovery-agent", {
      blogId,
      topic,
      totalOpportunities: opportunities.length,
      durationMs
    });

    // Salvar no histórico
    this.saveToHistory(output);

    return output;
  }

  /**
   * Algoritmo de Pontuação (Scoring) e Priorização baseado nas regras formais
   */
  private static scoreAndPrioritize(opportunities: DiscoveryOpportunity[], topic: string): DiscoveryOpportunity[] {
    return opportunities.map(op => {
      let score = op.score;
      const reasons: string[] = [];

      // Regra 1: Alta intenção educacional (+15 pontos)
      const educationalWords = ["como", "guia", "manual", "passo a passo", "estudar", "aprender", "dicas", "recurso", "simulado"];
      const isEducational = educationalWords.some(w => op.title.toLowerCase().includes(w)) || op.intent === "educational";
      if (isEducational) {
        score += 15;
        reasons.push("Alta intenção educacional identificada");
      }

      // Regra 2: Relacionado a Concursos Municipais (+20 pontos)
      if (op.title.toLowerCase().includes("concurso") || op.title.toLowerCase().includes("prefeitura") || op.title.toLowerCase().includes("municipal")) {
        score += 20;
        reasons.push("Vinculado diretamente a concurso municipal");
      }

      // Regra 3: Banca IVIN (+20 pontos)
      if (op.title.toLowerCase().includes("ivin") || op.title.toLowerCase().includes("banca ivin") || op.reason.toLowerCase().includes("ivin")) {
        score += 20;
        reasons.push("Focado na banca organizadora IVIN");
      }

      // Regra 4: Lacuna de inventário (+10 pontos)
      if (op.source === "Inventory Gaps") {
        score += 10;
        reasons.push("Preenche lacuna explícita no inventário");
      }

      // Regra 5: Conversão para assinatura/lead (+15 pontos)
      const conversionWords = ["simulado", "apostila", "pdf", "isencao", "inscricao", "cronograma"];
      const hasConversion = conversionWords.some(w => op.title.toLowerCase().includes(w)) || op.next_step.toLowerCase().includes("lead");
      if (hasConversion) {
        score += 15;
        reasons.push("Forte potencial para conversão de leads ou assinaturas");
      }

      // Evitar promessas de aprovação (Penalização severa ou descarte - aqui reduziremos o score e limitaremos)
      if (op.title.toLowerCase().includes("garantid") || op.title.toLowerCase().includes("passe de primeira") || op.title.toLowerCase().includes("sem estudar")) {
        score -= 40;
        reasons.push("Penalizado: Evitar títulos com promessas excessivas ou milagrosas");
      }

      // Garantir limite do score
      score = Math.min(100, Math.max(0, score));

      // Re-classificar prioridade
      let priority: "high" | "medium" | "low" = "low";
      if (score >= 80) {
        priority = "high";
      } else if (score >= 50) {
        priority = "medium";
      }

      return {
        ...op,
        score,
        priority,
        reason: reasons.length > 0 ? reasons.join(" | ") : op.reason
      };
    }).sort((a, b) => b.score - a.score);
  }

  /**
   * Mock / Sugestões Híbridas baseadas nas diretrizes de Cumaru / Banca IVIN
   */
  private static getFallbackOpportunities(topic: string): DiscoveryOpportunity[] {
    return [
      {
        id: "op-cumaru-edital-prefeitura",
        title: "Edital Concurso Prefeitura de Cumaru do Norte: Guia Completo de Inscrição e Isenção",
        type: "new_article",
        category: "Editais",
        cluster: "Prefeitura de Cumaru",
        intent: "informational",
        priority: "high",
        score: 85,
        reason: "Oportunidade de alta relevância com alta intenção de busca para candidatos iniciantes sobre prazos de inscrição.",
        source: "SERP & Competitor Gap",
        confidence: 0.95,
        next_step: "Gerar briefing estruturado focando nas datas e documentação necessária."
      },
      {
        id: "op-cumaru-banca-ivin",
        title: "Como Estudar Português para a Banca IVIN: Perfil de Prova e Questões Recorrentes",
        type: "new_article",
        category: "Estudo",
        cluster: "Banca IVIN",
        intent: "educational",
        priority: "high",
        score: 80,
        reason: "Lacuna crucial de conteúdo. Candidatos têm grande dificuldade de encontrar o perfil de português da banca IVIN.",
        source: "Recurrent Questions",
        confidence: 0.9,
        next_step: "Coletar e analisar 5 provas recentes da IVIN para consolidar estatísticas de cobrança."
      },
      {
        id: "op-cumaru-simulados-ivin",
        title: "Simulado Gratuito de Legislação Municipal de Cumaru do Norte (Perfil IVIN)",
        type: "new_article",
        category: "Estudo",
        cluster: "Legislação Municipal",
        intent: "transactional",
        priority: "high",
        score: 78,
        reason: "Conteúdo focado em isca digital de alta conversão para captura de leads e assinaturas.",
        source: "Keywords Database",
        confidence: 0.88,
        next_step: "Formatar simulado com 20 questões comentadas de leis orgânicas e estatuto dos servidores."
      },
      {
        id: "op-cumaru-leis-organicas",
        title: "Lei Orgânica de Cumaru do Norte esquematizada para Concursos Públicos",
        type: "new_article",
        category: "Leis Municipais",
        cluster: "Legislação Municipal",
        intent: "educational",
        priority: "medium",
        score: 72,
        reason: "Conteúdo estritamente evergreen focado em disciplinas básicas obrigatórias de nível médio e superior.",
        source: "Inventory Gaps",
        confidence: 0.85,
        next_step: "Estruturar o artigo com infográficos explicativos das atribuições dos poderes municipais."
      },
      {
        id: "op-cumaru-gabaritos-provas",
        title: "Download de Provas Anteriores com Gabarito Oficial da Banca IVIN",
        type: "new_article",
        category: "Estudo",
        cluster: "Banca IVIN",
        intent: "transactional",
        priority: "medium",
        score: 68,
        reason: "Busca transacional muito frequente. Pode reter tráfego altíssimo nas semanas anteriores à prova.",
        source: "Keywords Database",
        confidence: 0.82,
        next_step: "Compilar repositório seguro para download de PDFs e links diretos oficiais."
      },
      {
        id: "op-cumaru-cargos-salarios",
        title: "Concurso Cumaru do Norte: Quais os cargos mais fáceis e melhores salários?",
        type: "new_article",
        category: "Concursos",
        cluster: "Prefeitura de Cumaru",
        intent: "informational",
        priority: "medium",
        score: 65,
        reason: "Artigo informativo ideal para iniciantes decidirem a inscrição com base no custo-benefício.",
        source: "SERP Analysis",
        confidence: 0.8,
        next_step: "Analisar a tabela salarial anexa ao edital atualizado."
      }
    ];
  }

  /**
   * Histórico de Execuções do Discovery Agent
   */
  static getHistory(): DiscoveryOutput[] {
    if (fs.existsSync(this.historyFile)) {
      try {
        return JSON.parse(fs.readFileSync(this.historyFile, "utf-8"));
      } catch (err) {
        console.error("Erro ao ler histórico do Discovery Agent:", err);
        return [];
      }
    }
    return [];
  }

  private static saveToHistory(output: DiscoveryOutput): void {
    try {
      const dir = path.dirname(this.historyFile);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      const history = this.getHistory();
      history.unshift(output); // Adicionar no início

      // Limitar a 50 execuções para evitar arquivos gigantescos
      const limitedHistory = history.slice(0, 50);

      fs.writeFileSync(this.historyFile, JSON.stringify(limitedHistory, null, 2), "utf-8");
    } catch (err) {
      console.error("Erro ao salvar histórico do Discovery Agent:", err);
    }
  }
}
