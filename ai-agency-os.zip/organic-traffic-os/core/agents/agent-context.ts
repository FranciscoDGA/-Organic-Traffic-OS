export interface AgentContext {
  agentId: string;
  role: string;
  persona: string;
  maxIterations?: number;
  availableTools?: string[];
  memorySettings?: Record<string, any>;
}
