import { CoreLog, CoreLayer } from "../types";

export class AppLogger {
  private static logs: CoreLog[] = [];

  static log(severity: 'INFO' | 'WARNING' | 'ERROR' | 'DEBUG', layer: CoreLayer, sourceId: string, message: string, meta?: any) {
    const logItem: CoreLog = {
      id: `log-${Math.random().toString(36).substring(2, 11)}`,
      timestamp: new Date().toISOString(),
      severity,
      layer,
      sourceId,
      message,
      meta
    };
    this.logs.unshift(logItem);
    if (this.logs.length > 500) {
      this.logs.pop();
    }
    console.log(`[${logItem.timestamp}] [${severity}] [Layer: ${layer}] [${sourceId}] ${message}`);
  }

  static getLogs(): CoreLog[] {
    return this.logs;
  }

  static clearLogs(): void {
    this.logs = [];
  }
}
