import { EditorialItem } from "../models/editorial-models";

export class EditorialRules {
  /**
   * Rule 1: Nunca criar artigo filho (satélite/faq) antes da página pilar.
   * Retorna true se a página pilar daquele cluster já existir no backlog ou planejamento,
   * permitindo a criação do filho. Se não existir, avisa ou recomenda criar o pilar primeiro.
   */
  public static checkPillarFirst(
    item: Partial<EditorialItem>,
    existingItems: EditorialItem[]
  ): { allowed: boolean; reason?: string } {
    // Se for um item pilar, ele mesmo é o pai, então é permitido.
    if (item.tipo === "pilar") {
      return { allowed: true };
    }

    // Se o cluster não for definido, permite por resiliência
    if (!item.cluster) {
      return { allowed: true };
    }

    const normalizedCluster = item.cluster.toLowerCase().trim();

    // Procurar se existe alguma página pilar para este cluster
    const hasPillar = existingItems.some(
      ex => ex.tipo === "pilar" && ex.cluster.toLowerCase().trim() === normalizedCluster
    );

    if (!hasPillar) {
      return {
        allowed: false,
        reason: `Pilar do cluster "${item.cluster}" não localizado. É necessário criar a Página Pilar antes dos artigos satélites.`
      };
    }

    return { allowed: true };
  }

  /**
   * Rule 2: Nunca publicar dois conteúdos com títulos/keywords extremamente similares (duplicados).
   */
  public static isDuplicate(
    titulo: string,
    existingItems: EditorialItem[]
  ): { isDuplicate: boolean; reason?: string } {
    const normalizedNew = titulo.toLowerCase().trim();
    for (const item of existingItems) {
      const normalizedExist = item.titulo.toLowerCase().trim();
      if (normalizedNew === normalizedExist && normalizedNew.length > 0) {
        return {
          isDuplicate: true,
          reason: `Conteúdo duplicado detectado com o ID ${item.id} ("${item.titulo}")`
        };
      }
    }
    return { isDuplicate: false };
  }

  /**
   * Rule 3: Priorizar clusters incompletos.
   * Dá boost para termos de clusters que têm poucos artigos publicados ou planejados
   * para acelerar a conclusão da autoridade temática daquele cluster.
   */
  public static getClusterIncompletenessBoost(
    cluster: string,
    existingItems: EditorialItem[]
  ): number {
    if (!cluster) return 0;
    const normalized = cluster.toLowerCase().trim();
    const count = existingItems.filter(item => item.cluster.toLowerCase().trim() === normalized).length;

    if (count === 0) {
      return 20; // Super boost: Cluster totalmente virgem!
    } else if (count < 3) {
      return 15; // Boost alto: Pouca cobertura, terminando silo básico
    } else if (count < 6) {
      return 5;  // Boost leve: Cluster parcialmente coberto
    }
    return 0; // Cluster já bem coberto/saturado, sem boost extra
  }

  /**
   * Rule 4: Priorizar conteúdos de alta autoridade.
   * Materiais ricos, simulados e guias pilar de alta relevância recebem boost para estabelecer domínio do nicho.
   */
  public static getAuthorityBoost(tipo: string): number {
    if (tipo === "pilar") return 15;
    if (tipo === "material_rico") return 10;
    if (tipo === "simulado") return 5;
    return 0;
  }

  /**
   * Rule 5: Priorizar conteúdos evergreen.
   * Conteúdos atemporais de guia de estudo e conceitos de concursos têm prioridade sobre notícias rápidas,
   * exceto se a notícia tiver urgência imediata de curto prazo.
   */
  public static getEvergreenBoost(titulo: string, categoria: string): number {
    const text = (titulo + " " + categoria).toLowerCase();
    
    // Conceitos e guias são altamente evergreen em blogs de concurso/carreiras
    if (
      text.includes("como estudar") ||
      text.includes("guia completo") ||
      text.includes("passo a passo") ||
      text.includes("cronograma") ||
      text.includes("dicas") ||
      text.includes("matérias") ||
      text.includes("lei") ||
      text.includes("conteúdo")
    ) {
      return 12; // Boost de conteúdo perene
    }
    
    return 0;
  }
}
