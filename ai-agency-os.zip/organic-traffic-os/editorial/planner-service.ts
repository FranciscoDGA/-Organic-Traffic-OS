import fs from "fs";
import path from "path";
import { EditorialItem, CalendarItem, Roadmap, DependencyRelation, Backlog } from "./models/editorial-models";
import { EditorialPlanner } from "./planner/editorial-planner";

const PLANNER_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "planner", "editorial-item.json");
const CALENDAR_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "calendar", "calendar.json");
const ROADMAP_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "roadmap", "roadmap.json");
const DEPENDENCIES_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "dependencies", "dependencies.json");
const BACKLOG_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "backlog", "backlog.json");

export class PlannerService {
  /**
   * Retorna os itens editoriais do plano.
   * Se o arquivo estiver vazio, executa a geração resiliente automática.
   */
  public static async getEditorialItems(): Promise<EditorialItem[]> {
    try {
      if (fs.existsSync(PLANNER_FILE)) {
        const raw = fs.readFileSync(PLANNER_FILE, "utf-8");
        const items = JSON.parse(raw);
        if (items && items.length > 0) return items;
      }
      // Se não houver, gera
      const plan = await this.generateEditorialPlan();
      return plan.editorialItems;
    } catch (e) {
      console.error("Erro ao buscar itens editoriais:", e);
      return [];
    }
  }

  /**
   * Retorna o calendário editorial.
   */
  public static async getCalendar(): Promise<CalendarItem[]> {
    try {
      if (fs.existsSync(CALENDAR_FILE)) {
        const raw = fs.readFileSync(CALENDAR_FILE, "utf-8");
        return JSON.parse(raw);
      }
      const plan = await this.generateEditorialPlan();
      return plan.calendar;
    } catch (e) {
      console.error("Erro ao buscar calendário:", e);
      return [];
    }
  }

  /**
   * Retorna o Roadmap editorial.
   */
  public static async getRoadmap(): Promise<Roadmap> {
    try {
      if (fs.existsSync(ROADMAP_FILE)) {
        const raw = fs.readFileSync(ROADMAP_FILE, "utf-8");
        return JSON.parse(raw);
      }
      const plan = await this.generateEditorialPlan();
      return plan.roadmap;
    } catch (e) {
      console.error("Erro ao buscar roadmap:", e);
      return { curto_prazo: [], medio_prazo: [], longo_prazo: [] };
    }
  }

  /**
   * Retorna as relações de dependências.
   */
  public static async getDependencies(): Promise<DependencyRelation[]> {
    try {
      if (fs.existsSync(DEPENDENCIES_FILE)) {
        const raw = fs.readFileSync(DEPENDENCIES_FILE, "utf-8");
        return JSON.parse(raw);
      }
      const plan = await this.generateEditorialPlan();
      return plan.dependencies;
    } catch (e) {
      console.error("Erro ao buscar dependências:", e);
      return [];
    }
  }

  /**
   * Retorna o backlog editorial agrupado.
   */
  public static async getBacklog(): Promise<Backlog> {
    try {
      if (fs.existsSync(BACKLOG_FILE)) {
        const raw = fs.readFileSync(BACKLOG_FILE, "utf-8");
        return JSON.parse(raw);
      }
      const plan = await this.generateEditorialPlan();
      return plan.backlog;
    } catch (e) {
      console.error("Erro ao buscar backlog:", e);
      return { pendentes: [], em_planejamento: [], prontos: [], blocked: [], arquivados: [] } as any;
    }
  }

  /**
   * Força a geração de um novo planejamento.
   */
  public static async generateEditorialPlan(blogId: string = "passacumaru"): Promise<{
    editorialItems: EditorialItem[];
    calendar: CalendarItem[];
    roadmap: Roadmap;
    dependencies: DependencyRelation[];
    backlog: Backlog;
    log: any;
  }> {
    return await EditorialPlanner.buildEditorialPlan(blogId);
  }
}
