import { EditorialItem } from "../models/editorial-models";

export class EditorialRanking {
  /**
   * Calcula o score final de priorização editorial do item (0 a 100)
   * baseado em 5 dimensões estratégicas: Impacto, Urgência, Complexidade, Retorno Esperado e Dependências.
   */
  public static calculate(
    item: Partial<EditorialItem> & { 
      tipoOriginal?: string; 
      origem?: string;
      isPillar?: boolean;
      hasPillarDependency?: boolean;
    }
  ): { 
    score: number; 
    factors: { 
      impacto: number; 
      urgencia: number; 
      complexidade: number; 
      retornoEsperado: number; 
      dependenciaFactor: number;
    }; 
    reason: string;
  } {
    // --- 1. IMPACTO (0 a 100) ---
    // Páginas pilares têm impacto estratégico máximo para a estrutura de silos.
    let impacto = 50;
    if (item.tipo === "pilar" || item.isPillar) {
      impacto = 95;
    } else if (item.tipo === "material_rico") {
      impacto = 85;
    } else if (item.tipo === "satelite") {
      impacto = 65;
    } else if (item.tipo === "faq") {
      impacto = 45;
    }

    // --- 2. URGÊNCIA (0 a 100) ---
    // Itens que vêm de tendências quentes ou notícias têm urgência máxima.
    let urgencia = 50;
    if (item.origem === "collectors" || item.origem === "trends") {
      urgencia = 90;
    } else if (item.prioridade === "critica") {
      urgencia = 95;
    } else if (item.prioridade === "alta") {
      urgencia = 75;
    } else if (item.prioridade === "media") {
      urgencia = 50;
    } else {
      urgencia = 25;
    }

    // --- 3. COMPLEXIDADE (0 a 100) ---
    // Quanto maior a complexidade, maior o esforço.
    // Pilares, simulados e materiais ricos são altamente complexos. Satélites e FAQs são simples.
    let complexidade = 30; // simples por padrão
    if (item.tipo === "pilar" || item.isPillar) {
      complexidade = 80;
    } else if (item.tipo === "material_rico" || item.tipo === "simulado") {
      complexidade = 90;
    } else if (item.tipo === "satelite") {
      complexidade = 40;
    } else if (item.tipo === "faq") {
      complexidade = 20;
    }

    // --- 4. RETORNO ESPERADO (0 a 100) ---
    // Alinhamento comercial e transacional gera mais valor imediato de conversão.
    let retornoEsperado = 50;
    if (item.tipo === "material_rico") {
      retornoEsperado = 95; // geração de leads de alta conversão
    } else if (item.tipo === "simulado") {
      retornoEsperado = 85; // alta retenção de usuários e links internos
    } else if (item.tipo === "pilar") {
      retornoEsperado = 80; // posicionamento orgânico de longo prazo
    } else {
      retornoEsperado = 60;
    }

    // --- 5. DEPENDÊNCIAS (0 a 100) ---
    // Se o item é um pilar de quem outros dependem, seu fator de dependência é alto (deve ser criado primeiro).
    // Se o item depende de um pilar que NÃO está pronto, ele é "penalizado" temporariamente para que o pilar nasça antes.
    let dependenciaFactor = 50;
    if (item.tipo === "pilar" || item.isPillar) {
      dependenciaFactor = 100; // Alta prioridade por ser facilitador/bloqueador de outros
    } else if (item.hasPillarDependency) {
      dependenciaFactor = 20; // Baixo fator para incentivar a pilar a nascer antes
    }

    // --- CÁLCULO FINAL PONDERADO ---
    // Queremos valorizar Alto Impacto, Alta Urgência, Alto Retorno Esperado, Alta prioridade de Dependência,
    // e dar uma ligeira vantagem para itens de Baixa Complexidade (Quick Wins) quando aplicável.
    // Fórmula: Impacto (30%) + Urgência (20%) + Retorno (25%) + Dependência (15%) + (100 - Complexidade) (10%)
    const scoreBase = (
      (impacto * 0.30) +
      (urgencia * 0.20) +
      (retornoEsperado * 0.25) +
      (dependenciaFactor * 0.15) +
      ((100 - complexidade) * 0.10)
    );

    const score = Math.max(0, Math.min(100, Math.round(scoreBase)));

    // Justificativa estruturada
    let reason = "";
    if (item.tipo === "pilar" || item.isPillar) {
      reason = "Conteúdo Pilar estrutural indispensável. Deve nascer primeiro para sustentar os silos e links internos dos artigos satélites.";
    } else if (item.origem === "collectors") {
      reason = "Oportunidade de alta urgência vinda do console de monitoramento de notícias em tempo real.";
    } else if (item.tipo === "material_rico") {
      reason = "Foco em conversão profunda e captação de leads qualificados do nicho.";
    } else if (item.hasPillarDependency) {
      reason = "Artigo satélite qualificado dependente da finalização e publicação da página pilar correspondente.";
    } else {
      reason = "Conteúdo de preenchimento de cluster semântico complementar com retorno equilibrado.";
    }

    return {
      score,
      factors: {
        impacto,
        urgencia,
        complexidade,
        retornoEsperado,
        dependenciaFactor
      },
      reason
    };
  }
}
