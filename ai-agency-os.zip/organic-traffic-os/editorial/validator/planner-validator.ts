import { EditorialItem, CalendarItem } from "../models/editorial-models";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export class PlannerValidator {
  /**
   * Valida o planejamento completo (EditorialItems, CalendarItems e dependências).
   */
  public static validate(
    items: EditorialItem[],
    calendar: CalendarItem[]
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    const itemMap = new Map<string, EditorialItem>();
    const titleSet = new Set<string>();

    // --- 1. Validar estrutura básica, categorias, clusters e duplicidades ---
    items.forEach((item, index) => {
      if (!item.id) {
        errors.push(`Item na posição ${index} não possui ID.`);
        return;
      }
      itemMap.set(item.id, item);

      if (!item.titulo || item.titulo.trim() === "") {
        errors.push(`Item ID ${item.id} está com o título em branco.`);
      } else {
        const normalizedTitle = item.titulo.toLowerCase().trim();
        if (titleSet.has(normalizedTitle)) {
          warnings.push(`Título duplicado ou muito similar detectado: "${item.titulo}"`);
        }
        titleSet.add(normalizedTitle);
      }

      if (!item.cluster || item.cluster.trim() === "") {
        errors.push(`Item "${item.titulo || item.id}" está sem cluster semântico definido.`);
      }

      if (!item.categoria || item.categoria.trim() === "") {
        errors.push(`Item "${item.titulo || item.id}" está sem categoria definida.`);
      }

      if (typeof item.score !== "number" || item.score < 0 || item.score > 100) {
        errors.push(`Item "${item.titulo}" possui score inválido: ${item.score}`);
      }
    });

    // --- 2. Validar dependências ---
    items.forEach(item => {
      if (item.dependencias && Array.isArray(item.dependencias)) {
        item.dependencias.forEach(depId => {
          // Verificar se a dependência existe no plano
          if (!itemMap.has(depId)) {
            errors.push(`Item "${item.titulo}" refere-se a uma dependência inexistente: ID "${depId}"`);
          } else {
            // Verificar se o filho tem data anterior ao pai no calendário
            const paiCal = calendar.find(c => c.id === depId);
            const filhoCal = calendar.find(c => c.id === item.id);

            if (paiCal && filhoCal) {
              const paiDate = new Date(paiCal.data).getTime();
              const filhoDate = new Date(filhoCal.data).getTime();

              if (filhoDate < paiDate) {
                errors.push(
                  `Inconsistência de Datas: O artigo satélite "${item.titulo}" está agendado para ${filhoCal.data}, que é antes de sua página pilar dependente ("${paiCal.conteudo}" em ${paiCal.data}).`
                );
              }
            }
          }
        });
      }
    });

    // --- 3. Validar consistência do calendário ---
    calendar.forEach((cal, index) => {
      if (!cal.id) {
        errors.push(`Item de calendário na posição ${index} está sem ID de amarração.`);
        return;
      }

      const dateVal = Date.parse(cal.data);
      if (isNaN(dateVal)) {
        errors.push(`Item de calendário ID "${cal.id}" possui data de publicação inválida: "${cal.data}".`);
      }

      if (!cal.conteudo || cal.conteudo.trim() === "") {
        errors.push(`Item de calendário ID "${cal.id}" está sem conteúdo/título.`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}
