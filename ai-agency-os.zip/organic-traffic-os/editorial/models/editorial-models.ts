export interface EditorialItem {
  id: string;
  titulo: string;
  cluster: string;
  categoria: string;
  tipo: "pilar" | "satelite" | "faq" | "simulado" | "material_rico" | string;
  prioridade: "baixa" | "media" | "alta" | "critica" | string;
  score: number; // Score calculado de 0 a 100
  dependencias: string[]; // IDs de itens que precisam ser publicados antes
  status: "pendente" | "planejamento" | "pronto" | "bloqueado" | "arquivado" | string;
  estimativa: string; // e.g. "4h", "8h", "16h"
  objetivo: string; // Meta editorial
  cta: string; // Call to Action principal sugerido
}

export interface CalendarItem {
  id: string;
  data: string; // ISO String (data de publicação programada)
  conteudo: string; // Título do conteúdo
  categoria: string;
  cluster: string;
  status: "agendado" | "publicado" | "atrasado" | string;
  responsavel: string; // Escritor/Agente responsável
}

export interface Roadmap {
  curto_prazo: EditorialItem[];  // Próximos 30 dias (Alta/Crítica prioridade, sem bloqueios)
  medio_prazo: EditorialItem[];  // 30-90 dias (Média prioridade ou bloqueado por curto prazo)
  longo_prazo: EditorialItem[];  // 90+ dias (Baixa prioridade ou dependências longas)
}

export interface DependencyRelation {
  id: string;
  paiId: string; // ID da Página Pilar
  filhoId: string; // ID do Artigo Satélite ou FAQ
  tipoRelacao: "pagina_pilar" | "artigo_satelite" | "faq_relacionado" | "simulado_relacionado" | "material_relacionado";
  tituloPai: string;
  tituloFilho: string;
}

export interface Backlog {
  pendentes: EditorialItem[];
  em_planejamento: EditorialItem[];
  prontos: EditorialItem[];
  bloqueados: EditorialItem[];
  arquivados: EditorialItem[];
}
