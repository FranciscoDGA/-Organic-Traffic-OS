import fs from "fs";
import path from "path";
import { EditorialItem, CalendarItem, Roadmap, DependencyRelation, Backlog } from "../models/editorial-models";
import { EditorialRanking } from "../ranking/editorial-ranking";
import { EditorialRules } from "../rules/editorial-rules";
import { PlannerValidator } from "../validator/planner-validator";
import { OpportunityService } from "../../opportunities/opportunity-service";

const PLANNER_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "planner", "editorial-item.json");
const CALENDAR_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "calendar", "calendar.json");
const ROADMAP_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "roadmap", "roadmap.json");
const DEPENDENCIES_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "dependencies", "dependencies.json");
const BACKLOG_FILE = path.join(process.cwd(), "organic-traffic-os", "editorial", "backlog", "backlog.json");

export class EditorialPlanner {
  /**
   * Executa a Engine do Planejamento Editorial completo.
   * Transforma oportunidades brutas em um plano estruturado, agendado e persistido.
   */
  public static async buildEditorialPlan(blogId: string = "passacumaru"): Promise<{
    editorialItems: EditorialItem[];
    calendar: CalendarItem[];
    roadmap: Roadmap;
    dependencies: DependencyRelation[];
    backlog: Backlog;
    log: any;
  }> {
    const startTime = Date.now();

    // 1. Carrega as oportunidades salvas ou força a descoberta
    let opportunities = OpportunityService.getOpportunities();
    if (opportunities.length === 0) {
      console.log("Nenhuma oportunidade no cache. Forçando descoberta resiliente...");
      opportunities = await OpportunityService.generateOpportunities(blogId);
    }

    // Se ainda assim for vazio (por exemplo, ausência completa de fontes), criamos candidatos default
    if (opportunities.length === 0) {
      console.log("Criando candidatos default de backup para o planejamento.");
      opportunities = [
        {
          id: "opp-backup-1",
          titulo: "Como Estudar para o Concurso da PF: Guia Completo de Estudos",
          categoria: "Concursos Policiais",
          cluster: "Polícia Federal",
          entidade: "Polícia Federal",
          tipo: "reforco_pilar",
          intencao: "Informacional",
          prioridade: "critica",
          score: 95,
          origem: "backup",
          motivo: "Palavra-chave pilar de alta busca e relevância extrema",
          status: "descoberta",
          criado_em: new Date().toISOString()
        },
        {
          id: "opp-backup-2",
          titulo: "Quais Matérias mais caem na prova de Agente da Polícia Federal?",
          categoria: "Concursos Policiais",
          cluster: "Polícia Federal",
          entidade: "Polícia Federal",
          tipo: "novo_artigo",
          intencao: "Informacional",
          prioridade: "alta",
          score: 80,
          origem: "backup",
          motivo: "Dúvida frequente identificada nas buscas PAA",
          status: "descoberta",
          criado_em: new Date().toISOString()
        },
        {
          id: "opp-backup-3",
          titulo: "Simulado Completo Grátis de Informática para Polícia Federal",
          categoria: "Concursos Policiais",
          cluster: "Polícia Federal",
          entidade: "Polícia Federal",
          tipo: "novo_artigo",
          intencao: "Transacional",
          prioridade: "alta",
          score: 85,
          origem: "backup",
          motivo: "Excelente para conversão e captura de leads do concurso",
          status: "descoberta",
          criado_em: new Date().toISOString()
        }
      ];
    }

    const editorialItems: EditorialItem[] = [];
    const dependencies: DependencyRelation[] = [];

    // --- 2. MAPEAMENTO DOS TIPOS EDITORIAIS & AGRUPAMENTO POR CLUSTERS ---
    // Agrupa oportunidades por cluster
    const clusterGroups: Record<string, typeof opportunities> = {};
    opportunities.forEach(opp => {
      const cluster = opp.cluster || "Geral";
      if (!clusterGroups[cluster]) {
        clusterGroups[cluster] = [];
      }
      clusterGroups[cluster].push(opp);
    });

    // Para cada cluster, define quem é a "Página Pilar" (geralmente o de maior score ou tipo reforco_pilar)
    // E os satélites de preenchimento.
    Object.entries(clusterGroups).forEach(([clusterName, opps]) => {
      // Ordena por score decrescente para facilitar a escolha do pilar
      opps.sort((a, b) => b.score - a.score);

      // Identifica ou define um item pilar
      let pilarId = "";
      let pilarTitulo = "";

      opps.forEach((opp, index) => {
        // Regra 2: Nunca publicar dois conteúdos iguais
        const isDup = EditorialRules.isDuplicate(opp.titulo, editorialItems);
        if (isDup.isDuplicate) {
          console.log(`Descartando item duplicado no plano: "${opp.titulo}"`);
          return;
        }

        // Determina o tipo editorial detalhado
        let tipo: "pilar" | "satelite" | "faq" | "simulado" | "material_rico" = "satelite";
        const titleLower = opp.titulo.toLowerCase();

        if (opp.tipo === "reforco_pilar" || index === 0) {
          tipo = "pilar";
        } else if (titleLower.includes("simulado") || titleLower.includes("questões")) {
          tipo = "simulado";
        } else if (titleLower.includes("e-book") || titleLower.includes("cronograma") || titleLower.includes("guia")) {
          tipo = "material_rico";
        } else if (titleLower.includes("como") || titleLower.includes("por que") || titleLower.includes("onde") || titleLower.includes("o que")) {
          tipo = "faq";
        }

        // Guarda informações do pilar para amarrar dependências
        if (tipo === "pilar") {
          pilarId = opp.id;
          pilarTitulo = opp.titulo;
        }

        // Estima tempo de produção
        let estimativa = "4h";
        if (tipo === "pilar") estimativa = "16h";
        else if (tipo === "material_rico" || tipo === "simulado") estimativa = "12h";
        else if (tipo === "satelite") estimativa = "6h";

        // Cria o EditorialItem temporário
        const edItem: EditorialItem = {
          id: opp.id,
          titulo: opp.titulo,
          cluster: clusterName,
          categoria: opp.categoria,
          tipo,
          prioridade: opp.prioridade,
          score: opp.score,
          dependencias: [],
          status: "pendente",
          estimativa,
          objetivo: tipo === "pilar" ? "Estabelecer autoridade central e hub de links." : "Responder intenção de busca específica e enviar link para o pilar.",
          cta: tipo === "pilar" ? "Inscreva-se na nossa newsletter semanal do concurso." : "Baixe nosso simulado de estudos gratuito."
        };

        editorialItems.push(edItem);
      });

      // Amarra as dependências: todos os filhos (satélite, faq, etc.) dependem da página pilar do cluster
      if (pilarId) {
        opps.forEach(opp => {
          if (opp.id !== pilarId) {
            const childItem = editorialItems.find(item => item.id === opp.id);
            if (childItem) {
              childItem.dependencias.push(pilarId);

              // Registra relação de dependência
              const relation: DependencyRelation = {
                id: `dep-${Math.random().toString(36).substring(2, 9)}`,
                paiId: pilarId,
                filhoId: opp.id,
                tipoRelacao: childItem.tipo === "faq" 
                  ? "faq_relacionado" 
                  : childItem.tipo === "simulado" 
                    ? "simulado_relacionado" 
                    : childItem.tipo === "material_rico" 
                      ? "material_relacionado" 
                      : "artigo_satelite",
                tituloPai: pilarTitulo,
                tituloFilho: opp.titulo
              };
              dependencies.push(relation);
            }
          }
        });
      }
    });

    // --- 3. RE-CALCULA PONTUAÇÃO (EDITORIAL RANKING) COM OS BOOSTS DE EDITORIAL RULES ---
    editorialItems.forEach(item => {
      const hasPillarDependency = item.dependencias.length > 0;
      
      // Calcula o score de ranking estratégico do planejamento
      const rankObj = EditorialRanking.calculate({
        tipo: item.tipo,
        prioridade: item.prioridade,
        origem: "opportunity",
        hasPillarDependency
      });

      // Aplica boosts específicos de regras editoriais
      let scoreFinal = rankObj.score;
      scoreFinal += EditorialRules.getClusterIncompletenessBoost(item.cluster, editorialItems);
      scoreFinal += EditorialRules.getAuthorityBoost(item.tipo);
      scoreFinal += EditorialRules.getEvergreenBoost(item.titulo, item.categoria);

      item.score = Math.max(0, Math.min(100, scoreFinal));

      // Deduz prioridade pelo score
      if (item.score >= 85) item.prioridade = "critica";
      else if (item.score >= 70) item.prioridade = "alta";
      else if (item.score >= 50) item.prioridade = "media";
      else item.prioridade = "baixa";
    });

    // --- 4. CRIAÇÃO DO CALENDÁRIO COM ORDENAÇÃO DE PILAR ANTES DO FILHO ---
    // Ordena de forma que:
    // 1. Pilares vêm antes de satélites do mesmo cluster
    // 2. Scores maiores vêm antes
    const sortedForScheduling = [...editorialItems].sort((a, b) => {
      // Se um for pilar e o outro satélite do mesmo cluster, pilar vem antes
      if (a.cluster === b.cluster) {
        if (a.tipo === "pilar" && b.tipo !== "pilar") return -1;
        if (b.tipo === "pilar" && a.tipo !== "pilar") return 1;
      }
      return b.score - a.score;
    });

    const calendar: CalendarItem[] = [];
    let currentDate = new Date("2026-07-01T10:00:00Z"); // Data de referência da sprint

    sortedForScheduling.forEach((item, index) => {
      // Agenda 2 posts por semana (Terças e Quintas)
      // Adiciona dias de acordo com o index
      // Se for terço/quinto index, pulamos para a próxima data disponível
      const daysToAdd = index * 3.5; // Aproximadamente 2 por semana
      const pubDate = new Date(currentDate.getTime() + daysToAdd * 24 * 60 * 60 * 1000);
      
      calendar.push({
        id: item.id,
        data: pubDate.toISOString().split("T")[0], // YYYY-MM-DD
        conteudo: item.titulo,
        categoria: item.categoria,
        cluster: item.cluster,
        status: "agendado",
        responsavel: "Agente Editor-Chefe"
      });

      // Atualiza status do EditorialItem
      // Os primeiros 3 itens no calendário já entram como "em_planejamento" ou "pronto", o restante "pendente"
      if (index === 0) {
        item.status = "pronto";
      } else if (index < 4) {
        item.status = "planejamento";
      } else {
        item.status = "pendente";
      }
    });

    // --- 5. ROADMAP (CURTO, MÉDIO E LONGO PRAZO) ---
    const roadmap: Roadmap = {
      curto_prazo: [],
      medio_prazo: [],
      longo_prazo: []
    };

    sortedForScheduling.forEach((item, index) => {
      // Curto prazo: Pilares ou alta prioridade, programados para os primeiros 30 dias (primeiros 8 artigos)
      if (index < 8) {
        roadmap.curto_prazo.push(item);
      } else if (index < 18) {
        roadmap.medio_prazo.push(item);
      } else {
        roadmap.longo_prazo.push(item);
      }
    });

    // --- 6. BACKLOG (STATUS GROUPS) ---
    const backlog: Backlog = {
      pendentes: [],
      em_planejamento: [],
      prontos: [],
      bloqueados: [],
      arquivados: []
    };

    editorialItems.forEach(item => {
      // Verifica se o pai de dependência está agendado antes. Se não, fica bloqueado!
      let isBlocked = false;
      if (item.dependencias && item.dependencias.length > 0) {
        const pilarId = item.dependencias[0];
        const pilarCal = calendar.find(c => c.id === pilarId);
        const filhoCal = calendar.find(c => c.id === item.id);

        if (pilarCal && filhoCal) {
          const pilarTime = new Date(pilarCal.data).getTime();
          const filhoTime = new Date(filhoCal.data).getTime();
          if (filhoTime < pilarTime) {
            isBlocked = true;
            item.status = "bloqueado";
          }
        }
      }

      if (isBlocked) {
        backlog.bloqueados.push(item);
      } else if (item.status === "pronto") {
        backlog.prontos.push(item);
      } else if (item.status === "planejamento") {
        backlog.em_planejamento.push(item);
      } else if (item.status === "arquivado") {
        backlog.arquivados.push(item);
      } else {
        backlog.pendentes.push(item);
      }
    });

    // --- 7. VALIDAÇÃO DO PLANEJAMENTO (PLANNER VALIDATOR) ---
    const validation = PlannerValidator.validate(editorialItems, calendar);
    if (!validation.isValid) {
      console.warn("Divergências encontradas no planejamento editorial durante validação automática:", validation.errors);
    }

    // --- 8. PERSISTÊNCIA DOS ARQUIVOS JSON ---
    fs.writeFileSync(PLANNER_FILE, JSON.stringify(editorialItems, null, 2), "utf-8");
    fs.writeFileSync(CALENDAR_FILE, JSON.stringify(calendar, null, 2), "utf-8");
    fs.writeFileSync(ROADMAP_FILE, JSON.stringify(roadmap, null, 2), "utf-8");
    fs.writeFileSync(DEPENDENCIES_FILE, JSON.stringify(dependencies, null, 2), "utf-8");
    fs.writeFileSync(BACKLOG_FILE, JSON.stringify(backlog, null, 2), "utf-8");

    const duracaoMs = Date.now() - startTime;
    const logObj = {
      timestamp: new Date().toISOString(),
      duracaoMs,
      totalOportunidadesProcessadas: opportunities.length,
      totalItensEditorialGerados: editorialItems.length,
      pilaresCriados: editorialItems.filter(i => i.tipo === "pilar").length,
      satelitesCriados: editorialItems.filter(i => i.tipo === "satelite").length,
      faqsCriados: editorialItems.filter(i => i.tipo === "faq").length,
      dependenciasMapeadas: dependencies.length,
      errosValidacao: validation.errors,
      avisosValidacao: validation.warnings
    };

    return {
      editorialItems,
      calendar,
      roadmap,
      dependencies,
      backlog,
      log: logObj
    };
  }
}
export default EditorialPlanner;
