import { GoogleGenAI } from "@google/genai";
import { Fact, FactEvidence } from "../models/fact-models";
import { FactValidator } from "../validators/fact-validator";
import { ResearchPack } from "../../research-pack/models/research-models";
import confidenceRules from "../sources/confidence-score.json";
import categoriesData from "../sources/fact-categories.json";

export class FactEngine {
  private static aiClient: any = null;

  private static getAI(): any {
    if (!this.aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey) {
        this.aiClient = new GoogleGenAI({ apiKey });
      }
    }
    return this.aiClient;
  }

  /**
   * Calculates the detailed confidence score based on rules and evidence attributes.
   */
  public static calculateConfidenceScore(
    factDesc: string,
    origin: string,
    evidences: FactEvidence[]
  ): {
    confiabilidade: number;
    quantidade_fontes: number;
    atualidade: number;
    autoridade: number;
    consistencia: number;
    geral: number;
  } {
    // 1. Confiabilidade (0-100)
    let confiabilidade = 70; // baseline
    if (origin.toLowerCase().includes("clt") || origin.toLowerCase().includes("lei") || origin.toLowerCase().includes("mte")) {
      confiabilidade = 95;
    } else if (origin.toLowerCase().includes("edital") || origin.toLowerCase().includes("dou")) {
      confiabilidade = 100;
    }

    // 2. Quantidade de fontes (0-100)
    const sourceCount = evidences.length;
    const quantidade_fontes = Math.min(100, Math.max(30, sourceCount * 45));

    // 3. Atualidade (0-100)
    let atualidade = 80; // default for current year or specified date
    const currentYear = new Date().getFullYear();
    const hasRecentEvidence = evidences.some(ev => ev.data && ev.data.includes(String(currentYear)));
    if (hasRecentEvidence) {
      atualidade = 98;
    }

    // 4. Autoridade (0-100)
    let autoridade = 50;
    evidences.forEach(ev => {
      if (ev.url && (ev.url.includes(".gov.br") || ev.url.includes("planalto.gov.br") || ev.url.includes("jus.br"))) {
        autoridade = 100;
      } else if (ev.url && ev.url.includes("wikipedia.org") || ev.url.includes("g1.globo.com")) {
        autoridade = Math.max(autoridade, 75);
      }
    });

    // 5. Consistencia (0-100)
    let consistencia = 90;
    if (factDesc.length > 25) consistencia = 95;

    // Load weights from confidenceRules or use defaults
    const weights = confidenceRules?.metricas || {
      confiabilidade: { peso: 0.25 },
      quantidade_fontes: { peso: 0.15 },
      atualidade: { peso: 0.20 },
      autoridade: { peso: 0.25 },
      consistencia: { peso: 0.15 }
    };

    const wConf = weights.confiabilidade.peso;
    const wQtd = weights.quantidade_fontes.peso;
    const wAtu = weights.atualidade.peso;
    const wAut = weights.autoridade.peso;
    const wCons = weights.consistencia.peso;

    const geral = Math.round(
      confiabilidade * wConf +
      quantidade_fontes * wQtd +
      atualidade * wAtu +
      autoridade * wAut +
      consistencia * wCons
    );

    return {
      confiabilidade,
      quantidade_fontes,
      atualidade,
      autoridade,
      consistencia,
      geral
    };
  }

  /**
   * Infers the most suitable category based on fact description keywords
   */
  public static inferCategory(text: string): string {
    const textLower = text.toLowerCase();
    
    if (textLower.includes("lei") || textLower.includes("clt") || textLower.includes("decreto") || textLower.includes("artigo") || textLower.includes("art.")) {
      return "Legislação";
    }
    if (textLower.includes("concurso") || textLower.includes("vagas") || textLower.includes("prova") || textLower.includes("certame")) {
      return "Concurso";
    }
    if (textLower.includes("salário") || textLower.includes("vencimento") || textLower.includes("remuneração") || textLower.includes("benefício") || textLower.includes("r$") || textLower.includes("pagamento")) {
      return "Salário";
    }
    if (textLower.includes("edital") || textLower.includes("retificação")) {
      return "Edital";
    }
    if (textLower.includes("cargo") || textLower.includes("atribuição") || textLower.includes("requisito") || textLower.includes("agente") || textLower.includes("escrivão")) {
      return "Cargo";
    }
    if (textLower.includes("cronograma") || textLower.includes("calendário") || textLower.includes("datas") || textLower.includes("período") || textLower.includes("inscrição") || textLower.includes("prazo")) {
      return "Cronograma";
    }
    if (textLower.includes("cebraspe") || textLower.includes("fgv") || textLower.includes("fcc") || textLower.includes("banca") || textLower.includes("organizadora")) {
      return "Banca";
    }
    if (textLower.includes("polícia") || textLower.includes("pf") || textLower.includes("instituto") || textLower.includes("ministério") || textLower.includes("mte") || textLower.includes("ibama")) {
      return "Instituição";
    }
    if (textLower.includes("resolução") || textLower.includes("instrução normativa") || textLower.includes("portaria") || textLower.includes("norma")) {
      return "Norma";
    }
    
    // Default fallback
    return "Documento";
  }

  /**
   * Compiles the raw Fact list by extracting them from the Research Pack.
   * Leverages Gemini if API Key is available, otherwise falls back to algorithmic parsing.
   */
  public static async extractFacts(pack: ResearchPack): Promise<Fact[]> {
    const facts: Fact[] = [];
    const ai = this.getAI();

    // Map initial evidences based on research pack sources
    const baseEvidences: FactEvidence[] = (pack.fontes || []).map(f => ({
      fonte: f.nome || "Fonte Mapeada",
      tipo: f.tipo || "oficial",
      url: f.url || "https://www.gov.br",
      titulo: f.nome || "Documento de Referência",
      data: new Date().toISOString().split("T")[0],
      autor: "Pesquisa Editorial"
    }));

    if (ai) {
      try {
        const prompt = `Você é o Fact Intelligence Engine do Organic Traffic OS.
Você deve analisar o seguinte Dossiê de Pesquisa (Research Pack) e extrair fatos técnicos cruciais, regulamentos, prazos, exigências ou salários.

CONTEÚDO DO DOSSIÊ DE PESQUISA:
Título: ${pack.titulo}
Contexto: ${pack.contexto}
Fatos Brutos Informados: ${JSON.stringify(pack.fatos)}
Perguntas do SEO: ${JSON.stringify(pack.perguntas)}
Fontes: ${JSON.stringify(pack.fontes)}

SUA MISSÃO:
Extraia pelo menos 3 e no máximo 6 fatos técnicos independentes, imutáveis e verificáveis.
Para cada fato extraído, estruture em formato JSON válido como um array de objetos com os seguintes campos:
- descricao (string, exata, concisa e auto-contida)
- categoria (deve ser estritamente uma destas: Legislação, Concurso, Cargo, Salário, Edital, Cronograma, Banca, Instituição, Cidade, Estado, Norma, Documento)
- origem (string, específica e identificável, ex: "CLT Art. 477", "Edital PF 2026")
- tipo (string, ex: "lei", "regulamento", "cronograma", "salário", etc.)
- observacoes (string, notas adicionais contextuais)

RETORNE APENAS O ARRAY JSON, sem comentários ou explicações em markdown.`;

        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json"
          }
        });

        const textResponse = response.text || "";
        const extracted = JSON.parse(textResponse);

        if (Array.isArray(extracted)) {
          extracted.forEach((item, index) => {
            const factId = `fact-${pack.id}-${index}-${Date.now().toString(36)}`;
            const score_detalhado = this.calculateConfidenceScore(item.descricao, item.origem || "MTE", baseEvidences);
            const rawFact: Fact = {
              id: factId,
              descricao: item.descricao,
              categoria: item.categoria || this.inferCategory(item.descricao),
              origem: item.origem || "Pesquisa Editorial",
              tipo: item.tipo || "regulamento",
              nivel_confianca: score_detalhado.geral >= 85 ? "alta" : score_detalhado.geral >= 55 ? "média" : "baixa",
              status: "pendente", // Default to pending for validation review
              ultima_validacao: new Date().toISOString(),
              observacoes: item.observacoes || "Extraído via Fact Intelligence Engine.",
              score_detalhado,
              evidencias: baseEvidences,
              versao: 1,
              historico: []
            };
            facts.push(rawFact);
          });
        }
      } catch (err) {
        console.warn("Falha ao invocar o Gemini para Fact Extraction, utilizando fallback algorítmico:", err);
      }
    }

    // Programmatic algorithmic fallback if Gemini was not available or failed
    if (facts.length === 0) {
      // 1. Extract from pack.fatos list
      if (pack.fatos && pack.fatos.length > 0) {
        pack.fatos.forEach((f, idx) => {
          const factId = `fact-${pack.id}-f-${idx}`;
          const inferredCategory = this.inferCategory(f.descricao);
          const score_detalhado = this.calculateConfidenceScore(f.descricao, f.origem, baseEvidences);

          facts.push({
            id: factId,
            descricao: f.descricao,
            categoria: inferredCategory,
            origem: f.origem || "Pesquisa do Blueprint",
            tipo: "fato_pesquisa",
            nivel_confianca: f.nivel_confianca || (score_detalhado.geral >= 85 ? "alta" : score_detalhado.geral >= 55 ? "média" : "baixa"),
            status: "aprovado", // Seed facts can default to approved
            ultima_validacao: new Date().toISOString(),
            observacoes: "Fato extraído de forma algorítmica do Research Pack.",
            score_detalhado,
            evidencias: baseEvidences,
            versao: 1,
            historico: []
          });
        });
      }

      // 2. Synthesize one fact from context or metadata if the pack has very few facts
      if (facts.length < 2 && pack.contexto) {
        const factId = `fact-${pack.id}-ctx`;
        const desc = `Para o conteúdo '${pack.titulo.replace("Dossiê de Pesquisa: ", "")}', aplica-se o escopo regulatório descrito no dossiê.`;
        const score_detalhado = this.calculateConfidenceScore(desc, "Contexto de Pesquisa", baseEvidences);

        facts.push({
          id: factId,
          descricao: desc,
          categoria: "Documento",
          origem: "Contexto do Dossiê",
          tipo: "sintese_contextual",
          nivel_confianca: "média",
          status: "pendente",
          ultima_validacao: new Date().toISOString(),
          observacoes: "Fato de síntese gerado automaticamente com base no contexto geral do dossiê.",
          score_detalhado,
          evidencias: baseEvidences,
          versao: 1,
          historico: []
        });
      }
    }

    return facts;
  }
}
