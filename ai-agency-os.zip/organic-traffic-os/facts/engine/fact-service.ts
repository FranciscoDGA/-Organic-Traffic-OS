import fs from "fs";
import path from "path";
import { Fact, FactEvidence, FactValidationResult } from "../models/fact-models";
import { FactValidator } from "../validators/fact-validator";
import { FactEngine } from "./fact-engine";
import { ResearchService } from "../../research-pack/engine/research-service";

const FACTS_FILE = path.join(process.cwd(), "organic-traffic-os", "facts", "database", "fact.json");
const EVIDENCE_FILE = path.join(process.cwd(), "organic-traffic-os", "facts", "evidence", "evidence.json");

function ensureDbExists() {
  const factsDir = path.dirname(FACTS_FILE);
  if (!fs.existsSync(factsDir)) {
    fs.mkdirSync(factsDir, { recursive: true });
  }
  const evidenceDir = path.dirname(EVIDENCE_FILE);
  if (!fs.existsSync(evidenceDir)) {
    fs.mkdirSync(evidenceDir, { recursive: true });
  }

  if (!fs.existsSync(FACTS_FILE)) {
    fs.writeFileSync(FACTS_FILE, "[]", "utf-8");
  }
  if (!fs.existsSync(EVIDENCE_FILE)) {
    fs.writeFileSync(EVIDENCE_FILE, "[]", "utf-8");
  }
}

export class FactService {
  /**
   * Retrieves all registered facts from the database.
   */
  public static getAllFacts(): Fact[] {
    ensureDbExists();
    try {
      const raw = fs.readFileSync(FACTS_FILE, "utf-8");
      return JSON.parse(raw);
    } catch (e) {
      console.error("Erro ao ler banco de fatos:", e);
      return [];
    }
  }

  /**
   * Retrieves a specific fact by ID.
   */
  public static getFact(id: string): Fact | null {
    const facts = this.getAllFacts();
    return facts.find(f => f.id === id) || null;
  }

  /**
   * Saves the list of facts back to the database.
   */
  private static saveFacts(facts: Fact[]) {
    ensureDbExists();
    fs.writeFileSync(FACTS_FILE, JSON.stringify(facts, null, 2), "utf-8");
  }

  /**
   * Registers a brand new fact in the database.
   */
  public static registerFact(fact: Fact): Fact {
    const facts = this.getAllFacts();
    
    // Validate
    const validation = FactValidator.validate(fact, facts);
    if (!validation.isValid) {
      throw new Error(`Validação de fato falhou: ${validation.errors.join("; ")}`);
    }

    // Set defaults
    const newFact: Fact = {
      ...fact,
      versao: fact.versao || 1,
      historico: fact.historico || [],
      ultima_validacao: new Date().toISOString()
    };

    facts.push(newFact);
    this.saveFacts(facts);

    // Also register its evidences
    if (newFact.evidencias && newFact.evidencias.length > 0) {
      this.registerEvidences(newFact.evidencias);
    }

    return newFact;
  }

  /**
   * Updates an existing fact, performing validations and incrementing version details.
   */
  public static updateFact(
    id: string,
    updatedData: Partial<Fact>,
    autor: string = "Editor de Fatos",
    alteracao: string = "Edição manual"
  ): Fact {
    const facts = this.getAllFacts();
    const index = facts.findIndex(f => f.id === id);
    if (index === -1) {
      throw new Error(`Fato com ID '${id}' não localizado para atualização.`);
    }

    const existing = facts[index];
    const previousDesc = existing.descricao;
    const currentVersion = existing.versao || 1;
    const nextVersion = currentVersion + 1;

    // Build proposed updated fact
    const updatedFact: Fact = {
      ...existing,
      ...updatedData,
      id: existing.id, // Preserve ID
      versao: nextVersion,
      ultima_validacao: new Date().toISOString(),
      historico: [
        ...(existing.historico || []),
        {
          versao: currentVersion,
          data: existing.ultima_validacao || new Date().toISOString(),
          autor,
          alteracao,
          descricao_anterior: previousDesc
        }
      ]
    };

    // Re-validate
    const validation = FactValidator.validate(updatedFact, facts);
    if (!validation.isValid) {
      throw new Error(`Erro na validação do fato atualizado: ${validation.errors.join("; ")}`);
    }

    // Calculate score
    if (updatedFact.descricao !== existing.descricao || updatedFact.origem !== existing.origem || updatedFact.evidencias?.length !== existing.evidencias?.length) {
      updatedFact.score_detalhado = FactEngine.calculateConfidenceScore(
        updatedFact.descricao,
        updatedFact.origem,
        updatedFact.evidencias || []
      );
      updatedFact.nivel_confianca = updatedFact.score_detalhado.geral >= 85 ? "alta" : updatedFact.score_detalhado.geral >= 55 ? "média" : "baixa";
    }

    facts[index] = updatedFact;
    this.saveFacts(facts);

    // Register any new evidences
    if (updatedFact.evidencias && updatedFact.evidencias.length > 0) {
      this.registerEvidences(updatedFact.evidencias);
    }

    return updatedFact;
  }

  /**
   * Registers a batch of evidences. Appends only non-duplicate URLs to evidence.json.
   */
  public static registerEvidences(evidences: FactEvidence[]) {
    ensureDbExists();
    try {
      const raw = fs.readFileSync(EVIDENCE_FILE, "utf-8");
      const existingEvidences: FactEvidence[] = JSON.parse(raw);

      evidences.forEach(newEv => {
        const isDuplicated = existingEvidences.some(
          ex => ex.url.trim().toLowerCase() === newEv.url.trim().toLowerCase()
        );
        if (!isDuplicated) {
          existingEvidences.push(newEv);
        }
      });

      fs.writeFileSync(EVIDENCE_FILE, JSON.stringify(existingEvidences, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar evidências:", e);
    }
  }

  /**
   * Retrieves all unique evidences in the system.
   */
  public static getAllEvidences(): FactEvidence[] {
    ensureDbExists();
    try {
      const raw = fs.readFileSync(EVIDENCE_FILE, "utf-8");
      return JSON.parse(raw);
    } catch (e) {
      console.error("Erro ao ler base de evidências:", e);
      return [];
    }
  }

  /**
   * Search and filter facts by category.
   */
  public static getFactsByCategory(category: string): Fact[] {
    const facts = this.getAllFacts();
    return facts.filter(f => f.categoria.toLowerCase() === category.toLowerCase());
  }

  /**
   * Executes the Fact Engine Workflow:
   * 1. Loads a Research Pack.
   * 2. Extracts candidate facts.
   * 3. Performs de-duplication against existing database facts.
   * 4. Appends all unique valid facts as 'pendente' for manual audit.
   */
  public static async processResearchPack(packId: string): Promise<Fact[]> {
    const pack = ResearchService.getPack(packId);
    if (!pack) {
      throw new Error(`Dossiê de Pesquisa (Research Pack) com ID '${packId}' não foi localizado.`);
    }

    // Extract facts
    const extractedFacts = await FactEngine.extractFacts(pack);
    const existingFacts = this.getAllFacts();
    const registered: Fact[] = [];

    for (const fact of extractedFacts) {
      // De-duplicate checking identical descriptions
      const isDuplicated = existingFacts.some(
        ex => ex.descricao.trim().toLowerCase() === fact.descricao.trim().toLowerCase()
      );

      if (!isDuplicated) {
        // Run validator
        const validation = FactValidator.validate(fact, existingFacts);
        if (validation.isValid) {
          // Register
          const saved = this.registerFact(fact);
          registered.push(saved);
          existingFacts.push(saved); // update memory list for subsequent loop iterations
        } else {
          console.warn(`Fato extraído foi pulado devido a erros de validação:`, validation.errors);
        }
      }
    }

    return registered;
  }
}
export { FactValidator };
