export interface FactEvidence {
  fonte: string;
  tipo: "oficial" | "documentação" | "institucional" | "norma" | "outro" | string;
  url: string;
  titulo: string;
  data: string;
  autor: string;
  observacoes?: string;
}

export interface Fact {
  id: string;
  descricao: string;
  categoria: "Legislação" | "Concurso" | "Cargo" | "Salário" | "Edital" | "Cronograma" | "Banca" | "Instituição" | "Cidade" | "Estado" | "Norma" | "Documento" | string;
  origem: string;
  tipo: string;
  nivel_confianca: "alta" | "média" | "baixa" | string;
  status: "pendente" | "aprovado" | "rejeitado" | string;
  ultima_validacao: string;
  observacoes: string;
  score_detalhado?: {
    confiabilidade: number; // 0-100
    quantidade_fontes: number; // 0-100
    atualidade: number; // 0-100
    autoridade: number; // 0-100
    consistencia: number; // 0-100
    geral: number; // Weighted/average score
  };
  evidencias?: FactEvidence[];
  versao?: number;
  historico?: {
    versao: number;
    data: string;
    autor: string;
    alteracao: string;
    descricao_anterior: string;
  }[];
}

export interface FactCategory {
  nome: string;
  descricao: string;
}

export interface FactRule {
  id: string;
  regra: string;
  descricao: string;
  obrigatoria: boolean;
}

export interface FactValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}
