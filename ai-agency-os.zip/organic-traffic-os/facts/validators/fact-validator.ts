import { Fact, FactValidationResult } from "../models/fact-models";
import categoriesData from "../sources/fact-categories.json";

export class FactValidator {
  /**
   * Validates a single fact according to structure, consistency, and completeness rules.
   */
  public static validate(fact: Fact, existingFacts: Fact[] = []): FactValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 1. Structural checks
    if (!fact.id || typeof fact.id !== "string" || !fact.id.trim()) {
      errors.push("O ID do fato é obrigatório e precisa ser uma string não vazia.");
    }

    if (!fact.descricao || typeof fact.descricao !== "string" || !fact.descricao.trim()) {
      errors.push("A descrição/texto do fato é obrigatória.");
    } else if (fact.descricao.length < 15) {
      warnings.push("Descrição do fato é muito curta (menos de 15 caracteres). Recomenda-se maior profundidade de evidência.");
    }

    if (!fact.categoria || typeof fact.categoria !== "string" || !fact.categoria.trim()) {
      errors.push("A categoria do fato é obrigatória.");
    } else {
      const allowedCategories = categoriesData.map(c => c.nome.toLowerCase());
      if (!allowedCategories.includes(fact.categoria.toLowerCase())) {
        warnings.push(`A categoria '${fact.categoria}' não consta no catálogo padrão de categorias homologadas.`);
      }
    }

    // 2. Origins (Rule: Nunca aceitar fatos sem origem clara)
    if (!fact.origem || typeof fact.origem !== "string" || !fact.origem.trim() || fact.origem.toLowerCase() === "desconhecido" || fact.origem.toLowerCase() === "unknown") {
      errors.push("Regra Violada: O fato não possui origem documentada clara. Não são aceitas informações sem rastreabilidade.");
    }

    if (!fact.nivel_confianca || !["alta", "média", "baixa"].includes(fact.nivel_confianca.toLowerCase())) {
      errors.push("O nível de confiança deve ser explicitamente definido como 'alta', 'média' ou 'baixa'.");
    }

    if (!fact.status || !["pendente", "aprovado", "rejeitado"].includes(fact.status.toLowerCase())) {
      errors.push("O status do fato deve ser 'pendente', 'aprovado' ou 'rejeitado'.");
    }

    // 3. Duplicity & Consistency check
    const duplicatedId = existingFacts.find(f => f.id === fact.id && f !== fact);
    if (duplicatedId) {
      errors.push(`ID Duplicado: Já existe outro fato cadastrado com o ID '${fact.id}'.`);
    }

    const duplicatedText = existingFacts.find(f => 
      f.descricao.trim().toLowerCase() === fact.descricao.trim().toLowerCase() && 
      f.id !== fact.id
    );
    if (duplicatedText) {
      warnings.push(`Fato Redundante: Existe outro fato com a mesma descrição exata (ID: ${duplicatedText.id}).`);
    }

    // 4. Evidence check
    if (fact.evidencias && Array.isArray(fact.evidencias)) {
      fact.evidencias.forEach((ev, idx) => {
        if (!ev.fonte || !ev.fonte.trim()) {
          errors.push(`Evidência [${idx}]: Nome da fonte é obrigatório.`);
        }
        if (!ev.url || !ev.url.trim()) {
          errors.push(`Evidência [${idx}]: URL de apoio é obrigatória.`);
        } else {
          try {
            const urlObj = new URL(ev.url);
            if (!["http:", "https:"].includes(urlObj.protocol)) {
              errors.push(`Evidência [${idx}]: Protocolo de URL inválido (${urlObj.protocol}). Requer HTTP ou HTTPS.`);
            }
          } catch (e) {
            errors.push(`Evidência [${idx}]: URL malformada ('${ev.url}').`);
          }
        }
      });
    } else if (fact.status === "aprovado") {
      warnings.push("Fato foi aprovado, mas não contém referências de evidências mapeadas em anexo.");
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}
