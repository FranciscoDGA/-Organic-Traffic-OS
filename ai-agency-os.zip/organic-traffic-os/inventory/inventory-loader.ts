import fs from "fs";
import path from "path";
import { runInventoryScan } from "./inventory-engine";
import { validateInventory } from "./inventory-validator";

export interface ConsolidatedInventory {
  index: any[];
  health: any[];
  gaps: any[];
  duplicates: any[];
  orphans: any[];
  brokenLinks: any[];
  metadata: {
    totalContents: number;
    totalCategories: number;
    totalTags: number;
    articlesCount: number;
    pagesCount: number;
    videosCount: number;
    ebooksCount: number;
    simuladosCount: number;
    orphansCount: number;
    duplicatesCount: number;
    averageHealthScore: number;
    lastUpdated: string;
    isValid: boolean;
    errors: string[];
  };
}

export function loadInventory(blogId: string = "passacumaru"): ConsolidatedInventory {
  // Always trigger scan so we work with live and real data!
  runInventoryScan(blogId);

  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "content");

  const files = {
    index: "content-index.json",
    health: "content-health.json",
    gaps: "content-gaps.json",
    duplicates: "duplicate-content.json",
    orphans: "orphan-pages.json",
    broken: "broken-links.json"
  };

  let index: any[] = [];
  let health: any[] = [];
  let gaps: any[] = [];
  let duplicates: any[] = [];
  let orphans: any[] = [];
  let brokenLinks: any[] = [];

  try {
    if (fs.existsSync(path.join(baseDir, files.index))) {
      index = JSON.parse(fs.readFileSync(path.join(baseDir, files.index), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.health))) {
      health = JSON.parse(fs.readFileSync(path.join(baseDir, files.health), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.gaps))) {
      gaps = JSON.parse(fs.readFileSync(path.join(baseDir, files.gaps), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.duplicates))) {
      duplicates = JSON.parse(fs.readFileSync(path.join(baseDir, files.duplicates), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.orphans))) {
      orphans = JSON.parse(fs.readFileSync(path.join(baseDir, files.orphans), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.broken))) {
      brokenLinks = JSON.parse(fs.readFileSync(path.join(baseDir, files.broken), "utf-8"));
    }
  } catch (err) {
    console.error("Error reading inventory compiled files:", err);
  }

  // Validate loaded structures
  const valResult = validateInventory();

  // Compute stats/metadata
  const categoriesSet = new Set<string>();
  const tagsSet = new Set<string>();
  let articlesCount = 0;
  let pagesCount = 0;
  let videosCount = 0;
  let ebooksCount = 0;
  let simuladosCount = 0;

  index.forEach((item: any) => {
    if (item.categoria) categoriesSet.add(item.categoria);
    if (item.tags && Array.isArray(item.tags)) {
      item.tags.forEach((t: string) => tagsSet.add(t));
    }

    if (item.tipo === "artigo") articlesCount++;
    else if (item.tipo === "pagina") pagesCount++;
    else if (item.tipo === "video") videosCount++;
    else if (item.tipo === "ebook") ebooksCount++;
    else if (item.tipo === "simulado") simuladosCount++;
  });

  const totalScore = health.reduce((sum, item) => sum + (item.scoreGeral || 0), 0);
  const averageHealthScore = health.length > 0 ? Math.round(totalScore / health.length) : 0;

  return {
    index,
    health,
    gaps,
    duplicates,
    orphans,
    brokenLinks,
    metadata: {
      totalContents: index.length,
      totalCategories: categoriesSet.size,
      totalTags: tagsSet.size,
      articlesCount,
      pagesCount,
      videosCount,
      ebooksCount,
      simuladosCount,
      orphansCount: orphans.length,
      duplicatesCount: duplicates.length,
      averageHealthScore,
      lastUpdated: new Date().toISOString(),
      isValid: valResult.isValid,
      errors: valResult.errors
    }
  };
}
