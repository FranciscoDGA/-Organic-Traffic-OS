import fs from "fs";
import path from "path";

export interface ContentItem {
  id: string;
  tipo: string;
  titulo: string;
  slug: string;
  url: string;
  categoria: string;
  tags: string[];
  status: string;
  autor: string;
  data_publicacao: string;
  ultima_atualizacao: string;
  palavra_chave_principal: string;
  palavras_secundarias: string[];
  meta_title: string;
  meta_description: string;
  quantidade_palavras: number;
  quantidade_imagens: number;
  links_internos: string[];
  links_externos: string[];
  possui_FAQ: boolean;
  possui_schema: boolean;
  possui_CTA: boolean;
  produto_relacionado: string | null;
}

export interface ContentHealthItem {
  id: string;
  titulo: string;
  url: string;
  scoreGeral: number;
  seoScore: number;
  qualidade: number; // 0-100
  legibilidade: number; // 0-100
  atualizacao: string; // "Atualizado" | "Regular" | "Desatualizado"
  estrutura: number; // 0-100
  links: number; // 0-100
  imagens: number; // 0-100
  faq: string; // "Sim" | "Não"
  cta: string; // "Sim" | "Não"
  status: "Excelente" | "Bom" | "Precisa de Atenção" | "Crítico";
}

export interface DuplicateGroup {
  id_A: string;
  id_B: string;
  titulo_A: string;
  titulo_B: string;
  conflito: string; // "slug" | "palavra_chave_principal" | "titulo" | "url"
  valor_conflito: string;
}

export interface OrphanPage {
  id: string;
  titulo: string;
  url: string;
  categoria: string;
}

export interface BrokenLink {
  url: string;
  origem: string;
  destino: string;
  status: number;
  observacoes: string;
}

export function runInventoryScan(blogId: string = "passacumaru") {
  const postsDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "blogs", blogId, "posts");
  const outputDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "content");

  // Ensure directories exist
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const items: ContentItem[] = [];

  if (fs.existsSync(postsDir)) {
    const files = fs.readdirSync(postsDir);
    files.forEach(file => {
      if (file.endsWith(".json")) {
        try {
          const raw = fs.readFileSync(path.join(postsDir, file), "utf-8");
          const parsed = JSON.parse(raw);
          items.push({
            id: parsed.id,
            tipo: parsed.tipo || "artigo",
            titulo: parsed.titulo || "",
            slug: parsed.slug || "",
            url: parsed.url || "",
            categoria: parsed.categoria || "Geral",
            tags: parsed.tags || [],
            status: parsed.status || "publicado",
            autor: parsed.autor || "Desconhecido",
            data_publicacao: parsed.data_publicacao || "",
            ultima_atualizacao: parsed.ultima_atualizacao || "",
            palavra_chave_principal: parsed.palavra_chave_principal || "",
            palavras_secundarias: parsed.palavras_secundarias || [],
            meta_title: parsed.meta_title || "",
            meta_description: parsed.meta_description || "",
            quantidade_palavras: parsed.quantidade_palavras || 0,
            quantidade_imagens: parsed.quantidade_imagens || 0,
            links_internos: parsed.links_internos || [],
            links_externos: parsed.links_externos || [],
            possui_FAQ: parsed.possui_FAQ || false,
            possui_schema: parsed.possui_schema || false,
            possui_CTA: parsed.possui_CTA || false,
            produto_relacionado: parsed.produto_relacionado || null
          });
        } catch (e) {
          console.error(`Error reading content file ${file}:`, e);
        }
      }
    });
  }

  // 1. Write content-index.json
  fs.writeFileSync(path.join(outputDir, "content-index.json"), JSON.stringify(items, null, 2), "utf-8");

  // 2. Compute Health
  const healthList: ContentHealthItem[] = items.map(item => {
    // SEO score
    let seoScore = 0;
    if (item.titulo.toLowerCase().includes(item.palavra_chave_principal.toLowerCase())) seoScore += 25;
    if (item.meta_description.length >= 100 && item.meta_description.length <= 160) seoScore += 25;
    if (item.possui_schema) seoScore += 20;
    if (item.links_internos.length >= 2) seoScore += 15;
    if (item.links_externos.length >= 1) seoScore += 15;

    // Quality
    let qualidade = 0;
    if (item.quantidade_palavras >= 1500) qualidade += 50;
    else if (item.quantidade_palavras >= 1000) qualidade += 40;
    else if (item.quantidade_palavras >= 600) qualidade += 25;
    else qualidade += 10;
    if (item.quantidade_imagens >= 2) qualidade += 30;
    else if (item.quantidade_imagens >= 1) qualidade += 15;
    if (item.possui_CTA) qualidade += 20;

    // Readability (Legibilidade)
    let legibilidade = 85; // baseline
    if (item.quantidade_palavras > 2000) legibilidade -= 10; // slightly harder to read if too long without layout checks
    if (item.quantidade_imagens === 0) legibilidade -= 15; // needs visual aids

    // Structure (Estrutura)
    let estrutura = 70;
    if (item.possui_FAQ) estrutura += 15;
    if (item.quantidade_palavras >= 1000) estrutura += 15; // expected headings

    // Links score
    let links = 0;
    if (item.links_internos.length > 0) links += 50;
    if (item.links_externos.length > 0) links += 50;

    // Imagens score
    const imagens = item.quantidade_imagens >= 2 ? 100 : item.quantidade_imagens === 1 ? 75 : 40;

    // Recency (Atualizacao)
    let recencyStatus: "Atualizado" | "Regular" | "Desatualizado" = "Desatualizado";
    const updateDate = new Date(item.ultima_atualizacao);
    const currentDate = new Date("2026-07-01"); // using container reference date
    const diffTime = Math.abs(currentDate.getTime() - updateDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays <= 45) {
      recencyStatus = "Atualizado";
    } else if (diffDays <= 120) {
      recencyStatus = "Regular";
    } else {
      recencyStatus = "Desatualizado";
    }

    // Average General Score
    const scoreGeral = Math.round((seoScore + qualidade + legibilidade + estrutura + links + imagens) / 6);

    let status: "Excelente" | "Bom" | "Precisa de Atenção" | "Crítico" = "Precisa de Atenção";
    if (scoreGeral >= 85) status = "Excelente";
    else if (scoreGeral >= 70) status = "Bom";
    else if (scoreGeral >= 50) status = "Precisa de Atenção";
    else status = "Crítico";

    return {
      id: item.id,
      titulo: item.titulo,
      url: item.url,
      scoreGeral,
      seoScore,
      qualidade,
      legibilidade,
      atualizacao: recencyStatus,
      estrutura,
      links,
      imagens,
      faq: item.possui_FAQ ? "Sim" : "Não",
      cta: item.possui_CTA ? "Sim" : "Não",
      status
    };
  });
  fs.writeFileSync(path.join(outputDir, "content-health.json"), JSON.stringify(healthList, null, 2), "utf-8");

  // 3. Duplicate detection
  const duplicates: DuplicateGroup[] = [];
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      const a = items[i];
      const b = items[j];

      if (a.slug === b.slug && a.slug !== "") {
        duplicates.push({
          id_A: a.id,
          id_B: b.id,
          titulo_A: a.titulo,
          titulo_B: b.titulo,
          conflito: "slug",
          valor_conflito: a.slug
        });
      } else if (
        a.palavra_chave_principal.toLowerCase().trim() === b.palavra_chave_principal.toLowerCase().trim() &&
        a.palavra_chave_principal !== ""
      ) {
        duplicates.push({
          id_A: a.id,
          id_B: b.id,
          titulo_A: a.titulo,
          titulo_B: b.titulo,
          conflito: "palavra_chave_principal",
          valor_conflito: a.palavra_chave_principal
        });
      } else if (a.titulo.toLowerCase().trim() === b.titulo.toLowerCase().trim() && a.titulo !== "") {
        duplicates.push({
          id_A: a.id,
          id_B: b.id,
          titulo_A: a.titulo,
          titulo_B: b.titulo,
          conflito: "titulo",
          valor_conflito: a.titulo
        });
      } else if (a.url === b.url && a.url !== "") {
        duplicates.push({
          id_A: a.id,
          id_B: b.id,
          titulo_A: a.titulo,
          titulo_B: b.titulo,
          conflito: "url",
          valor_conflito: a.url
        });
      }
    }
  }
  fs.writeFileSync(path.join(outputDir, "duplicate-content.json"), JSON.stringify(duplicates, null, 2), "utf-8");

  // 4. Orphan pages
  // Collect all outbound internal link URLs
  const allOutboundLinks = new Set<string>();
  items.forEach(item => {
    item.links_internos.forEach(link => {
      // Normalize links
      let cleanLink = link.trim().toLowerCase();
      // ensure we match regardless of trailing slash
      if (cleanLink.endsWith("/")) {
        cleanLink = cleanLink.slice(0, -1);
      }
      allOutboundLinks.add(cleanLink);
    });
  });

  const orphans: OrphanPage[] = [];
  items.forEach(item => {
    let cleanUrl = item.url.trim().toLowerCase();
    if (cleanUrl.endsWith("/")) {
      cleanUrl = cleanUrl.slice(0, -1);
    }
    
    // Check if any other page links to this page's URL
    if (!allOutboundLinks.has(cleanUrl)) {
      orphans.push({
        id: item.id,
        titulo: item.titulo,
        url: item.url,
        categoria: item.categoria
      });
    }
  });
  fs.writeFileSync(path.join(outputDir, "orphan-pages.json"), JSON.stringify(orphans, null, 2), "utf-8");

  // 5. Gaps - save empty array as requested
  if (!fs.existsSync(path.join(outputDir, "content-gaps.json"))) {
    fs.writeFileSync(path.join(outputDir, "content-gaps.json"), "[]", "utf-8");
  }

  // 6. Broken links - save empty array as requested
  if (!fs.existsSync(path.join(outputDir, "broken-links.json"))) {
    fs.writeFileSync(path.join(outputDir, "broken-links.json"), "[]", "utf-8");
  }

  return {
    itemsCount: items.length,
    healthCount: healthList.length,
    duplicatesCount: duplicates.length,
    orphansCount: orphans.length
  };
}
