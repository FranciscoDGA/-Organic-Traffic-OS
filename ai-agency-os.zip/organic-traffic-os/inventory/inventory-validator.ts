import fs from "fs";
import path from "path";

export interface InventoryValidationReport {
  isValid: boolean;
  errors: string[];
  checkedFiles: string[];
}

export function validateInventory(): InventoryValidationReport {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "content");
  const errors: string[] = [];
  const checkedFiles: string[] = [];

  const requiredFiles = [
    "content-index.json",
    "content-health.json",
    "content-gaps.json",
    "duplicate-content.json",
    "orphan-pages.json",
    "broken-links.json"
  ];

  requiredFiles.forEach(filename => {
    const filePath = path.join(baseDir, filename);
    checkedFiles.push(filename);

    if (!fs.existsSync(filePath)) {
      errors.push(`Missing inventory compiled report: ${filename}`);
      return;
    }

    try {
      const raw = fs.readFileSync(filePath, "utf-8");
      const parsed = JSON.parse(raw);

      if (!Array.isArray(parsed)) {
        errors.push(`File ${filename} must contain a JSON array, but found ${typeof parsed}`);
        return;
      }

      // Deeper field validation for content-index.json
      if (filename === "content-index.json") {
        parsed.forEach((item, idx) => {
          const missing: string[] = [];
          if (!item.id) missing.push("id");
          if (!item.tipo) missing.push("tipo");
          if (!item.titulo) missing.push("titulo");
          if (!item.slug) missing.push("slug");
          if (!item.url) missing.push("url");

          if (missing.length > 0) {
            errors.push(`content-index.json entry at index ${idx} is missing required field(s): ${missing.join(", ")}`);
          }
        });

        // Double check ids
        const ids = parsed.map((item: any) => item.id).filter(Boolean);
        const dupIds = ids.filter((id, i) => ids.indexOf(id) !== i);
        if (dupIds.length > 0) {
          errors.push(`Duplicate ID(s) detected in content-index.json: ${Array.from(new Set(dupIds)).join(", ")}`);
        }
      }

      // Deeper field validation for content-health.json
      if (filename === "content-health.json") {
        parsed.forEach((item, idx) => {
          if (item.scoreGeral === undefined || item.seoScore === undefined || !item.id || !item.status) {
            errors.push(`content-health.json entry at index ${idx} is missing required calculation fields.`);
          }
        });
      }

    } catch (e: any) {
      errors.push(`File ${filename} is corrupted or invalid JSON: ${e.message || e}`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    checkedFiles
  };
}
