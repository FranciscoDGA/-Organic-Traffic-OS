import { ContentPerformance } from "../types/performance-types";

export interface PerformanceValidationIssue {
  tipo: "critico" | "aviso" | "info";
  campo: string;
  mensagem: string;
}

export interface PerformanceValidationReport {
  valido: boolean;
  errosCriticos: number;
  avisos: number;
  problemas: PerformanceValidationIssue[];
}

export class PerformanceValidator {
  /**
   * Valida a integridade dos dados e métricas de performance de um conteúdo.
   */
  public static validate(perf: ContentPerformance): PerformanceValidationReport {
    const problemas: PerformanceValidationIssue[] = [];

    // 1. Validar Campos Obrigatórios do Identificador
    if (!perf.content_id || perf.content_id.trim() === "") {
      problemas.push({
        tipo: "critico",
        campo: "content_id",
        mensagem: "O campo 'content_id' é obrigatório e não pode estar vazio.",
      });
    }

    if (!perf.url || perf.url.trim() === "") {
      problemas.push({
        tipo: "critico",
        campo: "url",
        mensagem: "A URL de publicação vinculada é obrigatória.",
      });
    }

    // 2. Validar Estrutura de Datas
    const dateRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/; // ISO simplified check
    if (!perf.ultima_analise || !dateRegex.test(perf.ultima_analise)) {
      problemas.push({
        tipo: "critico",
        campo: "ultima_analise",
        mensagem: "A data de 'ultima_analise' deve estar em formato ISO string válido.",
      });
    }

    if (!perf.ultima_atualizacao || !dateRegex.test(perf.ultima_atualizacao)) {
      problemas.push({
        tipo: "aviso",
        campo: "ultima_atualizacao",
        mensagem: "A data de 'ultima_atualizacao' está ausente ou malformatada.",
      });
    }

    // 3. Validar Métricas Principais (Não negativas)
    const m = perf.metrics;
    if (!m) {
      problemas.push({
        tipo: "critico",
        campo: "metrics",
        mensagem: "O objeto de métricas atuais ('metrics') está ausente.",
      });
    } else {
      const metricFields: Array<{ name: keyof typeof m; label: string }> = [
        { name: "visualizacoes", label: "Visualizações" },
        { name: "cliques", label: "Cliques" },
        { name: "impressoes", label: "Impressões" },
        { name: "tempo_medio_segundos", label: "Tempo médio de permanência" },
        { name: "scroll_porcentagem", label: "Média de Scroll" },
        { name: "conversoes", label: "Conversões" },
        { name: "leads", label: "Leads" },
        { name: "downloads", label: "Downloads" },
        { name: "compartilhamentos", label: "Compartilhamentos" },
      ];

      metricFields.forEach((f) => {
        const val = m[f.name];
        if (typeof val !== "number" || isNaN(val)) {
          problemas.push({
            tipo: "critico",
            campo: `metrics.${f.name}`,
            mensagem: `A métrica '${f.label}' deve ser um número válido.`,
          });
        } else if (val < 0) {
          problemas.push({
            tipo: "critico",
            campo: `metrics.${f.name}`,
            mensagem: `A métrica '${f.label}' não pode ser um número negativo (${val}).`,
          });
        }
      });

      // Validação lógica de cliques em relação a impressões
      if (m.cliques > m.impressoes) {
        problemas.push({
          tipo: "critico",
          campo: "metrics.cliques",
          mensagem: `Incoerência estatística: Número de cliques (${m.cliques}) não pode superar o número de impressões (${m.impressoes}).`,
        });
      }

      // Validação lógica de conversão em relação a visualizações
      if (m.leads > m.visualizacoes) {
        problemas.push({
          tipo: "aviso",
          campo: "metrics.leads",
          mensagem: `Alerta estatístico: Mais leads gerados (${m.leads}) do que visualizações de página (${m.visualizacoes}).`,
        });
      }

      // Validação de CTR em relação aos cliques e impressões reais
      if (m.impressoes > 0) {
        const calculatedCtr = parseFloat(((m.cliques / m.impressoes) * 100).toFixed(2));
        if (Math.abs(m.ctr - calculatedCtr) > 0.1) {
          problemas.push({
            tipo: "aviso",
            campo: "metrics.ctr",
            mensagem: `O CTR fornecido (${m.ctr}%) diverge do CTR recalculado (${calculatedCtr}%). Ajuste sugerido.`,
          });
        }
      }

      // Validação de margens de scroll excessivas
      if (m.scroll_porcentagem > 100) {
        problemas.push({
          tipo: "critico",
          campo: "metrics.scroll_porcentagem",
          mensagem: `A porcentagem de scroll não pode ser superior a 100% (recebido: ${m.scroll_porcentagem}%).`,
        });
      }
    }

    // 4. Validar Histórico
    if (!perf.history || !Array.isArray(perf.history)) {
      problemas.push({
        tipo: "critico",
        campo: "history",
        mensagem: "O histórico de performance ('history') deve ser uma lista (array) de registros.",
      });
    } else {
      perf.history.forEach((h, idx) => {
        if (!h.data || !dateRegex.test(h.data)) {
          problemas.push({
            tipo: "critico",
            campo: `history[${idx}].data`,
            mensagem: `A data do histórico na posição ${idx} é inválida.`,
          });
        }
        if (!h.metrics || typeof h.metrics !== "object") {
          problemas.push({
            tipo: "critico",
            campo: `history[${idx}].metrics`,
            mensagem: `As métricas do histórico na posição ${idx} estão ausentes ou corrompidas.`,
          });
        }
      });
    }

    // 5. Validar Prioridades (ICE Score bounds)
    const p = perf.priority;
    if (p) {
      if (p.urgencia < 1 || p.urgencia > 10) {
        problemas.push({
          tipo: "aviso",
          campo: "priority.urgencia",
          mensagem: `Valor de urgência (${p.urgencia}) fora da escala normalizada de 1 a 10.`,
        });
      }
      if (p.impacto < 1 || p.impacto > 10) {
        problemas.push({
          tipo: "aviso",
          campo: "priority.impacto",
          mensagem: `Valor de impacto (${p.impacto}) fora da escala normalizada de 1 a 10.`,
        });
      }
      if (p.roi_esperado < 1 || p.roi_esperado > 10) {
        problemas.push({
          tipo: "aviso",
          campo: "priority.roi_esperado",
          mensagem: `Valor de ROI esperado (${p.roi_esperado}) fora da escala normalizada de 1 a 10.`,
        });
      }
      if (p.esforco < 1 || p.esforco > 10) {
        problemas.push({
          tipo: "aviso",
          campo: "priority.esforco",
          mensagem: `Valor de esforço de desenvolvimento (${p.esforco}) fora da escala de 1 a 10.`,
        });
      }
    }

    const errosCriticos = problemas.filter((prob) => prob.tipo === "critico").length;
    const avisos = problemas.filter((prob) => prob.tipo === "aviso").length;

    return {
      valido: errosCriticos === 0,
      errosCriticos,
      avisos,
      problemas,
    };
  }
}
