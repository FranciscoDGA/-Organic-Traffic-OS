export interface PerformanceMetrics {
  visualizacoes: number;
  cliques: number;
  ctr: number; // Porcentagem: (cliques / impressoes) * 100
  impressoes: number;
  tempo_medio_segundos: number;
  scroll_porcentagem: number;
  conversoes: number;
  downloads: number;
  leads: number;
  compartilhamentos: number;
}

export type TrendStatus = "alta" | "queda" | "estabilidade" | "mudanca_brusca";

export interface TrendAnalysis {
  status: TrendStatus;
  descricao: string;
  percentual_variacao_cliques: number;
  percentual_variacao_visualizacoes: number;
}

export type RecommendationType =
  | "atualizar_conteudo"
  | "criar_faq"
  | "criar_artigo_satelite"
  | "melhorar_cta"
  | "criar_landing"
  | "melhorar_links"
  | "adicionar_imagens"
  | "adicionar_video"
  | "criar_quiz"
  | "criar_simulado";

export interface PerformanceRecommendation {
  id: string;
  tipo: RecommendationType;
  titulo: string;
  descricao: string;
  urgencia: "critica" | "alta" | "media" | "baixa";
}

export interface RefreshPriority {
  urgencia: number; // 1 a 10
  impacto: number; // 1 a 10
  roi_esperado: number; // 1 a 10
  esforco: number; // 1 a 10
  score_final: number; // Fórmula sugerida: ((urgencia * 1.5) + (impacto * 1.2) + roi_esperado) / esforco
}

export interface PerformanceHistoryRecord {
  data: string; // ISO date
  metrics: PerformanceMetrics;
}

export interface ContentPerformance {
  content_id: string;
  titulo_conteudo: string; // Título descritivo do conteúdo para exibição no painel
  url: string;
  status: "ativo" | "revisar" | "em_revisao" | "atualizado";
  ultima_analise: string; // ISO date
  ultima_atualizacao: string; // ISO date
  metrics: PerformanceMetrics;
  history: PerformanceHistoryRecord[];
  trends: TrendAnalysis;
  recommendations: PerformanceRecommendation[];
  priority: RefreshPriority;
}
