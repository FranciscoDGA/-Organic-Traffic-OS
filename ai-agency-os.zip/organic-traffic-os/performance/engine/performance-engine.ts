import {
  ContentPerformance,
  PerformanceMetrics,
  PerformanceRecommendation,
  RefreshPriority,
  TrendAnalysis,
  TrendStatus,
  RecommendationType,
} from "../types/performance-types";

export class PerformanceEngine {
  /**
   * Executa a análise de performance de um conteúdo com base em suas métricas atuais e histórico.
   * Gera tendências, recomendações e prioridades de atualização automaticamente.
   */
  public static analyze(
    content_id: string,
    titulo_conteudo: string,
    url: string,
    status: ContentPerformance["status"],
    metrics: PerformanceMetrics,
    history: ContentPerformance["history"] = [],
    ultima_atualizacao: string = new Date().toISOString()
  ): ContentPerformance {
    // 1. Garantir que o CTR está correto
    const ctr = metrics.impressoes > 0 
      ? parseFloat(((metrics.cliques / metrics.impressoes) * 100).toFixed(2))
      : 0;
    metrics.ctr = ctr;

    // 2. Analisar Tendências comparando com o histórico anterior se existir
    const trends = this.calculateTrends(metrics, history);

    // 3. Gerar Recomendações de Otimização baseadas em Heurísticas de Tráfego Orgânico
    const recommendations = this.generateRecommendations(content_id, metrics, trends);

    // 4. Calcular Prioridade de Atualização (Refresh Priority)
    const priority = this.calculateRefreshPriority(metrics, trends, recommendations);

    return {
      content_id,
      titulo_conteudo,
      url,
      status,
      ultima_analise: new Date().toISOString(),
      ultima_atualizacao,
      metrics,
      history,
      trends,
      recommendations,
      priority,
    };
  }

  /**
   * Calcula as tendências comparando as métricas atuais com o registro histórico mais recente.
   */
  private static calculateTrends(
    current: PerformanceMetrics,
    history: ContentPerformance["history"]
  ): TrendAnalysis {
    if (!history || history.length === 0) {
      return {
        status: "estabilidade",
        descricao: "Sem histórico suficiente para traçar tendências de tráfego.",
        percentual_variacao_cliques: 0,
        percentual_variacao_visualizacoes: 0,
      };
    }

    // Obter o registro mais recente do histórico
    const pastRecord = history[history.length - 1];
    const past = pastRecord.metrics;

    const diffCliques = current.cliques - past.cliques;
    const pctCliques = past.cliques > 0 
      ? parseFloat(((diffCliques / past.cliques) * 100).toFixed(1))
      : 0;

    const diffViews = current.visualizacoes - past.visualizacoes;
    const pctViews = past.visualizacoes > 0
      ? parseFloat(((diffViews / past.visualizacoes) * 100).toFixed(1))
      : 0;

    let status: TrendStatus = "estabilidade";
    let descricao = "Desempenho estável em comparação ao período anterior.";

    if (Math.abs(pctCliques) >= 50 || Math.abs(pctViews) >= 50) {
      status = "mudanca_brusca";
      descricao = pctCliques < 0 
        ? `Alerta de queda drástica! Cliques caíram ${Math.abs(pctCliques)}% repentinamente.`
        : `Excelente! Crescimento exponencial de ${pctCliques}% nos cliques detectado.`;
    } else if (pctCliques <= -15) {
      status = "queda";
      descricao = `Queda contínua de ${Math.abs(pctCliques)}% nos cliques. Necessita intervenção de otimização.`;
    } else if (pctCliques >= 15) {
      status = "alta";
      descricao = `Tendência de alta de ${pctCliques}% nos cliques e ${pctViews}% nas visualizações.`;
    }

    return {
      status,
      descricao,
      percentual_variacao_cliques: pctCliques,
      percentual_variacao_visualizacoes: pctViews,
    };
  }

  /**
   * Heurística para gerar Recomendações de Ação com base nas métricas de engajamento e conversão.
   */
  private static generateRecommendations(
    content_id: string,
    metrics: PerformanceMetrics,
    trends: TrendAnalysis
  ): PerformanceRecommendation[] {
    const recs: PerformanceRecommendation[] = [];
    let recIdCounter = 1;

    const addRec = (tipo: RecommendationType, titulo: string, descricao: string, urgencia: PerformanceRecommendation["urgencia"]) => {
      recs.push({
        id: `rec_${content_id}_${recIdCounter++}`,
        tipo,
        titulo,
        descricao,
        urgencia,
      });
    };

    // Regra 1: CTR Baixo (Insinua que o título, meta-descrição ou o CTA principal da SERP precisam ser melhorados)
    if (metrics.ctr < 1.5 && metrics.impressoes > 200) {
      addRec(
        "atualizar_conteudo",
        "Otimizar Title Tag & Meta Description",
        `O CTR está em ${metrics.ctr}%, abaixo do ideal de 2.0%. Reescreva o título de busca e meta descrição para torná-los mais magnéticos e atraentes na SERP.`,
        "alta"
      );
    }

    // Regra 2: Queda acentuada de cliques e visualizações
    if (trends.status === "queda" || (trends.status === "mudanca_brusca" && trends.percentual_variacao_cliques < 0)) {
      addRec(
        "atualizar_conteudo",
        "Atualização Geral e Enriquecimento Editorial",
        "Este conteúdo está sofrendo de depreciação orgânica histórica (decay). Atualize as informações pedagógicas, revise o edital e expanda os parágrafos principais.",
        "critica"
      );
    }

    // Regra 3: Tempo de permanência baixo (< 90 segundos) ou Scroll insatisfatório (< 45%)
    if (metrics.tempo_medio_segundos < 90 && metrics.visualizacoes > 50) {
      addRec(
        "criar_faq",
        "Adicionar Bloco de FAQ Estruturado",
        `O tempo de leitura médio é de apenas ${metrics.tempo_medio_segundos}s. FAQs no final de artigos aumentam a retenção, engajamento e qualificam para Rich Snippets no Google.`,
        "media"
      );

      addRec(
        "adicionar_imagens",
        "Enriquecer com Recursos Visuais (Infográficos/Imagens)",
        "Melhore o escaneamento do artigo inserindo infográficos explicativos para quebrar blocos longos de texto e reduzir a taxa de rejeição.",
        "media"
      );
    }

    // Regra 4: Conversão de Leads Baixa (< 1.5%) em relação às visualizações
    const conversionRate = metrics.visualizacoes > 0 
      ? (metrics.leads / metrics.visualizacoes) * 100 
      : 0;
    
    if (conversionRate < 1.5 && metrics.visualizacoes > 100) {
      addRec(
        "melhorar_cta",
        "Refatorar Botão e Texto de CTA",
        `Sua taxa de conversão de leads está em ${conversionRate.toFixed(2)}%. Torne a chamada para ação mais focada, use contrastes fortes e ofereça um material de apoio mais valioso.`,
        "alta"
      );
    }

    // Regra 5: Alto tráfego, boa permanência mas pouca interatividade profunda
    if (metrics.visualizacoes > 300 && metrics.tempo_medio_segundos > 120) {
      addRec(
        "criar_quiz",
        "Implementar Quiz Interativo de Memorização",
        "Excelente engajamento detectado! Aproveite para inserir um quiz interativo rápido sobre o tema para prender ainda mais o concurseiro e capturar leads extras.",
        "media"
      );

      addRec(
        "criar_simulado",
        "Acoplar Simulado de Questões Reais",
        "O tema possui forte apelo. Crie um minisimulado com cronômetro para elevar o artigo de 'leitura' para 'plataforma de exercícios ativos'.",
        "media"
      );
    }

    // Regra 6: Baixo compartilhamento geral
    if (metrics.compartilhamentos < 5 && metrics.visualizacoes > 200) {
      addRec(
        "melhorar_links",
        "Aprimorar Linkagem Interna e Silos",
        "Adicione links de ancoragem recíproca direcionando para artigos-satélites do mesmo silo para incentivar a circulação de tráfego do usuário.",
        "baixa"
      );
    }

    // Garantir pelo menos uma recomendação padrão se nenhuma regra disparar
    if (recs.length === 0) {
      addRec(
        "atualizar_conteudo",
        "Manter Conteúdo Higienizado",
        "As métricas estão excelentes e estáveis. Continue monitorando e revise pontualmente a cada 90 dias para garantir o frescor (Freshness) perante o Google.",
        "baixa"
      );
    }

    return recs;
  }

  /**
   * Calcula a prioridade e ROI de atualização baseado nas métricas e perdas históricas.
   */
  private static calculateRefreshPriority(
    metrics: PerformanceMetrics,
    trends: TrendAnalysis,
    recommendations: PerformanceRecommendation[]
  ): RefreshPriority {
    // 1. Calcular Urgência (1 a 10)
    // Se há recomendação crítica, urgência é muito alta. Se há quedas de cliques, urgência sobe.
    let urgencia = 3;
    if (trends.status === "queda") urgencia += 4;
    if (trends.status === "mudanca_brusca" && trends.percentual_variacao_cliques < 0) urgencia += 5;
    
    const hasCritico = recommendations.some(r => r.urgencia === "critica");
    const hasAlta = recommendations.some(r => r.urgencia === "alta");
    if (hasCritico) urgencia += 3;
    else if (hasAlta) urgencia += 1.5;

    urgencia = Math.min(10, Math.max(1, Math.round(urgencia)));

    // 2. Calcular Impacto Estimado de Otimização (1 a 10)
    // Se tem muitas impressões acumuladas mas poucos cliques (CTR baixo), o impacto de consertar o CTR é gigantesco.
    let impacto = 4;
    if (metrics.impressoes > 1000 && metrics.ctr < 1.2) impacto += 4;
    if (metrics.visualizacoes > 500 && metrics.leads < 5) impacto += 3;
    impacto = Math.min(10, Math.max(1, Math.round(impacto)));

    // 3. ROI Esperado (1 a 10)
    // Formula de ROI baseada no volume potencial: se temos muitas impressões e tráfego pré-existente, o retorno é quase imediato.
    let roi_esperado = 3;
    if (metrics.impressoes > 800) roi_esperado += 3;
    if (trends.status === "queda") roi_esperado += 2; // Recuperar tráfego perdido tem ROI alto e rápido
    roi_esperado = Math.min(10, Math.max(1, Math.round(roi_esperado)));

    // 4. Calcular Esforço Estimado (1 a 10)
    // Esforço depende das recomendações associadas. Criar simulados/quizzes ou reescrever artigos inteiros exige mais esforço.
    let esforco = 3; // base esforço baixo
    const types = recommendations.map(r => r.tipo);
    if (types.includes("criar_simulado")) esforco += 3;
    if (types.includes("criar_quiz")) esforco += 2;
    if (types.includes("atualizar_conteudo")) esforco += 1.5;
    if (types.includes("criar_landing")) esforco += 2.5;
    esforco = Math.min(10, Math.max(1, Math.round(esforco)));

    // 5. Calcular Score Final de Prioridade (ICE-like Score)
    // Score = ((Urgência * 1.5) + (Impacto * 1.2) + ROI) / Esforço
    const rawScore = ((urgencia * 1.5) + (impacto * 1.2) + roi_esperado) / esforco;
    const score_final = parseFloat(rawScore.toFixed(2));

    return {
      urgencia,
      impacto,
      roi_esperado,
      esforco,
      score_final,
    };
  }
}
