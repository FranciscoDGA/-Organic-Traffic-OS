import * as fs from "fs";
import * as path from "path";
import { ContentPerformance, PerformanceMetrics } from "../types/performance-types";
import { PerformanceEngine } from "./performance-engine";
import { PerformanceValidator } from "../validators/performance-validator";

export class PerformanceService {
  private static baseDir = path.join(process.cwd(), "organic-traffic-os/performance");
  private static historyDir = path.join(PerformanceService.baseDir, "history");
  private static metricsDir = path.join(PerformanceService.baseDir, "metrics");
  private static recommendationsDir = path.join(PerformanceService.baseDir, "recommendations");
  
  private static contentPerformancePath = path.join(PerformanceService.historyDir, "content-performance.json");

  private static ensureDirectoriesExist() {
    const dirs = [
      PerformanceService.baseDir,
      PerformanceService.historyDir,
      PerformanceService.metricsDir,
      PerformanceService.recommendationsDir,
      path.join(PerformanceService.baseDir, "reports"),
      path.join(PerformanceService.baseDir, "validators"),
    ];

    dirs.forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
  }

  /**
   * Inicializa e semeia dados padrão de performance se o arquivo persistido não existir.
   */
  public static seedInitialData() {
    this.ensureDirectoriesExist();

    if (!fs.existsSync(this.contentPerformancePath)) {
      const initialData: ContentPerformance[] = [
        {
          content_id: "pub_direito_admin_101",
          titulo_conteudo: "Guia Completo de Agentes Públicos e Improbidade",
          url: "https://passacumaru.com.br/blog/direito-administrativo-agentes",
          status: "revisar",
          ultima_analise: "2026-06-30T10:00:00.000Z",
          ultima_atualizacao: "2026-05-10T14:30:00.000Z",
          metrics: {
            visualizacoes: 450,
            cliques: 8,
            ctr: 0.67,
            impressoes: 1200,
            tempo_medio_segundos: 45,
            scroll_porcentagem: 20,
            conversoes: 1,
            downloads: 0,
            leads: 1,
            compartilhamentos: 2
          },
          history: [
            {
              data: "2026-06-01T09:00:00.000Z",
              metrics: {
                visualizacoes: 850,
                cliques: 45,
                ctr: 2.5,
                impressoes: 1800,
                tempo_medio_segundos: 140,
                scroll_porcentagem: 65,
                conversoes: 12,
                downloads: 4,
                leads: 10,
                compartilhamentos: 9
              }
            },
            {
              data: "2026-06-15T09:00:00.000Z",
              metrics: {
                visualizacoes: 600,
                cliques: 22,
                ctr: 1.47,
                impressoes: 1500,
                tempo_medio_segundos: 95,
                scroll_porcentagem: 45,
                conversoes: 5,
                downloads: 1,
                leads: 4,
                compartilhamentos: 5
              }
            }
          ],
          trends: {
            status: "queda",
            descricao: "Queda contínua de -63.6% nos cliques em relação à última medição. Conteúdo obsoleto ou defasado.",
            percentual_variacao_cliques: -63.6,
            percentual_variacao_visualizacoes: -25.0
          },
          recommendations: [], // calculadas dinamicamente na leitura ou carregamento
          priority: {
            urgencia: 9,
            impacto: 8,
            roi_esperado: 9,
            esforco: 4,
            score_final: 7.2
          }
        },
        {
          content_id: "pub_faq_edital_202",
          titulo_conteudo: "FAQ Estruturado — Edital Unificado CNU 2026",
          url: "https://passacumaru.com.br/blog/faq-edital-cnu",
          status: "ativo",
          ultima_analise: "2026-06-30T10:00:00.000Z",
          ultima_atualizacao: "2026-06-02T11:00:00.000Z",
          metrics: {
            visualizacoes: 1450,
            cliques: 112,
            ctr: 4.48,
            impressoes: 2500,
            tempo_medio_segundos: 185,
            scroll_porcentagem: 78,
            conversoes: 48,
            downloads: 18,
            leads: 42,
            compartilhamentos: 28
          },
          history: [
            {
              data: "2026-06-15T09:00:00.000Z",
              metrics: {
                visualizacoes: 950,
                cliques: 60,
                ctr: 3.0,
                impressoes: 2000,
                tempo_medio_segundos: 160,
                scroll_porcentagem: 72,
                conversoes: 28,
                downloads: 10,
                leads: 25,
                compartilhamentos: 15
              }
            }
          ],
          trends: {
            status: "alta",
            descricao: "Tendência de forte alta de +86.7% nos cliques impulsionada pela proximidade da prova.",
            percentual_variacao_cliques: 86.7,
            percentual_variacao_visualizacoes: 52.6
          },
          recommendations: [],
          priority: {
            urgencia: 3,
            impacto: 5,
            roi_esperado: 4,
            esforco: 3,
            score_final: 4.5
          }
        },
        {
          content_id: "pub_simulado_artigo5_303",
          titulo_conteudo: "Simulado Constitucional: Questões Comentadas do Artigo 5º",
          url: "https://passacumaru.com.br/blog/simulado-constitucional-artigo-5",
          status: "ativo",
          ultima_analise: "2026-06-30T10:00:00.000Z",
          ultima_atualizacao: "2026-06-20T16:00:00.000Z",
          metrics: {
            visualizacoes: 820,
            cliques: 38,
            ctr: 1.9,
            impressoes: 2000,
            tempo_medio_segundos: 210,
            scroll_porcentagem: 82,
            conversoes: 32,
            downloads: 15,
            leads: 29,
            compartilhamentos: 19
          },
          history: [
            {
              data: "2026-06-15T09:00:00.000Z",
              metrics: {
                visualizacoes: 800,
                cliques: 37,
                ctr: 1.85,
                impressoes: 2000,
                tempo_medio_segundos: 205,
                scroll_porcentagem: 80,
                conversoes: 30,
                downloads: 14,
                leads: 28,
                compartilhamentos: 18
              }
            }
          ],
          trends: {
            status: "estabilidade",
            descricao: "Desempenho altamente consolidado e estável na SERP.",
            percentual_variacao_cliques: 2.7,
            percentual_variacao_visualizacoes: 2.5
          },
          recommendations: [],
          priority: {
            urgencia: 2,
            impacto: 4,
            roi_esperado: 3,
            esforco: 2,
            score_final: 3.2
          }
        }
      ];

      // Computar as recomendações e prioridades dinâmicas do motor para que fiquem bem refinadas de saída
      const seededAnalyzed = initialData.map(item => 
        PerformanceEngine.analyze(
          item.content_id,
          item.titulo_conteudo,
          item.url,
          item.status,
          item.metrics,
          item.history,
          item.ultima_atualizacao
        )
      );

      fs.writeFileSync(this.contentPerformancePath, JSON.stringify(seededAnalyzed, null, 2), "utf-8");
      
      // Salvar cópias isoladas para rastreabilidade de arquivos requeridos de forma estática
      fs.writeFileSync(path.join(this.metricsDir, "metrics.json"), JSON.stringify(seededAnalyzed.map(a => ({ content_id: a.content_id, metrics: a.metrics })), null, 2), "utf-8");
      fs.writeFileSync(path.join(this.recommendationsDir, "recommendations.json"), JSON.stringify(seededAnalyzed.map(a => ({ content_id: a.content_id, recommendations: a.recommendations })), null, 2), "utf-8");
    }
  }

  /**
   * Obtém a lista completa de conteúdos monitorados.
   */
  public static getPerformanceList(): ContentPerformance[] {
    this.seedInitialData();
    try {
      if (fs.existsSync(this.contentPerformancePath)) {
        const raw = fs.readFileSync(this.contentPerformancePath, "utf-8");
        return JSON.parse(raw || "[]");
      }
    } catch (e) {
      console.error("Erro ao ler índice de performance:", e);
    }
    return [];
  }

  /**
   * Busca a análise de performance de um conteúdo específico.
   */
  public static getPerformanceById(contentId: string): ContentPerformance | null {
    const list = this.getPerformanceList();
    return list.find(p => p.content_id === contentId) || null;
  }

  /**
   * Registra uma nova rodada de métricas manuais para um conteúdo.
   * Cria o registro se ele não existir, ou atualiza o atual empurrando o anterior para o histórico de auditoria.
   */
  public static registerMetrics(
    contentId: string,
    tituloConteudo: string,
    url: string,
    status: ContentPerformance["status"],
    newMetrics: PerformanceMetrics
  ): ContentPerformance {
    this.seedInitialData();
    const list = this.getPerformanceList();
    const existingIndex = list.findIndex(p => p.content_id === contentId);

    let history: ContentPerformance["history"] = [];
    let ultimaAtualizacao = new Date().toISOString();

    if (existingIndex !== -1) {
      const existing = list[existingIndex];
      history = existing.history || [];
      ultimaAtualizacao = existing.ultima_atualizacao;

      // Salvar a medição anterior no histórico para fins de cálculo de tendências futuras
      const alreadyInHistory = history.some(h => h.data.split('T')[0] === existing.ultima_analise.split('T')[0]);
      if (!alreadyInHistory) {
        history.push({
          data: existing.ultima_analise,
          metrics: { ...existing.metrics }
        });
      }
      
      // Limitar histórico aos últimos 10 registros para otimização de token/espaço
      if (history.length > 10) {
        history.shift();
      }
    }

    // Executar a análise de performance pelo motor matemático
    const analyzed = PerformanceEngine.analyze(
      contentId,
      tituloConteudo,
      url,
      status,
      newMetrics,
      history,
      ultimaAtualizacao
    );

    // Validar os dados gerados
    const validation = PerformanceValidator.validate(analyzed);
    if (!validation.valido) {
      console.warn(`Aviso de validação no registro de performance '${contentId}':`, validation.problemas);
    }

    if (existingIndex !== -1) {
      list[existingIndex] = analyzed;
    } else {
      list.unshift(analyzed);
    }

    fs.writeFileSync(this.contentPerformancePath, JSON.stringify(list, null, 2), "utf-8");

    // Sincronizar sub-arquivos exigidos pela estrutura do OS
    fs.writeFileSync(path.join(this.metricsDir, "metrics.json"), JSON.stringify(list.map(a => ({ content_id: a.content_id, metrics: a.metrics })), null, 2), "utf-8");
    fs.writeFileSync(path.join(this.recommendationsDir, "recommendations.json"), JSON.stringify(list.map(a => ({ content_id: a.content_id, recommendations: a.recommendations })), null, 2), "utf-8");

    return analyzed;
  }

  /**
   * Remove o monitoramento de performance de um conteúdo.
   */
  public static deletePerformance(contentId: string): boolean {
    const list = this.getPerformanceList();
    const filtered = list.filter(p => p.content_id !== contentId);
    if (list.length === filtered.length) return false;

    fs.writeFileSync(this.contentPerformancePath, JSON.stringify(filtered, null, 2), "utf-8");
    return true;
  }

  /**
   * Compara as métricas de dois períodos de forma quantitativa.
   */
  public static comparePeriods(contentId: string): {
    current: PerformanceMetrics;
    past: PerformanceMetrics | null;
    diffPercent: Record<string, number>;
  } {
    const perf = this.getPerformanceById(contentId);
    if (!perf) {
      throw new Error(`Registro de performance '${contentId}' não encontrado.`);
    }

    const current = perf.metrics;
    const past = perf.history && perf.history.length > 0
      ? perf.history[perf.history.length - 1].metrics
      : null;

    const diffPercent: Record<string, number> = {};

    if (past) {
      const keys: Array<keyof PerformanceMetrics> = [
        "visualizacoes",
        "cliques",
        "ctr",
        "impressoes",
        "tempo_medio_segundos",
        "scroll_porcentagem",
        "conversoes",
        "leads",
        "compartilhamentos"
      ];

      keys.forEach(k => {
        const currentVal = current[k];
        const pastVal = past[k];
        if (pastVal > 0) {
          diffPercent[k] = parseFloat((((currentVal - pastVal) / pastVal) * 100).toFixed(1));
        } else {
          diffPercent[k] = currentVal > 0 ? 100 : 0;
        }
      });
    }

    return {
      current,
      past,
      diffPercent
    };
  }
}
