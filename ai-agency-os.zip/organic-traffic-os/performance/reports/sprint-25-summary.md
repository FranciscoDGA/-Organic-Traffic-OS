# Sprint 25 — Content Performance Engine V1

## Objetivo Geral
Implementação do primeiro motor inteligente responsável por monitorar, avaliar e recomendar refinamentos contínuos para todos os conteúdos publicados na plataforma **PassaCumaru**. O foco estratégico deste módulo é garantir que **nenhum conteúdo seja tratado como concluído**, alimentando dinamicamente o loop contínuo de evolução de tráfego orgânico (SEO e Conversão de Leads).

---

## Estrutura de Diretórios Criada
```
organic-traffic-os/performance/
├── engine/
│   ├── performance-engine.ts
│   └── performance-service.ts
├── history/
│   └── content-performance.json (Seed de Histórico de Auditoria)
├── metrics/
│   └── metrics.json
├── recommendations/
│   └── recommendations.json
├── reports/
│   └── sprint-25-summary.md (Esta documentação)
├── types/
│   └── performance-types.ts
└── validators/
    └── performance-validator.ts
```

---

## Componentes Técnicos Desenvolvidos

### 1. Performance Engine (`performance-engine.ts`)
Motor matemático e heurístico de processamento. Ele analisa as métricas inseridas manualmente e:
- **Calcula CTRs**: Garante exatidão estatística `(cliques / impressões) * 100`.
- **Analisa Tendências**: Compara os dados correntes contra o histórico anterior de medições de auditoria, classificando o status em `alta`, `queda`, `estabilidade` ou `mudança_brusca`.
- **Gera Recomendações de Refino**: Regras inteligentes identificam problemas de CTR baixo, tempos de leitura insatisfatórios (baixo Dwell Time), retenção defasada (Scroll de página ruim), ou baixa conversão de Leads, gerando planos táticos automatizados (ex: "Otimizar Title Tag & Meta Description", "Criar Bloco FAQ", "Acoplar Simulado").
- **Prioriza Atualizações (ICE Score)**: Aplica uma adaptação do framework ICE prioritário para sugerir a ordem ideal de esforço do redator:
  $$\text{Score Final} = \frac{(\text{Urgência} \times 1.5) + (\text{Impacto} \times 1.2) + \text{ROI esperado}}{\text{Esforço}}$$

### 2. Performance Service (`performance-service.ts`)
Camada responsável por gerenciar a leitura, persistência e auditoria de histórico.
- **Auto-seeding**: Fornece dados iniciais realistas de simulação no primeiro carregamento de forma a ilustrar perfeitamente conteúdos em status de alta, queda contínua, e estabilidade orgânica.
- **Sincronização**: Salva as modificações no arquivo mestre `/organic-traffic-os/performance/history/content-performance.json` e propaga os dados para arquivos específicos como `metrics.json` e `recommendations.json`.

### 3. Performance Validator (`performance-validator.ts`)
Módulo rígido de integridade de dados que realiza a validação de contratos:
- Validação de tipos obrigatórios de dados e URLs de destino.
- Validação matemática de métricas negativas ou incoerentes (ex: cliques superando impressões, scroll depth > 100%).
- Validação estrutural de datas em formato de string ISO.

### 4. API Endpoints (`server.ts`)
Criada e exposta uma interface REST de integração com os seguintes endpoints:
- `GET /api/organic-os/performance` — Retorna o array completo de conteúdos sob monitoramento.
- `GET /api/organic-os/performance/:content_id` — Busca o histórico e relatório individualizado de uma URL.
- `POST /api/organic-os/performance/analyze` — Executa a análise de performance em tempo real ao registrar novas métricas.
- `DELETE /api/organic-os/performance/:content_id` — Remove o monitoramento de uma página.

### 5. Painel de Controle (`OrganicPerformance.tsx`)
Interface visual de alta fidelidade que provê:
- **Bento Stats Grid**: Exibição instantânea de conteúdos monitorados, tendências de alta, queda e o ativo de melhor tráfego orgânico.
- **Overview Interativo**: Tabela completa listando URLs, cliques, CTRs, status atuais, e score dinâmico com barras de progresso coloridas.
- **Separador de Tendências**: Agrupamento visual focado de itens em desgaste orgânico (Decay) versus itens impulsionados.
- **Fila de Recomendações Detalhadas**: Visualização e resolução de tarefas geradas pelo algoritmo (ex: Otimizar Title Tag, Criar FAQs).
- **Formulário de Entrada de Métricas**: Formulário interativo para entrada de métricas reais sem requerer integrações complexas de GSC/GA4 de início.

---

## Garantias de Teste e Compilação
- O projeto compila com sucesso (`npm run build`).
- Linter executado com sucesso e zero erros pendentes de tipagem (`tsc --noEmit`).
