# EPIC 02 — SEARCH INTELLIGENCE ENGINE V1
## Relatório de Conclusão de Sprint 26

Este documento detalha o design arquitetural, a implementação técnica e o fluxo de operação do novo motor de inteligência de buscas (**Search Intelligence Engine**), introduzido na Sprint 26 como parte do **EPIC 02**.

---

## 1. Visão Geral da Arquitetura

O **Search Intelligence Engine** representa uma mudança de paradigma no *Organic Traffic OS*. Anteriormente, a plataforma confiava estritamente em análises on-page estáticas e sitemaps internos. Agora, ela aprende de forma adaptativa e contínua com o comportamento do tráfego real.

Para isso, estabeleceu-se uma **arquitetura baseada em Connectors**, desacoplando totalmente as APIs e fontes externas da lógica de processamento interno da Engine.

```
[Fontes Externas] ---> [Connectors] ---> [Connector Manager] ---> [Search Intelligence Engine] ---> [JSON Cache Files]
 (GSC, Trends, Bing)      (Contratos)       (Status & Falhas)          (Regras de Oportunidade)          (Sincronização)
```

### 1.1 Contrato Único (`Connector`)
Todos os conectores implementam estritamente a interface comum `Connector`, garantindo a integridade dos tipos e modularidade.

Campos obrigatórios:
- `id` (Identificador único)
- `nome` (Nome de exibição do conector)
- `versao` (Semantic versioning)
- `status` (`ativo` | `inativo` | `falha`)
- `autenticar()` (Verificação de chaves e handshake)
- `validar()` (Sanidade das conexões)
- `sincronizar()` (Retorno de consultas, métricas e históricos normalizados)
- `normalizar()` (Conversão dos dados brutos específicos do provedor para os tipos unificados da plataforma)

---

## 2. Connectors Implementados

Nesta Sprint 26, cinco conectores principais foram introduzidos:

1. **Manual Connector (Totalmente Funcional):** Permite a inserção direta de dados pelo usuário através de formulário interativo no painel de controle. Extremamente útil para simulação imediata de conversão de leads e teste de novas palavras-chave sem necessidade de credenciais de produção.
2. **Mock Connector (Totalmente Funcional):** Provê sementes de dados simulados simulando canais em Cumaru do Norte. Possibilita testes automatizados consistentes e amostragem imediata de todas as regras de oportunidade.
3. **Google Search Console Connector (Estrutura Pronta):** Template estrutural preparado para integração real utilizando a biblioteca oficial `googleapis`. Utiliza variáveis de ambiente (`GOOGLE_SEARCH_CONSOLE_CLIENT_EMAIL` e `GOOGLE_SEARCH_CONSOLE_PRIVATE_KEY`) de forma segura.
4. **Google Trends Connector (Estrutura Pronta):** Configuração pronta para monitoramento de tendências emergentes por meio do `GOOGLE_TRENDS_API_KEY`.
5. **Bing Webmaster Connector (Estrutura Pronta):** Suporte inicial para monitoramento de busca orgânica no ecossistema Microsoft com autenticação robusta baseada em `BING_WEBMASTER_API_KEY`.

*Nenhuma chave ou credencial secreta é embutida no código. Todas as verificações de autenticação são lidas a partir de variáveis de ambiente (`process.env`).*

---

## 3. Algoritmo de Otimização e Detecção de Oportunidades

O motor processa os dados mesclados e unificados por meio de regras de inteligência pré-estabelecidas para extrair caminhos de melhoria de tráfego de alto impacto:

*   **Alta impressão + baixo CTR:** Detecta palavras-chave com mais de 4.000 impressões mas CTR menor que 3%. *Ação recomendada:* Otimização on-page rigorosa do Title de SEO e Meta Description.
*   **Alta posição + baixa conversão:** Detecta páginas no Top 3 (posição <= 3.0) com mais de 100 cliques mas conversão de leads menor que 1.5%. *Ação recomendada:* Ajuste fino de CTAs, captures de email e formulários de conversão interna.
*   **Queda de impressões:** Monitora decaimento de visibilidade com base em variações de posição negativas superiores a -2.0 posições. *Ação recomendada:* Atualização semântica do post, adição de seções FAQ e revisão de dados temporais desatualizados.
*   **Consultas emergentes:** Identifica tendências rápidas de crescimento (+3.0 posições) para termos promissores. *Ação recomendada:* Fortalecimento de links internos e link juice de artigos de alta autoridade.
*   **Conteúdos promissores:** Identifica conteúdos na transição de página (posições entre 4.0 e 10.0) com alto volume de impressões (> 1.500). *Ação recomendada:* Otimização de tempo de permanência do usuário e otimização técnica fina para alavancar ao Top 3.

---

## 4. Estrutura de Armazenamento e Cache Local

Para evitar chamadas repetitivas de rede e estresse de cota das APIs, toda a consolidação é persistida em arquivos de cache estruturados localizados sob `/organic-traffic-os/connectors/cache/`:

- `search-query.json`: Registro unificado de consultas catalogadas por página.
- `search-metrics.json`: Registro de impressões, cliques, CTR, posições e taxa de conversão.
- `search-history.json`: Histórico diário acumulado para plotagem de evolução temporal.
- `search-opportunities.json`: Oportunidades catalogadas geradas em lote pelo motor adaptativo.

A validação de integridade, sanitização de strings, padronização de campos decimais e remoção de duplicidades ocorre automaticamente na camada `SearchValidator` antes de qualquer persistência.

---

## 5. Endpoints da API Criados

Toda a interação do painel de controle e agentes ocorre de forma assíncrona e segura por meio dos endpoints mapeados na porta `3000`:

*   `GET /api/organic-os/search` — Retorna todas as métricas consolidadas, consultas e status de conectores.
*   `POST /api/organic-os/search/sync` — Sincroniza todos os conectores ativos em lote, funde os dados, gera oportunidades e grava os caches atualizados.
*   `GET /api/organic-os/search/opportunities` — Lista as oportunidades inteligentes de tráfego calculadas.
*   `POST /api/organic-os/search/manual` — Envia entradas manuais enviadas pelo usuário, integrando-as de imediato ao motor adaptativo.
*   `POST /api/organic-os/search/toggle-connector` — Ativa ou desativa um conector específico do gerenciador de forma dinâmica no runtime.

---

## 6. Checklist de Validação Final

- [x] Contrato da interface de Conectores criado.
- [x] Mock Connector operacional com sementes realistas.
- [x] Manual Connector totalmente integrado à interface.
- [x] Três templates estruturais de conectores de produção prontos (GSC, Trends, Bing).
- [x] Cache em formato JSON estruturado e persistente operando de forma otimizada.
- [x] Validador de dados contra duplicidades e anomalias numéricas.
- [x] Motor adaptativo gerando oportunidades robustas com base nas 5 regras descritas.
- [x] Endpoints Express totalmente integrados ao servidor central da plataforma.
- [x] Painel de controle rico em Tailwind CSS integrado à barra de navegação principal.
