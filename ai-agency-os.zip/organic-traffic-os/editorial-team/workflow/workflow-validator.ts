export interface WorkflowStep {
  pos: number;
  id: string;
  nome: string;
  tipo: "Technical Engine" | "Editorial Agent";
  agente_id?: string;
  descricao: string;
  saida: string;
}

export interface AgentContract {
  inputs: string[];
  outputs: string[];
  dependencies: string[];
  possible_errors: string[];
  expected_time_seconds: number;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  executionPlan: string[];
}

export class EditorialWorkflowValidator {
  /**
   * Valida a integridade lógica, ordenação e contratos de entrada/saída do fluxo editorial.
   */
  static validate(
    steps: WorkflowStep[],
    contracts: Record<string, AgentContract>
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    const executionPlan: string[] = [];

    // 1. Validar ordenação sequencial estrita (posições 1 a N)
    const sortedSteps = [...steps].sort((a, b) => a.pos - b.pos);
    
    for (let i = 0; i < sortedSteps.length; i++) {
      if (sortedSteps[i].pos !== i + 1) {
        errors.push(`A sequência de posições do fluxo está desalinhada. Esperado posição ${i + 1} mas obteve-se ${sortedSteps[i].pos} na etapa '${sortedSteps[i].nome}'.`);
      }
      executionPlan.push(`${sortedSteps[i].pos}. ${sortedSteps[i].nome} (${sortedSteps[i].tipo})`);
    }

    // 2. Acumulador de outputs gerados pelas etapas técnicas e agentes
    const availableOutputs = new Set<string>();

    sortedSteps.forEach((step) => {
      // Registrar a saída direta declarada na etapa do fluxo
      if (step.saida) {
        availableOutputs.add(step.saida);
      }

      // Se for um agente editorial, analisar o contrato estrito
      if (step.tipo === "Editorial Agent" && step.agente_id) {
        const contract = contracts[step.agente_id];
        
        if (!contract) {
          errors.push(`Etapa '${step.nome}' faz referência a um agente sem contrato registrado: '${step.agente_id}'.`);
          return;
        }

        // Validar se todas as ENTRADAS obrigatórias do contrato já estão disponíveis
        contract.inputs.forEach((input) => {
          if (!availableOutputs.has(input)) {
            // Algumas entradas podem ser geradas de forma complexa, mas se faltar no fluxo linear, apontamos erro
            errors.push(`Contrato do agente '${step.agente_id}' exige a entrada '${input}', mas ela ainda não foi produzida no fluxo anterior.`);
          }
        });

        // Registrar as SAÍDAS homologadas do contrato do agente
        contract.outputs.forEach((output) => {
          availableOutputs.add(output);
        });

        // Validar as dependências declaradas do agente
        contract.dependencies.forEach((depAgentId) => {
          // O agente dependente deve ter aparecido em alguma etapa anterior
          const depStep = sortedSteps.find(s => s.tipo === "Editorial Agent" && s.agente_id === depAgentId);
          if (!depStep) {
            errors.push(`O agente '${step.agente_id}' depende de '${depAgentId}', mas esse agente não está cadastrado em nenhuma etapa do fluxo.`);
          } else if (depStep.pos >= step.pos) {
            errors.push(`O agente '${step.agente_id}' (pos ${step.pos}) depende de '${depAgentId}' (pos ${depStep.pos}), infringindo a ordenação topológica do fluxo.`);
          }
        });
      }
    });

    // 3. Verificações de robustez adicional
    const writerStep = sortedSteps.find(s => s.agente_id === "agent-content-writer");
    const qaStep = sortedSteps.find(s => s.agente_id === "agent-quality-reviewer");

    if (!writerStep) {
      errors.push("O fluxo editorial não possui nenhum redator ativo ('agent-content-writer').");
    }
    if (!qaStep) {
      errors.push("O fluxo editorial não possui etapa final de garantia de qualidade ('agent-quality-reviewer').");
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      executionPlan
    };
  }
}
