import fs from "fs";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import { 
  EditorialBrief, 
  BriefScore, 
  BriefVersion, 
  SearchIntent, 
  EntitiesBrief, 
  QuestionsBrief, 
  OutlineBrief, 
  SeoBrief, 
  InternalLinksBrief, 
  ReferencesBrief, 
  WritingGuidelinesBrief 
} from "../models/brief-models";

// Loaders and Services from other modules
import { loadKnowledgeCore } from "../../knowledge/knowledge-loader";
import { loadInventory } from "../../inventory/inventory-loader";
import { loadCompetitors } from "../../competitors/competitor-loader";
import { loadSerpData } from "../../serp/serp-loader";
import { loadKeywordsData } from "../../keywords/keyword-loader";
import { PlannerService } from "../../editorial/planner-service";
import { EditorialItem } from "../../editorial/models/editorial-models";

const STORE_DIR = path.join(process.cwd(), "organic-traffic-os", "briefs", "store");
const TEMPLATE_DIR = path.join(process.cwd(), "organic-traffic-os", "briefs", "templates");

/**
 * Ensures the brief storage directory exists.
 */
function ensureStoreExists() {
  if (!fs.existsSync(STORE_DIR)) {
    fs.mkdirSync(STORE_DIR, { recursive: true });
  }
}

/**
 * Calculates a detailed Brief Score (0-100) across 6 dimensions.
 */
export function calculateBriefScore(brief: Partial<EditorialBrief>): BriefScore {
  // 1. Completude (Completeness)
  let completude = 0;
  if (brief.titulo) completude += 10;
  if (brief.objetivo) completude += 10;
  if (brief.search_intent?.intencao_principal) completude += 20;
  if (brief.outline?.secoes && brief.outline.secoes.length > 0) completude += 20;
  if (brief.writing_guidelines?.tom && brief.writing_guidelines?.publico) completude += 20;
  if (brief.seo?.keyword_principal) completude += 10;
  if (brief.references?.fontes && brief.references.fontes.length > 0) completude += 10;

  // 2. SEO Score
  let seo = 0;
  const kw = (brief.seo?.keyword_principal || "").toLowerCase();
  if (kw) {
    const title = (brief.seo?.meta_title || "").toLowerCase();
    const desc = (brief.seo?.meta_description || "").toLowerCase();
    const h1 = (brief.outline?.H1 || "").toLowerCase();
    const slug = (brief.seo?.slug || "").toLowerCase();

    if (title.includes(kw)) seo += 30;
    if (desc.includes(kw)) seo += 20;
    if (h1.includes(kw)) seo += 30;
    if (slug.includes(kw.replace(/\s+/g, "-"))) seo += 20;
  } else {
    seo = 50; // default if no keyword specified yet
  }

  // 3. Knowledge Score
  let knowledge = 0;
  // Check if writing guidelines and audience align with PassaCumaru knowledge core
  const hasTom = brief.writing_guidelines?.tom ? 1 : 0;
  const hasPublico = brief.writing_guidelines?.publico ? 1 : 0;
  const hasObjetivo = brief.writing_guidelines?.objetivo ? 1 : 0;
  const hasNivel = brief.writing_guidelines?.nivel_tecnico ? 1 : 0;
  const hasFormato = brief.writing_guidelines?.formato ? 1 : 0;
  knowledge = (hasTom + hasPublico + hasObjetivo + hasNivel + hasFormato) * 20;

  // 4. Entidades (Entities) Score
  let entidades = 0;
  const compulsoryEntities = ["IVIN", "Prefeitura", "Concurso", "Legislação", "Cumaru do Norte", "Secretarias"];
  const outlineStr = JSON.stringify(brief.outline || "").toLowerCase();
  const entitiesList = (brief.entities?.entidades_obrigatorias || []).concat(brief.seo?.entidades || []);
  
  let foundCount = 0;
  compulsoryEntities.forEach(ent => {
    const hasInList = entitiesList.some(e => e.toLowerCase().includes(ent.toLowerCase()));
    const hasInOutline = outlineStr.includes(ent.toLowerCase());
    if (hasInList || hasInOutline) {
      foundCount++;
    }
  });
  entidades = Math.round((foundCount / compulsoryEntities.length) * 100);

  // 5. Perguntas (Questions) Score
  let perguntas = 0;
  const qObrigatorias = brief.questions?.perguntas_obrigatorias?.length || 0;
  const qComp = brief.questions?.perguntas_complementares?.length || 0;
  const faqLength = brief.outline?.FAQ?.length || 0;
  
  const totalQ = qObrigatorias + qComp + faqLength;
  if (totalQ >= 5) perguntas = 100;
  else if (totalQ >= 3) perguntas = 85;
  else if (totalQ >= 1) perguntas = 60;
  else perguntas = 20;

  // 6. Estrutura (Structure) Score
  let estrutura = 0;
  if (brief.outline?.H1) estrutura += 20;
  if (brief.outline?.introducao) estrutura += 20;
  if (brief.outline?.resumo) estrutura += 20;
  if (brief.outline?.FAQ && brief.outline.FAQ.length > 0) estrutura += 20;
  if (brief.outline?.CTA) estrutura += 20;

  // Overall Score (weighted average)
  const geral = Math.round(
    completude * 0.15 +
    seo * 0.20 +
    knowledge * 0.15 +
    entidades * 0.15 +
    perguntas * 0.15 +
    estrutura * 0.20
  );

  return { completude, seo, knowledge, entidades, perguntas, estrutura, geral };
}

/**
 * Validates brief integrity, JSON format, duplicates and parent dependencies.
 */
export function validateBrief(brief: EditorialBrief, parentPilarExists: boolean = true): {
  isValid: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  // 1. Mandatory Fields Check
  if (!brief.id || brief.id === "brief-id-placeholder") errors.push("ID do Briefing é inválido ou nulo.");
  if (!brief.titulo) errors.push("Título do conteúdo é obrigatório.");
  if (!brief.categoria) errors.push("Categoria editorial é obrigatória.");
  if (!brief.cluster) errors.push("Silo/Cluster semântico é obrigatório.");
  
  // 2. Search Intent validation
  if (!brief.search_intent?.intencao_principal) {
    errors.push("Intenção de busca principal não informada.");
  }

  // 3. Keyword / SEO validation
  if (!brief.seo?.keyword_principal) {
    errors.push("Keyword Principal do SEO não definida.");
  } else {
    const slug = brief.seo.slug || "";
    if (slug.includes(" ") || /[A-Z]/.test(slug)) {
      warnings.push("O slug do SEO deve ser limpo (sem espaços ou letras maiúsculas).");
    }
  }

  // 4. Duplicate Check (Keywords & Entities)
  const kwSecundarias = brief.seo?.keywords_secundarias || [];
  const pKw = brief.seo?.keyword_principal || "";
  if (kwSecundarias.includes(pKw)) {
    warnings.push("A palavra-chave principal está duplicada na lista de palavras-chave secundárias.");
  }

  const uniqueSecKeywords = new Set(kwSecundarias);
  if (uniqueSecKeywords.size !== kwSecundarias.length) {
    warnings.push("Existem palavras-chave secundárias duplicadas no brief de SEO.");
  }

  const entities = brief.entities?.entidades_obrigatorias || [];
  const uniqueEntities = new Set(entities);
  if (uniqueEntities.size !== entities.length) {
    warnings.push("Existem entidades obrigatórias duplicadas.");
  }

  // 5. Structure Checklist
  if (!brief.outline?.H1) {
    errors.push("Estrutura de tópicos sem H1.");
  }
  if (!brief.outline?.secoes || brief.outline.secoes.length === 0) {
    errors.push("O conteúdo precisa de pelo menos uma seção de conteúdo estruturada (H2/H3).");
  }

  // 6. Dependencies Validation
  if (brief.tipo !== "pilar" && !parentPilarExists) {
    warnings.push(`Este conteúdo é do tipo '${brief.tipo}', mas nenhuma Página Pilar ativa foi detectada ou vinculada.`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}

/**
 * Brief Loader: Responsible for loading briefs from storage.
 */
export class BriefLoader {
  /**
   * Loads a brief by ID.
   */
  public static load(id: string): EditorialBrief | null {
    ensureStoreExists();
    const filePath = path.join(STORE_DIR, `${id}.json`);
    if (!fs.existsSync(filePath)) return null;

    try {
      const raw = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(raw);
    } catch (e) {
      console.error(`Erro ao carregar o brief ${id}:`, e);
      return null;
    }
  }

  /**
   * Loads all briefs in the storage directory.
   */
  public static loadAll(): EditorialBrief[] {
    ensureStoreExists();
    try {
      const files = fs.readdirSync(STORE_DIR).filter(f => f.endsWith(".json"));
      const briefs: EditorialBrief[] = [];
      files.forEach(f => {
        const raw = fs.readFileSync(path.join(STORE_DIR, f), "utf-8");
        try {
          briefs.push(JSON.parse(raw));
        } catch (err) {
          console.error(`Erro ao parsear arquivo de brief ${f}:`, err);
        }
      });
      return briefs.sort((a, b) => new Date(b.criado_em).getTime() - new Date(a.criado_em).getTime());
    } catch (e) {
      console.error("Erro ao listar briefs:", e);
      return [];
    }
  }
}

/**
 * Brief Engine: Builds, scores, validates, updates and versions briefs.
 */
export class BriefEngine {
  /**
   * Constructs a brief using Gemini or falls back programmatically.
   */
  public static async generateBrief(editorialItemId: string, blogId: string = "passacumaru"): Promise<EditorialBrief> {
    ensureStoreExists();

    // 1. Gather all required contexts
    const editorialItems = await PlannerService.getEditorialItems();
    const item = editorialItems.find(x => x.id === editorialItemId);
    if (!item) {
      throw new Error(`Item editorial com ID '${editorialItemId}' não foi localizado no planejamento.`);
    }

    const knowledge = loadKnowledgeCore(blogId);
    const inventory = loadInventory(blogId);
    const competitors = loadCompetitors();
    const serpData = loadSerpData();
    const keywordsData = loadKeywordsData();

    // Check if parent pilar exists in planning or inventory
    let parentPilarExists = false;
    if (item.tipo !== "pilar") {
      const parentInPlan = editorialItems.some(x => x.cluster === item.cluster && x.tipo === "pilar");
      const parentInInv = inventory.index.some((x: any) => x.cluster === item.cluster && x.tipo === "pilar");
      parentPilarExists = parentInPlan || parentInInv;
    } else {
      parentPilarExists = true;
    }

    // Try to find keyword details
    const cleanKeyword = item.titulo.toLowerCase()
      .replace(/guia completo|tudo sobre|como fazer|o que é/gi, "")
      .trim();
    const mainKw = cleanKeyword || item.titulo.toLowerCase();

    // Get secondary keywords candidates from keywordsData
    const kwsFromDb = keywordsData.keywords || [];
    const secondaryKwCandidates = kwsFromDb
      .filter((k: any) => k.cluster === item.cluster && k.keyword.toLowerCase() !== mainKw)
      .map((k: any) => k.keyword)
      .slice(0, 4);

    // Get template bases
    const searchIntentBase = this.loadTemplate<SearchIntent>("search-intent.json") || {
      intencao_principal: `Saber tudo sobre ${item.titulo} no contexto de ${item.cluster}.`,
      intencoes_secundarias: [`Entender as novidades sobre ${item.cluster}`, `Baixar editais e informativos`],
      problemas: [`Desinformação sobre os processos em ${item.cluster}`, `Falta de canal unificado`],
      objetivos: [`Ajudar o candidato/leitor com dados confiáveis`, `Aumentar tráfego qualificado do blog`]
    };

    const entitiesBase = this.loadTemplate<EntitiesBrief>("entities.json") || {
      entidades_obrigatorias: ["IVIN", "Prefeitura", "Concurso", "Legislação", "Cumaru do Norte", "Secretarias"],
      entidades_recomendadas: ["Gabarito", "Diário Oficial", "Vagas"]
    };

    const questionsBase = this.loadTemplate<QuestionsBrief>("questions.json") || {
      perguntas_obrigatorias: [
        `Como funciona o processo de ${item.titulo}?`,
        `Qual é o prazo final de inscrição?`
      ],
      perguntas_complementares: [
        `Quem pode concorrer?`,
        `Qual é a taxa de inscrição?`
      ],
      perguntas_relacionadas: [
        `Onde fica a Prefeitura de Cumaru do Norte?`
      ]
    };

    const writingBase = this.loadTemplate<WritingGuidelinesBrief>("writing-guidelines.json") || {
      tom: "informativo, profissional, útil e empático",
      publico: "candidatos e cidadãos interessados",
      objetivo: `Educar o leitor sobre ${item.titulo}`,
      nivel_tecnico: "médio (acessível mas preciso)",
      tamanho_esperado: "1200 - 1500 palavras",
      formato: "Artigo de blog estruturado com tabelas e FAQ"
    };

    let brief: Partial<EditorialBrief> = {
      id: `brief-${item.id}`,
      titulo: item.titulo,
      objetivo: item.objetivo || "Meta editorial padrão de aprofundamento e autoridade.",
      categoria: item.categoria,
      cluster: item.cluster,
      tipo: item.tipo,
      status: "ready", // ready for writing
      versao: 1,
      autor: "Brief Intelligence Engine V1",
      criado_em: new Date().toISOString(),
      atualizado_em: new Date().toISOString(),
      search_intent: searchIntentBase,
      entities: entitiesBase,
      questions: questionsBase,
      writing_guidelines: writingBase,
      versions: []
    };

    // 2. Dynamic generation: If API key is available, use Gemini to make it extremely premium
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } }
        });

        const prompt = `
          Você é o Editor-Chefe da agência Organic Traffic OS.
          Sua missão é gerar um Briefing Editorial Premium para o seguinte conteúdo planejado:
          - Título: "${item.titulo}"
          - Silo/Cluster Semântico: "${item.cluster}"
          - Tipo Editorial: "${item.tipo}"
          - Objetivo de Negócio: "${item.objetivo}"
          - CTA Recomendado: "${item.cta}"

          Use as seguintes fontes de dados reais do blog e da SERP para enriquecer o brief:
          1. Diretrizes de Escrita do Blog: ${JSON.stringify(knowledge?.writingStyle || "Profissional, acolhedor")}
          2. Regras Editoriais: ${JSON.stringify(knowledge?.editorial || "Manter imparcialidade")}
          3. Dados da SERP sobre Cumaru: ${JSON.stringify(serpData?.results || "Banca IVIN, concurso público")}
          4. Concorrentes Analisados: ${JSON.stringify(competitors?.competitors || "Blogs de concursos locais")}
          5. Keywords Disponíveis: ${JSON.stringify(secondaryKwCandidates)}

          Gere um objeto JSON completo respeitando a seguinte estrutura:
          {
            "search_intent": {
              "intencao_principal": "string detalhando o que o usuário quer ao buscar isso",
              "intencoes_secundarias": ["string", "string"],
              "problemas": ["principais dores do usuário", "outra dor"],
              "objetivos": ["o que o artigo deve realizar para o leitor"]
            },
            "entities": {
              "entidades_obrigatorias": ["IVIN", "Prefeitura", "Concurso", "Legislação", "Cumaru do Norte", "Secretarias", "e outras 2 ou 3 específicas para o tema"],
              "entidades_recomendadas": ["outros termos chave de entidade de SEO"]
            },
            "questions": {
              "perguntas_obrigatorias": ["pergunta 1", "pergunta 2"],
              "perguntas_complementares": ["pergunta 1", "pergunta 2"],
              "perguntas_relacionadas": ["pergunta 1", "pergunta 2"]
            },
            "outline": {
              "H1": "Título SEO H1 recomendado extremamente atraente e contendo a keyword",
              "introducao": "Diretriz detalhada de como deve ser a introdução do artigo",
              "secoes": [
                {
                  "nivel": "H2",
                  "titulo": "Título da seção principal",
                  "diretrizes": "O que deve ser abordado nesta seção",
                  "subsecoes": [
                    {
                      "nivel": "H3",
                      "titulo": "Subtópico de aprofundamento",
                      "diretrizes": "Instruções específicas para o escritor"
                    }
                  ]
                }
              ],
              "resumo": "Diretrizes para a seção de encerramento do texto",
              "FAQ": [
                { "pergunta": "Pergunta frequente 1?", "resposta": "Diretriz rápida de resposta" },
                { "pergunta": "Pergunta frequente 2?", "resposta": "Diretriz rápida de resposta" }
              ],
              "CTA": "Diretriz clara de Call to Action usando: ${item.cta}"
            },
            "seo": {
              "meta_title": "Meta Title otimizado com menos de 60 caracteres",
              "meta_description": "Meta Description persuasiva com menos de 155 caracteres",
              "slug": "slug-limpo-em-lowercase-com-hifens",
              "keyword_principal": "keyword principal derivada",
              "keywords_secundarias": ["keyword 1", "keyword 2"],
              "entidades": ["entidade1", "entidade2"],
              "schema_recomendado": ["FAQPage", "Article"]
            },
            "internal_links": {
              "paginas_recomendadas": [
                { "url": "/sobre", "anchor": "Sobre o Cumaru do Norte" }
              ],
              "artigos_relacionados": [
                { "url": "/noticias", "anchor": "Últimas notícias municipais" }
              ],
              "categorias": ["${item.categoria}"],
              "produtos": []
            },
            "references": {
              "fontes": ["Site Oficial da Prefeitura de Cumaru do Norte", "Banca IVIN Concursos"],
              "documentacao": ["Estatuto dos Servidores", "Leis Municipais"],
              "links_oficiais": ["https://cumarudonorte.pa.gov.br"],
              "observacoes": "Instrução crucial de checagem de fontes oficiais."
            },
            "writing_guidelines": {
              "tom": "informativo, prestativo e neutro",
              "publico": "Candidatos ao concurso de Cumaru do Norte",
              "objetivo": "Orientar de forma transparente sobre o edital, etapas e salários",
              "nivel_tecnico": "médio",
              "tamanho_esperado": "1500 a 2000 palavras",
              "formato": "Guia de blog completo com tabelas"
            }
          }

          Retorne APENAS o JSON válido estruturado de acordo com essa especificação, sem textos explicativos ao redor.
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json"
          }
        });

        const text = response.text || "";
        const geminiResult = JSON.parse(text.trim());

        brief.search_intent = geminiResult.search_intent || brief.search_intent;
        brief.entities = geminiResult.entities || brief.entities;
        brief.questions = geminiResult.questions || brief.questions;
        brief.outline = geminiResult.outline || brief.outline;
        brief.seo = geminiResult.seo || brief.seo;
        brief.internal_links = geminiResult.internal_links || brief.internal_links;
        brief.references = geminiResult.references || brief.references;
        brief.writing_guidelines = geminiResult.writing_guidelines || brief.writing_guidelines;

      } catch (geminiErr) {
        console.error("Erro ao chamar a API Gemini, aplicando fallback programático robusto:", geminiErr);
        // Apply robust programmatically structured outline and seo briefs
        this.applyProgrammaticBrief(brief, item, mainKw, secondaryKwCandidates);
      }
    } else {
      // API Key missing - programmatic fallback
      this.applyProgrammaticBrief(brief, item, mainKw, secondaryKwCandidates);
    }

    // 3. Score calculation
    const score = calculateBriefScore(brief);
    brief.score = score;

    // 4. Audit validation
    const audit = validateBrief(brief as EditorialBrief, parentPilarExists);
    brief.audit = audit;

    // Save initial brief as V1
    const finalBrief = brief as EditorialBrief;
    const savePath = path.join(STORE_DIR, `${finalBrief.id}.json`);
    fs.writeFileSync(savePath, JSON.stringify(finalBrief, null, 2), "utf-8");

    return finalBrief;
  }

  /**
   * Generates logical programmatic outlines and links when Gemini is unavailable.
   */
  private static applyProgrammaticBrief(
    brief: Partial<EditorialBrief>, 
    item: EditorialItem, 
    mainKw: string, 
    secondaryKws: string[]
  ) {
    const slug = mainKw
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .toLowerCase();

    // Outlines are highly contextual to content types
    let outline: OutlineBrief;
    if (item.tipo === "pilar") {
      outline = {
        H1: `Guia Definitivo: Tudo sobre o ${item.titulo}`,
        introducao: `Este guia completo foi planejado para reunir todas as informações fundamentais sobre o ${item.titulo}. Descubra os requisitos básicos, histórico e o passo a passo completo para se situar no tema.`,
        secoes: [
          {
            nivel: "H2",
            titulo: `O que é o ${item.titulo}`,
            diretrizes: "Explicar o conceito básico, histórico e os principais pilares de atuação."
          },
          {
            nivel: "H2",
            titulo: "Principais Requisitos e Quem pode Participar",
            diretrizes: "Listar detalhadamente as regras de elegibilidade, graus de instrução e documentos necessários."
          },
          {
            nivel: "H2",
            titulo: "Passo a Passo: Como Começar a sua Preparação",
            diretrizes: "Roteiro prático com cronograma sugerido, indicação de links oficiais e dicas de estudo.",
            subsecoes: [
              {
                nivel: "H3",
                titulo: "Materiais Recomendados e Legislação Oficial",
                diretrizes: "Mapear as principais leis municipais, decretos de Cumaru do Norte e apostilas."
              }
            ]
          }
        ],
        resumo: `O ${item.titulo} representa uma chance imperdível de evolução pessoal e profissional. Utilize este guia como ponto de partida definitivo para sua jornada de sucesso.`,
        FAQ: [
          { pergunta: `Onde baixar o edital do ${item.titulo}?`, resposta: "O edital oficial fica centralizado no portal da organizadora e no Diário Oficial." },
          { pergunta: "Qual é a taxa média?", resposta: "A taxa varia de acordo com o nível do cargo, entre R$ 50 e R$ 120." }
        ],
        CTA: item.cta || "Baixar Apostila de Estudo Completa para o Concurso!"
      };
    } else if (item.tipo === "simulado" || item.tipo === "material_rico") {
      outline = {
        H1: `Simulado Exclusivo Gabaritado: ${item.titulo}`,
        introducao: `Acelere seu aprendizado com o nosso caderno de questões prático para ${item.titulo}. Teste seus conhecimentos agora mesmo.`,
        secoes: [
          {
            nivel: "H2",
            titulo: "Estrutura do Caderno de Questões",
            diretrizes: "Apresentar a quantidade de questões de concurso, divisões por disciplinas e nível de dificuldade."
          },
          {
            nivel: "H2",
            titulo: "Simulado Prático (Questões de Exemplo)",
            diretrizes: "Apresentar as questões numeradas com alternativas claras baseadas em provas anteriores da banca IVIN."
          }
        ],
        resumo: "Conclua seu simulado revisando os pontos fracos apontados pelo gabarito oficial.",
        FAQ: [
          { pergunta: "Como ter acesso ao gabarito comentado?", resposta: "O gabarito comentado está disponível para download no final deste artigo." }
        ],
        CTA: item.cta || "Fazer download do PDF com 100 Questões Gabaritadas!"
      };
    } else {
      // satelite / faq
      outline = {
        H1: `${item.titulo}: Tudo o que você precisa saber`,
        introducao: `Entenda de forma rápida e prática as principais regras e atualizações sobre o ${item.titulo}. Esclarecemos as principais dúvidas coletadas na SERP para você.`,
        secoes: [
          {
            nivel: "H2",
            titulo: `Principais Dúvidas Resolvidas: ${item.titulo}`,
            diretrizes: "Direcionar as respostas diretamente às dores mais urgentes dos concurseiros."
          },
          {
            nivel: "H2",
            titulo: "Prazos, Taxas e Isenção",
            diretrizes: "Informações sobre como requerer isenção e prazos de pagamento na banca oficial."
          }
        ],
        resumo: "Mantenha o foco acompanhando os canais oficiais e as atualizações do blog PassaCumaru.",
        FAQ: [
          { pergunta: `Qual é a banca do ${item.titulo}?`, resposta: "A banca organizadora oficial é o Instituto IVIN." }
        ],
        CTA: item.cta || "Ler Guia Pilar de Cumaru do Norte"
      };
    }

    brief.outline = outline;

    brief.seo = {
      meta_title: `${item.titulo.substring(0, 45)}: Edital e Inscrições`,
      meta_description: `Saiba tudo sobre o ${item.titulo}. Informações cruciais sobre vagas, banca organizadora, salários e cronograma de provas atualizado.`,
      slug,
      keyword_principal: mainKw,
      keywords_secundarias: secondaryKws,
      entidades: ["IVIN", "Prefeitura de Cumaru do Norte", "Concurso Público"],
      schema_recommended: ["Article", "FAQPage"]
    } as any;

    brief.internal_links = {
      paginas_recomendadas: [{ url: "/concursos/cumaru", anchor: "Concursos em Cumaru do Norte" }],
      artigos_relacionados: [{ url: `/blog/concurso-${slug}`, anchor: `Guia de Inscrição ${item.titulo}` }],
      categorias: [item.categoria],
      produtos: []
    };

    brief.references = {
      fontes: ["Diário Oficial de Cumaru do Norte", "Instituto IVIN Concursos"],
      documentacao: ["Lei Orgânica Municipal", "Editais Anteriores"],
      links_oficiais: ["https://cumarudonorte.pa.gov.br"],
      observacoes: "Verificar retificações de editais e datas no site da banca IVIN."
    };
  }

  /**
   * Helper to load template.
   */
  private static loadTemplate<T>(fileName: string): T | null {
    const templatePath = path.join(TEMPLATE_DIR, fileName);
    if (!fs.existsSync(templatePath)) return null;
    try {
      return JSON.parse(fs.readFileSync(templatePath, "utf-8"));
    } catch {
      return null;
    }
  }

  /**
   * Updates an existing brief and stores a historical version.
   */
  public static updateBrief(id: string, updatedData: Partial<EditorialBrief>, autor: string = "Editor-Chefe Engine"): EditorialBrief {
    ensureStoreExists();
    const existing = BriefLoader.load(id);
    if (!existing) {
      throw new Error(`Briefing com ID '${id}' não encontrado para atualização.`);
    }

    // Capture snapshot for historical versioning
    const previousSnapshot = { ...existing };
    delete previousSnapshot.versions; // avoid nested recursive versions

    const currentVersionNum = existing.versao || 1;
    const newVersionNum = currentVersionNum + 1;

    const newVersionRecord: BriefVersion = {
      versao: currentVersionNum,
      data_snapshot: existing.atualizado_em || existing.criado_em,
      autor: existing.autor || "Sistema",
      mudancas: `Atualização de campos do brief. Versão promovida de v${currentVersionNum} para v${newVersionNum}.`,
      brief_snapshot: previousSnapshot
    };

    const merged: EditorialBrief = {
      ...existing,
      ...updatedData,
      id: existing.id, // prevent overwriting ID
      versao: newVersionNum,
      autor,
      atualizado_em: new Date().toISOString(),
      versions: [...(existing.versions || []), newVersionRecord]
    };

    // Re-score
    merged.score = calculateBriefScore(merged);

    // Re-validate
    const serpData = loadSerpData();
    const inventory = loadInventory();
    let parentPilarExists = true;
    if (merged.tipo !== "pilar") {
      const allBriefs = BriefLoader.loadAll();
      const parentInBriefs = allBriefs.some(x => x.cluster === merged.cluster && x.tipo === "pilar");
      const parentInInv = inventory.index.some((x: any) => x.cluster === merged.cluster && x.tipo === "pilar");
      parentPilarExists = parentInBriefs || parentInInv;
    }
    merged.audit = validateBrief(merged, parentPilarExists);

    const savePath = path.join(STORE_DIR, `${merged.id}.json`);
    fs.writeFileSync(savePath, JSON.stringify(merged, null, 2), "utf-8");

    return merged;
  }
}

/**
 * Brief Service: Domain API service to handle business operations.
 */
export class BriefService {
  public static createBrief(editorialItemId: string, blogId: string = "passacumaru"): Promise<EditorialBrief> {
    return BriefEngine.generateBrief(editorialItemId, blogId);
  }

  public static getBrief(id: string): EditorialBrief | null {
    return BriefLoader.load(id);
  }

  public static getAllBriefs(): EditorialBrief[] {
    return BriefLoader.loadAll();
  }

  public static update(id: string, updatedData: Partial<EditorialBrief>, autor?: string): EditorialBrief {
    return BriefEngine.updateBrief(id, updatedData, autor);
  }

  public static getByCluster(cluster: string): EditorialBrief[] {
    return BriefLoader.loadAll().filter(b => b.cluster.toLowerCase() === cluster.toLowerCase());
  }

  public static getByCategory(category: string): EditorialBrief[] {
    return BriefLoader.loadAll().filter(b => b.categoria.toLowerCase() === category.toLowerCase());
  }
}
