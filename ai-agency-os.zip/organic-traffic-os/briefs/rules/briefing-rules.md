# Regras Editoriais para Briefings Premium

## 1. Regras de Entrada
- Todo briefing deve obrigatoriamente estar vinculado a uma oportunidade editorial do planejamento backlog.
- O tema, silo de conteúdo (cluster) e categoria devem ser importados de forma direta do planejamento para evitar inconsistências taxonômicas.

## 2. Regras de Integração
- **Knowledge Core**: Deve guiar o tom de voz, público alvo e restrições de formatação.
- **Content Inventory**: Fornece os candidatos a links internos baseados em artigos existentes para evitar páginas órfãs.
- **Competidores & SERP**: Mapeia as intenções secundárias e perguntas reais feitas por usuários para compor a FAQ e os subtópicos do conteúdo.

## 3. Regras de Pontuação (Brief Score)
- **Completude (15%)**: Valida se todas as seções estruturais mínimas foram geradas.
- **SEO (20%)**: Checa se a palavra-chave principal está inserida estrategicamente no Meta Title, Meta Description, Slug e Heading H1.
- **Knowledge (15%)**: Garante fidelidade ao perfil e objetivos de escrita do blog.
- **Entidades (15%)**: Avalia se as entidades de alta relevância foram incorporadas para robustecer o SEO semântico.
- **Perguntas (15%)**: Confirma se as principais dores do público foram cobertas na forma de perguntas diretas.
- **Estrutura (20%)**: Reclama a presença obrigatória de introdução estruturada, seções com subtópicos, resumo e FAQ.

## 4. Regras de Versionamento
- Qualquer alteração manual ou assistida por IA nos campos sensíveis do brief incrementa a versão (`versao++`) e cria um snapshot de backup histórico e imutável para posterior restauração.
