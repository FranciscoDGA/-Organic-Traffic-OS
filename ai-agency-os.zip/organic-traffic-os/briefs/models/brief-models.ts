export interface SearchIntent {
  intencao_principal: string;
  intencoes_secundarias: string[];
  problemas: string[];
  objetivos: string[];
}

export interface EntitiesBrief {
  entidades_obrigatorias: string[];
  entidades_recomendadas: string[];
  entidades_secundarias?: string[];
}

export interface QuestionsBrief {
  perguntas_obrigatorias: string[];
  perguntas_complementares: string[];
  perguntas_relacionadas: string[];
}

export interface OutlineSection {
  nivel: string; // H2, H3, H4
  titulo: string;
  diretrizes: string;
  subsecoes?: OutlineSection[];
}

export interface OutlineBrief {
  H1: string;
  introducao: string;
  secoes: OutlineSection[];
  resumo: string;
  FAQ: { pergunta: string; resposta: string }[];
  CTA: string;
}

export interface SeoBrief {
  meta_title: string;
  meta_description: string;
  slug: string;
  keyword_principal: string;
  keywords_secundarias: string[];
  entidades: string[];
  schema_recomendado: string[];
}

export interface InternalLinksBrief {
  paginas_recomendadas: { url: string; anchor: string }[];
  artigos_relacionados: { url: string; anchor: string }[];
  categorias: string[];
  produtos: string[];
}

export interface ReferencesBrief {
  fontes: string[];
  documentacao: string[];
  links_oficiais: string[];
  observacoes: string;
}

export interface WritingGuidelinesBrief {
  tom: string;
  publico: string;
  objetivo: string;
  nivel_tecnico: string;
  tamanho_esperado: string;
  formato: string;
}

export interface BriefScore {
  completude: number; // 0-100
  seo: number; // 0-100
  knowledge: number; // 0-100
  entidades: number; // 0-100
  perguntas: number; // 0-100
  estrutura: number; // 0-100
  geral: number; // média ponderada
}

export interface BriefVersion {
  versao: number;
  data_snapshot: string;
  autor: string;
  mudancas: string;
  brief_snapshot: any; // brief data
}

export interface EditorialBrief {
  id: string;
  titulo: string;
  objetivo: string;
  categoria: string;
  cluster: string;
  tipo: "pilar" | "satelite" | "faq" | "simulado" | "material_rico" | string;
  status: "draft" | "pending" | "ready" | "archived" | string;
  versao: number;
  autor: string;
  criado_em: string;
  atualizado_em?: string;

  search_intent: SearchIntent;
  entities: EntitiesBrief;
  questions: QuestionsBrief;
  outline: OutlineBrief;
  seo: SeoBrief;
  internal_links: InternalLinksBrief;
  references: ReferencesBrief;
  writing_guidelines: WritingGuidelinesBrief;

  score: BriefScore;
  audit: {
    isValid: boolean;
    errors: string[];
    warnings: string[];
  };
  versions?: BriefVersion[];
}
