import fs from "fs";
import path from "path";
import { validateSerpData } from "./serp-validator";

export interface ConsolidatedSerpData {
  queries: any[];
  results: any[];
  features: any[];
  patterns: any[];
  intents: any[];
  opportunities: any[];
  metadata: {
    totalQueries: number;
    analysedCount: number;
    pendingCount: number;
    totalOpportunities: number;
    intentDistribution: Record<string, number>;
    featureCounts: {
      featuredSnippet: number;
      peopleAlsoAsk: number;
      faq: number;
      videos: number;
      imagens: number;
      localPack: number;
    };
    isValid: boolean;
    errors: string[];
    lastUpdated: string;
  };
}

export function loadSerpData(): ConsolidatedSerpData {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "serp");

  const files = {
    queries: "serp-query.json",
    results: "serp-results.json",
    features: "serp-features.json",
    patterns: "content-patterns.json",
    intents: "search-intent.json",
    opportunities: "serp-opportunities.json"
  };

  let queries: any[] = [];
  let results: any[] = [];
  let features: any[] = [];
  let patterns: any[] = [];
  let intents: any[] = [];
  let opportunities: any[] = [];

  try {
    if (fs.existsSync(path.join(baseDir, files.queries))) {
      queries = JSON.parse(fs.readFileSync(path.join(baseDir, files.queries), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.results))) {
      results = JSON.parse(fs.readFileSync(path.join(baseDir, files.results), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.features))) {
      features = JSON.parse(fs.readFileSync(path.join(baseDir, files.features), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.patterns))) {
      patterns = JSON.parse(fs.readFileSync(path.join(baseDir, files.patterns), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.intents))) {
      intents = JSON.parse(fs.readFileSync(path.join(baseDir, files.intents), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.opportunities))) {
      opportunities = JSON.parse(fs.readFileSync(path.join(baseDir, files.opportunities), "utf-8"));
    }
  } catch (err) {
    console.error("Error reading SERP database files:", err);
  }

  // Run schema validation
  const validationResult = validateSerpData();

  // Aggregate metadata calculations
  let analysedCount = 0;
  let pendingCount = 0;

  queries.forEach((q: any) => {
    if (q.status === "analisado") {
      analysedCount++;
    } else {
      pendingCount++;
    }
  });

  // Calculate search intent distribution across the analyzed queries
  const intentCounts: Record<string, number> = {};
  intents.forEach((si: any) => {
    if (si.intencao) {
      intentCounts[si.intencao] = (intentCounts[si.intencao] || 0) + 1;
    }
  });

  // Calculate SERP feature counts
  const featureCounts = {
    featuredSnippet: 0,
    peopleAlsoAsk: 0,
    faq: 0,
    videos: 0,
    imagens: 0,
    localPack: 0
  };

  features.forEach((f: any) => {
    if (f.featuredSnippet && f.featuredSnippet.presente) featureCounts.featuredSnippet++;
    if (f.peopleAlsoAsk && f.peopleAlsoAsk.length > 0) featureCounts.peopleAlsoAsk++;
    if (f.faq) featureCounts.faq++;
    if (f.videos) featureCounts.videos++;
    if (f.imagens) featureCounts.imagens++;
    if (f.localPack) featureCounts.localPack++;
  });

  return {
    queries,
    results,
    features,
    patterns,
    intents,
    opportunities,
    metadata: {
      totalQueries: queries.length,
      analysedCount,
      pendingCount,
      totalOpportunities: opportunities.length,
      intentDistribution: intentCounts,
      featureCounts,
      isValid: validationResult.isValid,
      errors: validationResult.errors,
      lastUpdated: new Date().toISOString()
    }
  };
}
