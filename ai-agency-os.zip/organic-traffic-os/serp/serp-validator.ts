import fs from "fs";
import path from "path";

export interface SerpValidationReport {
  isValid: boolean;
  errors: string[];
  checkedFiles: string[];
}

export function validateSerpData(): SerpValidationReport {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "serp");
  const errors: string[] = [];
  const checkedFiles: string[] = [];

  const requiredFiles = [
    "serp-query.json",
    "serp-results.json",
    "serp-features.json",
    "content-patterns.json",
    "search-intent.json",
    "serp-opportunities.json"
  ];

  requiredFiles.forEach(filename => {
    const filePath = path.join(baseDir, filename);
    checkedFiles.push(filename);

    if (!fs.existsSync(filePath)) {
      errors.push(`Arquivo obrigatório do motor de SERP ausente: ${filename}`);
      return;
    }

    try {
      const raw = fs.readFileSync(filePath, "utf-8");
      const parsed = JSON.parse(raw);

      if (!Array.isArray(parsed)) {
        errors.push(`O arquivo ${filename} deve ser um array JSON válido.`);
        return;
      }

      // 1. Validar serp-query.json
      if (filename === "serp-query.json") {
        const ids = new Set<string>();
        const queries = new Set<string>();
        parsed.forEach((q: any, idx) => {
          const missing: string[] = [];
          if (!q.id) missing.push("id");
          if (!q.query) missing.push("query");
          if (!q.categoria) missing.push("categoria");
          if (!q.cluster) missing.push("cluster");
          if (!q.idioma) missing.push("idioma");
          if (!q.pais) missing.push("pais");

          if (missing.length > 0) {
            errors.push(`serp-query.json no índice ${idx} está sem campos obrigatórios: ${missing.join(", ")}`);
          }

          if (q.id) {
            if (ids.has(q.id)) {
              errors.push(`ID de consulta duplicado detectado em serp-query.json: ${q.id}`);
            }
            ids.add(q.id);
          }

          if (q.query) {
            const normalizedQuery = q.query.toLowerCase().trim();
            if (queries.has(normalizedQuery)) {
              errors.push(`Consulta textual duplicada detectada em serp-query.json: "${q.query}"`);
            }
            queries.add(normalizedQuery);
          }
        });
      }

      // 2. Validar serp-results.json
      if (filename === "serp-results.json") {
        parsed.forEach((r: any, idx) => {
          const missing: string[] = [];
          if (!r.id) missing.push("id");
          if (!r.queryId) missing.push("queryId");
          if (r.posicao === undefined) missing.push("posicao");
          if (!r.url) missing.push("url");
          if (!r.dominio) missing.push("dominio");
          if (!r.titulo) missing.push("titulo");
          if (!r.tipo) missing.push("tipo");

          if (missing.length > 0) {
            errors.push(`serp-results.json no índice ${idx} está sem campos obrigatórios: ${missing.join(", ")}`);
          }
        });
      }

      // 3. Validar serp-features.json
      if (filename === "serp-features.json") {
        parsed.forEach((f: any, idx) => {
          if (!f.queryId) {
            errors.push(`serp-features.json no índice ${idx} está sem 'queryId' para correlação`);
          }
          if (f.featuredSnippet === undefined || f.featuredSnippet.presente === undefined) {
            errors.push(`serp-features.json no índice ${idx} não define a estrutura obrigatória 'featuredSnippet'`);
          }
        });
      }

      // 4. Validar content-patterns.json
      if (filename === "content-patterns.json") {
        parsed.forEach((p: any, idx) => {
          if (!p.queryId) {
            errors.push(`content-patterns.json no índice ${idx} está sem 'queryId' para correlação`);
          }
          if (p.tamanhoMedio === undefined) {
            errors.push(`content-patterns.json no índice ${idx} está sem o campo obrigatório 'tamanhoMedio'`);
          }
        });
      }

      // 5. Validar search-intent.json
      if (filename === "search-intent.json") {
        parsed.forEach((si: any, idx) => {
          if (!si.queryId) {
            errors.push(`search-intent.json no índice ${idx} está sem 'queryId' para correlação`);
          }
          if (!si.intencao) {
            errors.push(`search-intent.json no índice ${idx} está sem a classificação principal 'intencao'`);
          }
        });
      }

      // 6. Validar serp-opportunities.json
      if (filename === "serp-opportunities.json") {
        const ids = new Set<string>();
        parsed.forEach((o: any, idx) => {
          const missing: string[] = [];
          if (!o.id) missing.push("id");
          if (!o.consulta) missing.push("consulta");
          if (!o.motivo) missing.push("motivo");
          if (!o.potencial) missing.push("potencial");
          if (!o.prioridade) missing.push("prioridade");
          if (!o.status) missing.push("status");

          if (missing.length > 0) {
            errors.push(`serp-opportunities.json no índice ${idx} está sem campos obrigatórios: ${missing.join(", ")}`);
          }

          if (o.id) {
            if (ids.has(o.id)) {
              errors.push(`ID de oportunidade duplicado em serp-opportunities.json: ${o.id}`);
            }
            ids.add(o.id);
          }
        });
      }

    } catch (err: any) {
      errors.push(`Falha crítica de leitura no arquivo de SERP ${filename}: ${err.message || err}`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    checkedFiles
  };
}
