import fs from "fs";
import path from "path";

export interface SerpQuery {
  id: string;
  query: string;
  categoria: string;
  cluster: string;
  idioma: string;
  pais: string;
  cidade: string;
  status: "analisado" | "pendente";
  ultima_analise: string;
}

export interface SerpResult {
  id: string;
  queryId: string;
  posicao: number;
  url: string;
  dominio: string;
  titulo: string;
  descricao: string;
  tipo: "blog" | "vídeo" | "fórum" | "governo" | "e-commerce" | "pdf" | "data" | string;
  data?: string;
}

export interface FeaturedSnippet {
  presente: boolean;
  tipo: "paragrafo" | "lista" | "tabela" | string;
  detentor: string;
  texto: string;
}

export interface SerpFeatures {
  queryId: string;
  featuredSnippet: FeaturedSnippet;
  peopleAlsoAsk: string[];
  knowledgePanel: boolean;
  localPack: boolean;
  videos: boolean;
  imagens: boolean;
  news: boolean;
  faq: boolean;
  breadcrumb: boolean;
  richResults: boolean;
}

export interface ContentPatterns {
  queryId: string;
  quantidadeMediaH2: number;
  quantidadeMediaH3: number;
  usoDeFaq: "Baixo" | "Médio" | "Alto" | "Altíssimo" | string;
  usoDeTabelas: "Baixo" | "Médio" | "Alto" | "Altíssimo" | string;
  usoDeListas: "Baixo" | "Médio" | "Alto" | "Altíssimo" | string;
  usoDeVideos: "Baixo" | "Médio" | "Alto" | "Altíssimo" | string;
  usoDeImagens: "Baixo" | "Médio" | "Alto" | "Altíssimo" | string;
  usoDeSchema: "Baixo" | "Médio" | "Alto" | "Altíssimo" | string;
  tamanhoMedio: number;
}

export interface SearchIntent {
  queryId: string;
  intencao: "Informacional" | "Navegacional" | "Comercial" | "Transacional" | "Local" | "Educacional" | string;
  distribuicao: Record<string, number>;
  observacoes: string;
}

export interface SerpOpportunity {
  id: string;
  consulta: string;
  motivo: string;
  potencial: "Baixo" | "Médio" | "Alto" | "Explosivo" | string;
  prioridade: "Baixa" | "Média" | "Alta" | "Crítica" | string;
  status: "Mapeado" | "Em Progresso" | "Implementado" | string;
  observações: string;
}

/**
 * Registra a análise completa de uma consulta na SERP
 */
export function registerSerpAnalysis(
  query: SerpQuery,
  results: SerpResult[],
  features: SerpFeatures,
  patterns: ContentPatterns,
  intent: SearchIntent
) {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "serp");

  if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true });
  }

  const queryWithTimestamp = {
    ...query,
    status: "analisado" as const,
    ultima_analise: new Date().toISOString()
  };

  // 1. Atualizar serp-query.json
  const queriesFile = path.join(baseDir, "serp-query.json");
  let queries: SerpQuery[] = [];
  if (fs.existsSync(queriesFile)) {
    try {
      queries = JSON.parse(fs.readFileSync(queriesFile, "utf-8"));
    } catch {
      queries = [];
    }
  }
  queries = queries.filter(q => q.id !== query.id);
  queries.push(queryWithTimestamp);
  fs.writeFileSync(queriesFile, JSON.stringify(queries, null, 2), "utf-8");

  // 2. Atualizar serp-results.json
  const resultsFile = path.join(baseDir, "serp-results.json");
  let allResults: SerpResult[] = [];
  if (fs.existsSync(resultsFile)) {
    try {
      allResults = JSON.parse(fs.readFileSync(resultsFile, "utf-8"));
    } catch {
      allResults = [];
    }
  }
  allResults = allResults.filter(r => r.queryId !== query.id);
  allResults.push(...results);
  fs.writeFileSync(resultsFile, JSON.stringify(allResults, null, 2), "utf-8");

  // 3. Atualizar serp-features.json
  const featuresFile = path.join(baseDir, "serp-features.json");
  let allFeatures: SerpFeatures[] = [];
  if (fs.existsSync(featuresFile)) {
    try {
      allFeatures = JSON.parse(fs.readFileSync(featuresFile, "utf-8"));
    } catch {
      allFeatures = [];
    }
  }
  allFeatures = allFeatures.filter(f => f.queryId !== query.id);
  allFeatures.push(features);
  fs.writeFileSync(featuresFile, JSON.stringify(allFeatures, null, 2), "utf-8");

  // 4. Atualizar content-patterns.json
  const patternsFile = path.join(baseDir, "content-patterns.json");
  let allPatterns: ContentPatterns[] = [];
  if (fs.existsSync(patternsFile)) {
    try {
      allPatterns = JSON.parse(fs.readFileSync(patternsFile, "utf-8"));
    } catch {
      allPatterns = [];
    }
  }
  allPatterns = allPatterns.filter(p => p.queryId !== query.id);
  allPatterns.push(patterns);
  fs.writeFileSync(patternsFile, JSON.stringify(allPatterns, null, 2), "utf-8");

  // 5. Atualizar search-intent.json
  const intentFile = path.join(baseDir, "search-intent.json");
  let allIntents: SearchIntent[] = [];
  if (fs.existsSync(intentFile)) {
    try {
      allIntents = JSON.parse(fs.readFileSync(intentFile, "utf-8"));
    } catch {
      allIntents = [];
    }
  }
  allIntents = allIntents.filter(i => i.queryId !== query.id);
  allIntents.push(intent);
  fs.writeFileSync(intentFile, JSON.stringify(allIntents, null, 2), "utf-8");

  return { success: true, queryId: query.id };
}

/**
 * Salva um snapshot HTML bruto da consulta para fins de histórico e auditoria
 */
export function saveSnapshot(queryId: string, queryText: string, htmlContent: string): string {
  const snapshotsDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "serp", "snapshots");

  if (!fs.existsSync(snapshotsDir)) {
    fs.mkdirSync(snapshotsDir, { recursive: true });
  }

  const safeQuery = queryText.toLowerCase().replace(/[^a-z0-9]/g, "-").replace(/-+/g, "-");
  const filename = `${queryId}-${safeQuery}-${Date.now()}.html`;
  const filePath = path.join(snapshotsDir, filename);

  fs.writeFileSync(filePath, htmlContent, "utf-8");
  return filename;
}

/**
 * Registra uma oportunidade identificada de SERP
 */
export function registerOpportunity(opportunity: SerpOpportunity) {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "serp");
  const oppsFile = path.join(baseDir, "serp-opportunities.json");

  if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true });
  }

  let opportunities: SerpOpportunity[] = [];
  if (fs.existsSync(oppsFile)) {
    try {
      opportunities = JSON.parse(fs.readFileSync(oppsFile, "utf-8"));
    } catch {
      opportunities = [];
    }
  }

  opportunities = opportunities.filter(o => o.id !== opportunity.id);
  opportunities.push(opportunity);
  fs.writeFileSync(oppsFile, JSON.stringify(opportunities, null, 2), "utf-8");

  return { success: true, id: opportunity.id };
}

/**
 * Compara as mudanças de posição orgânica entre duas listas de resultados
 */
export interface RankChange {
  url: string;
  dominio: string;
  titulo: string;
  posicaoAntiga: number | null; // null se for entrada nova
  posicaoNova: number | null;   // null se saiu do top 10
  variacao: number | "nova_entrada" | "queda_total";
}

export function compareChanges(queryId: string, newResults: SerpResult[]): RankChange[] {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "serp");
  const resultsFile = path.join(baseDir, "serp-results.json");

  let oldResults: SerpResult[] = [];
  if (fs.existsSync(resultsFile)) {
    try {
      const allResults: SerpResult[] = JSON.parse(fs.readFileSync(resultsFile, "utf-8"));
      oldResults = allResults.filter(r => r.queryId === queryId);
    } catch {
      oldResults = [];
    }
  }

  const oldMap = new Map<string, SerpResult>();
  oldResults.forEach(r => oldMap.set(r.url, r));

  const newMap = new Map<string, SerpResult>();
  newResults.forEach(r => newMap.set(r.url, r));

  const changes: RankChange[] = [];

  // 1. Analisar novas posições e movimentos
  newResults.forEach(nr => {
    const old = oldMap.get(nr.url);
    if (old) {
      const variation = old.posicao - nr.posicao; // positivo se subiu (ex: de 3 para 1 = +2)
      changes.push({
        url: nr.url,
        dominio: nr.dominio,
        titulo: nr.titulo,
        posicaoAntiga: old.posicao,
        posicaoNova: nr.posicao,
        variacao: variation
      });
    } else {
      changes.push({
        url: nr.url,
        dominio: nr.dominio,
        titulo: nr.titulo,
        posicaoAntiga: null,
        posicaoNova: nr.posicao,
        variacao: "nova_entrada"
      });
    }
  });

  // 2. Analisar saídas de classificação
  oldResults.forEach(or => {
    if (!newMap.has(or.url)) {
      changes.push({
        url: or.url,
        dominio: or.dominio,
        titulo: or.titulo,
        posicaoAntiga: or.posicao,
        posicaoNova: null,
        variacao: "queda_total"
      });
    }
  });

  // Ordenar por nova posição (colocando quedas totais no final)
  return changes.sort((a, b) => {
    if (a.posicaoNova === null) return 1;
    if (b.posicaoNova === null) return -1;
    return a.posicaoNova - b.posicaoNova;
  });
}
