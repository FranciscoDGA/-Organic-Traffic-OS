export interface Source {
  id: string;
  nome: string;
  tipo: string; // from source-types.json
  url: string;
  dominio: string;
  categoria: "Oficial" | "Imprensa" | "Acadêmico" | "Técnico" | "Outro" | string;
  idioma: string;
  pais: string;
  status: "ativo" | "indisponível" | "revisão" | string;
  ultima_verificacao: string;
  autoridade: number; // calculated 0-100
  observacoes: string;
}

export interface SourceType {
  nome: string;
  descricao: string;
  peso_base_autoridade: number;
}

export interface SourceHistoryEntry {
  id: string;
  sourceId: string;
  data: string;
  tipo_evento: "registro" | "atualizacao" | "falha" | "inatividade" | "alteracao_url" | string;
  detalhes: string;
  autor: string;
}

export interface SourceRelation {
  id: string;
  sourceId: string;
  targetType: "fato" | "brief" | "blueprint" | "research-pack" | string;
  targetId: string;
  criado_em: string;
}

export interface SourceRule {
  id: string;
  regra: string;
  descricao: string;
  obrigatoria: boolean;
}

export interface SourceValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}
