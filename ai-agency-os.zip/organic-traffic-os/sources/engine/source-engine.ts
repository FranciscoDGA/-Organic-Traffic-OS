import { Source, SourceType } from "../models/source-models";

export class SourceEngine {
  /**
   * Dynamically calculates the 0-100 authority index score for a source
   * using the rules specified in authority-score.json and the baseline weights of source-types.json.
   */
  public static calculateAuthority(
    source: Partial<Source>,
    categories: SourceType[],
    scoreConfig: any
  ): number {
    // 1. Resolve base authority from type
    const sourceTypeName = source.tipo || "Site Oficial";
    const matchedType = categories.find(
      c => c.nome.toLowerCase() === sourceTypeName.toLowerCase()
    );
    let score = matchedType ? matchedType.peso_base_autoridade : 50;

    // 2. Domain check & bonifications
    const urlStr = source.url || "";
    try {
      if (urlStr) {
        const parsedUrl = new URL(urlStr);
        const host = parsedUrl.hostname.toLowerCase();

        // Check gov bonus
        if (host.endsWith(".gov.br") || host.endsWith(".gov")) {
          score += scoreConfig.bonificacoes?.dominio_gov || 15;
        }
        // Check edu bonus
        else if (host.endsWith(".edu.br") || host.endsWith(".edu") || host.includes("universidade") || host.includes("ufrj") || host.includes("usp")) {
          score += scoreConfig.bonificacoes?.dominio_edu || 10;
        }

        // HTTPS SSL check
        if (parsedUrl.protocol === "https:") {
          score += scoreConfig.bonificacoes?.certificado_seguro || 5;
        }
      }
    } catch (e) {
      // URL parsing failed or incomplete - no bonuses applied
    }

    // 3. Status/Stability penalties
    if (source.status === "indisponível") {
      score += scoreConfig.penalidades?.indisponibilidade_recorrente || -20;
    }
    if (source.status === "revisão") {
      score += -5; // custom soft warning penalty
    }

    // 4. Verification recency bonus
    if (source.ultima_verificacao) {
      const lastCheck = new Date(source.ultima_verificacao);
      const now = new Date();
      const diffMs = now.getTime() - lastCheck.getTime();
      const diffDays = diffMs / (1000 * 60 * 60 * 24);

      if (diffDays <= 7) {
        score += 5; // recent confirmation bonus
      } else if (diffDays > 90) {
        score -= 10; // stale verification penalty
      }
    }

    // 5. Hard clamp between 0 and 100
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  /**
   * Helper to extract clean domain from URL
   */
  public static extractDomain(url: string): string {
    try {
      if (!url) return "";
      const parsed = new URL(url);
      return parsed.hostname.replace("www.", "");
    } catch (err) {
      return "";
    }
  }
}
