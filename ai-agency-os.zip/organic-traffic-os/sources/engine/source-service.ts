import fs from "fs";
import path from "path";
import { Source, SourceType, SourceHistoryEntry, SourceRelation, SourceRule } from "../models/source-models";
import { SourceEngine } from "./source-engine";
import { SourceValidator } from "../validators/source-validator";

const SOURCES_PATH = path.join(process.cwd(), "organic-traffic-os", "sources", "library", "source.json");
const TYPES_PATH = path.join(process.cwd(), "organic-traffic-os", "sources", "categories", "source-types.json");
const RULES_PATH = path.join(process.cwd(), "organic-traffic-os", "sources", "rules", "source-rules.json");
const AUTHORITY_PATH = path.join(process.cwd(), "organic-traffic-os", "sources", "authority", "authority-score.json");
const HISTORY_PATH = path.join(process.cwd(), "organic-traffic-os", "sources", "history", "source-history.json");
const RELATIONS_PATH = path.join(process.cwd(), "organic-traffic-os", "sources", "library", "source-relations.json");

export class SourceService {
  // Utility loaders
  public static getAllSources(): Source[] {
    try {
      if (!fs.existsSync(SOURCES_PATH)) return [];
      return JSON.parse(fs.readFileSync(SOURCES_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  public static getCategories(): SourceType[] {
    try {
      if (!fs.existsSync(TYPES_PATH)) return [];
      return JSON.parse(fs.readFileSync(TYPES_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  public static getRules(): SourceRule[] {
    try {
      if (!fs.existsSync(RULES_PATH)) return [];
      return JSON.parse(fs.readFileSync(RULES_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  public static getAuthorityConfig(): any {
    try {
      if (!fs.existsSync(AUTHORITY_PATH)) return {};
      return JSON.parse(fs.readFileSync(AUTHORITY_PATH, "utf-8"));
    } catch (e) {
      return {};
    }
  }

  public static getAllHistory(): SourceHistoryEntry[] {
    try {
      if (!fs.existsSync(HISTORY_PATH)) return [];
      return JSON.parse(fs.readFileSync(HISTORY_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  public static getAllRelations(): SourceRelation[] {
    try {
      if (!fs.existsSync(RELATIONS_PATH)) return [];
      return JSON.parse(fs.readFileSync(RELATIONS_PATH, "utf-8"));
    } catch (e) {
      return [];
    }
  }

  // Core Service Functions
  public static getSource(id: string): Source | null {
    const sources = this.getAllSources();
    return sources.find(s => s.id === id) || null;
  }

  public static getSourcesByCategory(category: string): Source[] {
    const sources = this.getAllSources();
    return sources.filter(s => s.tipo.toLowerCase() === category.toLowerCase());
  }

  public static getSourcesByDomain(domain: string): Source[] {
    const sources = this.getAllSources();
    return sources.filter(s => s.dominio.toLowerCase().includes(domain.toLowerCase()));
  }

  public static getSourcesByMinAuthority(minAuth: number): Source[] {
    const sources = this.getAllSources();
    return sources.filter(s => s.autoridade >= minAuth);
  }

  /**
   * Register a brand new source
   */
  public static registerSource(sourceData: Partial<Source>, autor = "Sistema"): Source {
    const sources = this.getAllSources();
    const categories = this.getCategories();
    const authConfig = this.getAuthorityConfig();

    // Fill missing metadata fields
    const id = sourceData.id || `src-${Date.now().toString(36)}`;
    const nome = sourceData.nome || "Fonte não nomeada";
    const tipo = sourceData.tipo || "Site Oficial";
    const url = sourceData.url || "";
    const dominio = sourceData.dominio || SourceEngine.extractDomain(url);
    const categoria = sourceData.categoria || "Oficial";
    const idioma = sourceData.idioma || "pt-BR";
    const pais = sourceData.pais || "BR";
    const status = sourceData.status || "ativo";
    const ultima_verificacao = sourceData.ultima_verificacao || new Date().toISOString();
    const observacoes = sourceData.observacoes || "Registrado pelo módulo de fontes.";

    const tempSource: Source = {
      id,
      nome,
      tipo,
      url,
      dominio,
      categoria,
      idioma,
      pais,
      status,
      ultima_verificacao,
      autoridade: 50, // temporary placeholder
      observacoes
    };

    // Calculate actual authority rating
    tempSource.autoridade = SourceEngine.calculateAuthority(tempSource, categories, authConfig);

    // Validate the complete schema
    const validation = SourceValidator.validate(tempSource, sources);
    if (!validation.isValid) {
      throw new Error(`Validação de Fonte recusada: ${validation.errors.join(" | ")}`);
    }

    // Append source
    sources.push(tempSource);
    fs.writeFileSync(SOURCES_PATH, JSON.stringify(sources, null, 2), "utf-8");

    // Add to history log
    this.addHistoryLog(
      id,
      "registro",
      `Cadastrado com autoridade de nível ${tempSource.autoridade}% (${tempSource.tipo}).`,
      autor
    );

    return tempSource;
  }

  /**
   * Updates an existing source, calculating changes and appending versions in history logs
   */
  public static updateSource(id: string, updatedData: Partial<Source>, autor = "Admin", alteracao = ""): Source {
    const sources = this.getAllSources();
    const sourceIdx = sources.findIndex(s => s.id === id);
    if (sourceIdx === -1) {
      throw new Error(`Fonte com ID '${id}' não encontrada para alteração.`);
    }

    const previous = { ...sources[sourceIdx] };
    const merged: Source = {
      ...previous,
      ...updatedData,
      id // force immutable id
    };

    // Check if URL altered and clean domain
    if (updatedData.url && updatedData.url !== previous.url) {
      merged.dominio = SourceEngine.extractDomain(updatedData.url);
      this.addHistoryLog(
        id,
        "alteracao_url",
        `URL alterada de '${previous.url}' para '${updatedData.url}'.`,
        autor
      );
    }

    // Check status failures or inactivities
    if (updatedData.status && updatedData.status !== previous.status) {
      if (updatedData.status === "indisponível") {
        this.addHistoryLog(id, "inatividade", "Fonte marcada como indisponível/offline pelo monitor.", autor);
      } else if (updatedData.status === "revisão") {
        this.addHistoryLog(id, "alteracao", "Fonte encaminhada para processo de revisão normativa.", autor);
      }
    }

    // Recalculate authority
    const categories = this.getCategories();
    const authConfig = this.getAuthorityConfig();
    merged.autoridade = SourceEngine.calculateAuthority(merged, categories, authConfig);

    // Validate merged schema
    const validation = SourceValidator.validate(merged, sources);
    if (!validation.isValid) {
      throw new Error(`Edição de fonte inválida: ${validation.errors.join(" | ")}`);
    }

    // Save back to db
    sources[sourceIdx] = merged;
    fs.writeFileSync(SOURCES_PATH, JSON.stringify(sources, null, 2), "utf-8");

    // General change log
    this.addHistoryLog(
      id,
      "atualizacao",
      alteracao || `Atualização de propriedades técnicas. Autoridade recalculada: ${merged.autoridade}%.`,
      autor
    );

    return merged;
  }

  /**
   * Links a source to an entity (fact, briefing, outline, etc.)
   */
  public static createRelation(sourceId: string, targetType: string, targetId: string): SourceRelation {
    const sources = this.getAllSources();
    const exists = sources.some(s => s.id === sourceId);
    if (!exists) {
      throw new Error(`Impossível criar relação: Fonte '${sourceId}' não existe no acervo.`);
    }

    const relations = this.getAllRelations();
    
    // Check if duplicate relation
    const existingRel = relations.find(
      r => r.sourceId === sourceId && r.targetType === targetType && r.targetId === targetId
    );
    if (existingRel) {
      return existingRel;
    }

    const newRel: SourceRelation = {
      id: `rel-${Date.now().toString(36)}`,
      sourceId,
      targetType,
      targetId,
      criado_em: new Date().toISOString()
    };

    relations.push(newRel);
    fs.writeFileSync(RELATIONS_PATH, JSON.stringify(relations, null, 2), "utf-8");

    this.addHistoryLog(
      sourceId,
      "alteracao",
      `Criado vínculo relacional com entidade '${targetType}' com o ID '${targetId}'.`,
      "Sistema de Relações"
    );

    return newRel;
  }

  // Private logger helper
  private static addHistoryLog(sourceId: string, tipo_evento: string, detalhes: string, autor: string) {
    const histories = this.getAllHistory();
    const newEntry: SourceHistoryEntry = {
      id: `hist-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 4)}`,
      sourceId,
      data: new Date().toISOString(),
      tipo_evento,
      detalhes,
      autor
    };
    histories.push(newEntry);
    fs.writeFileSync(HISTORY_PATH, JSON.stringify(histories, null, 2), "utf-8");
  }
}
