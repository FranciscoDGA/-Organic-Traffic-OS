# Sprint 14 Summary — Source Intelligence Engine V1

## Objetivo Geral
Implementar o motor de inteligência responsável por registrar, auditar, classificar, ponderar e gerenciar a integridade de todas as fontes regulatórias e científicas que servem de fundamentação para os fatos técnicos descritos no **Organic Traffic OS**.

Nenhum artigo ou publicação poderá ser estruturado sem possuir um lastro comprovável em fontes ativas de alta autoridade indexadas nesta biblioteca.

---

## 📂 Arquitetura Física e Estrutura de Diretórios
O módulo foi acomodado de forma autônoma sob o diretório principal das fontes:

```text
organic-traffic-os/sources/
├── models/
│   └── source-models.ts          # Interfaces de tipagem estrita em TypeScript
├── engine/
│   ├── source-engine.ts          # Algoritmo de cálculo de autoridade e domínio
│   └── source-service.ts         # Métodos de escrita e leitura síncronos persistentes
├── categories/
│   └── source-types.json         # Classificações padrão de fontes com pesos iniciais
├── validators/
│   └── source-validator.ts       # Validador de esquemas e consistência estrita
├── authority/
│   └── authority-score.json      # Configurações de pesos, bônus e penalidades
├── history/
│   └── source-history.json       # Log de trilha de auditoria técnica (nunca deletado)
├── rules/
│   └── source-rules.json         # Regras operacionais e de integridade declaradas
└── reports/
    └── sprint-14-summary.md      # Este documento descritivo de entrega
```

---

## ⚖️ Algoritmo de Cálculo de Autoridade
A autoridade de uma fonte é expressa dinamicamente de **0 a 100%**, recalculada a cada alteração ou processo de monitoramento conforme os seguintes pesos declarados em `authority-score.json`:

1. **Peso Base por Tipo de Fonte (`source-types.json`)**:
   - `Lei` / `Diário Oficial`: **100%**
   - `Governo Federal` / `Tribunal`: **95% a 98%**
   - `Universidade` / `Artigo Científico`: **85%**
   - `Site Oficial`: **70%**
   - `Blog`: **40%**
   
2. **Bonificações por Sufixo de Domínio**:
   - Domínios governamentais (`.gov` / `.gov.br`): **+15%**
   - Domínios de educação/pesquisa (`.edu` / `.edu.br`): **+10%**
   - Protocolo de conexão seguro (`HTTPS`): **+5%**

3. **Penalidades por Indisponibilidade**:
   - Status de conexão inativo (`indisponível`): **-20%**
   - Verificação stale (mais de 90 dias sem monitorar): **-10%**

*Os valores finais são estritamente limitados no intervalo fechado de `[0, 100]`, arredondados para inteiros.*

---

## 🛡️ Regras de Integridade e Validação
As operações de alteração ou inserção chamam o `SourceValidator.validate()` que aplica as seguintes barreiras:
- **Prevenção de Duplicidade**: Nenhuma fonte nova pode ser cadastrada compartilhando uma URL exata pré-existente.
- **Formatação de URL**: O link fornecido deve passar por parser DNS/URI válido com protocolo HTTP ou HTTPS.
- **Rastreabilidade de Histórico**: Mudanças de URL, status ou notas operacionais geram obrigatoriamente um registro descritivo de histórico contendo o autor, data UTC e metadados anteriores para fins de auditoria.

---

## 🌐 Layout de Endpoints da API REST
As seguintes rotas Express foram acopladas ao servidor central de microsserviços (`/server.ts`), respondendo de forma segura tanto em `/api/organic-os/` quanto em `/organic-os/api/`:

| Método | Endpoint | Descrição |
| :--- | :--- | :--- |
| **GET** | `/api/organic-os/sources` | Retorna a lista de todas as fontes indexadas |
| **GET** | `/api/organic-os/sources/categories` | Retorna as classificações válidas e seus pesos base |
| **GET** | `/api/organic-os/sources/rules` | Retorna as regras de conformidade e prioridade de design |
| **GET** | `/api/organic-os/sources/history` | Retorna o log de histórico completo de auditorias |
| **GET** | `/api/organic-os/sources/relations` | Retorna os mapeamentos cruzados ativos com fatos e dossiês |
| **GET** | `/api/organic-os/sources/:id` | Busca metadados específicos de uma única fonte |
| **POST** | `/api/organic-os/sources` | Registra e valida uma nova fonte, computando autoridade |
| **POST** | `/api/organic-os/sources/:id/update` | Atualiza propriedades, dispara o validador e gera histórico |
| **POST** | `/api/organic-os/sources/relations/create` | Vincula uma fonte a uma entidade (fato, brief, pack, etc.) |

---

## 🎨 Funcionalidades do Painel na Interface (`OrganicSources.tsx`)
A nova guia visual foi adicionada na navegação central do sistema, oferecendo um console administrativo altamente interativo:
- **Métricas Globais**: Apresenta contadores em tempo real de fontes, média ponderada de autoridade de todo o ecossistema, quantidade de links ativos e inativos.
- **Filtros e Controles**: Caixa de pesquisa instantânea por nome/URL, seletor de classificação documental, status operacional e slider deslizante de nível de autoridade.
- **Auditoria "Live"**: Analisador estático que destaca alertas ou advertências para a fonte selecionada de forma amigável no frontend.
- **Gerador de Vínculos**: Formulário dinâmico para associar a fonte a fatos existentes, gerando a rastreabilidade em tempo real de toda a base científica.
- **Audit Log Trail**: Timeline com scroll lateral/vertical expondo toda a sequência de vida do registro para total transparência de governança de conteúdo.
