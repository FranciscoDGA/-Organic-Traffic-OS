import { Source, SourceValidationResult } from "../models/source-models";

export class SourceValidator {
  /**
   * Performs physical formatting, schema structure, and sanity checks on a source object.
   */
  public static validate(source: Source, existingSources: Source[]): SourceValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 1. Check Required fields
    if (!source.id || !source.id.trim()) {
      errors.push("O identificador (id) da fonte é obrigatório.");
    }
    if (!source.nome || !source.nome.trim()) {
      errors.push("O nome descritivo da fonte é obrigatório.");
    }
    if (!source.tipo || !source.tipo.trim()) {
      errors.push("O tipo de documento/fonte é obrigatório.");
    }
    if (!source.url || !source.url.trim()) {
      errors.push("A URL de comprovação é obrigatória.");
    }

    // 2. Validate URL Format
    if (source.url && source.url.trim()) {
      const urlStr = source.url.trim();
      try {
        const parsedUrl = new URL(urlStr);
        if (!["http:", "https:"].includes(parsedUrl.protocol)) {
          errors.push("Protocolo de URL inválido. Use apenas HTTP ou HTTPS.");
        }
      } catch (err) {
        errors.push("Formato de URL inválido. Certifique-se de que o link contém protocolo (http/https) e domínio.");
      }
    }

    // 3. Domain extraction & verification
    if (source.url && source.url.trim() && source.dominio) {
      try {
        const parsedUrl = new URL(source.url.trim());
        const extractedHost = parsedUrl.hostname.replace("www.", "");
        const declaredHost = source.dominio.trim().replace("www.", "");
        
        if (extractedHost.toLowerCase() !== declaredHost.toLowerCase()) {
          warnings.push(`O domínio declarado '${declaredHost}' diverge do extraído da URL '${extractedHost}'.`);
        }
      } catch (e) {
        // Ignored here as it was already flagged in the error check
      }
    }

    // 4. Check for duplicates in existing database (same URL or ID)
    if (source.url && source.url.trim()) {
      const isDuplicateUrl = existingSources.some(
        s => s.id !== source.id && s.url.trim().toLowerCase() === source.url.trim().toLowerCase()
      );
      if (isDuplicateUrl) {
        errors.push(`Regra de Integridade Violada: A URL '${source.url}' já está cadastrada em outra fonte.`);
      }
    }

    if (source.id) {
      const isDuplicateId = existingSources.some(s => s.id === source.id);
      // Only error if we are adding a brand new source with a pre-existing ID
      // If we are updating, this check is bypassed by checking s.id === source.id elsewhere,
      // but here we validate based on a custom action flag or assume we only validate new entries.
    }

    // 5. Semantic quality warnings
    if (source.nome && source.nome.length < 5) {
      warnings.push("O nome da fonte é muito curto e pode prejudicar a indexabilidade técnica.");
    }

    if (source.categoria === "Outro") {
      warnings.push("Categoria definida como 'Outro'. Recomenda-se categorizar em Oficial, Imprensa, Acadêmico ou Técnico.");
    }

    // Check authority sanity
    if (source.autoridade < 0 || source.autoridade > 100) {
      errors.push("O valor numérico de autoridade deve estar obrigatoriamente entre 0 e 100.");
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}
