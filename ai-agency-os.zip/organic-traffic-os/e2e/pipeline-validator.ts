import fs from "fs";
import path from "path";

export interface StageReport {
  stage: string;
  tiempo_ms: number;
  entrada: any;
  saida: any;
  erros: string[];
  warnings: string[];
  resultado: "success" | "warning" | "failed";
}

export interface E2EExecutionReport {
  id: string;
  pipeline: string;
  tema: string;
  tempo_total_ms: number;
  status: "success" | "failed" | "warning";
  engines_executadas: string[];
  falhas: string[];
  avisos: string[];
  tokens: {
    entrada: number;
    saida: number;
    total: number;
  };
  provedores_utilizados: string[];
  health_score: {
    arquitetura: number;
    integracao: number;
    performance: number;
    confiabilidade: number;
    escalabilidade: number;
    geral: number;
  };
  quality_gate_passed: boolean;
}

export class PipelineValidator {
  /**
   * Validates all stages of an E2E pipeline run, checking dependencies, outputs, and versioning.
   */
  public static validate(stages: StageReport[], tema: string): {
    isValid: boolean;
    errors: string[];
    warnings: string[];
    outputChecks: Record<string, boolean>;
  } {
    const errors: string[] = [];
    const warnings: string[] = [];
    const outputChecks: Record<string, boolean> = {};

    const expectedStages = [
      "Knowledge Core", "Inventory", "Competitors", "SERP", "Keywords",
      "Opportunity", "Editorial Planner", "Brief", "Blueprint", "Research Pack",
      "Fact Engine", "Source Engine", "Strategy", "Draft Writer", "Quality Review",
      "Audience Adaptation", "Natural Language", "Visibility Optimization",
      "Asset Generation", "Publishing Package", "Performance Registration"
    ];

    // 1. Validate Stages Completion
    for (const expected of expectedStages) {
      const found = stages.find(s => s.stage === expected);
      if (!found) {
        errors.push(`Etapa crítica '${expected}' não foi executada no pipeline.`);
        outputChecks[expected] = false;
      } else {
        outputChecks[expected] = found.resultado !== "failed";
        if (found.resultado === "failed") {
          errors.push(`Etapa '${expected}' falhou com erros: ${found.erros.join("; ")}`);
        }
        if (found.warnings.length > 0) {
          warnings.push(`Aviso na etapa '${expected}': ${found.warnings.join("; ")}`);
        }
      }
    }

    // 2. Validate Step Dependencies & Inputs flowing to outputs
    const coreKnowledge = stages.find(s => s.stage === "Knowledge Core")?.saida;
    if (coreKnowledge && coreKnowledge.blog_id !== "passacumaru") {
      warnings.push("O Knowledge Core não está configurado para o blog padrão 'passacumaru'.");
    }

    // Opportunity dependency check
    const opportunityStage = stages.find(s => s.stage === "Opportunity");
    if (opportunityStage && opportunityStage.resultado !== "failed") {
      const ops = opportunityStage.saida;
      const targetOp = Array.isArray(ops) ? ops.find((o: any) => o.tema?.toLowerCase().includes(tema.toLowerCase()) || o.titulo?.toLowerCase().includes(tema.toLowerCase())) : null;
      if (!targetOp) {
        warnings.push(`Nenhuma oportunidade explícita com o tema '${tema}' foi detectada nos outputs do Opportunity Engine.`);
      }
    }

    // Brief dependency on Editorial Planner
    const briefStage = stages.find(s => s.stage === "Brief");
    const plannerStage = stages.find(s => s.stage === "Editorial Planner");
    if (briefStage && plannerStage) {
      const briefOutput = briefStage.saida;
      const plannerOutput = plannerStage.saida;
      if (briefOutput && plannerOutput) {
        const itemInPlanner = Array.isArray(plannerOutput) ? plannerOutput.find((p: any) => p.id === briefOutput.id?.replace("brief-", "")) : null;
        if (!itemInPlanner && briefStage.resultado !== "failed") {
          warnings.push("O brief gerado não possui correspondência direta no Editorial Planner.");
        }
      }
    }

    // Versioning Check
    stages.forEach(s => {
      const out = s.saida;
      if (out && typeof out === "object") {
        if ("versao" in out) {
          const v = out.versao;
          if (!v) {
            warnings.push(`O artefato de '${s.stage}' não possui versionamento explícito.`);
          }
        }
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      outputChecks
    };
  }

  /**
   * Calculates the Health Score based on five categories
   */
  public static calculateHealthScore(stages: StageReport[], validationErrors: string[], validationWarnings: string[]): E2EExecutionReport["health_score"] {
    const totalStages = stages.length;
    const failedStages = stages.filter(s => s.resultado === "failed").length;
    const warningStages = stages.filter(s => s.resultado === "warning").length;

    // 1. Arquitetura (Architecture)
    // Decreased by errors, failures, and structural warnings
    let arquitetura = 100 - (failedStages * 15) - (warningStages * 3) - (validationErrors.length * 10);
    arquitetura = Math.max(0, Math.min(100, arquitetura));

    // 2. Integração (Integration)
    // Check if stages outputs are populated and flowing
    let nullOutputs = 0;
    stages.forEach(s => {
      if (!s.saida || (typeof s.saida === "object" && Object.keys(s.saida).length === 0)) {
        nullOutputs++;
      }
    });
    let integracao = 100 - (nullOutputs * 10) - (validationWarnings.length * 2);
    integracao = Math.max(0, Math.min(100, integracao));

    // 3. Performance
    // Speed: We expect the whole local execution to be fast (mocking or light Gemini requests).
    // Let's analyze average speed per engine. Average speed < 200ms is excellent (local cache).
    const totalTime = stages.reduce((acc, s) => acc + s.tiempo_ms, 0);
    const avgTimePerStage = totalStages > 0 ? totalTime / totalStages : 0;
    let performance = 100;
    if (avgTimePerStage > 2000) {
      performance = 70;
    } else if (avgTimePerStage > 1000) {
      performance = 85;
    } else if (avgTimePerStage > 500) {
      performance = 92;
    }
    performance = Math.max(0, Math.min(100, performance));

    // 4. Confiabilidade (Reliability)
    // Based on failed runs or errors logged in stage reports
    let totalErrors = stages.reduce((acc, s) => acc + s.erros.length, 0);
    let confiabilidade = 100 - (totalErrors * 10) - (failedStages * 20);
    confiabilidade = Math.max(0, Math.min(100, confiabilidade));

    // 5. Escalonabilidade (Scalability)
    // Check if memory boundaries and token counts are reasonable
    let escalabilidade = 95; // base score
    const hasManyWarnings = validationWarnings.length > 10;
    if (hasManyWarnings) {
      escalabilidade -= 10;
    }
    escalabilidade = Math.max(0, Math.min(100, escalabilidade));

    // Geral (Weighted average)
    const geral = Math.round(
      arquitetura * 0.25 +
      integracao * 0.25 +
      performance * 0.15 +
      confiabilidade * 0.20 +
      escalabilidade * 0.15
    );

    return {
      arquitetura,
      integracao,
      performance,
      confiabilidade,
      escalabilidade,
      geral
    };
  }
}
