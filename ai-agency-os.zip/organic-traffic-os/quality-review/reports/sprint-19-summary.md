# Sprint 19 — Content Quality Review Engine V1

Este documento detalha o design do primeiro Agente Editorial responsável por auditar criticamente rascunhos de artigos gerados no ecossistema do Organic Traffic OS antes de permiti-los avançar para fases subsequentes de otimização de SEO ou distribuição.

---

## 1. Arquitetura do Motor

O Quality Review Engine reside sob a pasta `/organic-traffic-os/quality-review/` estruturado da seguinte forma:

- **`engine/`**: Núcleo computacional (`quality-review-engine.ts`) e o barramento operacional (`quality-service.ts`).
- **`rules/`**: Base declarativa de regras e restrições editoriais estritas (`quality-rules.json`).
- **`scores/`**: Atribuição de pesos e critérios das dimensões de pontuação (`quality-scores.json`).
- **`validators/`**: Mecanismos de validação programática de rascunhos em tempo real contra as dependências do OS (`quality-validator.ts`).
- **`reports/`**: Repositório persistente de auditoria contendo todos os laudos gerados (`quality-report.json`).

---

## 2. Critérios de Qualidade e Scores

Cada rascunho de artigo é submetido a um escaneamento multifatorial dividindo-se em 9 dimensões:

1. **Clareza Editorial (clareza - Peso 10%)**: Ritmo, legibilidade, tom científico palatável e ausência de jargão cru.
2. **Organização Estrutural (organizacao - Peso 10%)**: Presença física e ordenação geométrica correta de H1, H2, FAQ e CTA.
3. **Cobertura do Tema (cobertura_do_tema - Peso 15%)**: Nível de profundidade e exploração correta da temática do cluster.
4. **Aderência ao Briefing (aderencia_ao_brief - Peso 15%)**: Incorporação integral das orientações táticas e tese de marca.
5. **Aderência ao Blueprint (aderencia_ao_blueprint - Peso 15%)**: Preservação dos headings planejados topologicamente.
6. **Uso de Fatos (uso_correto_dos_fatos - Peso 10%)**: Cruzamento contra a Fact Checking Base para evitar fake news ou contradições.
7. **Uso de Fontes (uso_correto_das_fontes - Peso 10%)**: Menção e lastro em autoridades regulatórias ou científicas relevantes.
8. **Coerência Narrativa (coerencia_narrativa - Peso 10%)**: Transição lógica não repetitiva entre as ideias do texto.
9. **Utilidade para o Leitor (utilidade_para_o_leitor - Peso 5%)**: Capacidade imediata de orientar o leitor de forma acionável.

---

## 3. Fluxo de Revisão e Interpretação

O fluxo inicia-se no painel do editor:

```
Receber Draft
      ↓
Carregar Brief, Blueprint, Fatos, Fontes, Estratégia
      ↓
Validação de Regras Programáticas (Validator)
      ↓
Auditoria Profunda via Gemini 3.5 Flash ou Fallback
      ↓
Cálculo da Média Ponderada
      ↓
Aprovação Automática (Se Score Geral >= 75 E nenhuma regra Crítica falhar)
Ou Reprovação com Recomendações Estruturadas
```

### Como Interpretar os Scores:
- **Acima de 90**: Qualidade excepcional, pronto para publicação direta.
- **75 a 89**: Bom estado editorial. Pequenas melhorias recomendadas, porém estruturalmente aprovado.
- **Abaixo de 75**: Rascunho reprovado. Necessita de ajustes profundos para mitigar as falhas de regras clínicas ou estruturais relatadas nas Recomendações.
