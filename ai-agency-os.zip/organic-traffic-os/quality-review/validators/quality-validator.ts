import { DraftRecord } from "../../draft-writer/engine/draft-writer-engine";
import { ContentBlueprint } from "../../content-architecture/models/blueprint-models";
import { EditorialBrief } from "../../briefs/models/brief-models";

export interface QualityScores {
  clareza: number; // 0 - 100
  organizacao: number; // 0 - 100
  cobertura_do_tema: number; // 0 - 100
  aderencia_ao_brief: number; // 0 - 100
  aderencia_ao_blueprint: number; // 0 - 100
  uso_correto_dos_fatos: number; // 0 - 100
  uso_correto_das_fontes: number; // 0 - 100
  coerencia_narrativa: number; // 0 - 100
  utilidade_para_o_leitor: number; // 0 - 100
}

export interface RuleEvaluation {
  ruleId: string;
  nome: string;
  pass: boolean;
  feedback: string;
  severidade: string;
}

export interface QualityReport {
  id: string;
  draft_id: string;
  score_geral: number;
  status: "Aprovado" | "Reprovado" | "Pendente";
  observacoes: string;
  recomendacoes: string[];
  scores: QualityScores;
  regras_avaliadas: RuleEvaluation[];
  data: string;
}

export class QualityValidator {
  /**
   * Validates if a quality report is structurally complete and values are in bounds.
   */
  public static validateReport(report: QualityReport): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!report.id || report.id.trim() === "") {
      errors.push("O identificador do relatório ('id') é obrigatório.");
    }
    if (!report.draft_id || report.draft_id.trim() === "") {
      errors.push("O identificador do rascunho ('draft_id') é obrigatório.");
    }
    if (report.score_geral < 0 || report.score_geral > 100) {
      errors.push(`O score_geral (${report.score_geral}) deve estar contido na faixa de 0 a 100.`);
    }
    if (!["Aprovado", "Reprovado", "Pendente"].includes(report.status)) {
      errors.push(`O status do relatório ('${report.status}') é inválido.`);
    }
    if (!Array.isArray(report.recomendacoes)) {
      errors.push("O campo 'recomendacoes' deve ser uma lista de strings.");
    }

    const s = report.scores;
    if (!s) {
      errors.push("O bloco de pontuações de scores de qualidade ('scores') é obrigatório.");
    } else {
      const keys: (keyof QualityScores)[] = [
        "clareza",
        "organizacao",
        "cobertura_do_tema",
        "aderencia_ao_brief",
        "aderencia_ao_blueprint",
        "uso_correto_dos_fatos",
        "uso_correto_das_fontes",
        "coerencia_narrativa",
        "utilidade_para_o_leitor"
      ];
      keys.forEach(k => {
        if (typeof s[k] !== "number" || s[k] < 0 || s[k] > 100) {
          errors.push(`A métrica '${k}' (${s[k]}) deve ser um valor numérico entre 0 e 100.`);
        }
      });
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Helper to perform programmatic evaluations of standard rules on raw draft text.
   */
  public static evaluateProgrammaticRules(
    draft: DraftRecord,
    brief: EditorialBrief | null,
    blueprint: ContentBlueprint | null,
    facts: any[],
    sources: any[]
  ): RuleEvaluation[] {
    const evals: RuleEvaluation[] = [];
    const textLower = JSON.stringify(draft.conteudo).toLowerCase();

    // RULE-001: Todo H2 deve responder uma intenção.
    let r1Pass = true;
    let r1Feedback = "Todos os H2 analisados respondem a intenções de busca mapeadas.";
    if (!draft.conteudo.h2 || draft.conteudo.h2.trim().length < 20) {
      r1Pass = false;
      r1Feedback = "O conteúdo do H2 é excessivamente curto para responder satisfatoriamente a uma intenção de busca complexa.";
    }
    evals.push({
      ruleId: "RULE-001",
      nome: "Intenção de Busca no H2",
      pass: r1Pass,
      feedback: r1Feedback,
      severidade: "Alta"
    });

    // RULE-002: Nenhum tópico obrigatório pode faltar.
    let r2Pass = true;
    let r2Feedback = "Todos os tópicos estruturais obrigatórios definidos estão presentes.";
    const requiredKeys = ["h1", "introducao", "h2", "faq", "conclusao", "cta"];
    const missingKeys = requiredKeys.filter(k => !draft.conteudo[k as keyof typeof draft.conteudo]);
    if (missingKeys.length > 0) {
      r2Pass = false;
      r2Feedback = `Faltam seções obrigatórias no rascunho: ${missingKeys.join(", ")}.`;
    }
    evals.push({
      ruleId: "RULE-002",
      nome: "Cobertura de Tópicos do Briefing",
      pass: r2Pass,
      feedback: r2Feedback,
      severidade: "Critica"
    });

    // RULE-003: Todas as entidades obrigatórias devem aparecer.
    let r3Pass = true;
    let r3Feedback = "Mais de 70% das entidades recomendadas ou obrigatórias foram localizadas no texto.";
    let missingEntities: string[] = [];
    if (brief && brief.entities && brief.entities.entidades_obrigatorias) {
      const required = brief.entities.entidades_obrigatorias;
      missingEntities = required.filter(ent => !textLower.includes(ent.toLowerCase()));
      if (missingEntities.length > 0 && missingEntities.length / required.length > 0.3) {
        r3Pass = false;
        r3Feedback = `Entidades fundamentais ausentes: ${missingEntities.slice(0, 3).join(", ")}.`;
      }
    }
    evals.push({
      ruleId: "RULE-003",
      nome: "Presença de Entidades Obrigatórias",
      pass: r3Pass,
      feedback: r3Feedback,
      severidade: "Alta"
    });

    // RULE-004: Nenhuma afirmação deve contradizer os fatos aprovados.
    let r4Pass = true;
    let r4Feedback = "O rascunho está em plena conformidade factual com a Fact Checking Base.";
    if (facts.length > 0) {
      // Look for negative modifiers or lack of facts coverage
      const hasFactualTokens = facts.slice(0, 3).some(f => {
        const keywords = f.descricao.toLowerCase().split(/\s+/).filter((w: string) => w.length > 5);
        return keywords.some((kw: string) => textLower.includes(kw));
      });
      if (!hasFactualTokens) {
        r4Pass = false;
        r4Feedback = "O rascunho não faz referência explícita aos fatos ou dados clínicos aprovados pela equipe científica.";
      }
    }
    evals.push({
      ruleId: "RULE-004",
      nome: "Sem Contradição de Fatos",
      pass: r4Pass,
      feedback: r4Feedback,
      severidade: "Critica"
    });

    // RULE-005: O CTA deve estar alinhado com a estratégia.
    let r5Pass = true;
    let r5Feedback = "O Call to Action (CTA) foi localizado e apresenta gatilhos verbais de alta conversão.";
    const ctaText = draft.conteudo.cta || "";
    const strongVerbs = ["inscreva-se", "demonstração", "agende", "clique", "descubra", "baixe", "acesse", "fale", "teste", "conheça", "solicite", "comece"];
    const hasActionVerb = strongVerbs.some(verb => ctaText.toLowerCase().includes(verb));
    if (ctaText.trim().length < 10 || !hasActionVerb) {
      r5Pass = false;
      r5Feedback = "O CTA está desalinhado com as regras de conversão (curto demais ou sem verbos de ação recomendados).";
    }
    evals.push({
      ruleId: "RULE-005",
      nome: "Alinhamento do CTA",
      pass: r5Pass,
      feedback: r5Feedback,
      severidade: "Media"
    });

    // RULE-007: Mapeamento Estrito do Blueprint
    let r7Pass = true;
    let r7Feedback = "A estrutura hierárquica do texto segue com precisão geométrica o Blueprint aprovado.";
    if (blueprint && blueprint.estrutura) {
      const matched = blueprint.estrutura.filter(sec => textLower.includes(sec.titulo.toLowerCase()));
      if (matched.length / blueprint.estrutura.length < 0.6) {
        r7Pass = false;
        r7Feedback = `Apenas ${matched.length} de ${blueprint.estrutura.length} seções físicas do Blueprint foram identificadas no rascunho.`;
      }
    }
    evals.push({
      ruleId: "RULE-007",
      nome: "Mapeamento Estrito do Blueprint",
      pass: r7Pass,
      feedback: r7Feedback,
      severidade: "Alta"
    });

    return evals;
  }
}
