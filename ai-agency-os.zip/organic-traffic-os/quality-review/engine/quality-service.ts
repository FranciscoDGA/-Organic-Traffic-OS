import { QualityReviewEngine } from "./quality-review-engine";
import { QualityReport, QualityScores } from "../validators/quality-validator";

export interface QualityComparison {
  report1: QualityReport;
  report2: QualityReport;
  differences: {
    score_geral: number;
    metrics: { [key in keyof QualityScores]: number };
  };
}

export class QualityService {
  /**
   * Reviews a draft and generates a new QualityReport.
   */
  public static async reviewDraft(draftId: string): Promise<QualityReport> {
    return await QualityReviewEngine.executeReview(draftId);
  }

  /**
   * Gets a quality report by its ID.
   */
  public static getReport(reportId: string): QualityReport | null {
    const list = QualityReviewEngine.getAllReports();
    return list.find(r => r.id === reportId) || null;
  }

  /**
   * Gets all quality reports.
   */
  public static getAllReports(): QualityReport[] {
    return QualityReviewEngine.getAllReports();
  }

  /**
   * Gets all quality reports associated with a specific draft.
   */
  public static getReportsByDraftId(draftId: string): QualityReport[] {
    const list = QualityReviewEngine.getAllReports();
    return list.filter(r => r.draft_id === draftId);
  }

  /**
   * Force approves a quality report and overrides its status.
   */
  public static approveReport(reportId: string): QualityReport {
    const report = this.getReport(reportId);
    if (!report) {
      throw new Error(`Relatório de qualidade com ID '${reportId}' não encontrado.`);
    }

    report.status = "Aprovado";
    report.observacoes = `${report.observacoes} [Aprovado Manualmente pelo Editor Sênior]`;
    QualityReviewEngine.saveReportRecord(report);
    return report;
  }

  /**
   * Requests revision for a quality report, setting status to Reprovado and adding specific feedback notes.
   */
  public static requestRevision(reportId: string, guidance: string): QualityReport {
    const report = this.getReport(reportId);
    if (!report) {
      throw new Error(`Relatório de qualidade com ID '${reportId}' não encontrado.`);
    }

    report.status = "Reprovado";
    if (guidance) {
      report.recomendacoes.unshift(`Feedback do Editor: ${guidance}`);
    }
    QualityReviewEngine.saveReportRecord(report);
    return report;
  }

  /**
   * Compares two quality reports to analyze quality progress over revisions.
   */
  public static compareReports(report1Id: string, report2Id: string): QualityComparison {
    const r1 = this.getReport(report1Id);
    const r2 = this.getReport(report2Id);

    if (!r1 || !r2) {
      throw new Error("Ambos os relatórios devem ser fornecidos e válidos para a comparação.");
    }

    const mDiff: { [key: string]: number } = {};
    const keys: (keyof QualityScores)[] = [
      "clareza",
      "organizacao",
      "cobertura_do_tema",
      "aderencia_ao_brief",
      "aderencia_ao_blueprint",
      "uso_correto_dos_fatos",
      "uso_correto_das_fontes",
      "coerencia_narrativa",
      "utilidade_para_o_leitor"
    ];

    keys.forEach(k => {
      mDiff[k] = r2.scores[k] - r1.scores[k];
    });

    return {
      report1: r1,
      report2: r2,
      differences: {
        score_geral: r2.score_geral - r1.score_geral,
        metrics: mDiff as { [key in keyof QualityScores]: number }
      }
    };
  }
}
