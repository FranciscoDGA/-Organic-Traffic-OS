import fs from "fs";
import path from "path";
import { validateCompetitors } from "./competitor-validator";

export interface ConsolidatedCompetitors {
  competitors: any[];
  profiles: any[];
  strategies: any[];
  swot: any[];
  opportunities: any[];
  metadata: {
    totalCompetitors: number;
    totalCategories: number;
    totalTypes: number;
    activeCount: number;
    inactiveCount: number;
    totalOpportunities: number;
    isValid: boolean;
    errors: string[];
    lastUpdated: string;
  };
}

export function loadCompetitors(): ConsolidatedCompetitors {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "competitors");

  const files = {
    competitors: "competitors.json",
    profiles: "competitor-profile.json",
    strategies: "content-strategy.json",
    swot: "strengths-weaknesses.json",
    opportunities: "opportunity-map.json"
  };

  let competitors: any[] = [];
  let profiles: any[] = [];
  let strategies: any[] = [];
  let swot: any[] = [];
  let opportunities: any[] = [];

  try {
    if (fs.existsSync(path.join(baseDir, files.competitors))) {
      competitors = JSON.parse(fs.readFileSync(path.join(baseDir, files.competitors), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.profiles))) {
      profiles = JSON.parse(fs.readFileSync(path.join(baseDir, files.profiles), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.strategies))) {
      strategies = JSON.parse(fs.readFileSync(path.join(baseDir, files.strategies), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.swot))) {
      swot = JSON.parse(fs.readFileSync(path.join(baseDir, files.swot), "utf-8"));
    }
    if (fs.existsSync(path.join(baseDir, files.opportunities))) {
      opportunities = JSON.parse(fs.readFileSync(path.join(baseDir, files.opportunities), "utf-8"));
    }
  } catch (err) {
    console.error("Error reading competitor files:", err);
  }

  // Run validation
  const validationResult = validateCompetitors();

  // Aggregate metadata calculations
  const categoriesSet = new Set<string>();
  const typesSet = new Set<string>();
  let activeCount = 0;
  let inactiveCount = 0;

  competitors.forEach((c: any) => {
    if (c.categoria) categoriesSet.add(c.categoria);
    if (c.tipo) typesSet.add(c.tipo);
    if (c.status === "ativo") activeCount++;
    else inactiveCount++;
  });

  return {
    competitors,
    profiles,
    strategies,
    swot,
    opportunities,
    metadata: {
      totalCompetitors: competitors.length,
      totalCategories: categoriesSet.size,
      totalTypes: typesSet.size,
      activeCount,
      inactiveCount,
      totalOpportunities: opportunities.length,
      isValid: validationResult.isValid,
      errors: validationResult.errors,
      lastUpdated: new Date().toISOString()
    }
  };
}
