import fs from "fs";
import path from "path";

export interface CompetitorsValidationReport {
  isValid: boolean;
  errors: string[];
  checkedFiles: string[];
}

export function validateCompetitors(): CompetitorsValidationReport {
  const baseDir = path.join(process.cwd(), "organic-traffic-os", "knowledge", "competitors");
  const errors: string[] = [];
  const checkedFiles: string[] = [];

  const requiredFiles = [
    "competitors.json",
    "competitor-profile.json",
    "content-strategy.json",
    "strengths-weaknesses.json",
    "opportunity-map.json"
  ];

  requiredFiles.forEach(filename => {
    const filePath = path.join(baseDir, filename);
    checkedFiles.push(filename);

    if (!fs.existsSync(filePath)) {
      errors.push(`Arquivo obrigatório ausente: ${filename}`);
      return;
    }

    try {
      const raw = fs.readFileSync(filePath, "utf-8");
      const parsed = JSON.parse(raw);

      if (!Array.isArray(parsed)) {
        errors.push(`O arquivo ${filename} deve ser um array JSON válido.`);
        return;
      }

      // Validar dados de competitors.json
      if (filename === "competitors.json") {
        const ids = new Set<string>();
        parsed.forEach((c: any, index) => {
          const missing: string[] = [];
          if (!c.id) missing.push("id");
          if (!c.nome) missing.push("nome");
          if (!c.dominio) missing.push("dominio");
          if (!c.categoria) missing.push("categoria");
          if (!c.tipo) missing.push("tipo");
          if (!c.status) missing.push("status");

          if (missing.length > 0) {
            errors.push(`competitors.json item no índice ${index} está ausente de campos cruciais: ${missing.join(", ")}`);
          }

          if (c.id) {
            if (ids.has(c.id)) {
              errors.push(`ID de concorrente duplicado detectado: ${c.id}`);
            }
            ids.add(c.id);
          }
        });
      }

      // Validar dados do perfil
      if (filename === "competitor-profile.json") {
        parsed.forEach((p: any, index) => {
          if (!p.id) {
            errors.push(`competitor-profile.json item no índice ${index} está sem o identificador 'id'`);
          }
        });
      }

      // Validar dados da estratégia
      if (filename === "content-strategy.json") {
        parsed.forEach((s: any, index) => {
          if (!s.id) {
            errors.push(`content-strategy.json item no índice ${index} está sem o identificador 'id'`);
          }
        });
      }

    } catch (err: any) {
      errors.push(`Falha de parser de JSON no arquivo ${filename}: ${err.message || err}`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    checkedFiles
  };
}
