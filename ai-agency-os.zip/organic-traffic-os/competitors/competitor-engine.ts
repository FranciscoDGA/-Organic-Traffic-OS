import fs from "fs";
import path from "path";

export interface Competitor {
  id: string;
  nome: string;
  dominio: string;
  categoria: string;
  descricao: string;
  publico: string;
  cidade: string;
  estado: string;
  pais: string;
  tipo: string;
  status: "ativo" | "inativo";
  observacoes: string;
}

export interface CompetitorProfile {
  id: string;
  autoridade_percebida: string;
  especialidades: string[];
  formato_conteudo: string[];
  tom_de_voz: string;
  qualidade_visual: string;
  nivel_tecnico: string;
  monetiza_com: string[];
  produtos: string[];
  serviços: string[];
  redes_sociais: Record<string, string>;
  canal_youtube: string;
  newsletter: string;
  observacoes: string;
}

export interface ContentStrategy {
  id: string;
  categorias_trabalhadas: string[];
  frequencia_publicacao: string;
  tipos_de_conteudo: string[];
  uso_de_faq: string;
  uso_de_tabelas: string;
  uso_de_imagens: string;
  uso_de_videos: string;
  uso_de_ebooks: string;
  uso_de_simulados: string;
  uso_de_cta: string;
}

export interface SWOT {
  id: string;
  pontos_fortes: string[];
  pontos_fracos: string[];
  oportunidades: string[];
  ameacas: string[];
  observacoes: string;
}

export interface Opportunity {
  tema: string;
  concorrentes_que_cobrem: string[];
  passacumaru_cobre: boolean;
  prioridade: "Baixa" | "Média" | "Alta" | "Crítica";
  potencial: "Baixo" | "Médio" | "Alto" | "Explosivo";
  observações: string;
}

export function registerCompetitor(
  competitor: Competitor,
  profile: CompetitorProfile,
  strategy: ContentStrategy,
  swot: SWOT
) {
  const compPath = path.join(process.cwd(), "organic-traffic-os", "knowledge", "competitors");

  if (!fs.existsSync(compPath)) {
    fs.mkdirSync(compPath, { recursive: true });
  }

  // 1. Update competitors.json
  const compsFile = path.join(compPath, "competitors.json");
  let competitors: Competitor[] = [];
  if (fs.existsSync(compsFile)) {
    try {
      competitors = JSON.parse(fs.readFileSync(compsFile, "utf-8"));
    } catch (e) {
      competitors = [];
    }
  }
  competitors = competitors.filter(c => c.id !== competitor.id);
  competitors.push(competitor);
  fs.writeFileSync(compsFile, JSON.stringify(competitors, null, 2), "utf-8");

  // 2. Update competitor-profile.json
  const profsFile = path.join(compPath, "competitor-profile.json");
  let profiles: CompetitorProfile[] = [];
  if (fs.existsSync(profsFile)) {
    try {
      profiles = JSON.parse(fs.readFileSync(profsFile, "utf-8"));
    } catch (e) {
      profiles = [];
    }
  }
  profiles = profiles.filter(p => p.id !== profile.id);
  profiles.push(profile);
  fs.writeFileSync(profsFile, JSON.stringify(profiles, null, 2), "utf-8");

  // 3. Update content-strategy.json
  const stratFile = path.join(compPath, "content-strategy.json");
  let strategies: ContentStrategy[] = [];
  if (fs.existsSync(stratFile)) {
    try {
      strategies = JSON.parse(fs.readFileSync(stratFile, "utf-8"));
    } catch (e) {
      strategies = [];
    }
  }
  strategies = strategies.filter(s => s.id !== strategy.id);
  strategies.push(strategy);
  fs.writeFileSync(stratFile, JSON.stringify(strategies, null, 2), "utf-8");

  // 4. Update strengths-weaknesses.json
  const swotFile = path.join(compPath, "strengths-weaknesses.json");
  let swots: SWOT[] = [];
  if (fs.existsSync(swotFile)) {
    try {
      swots = JSON.parse(fs.readFileSync(swotFile, "utf-8"));
    } catch (e) {
      swots = [];
    }
  }
  swots = swots.filter(s => s.id !== swot.id);
  swots.push(swot);
  fs.writeFileSync(swotFile, JSON.stringify(swots, null, 2), "utf-8");

  return { success: true, id: competitor.id };
}
