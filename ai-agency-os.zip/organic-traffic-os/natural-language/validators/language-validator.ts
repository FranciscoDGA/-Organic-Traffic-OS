export interface LanguageValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  details: {
    structureIntact: boolean;
    factsPreserved: boolean;
    toneConsistent: boolean;
    ctaMaintained: boolean;
    statistics: {
      originalWordCount: number;
      refinedWordCount: number;
      wordCountDiff: number;
      originalParagraphs: number;
      refinedParagraphs: number;
    };
  };
}

export class LanguageValidator {
  /**
   * Realiza a validação estrita do texto refinado em relação ao original,
   * garantindo que nenhum fato, número ou estrutura essencial (como o CTA) foi violado.
   */
  public static validate(originalText: string, refinedText: string): LanguageValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!originalText || originalText.trim().length < 10) {
      errors.push("Texto original de rascunho inválido ou muito curto para validação.");
    }
    if (!refinedText || refinedText.trim().length < 10) {
      errors.push("Texto refinado inválido ou vazio.");
    }

    // 1. Extração de Números (Fatos, Datas, Valores, Estatutos) para garantir fidelidade
    const originalNumbers = (originalText.match(/\d+([.,]\d+)*/g) || []) as string[];
    const refinedNumbers = (refinedText.match(/\d+([.,]\d+)*/g) || []) as string[];

    // Validar se números importantes sumiram
    const missingNumbers = originalNumbers.filter(num => !refinedNumbers.includes(num));
    const uniqueMissingNumbers = Array.from(new Set(missingNumbers));

    let factsPreserved = true;
    if (uniqueMissingNumbers.length > 0) {
      // Se sumiu algum número, marcamos aviso ou erro conforme criticidade
      warnings.push(`Fatos numéricos potencialmente alterados. Os seguintes números presentes no rascunho original não foram localizados no texto refinado: ${uniqueMissingNumbers.join(", ")}`);
      if (uniqueMissingNumbers.length > 3) {
        factsPreserved = false;
        errors.push("Violação crítica de fidelidade de fatos: Muitos dados numéricos ou prazos foram removidos no refinamento.");
      }
    }

    // 2. Verificar presença de seções estruturais obrigatórias (FAQ, CTA, etc.)
    const originalHasFAQ = originalText.toLowerCase().includes("faq") || originalText.toLowerCase().includes("perguntas frequentes");
    const refinedHasFAQ = refinedText.toLowerCase().includes("faq") || refinedText.toLowerCase().includes("perguntas frequentes");

    let structureIntact = true;
    if (originalHasFAQ && !refinedHasFAQ) {
      structureIntact = false;
      errors.push("Estrutura corrompida: A seção de Perguntas Frequentes (FAQ) foi excluída do texto refinado.");
    }

    // 3. Garantir preservação do CTA (procurar termos comuns ou links de CTA)
    const originalHasCTA = originalText.toLowerCase().includes("cta") || originalText.toLowerCase().includes("chamada para ação") || originalText.toLowerCase().includes("inscreva-se") || originalText.toLowerCase().includes("acesse");
    const refinedHasCTA = refinedText.toLowerCase().includes("cta") || refinedText.toLowerCase().includes("chamada para ação") || refinedText.toLowerCase().includes("inscreva-se") || refinedText.toLowerCase().includes("acesse");

    let ctaMaintained = true;
    if (originalHasCTA && !refinedHasCTA) {
      ctaMaintained = false;
      warnings.push("Atenção: A Chamada para Ação (CTA) do rascunho pode ter perdido sua força ou marcações de link.");
    }

    // 4. Medir estatísticas de legibilidade e tamanho
    const originalWords = originalText.split(/\s+/).filter(Boolean);
    const refinedWords = refinedText.split(/\s+/).filter(Boolean);
    const origWordCount = originalWords.length;
    const refWordCount = refinedWords.length;

    const originalParagraphs = originalText.split(/\n+/).filter(p => p.trim().length > 0).length;
    const refinedParagraphs = refinedText.split(/\n+/).filter(p => p.trim().length > 0).length;

    // Se o texto encolheu ou cresceu demais, avisa
    const lengthDiffRatio = Math.abs(refWordCount - origWordCount) / (origWordCount || 1);
    if (lengthDiffRatio > 0.40) {
      warnings.push(`Variação de tamanho muito drástica (${Math.round(lengthDiffRatio * 100)}%). O refinamento de linguagem deve lapidar o ritmo sem alterar brutalmente a quantidade de informação.`);
    }

    // 5. Consistência do Tom de Voz (heurística)
    // Se o texto original continha expressões informais, o refinado não deve ficar árido e puramente técnico, e vice-versa.
    const technicalKeywords = ["jurisprudência", "erga omnes", "vício de iniciativa", "mandato de segurança", "autotutela"];
    const originalTechCount = technicalKeywords.filter(w => originalText.toLowerCase().includes(w)).length;
    const refinedTechCount = technicalKeywords.filter(w => refinedText.toLowerCase().includes(w)).length;

    let toneConsistent = true;
    if (originalTechCount > 0 && refinedTechCount === 0) {
      warnings.push("O nível técnico do texto caiu consideravelmente no refinamento. Verifique se os termos necessários foram mantidos.");
    }

    const valid = errors.length === 0;

    return {
      valid,
      errors,
      warnings,
      details: {
        structureIntact,
        factsPreserved,
        toneConsistent,
        ctaMaintained,
        statistics: {
          originalWordCount: origWordCount,
          refinedWordCount: refWordCount,
          wordCountDiff: refWordCount - origWordCount,
          originalParagraphs,
          refinedParagraphs
        }
      }
    };
  }
}
