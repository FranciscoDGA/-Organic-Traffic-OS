import * as fs from "fs";
import * as path from "path";
import { NaturalLanguageEngine, RefineReport } from "./natural-language-engine";

const REPORTS_PATH = path.join(process.cwd(), "organic-traffic-os/natural-language/reports/language-report.json");
const VERSIONS_PATH = path.join(process.cwd(), "organic-traffic-os/natural-language/versions/refined-versions.json");

export interface RefinedVersion {
  id: string; // Typically matches the report ID or a sequential identifier
  draft_id: string;
  original_title: string;
  original_content: string;
  refined_title: string;
  refined_content: string;
  autor: string;
  data: string;
}

export class LanguageService {
  /**
   * Obtém todos os relatórios de refinamento de linguagem.
   */
  public static getAllReports(): RefineReport[] {
    try {
      if (fs.existsSync(REPORTS_PATH)) {
        const fileContent = fs.readFileSync(REPORTS_PATH, "utf-8");
        return JSON.parse(fileContent) || [];
      }
    } catch (e) {
      console.error("Erro ao ler relatórios de linguagem:", e);
    }
    return [];
  }

  /**
   * Obtém um relatório de refinamento por ID.
   */
  public static getReportById(id: string): RefineReport | null {
    const reports = this.getAllReports();
    return reports.find(r => r.id === id) || null;
  }

  /**
   * Salva um relatório de refinamento.
   */
  public static saveReport(report: RefineReport): void {
    try {
      const reports = this.getAllReports();
      const index = reports.findIndex(r => r.id === report.id);
      if (index !== -1) {
        reports[index] = report;
      } else {
        reports.unshift(report);
      }
      fs.writeFileSync(REPORTS_PATH, JSON.stringify(reports, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar relatório de linguagem:", e);
    }
  }

  /**
   * Obtém todas as versões refinadas salvas.
   */
  public static getAllVersions(): RefinedVersion[] {
    try {
      if (fs.existsSync(VERSIONS_PATH)) {
        const fileContent = fs.readFileSync(VERSIONS_PATH, "utf-8");
        return JSON.parse(fileContent) || [];
      }
    } catch (e) {
      console.error("Erro ao obter versões de linguagem refinadas:", e);
    }
    return [];
  }

  /**
   * Salva uma versão refinada.
   */
  public static saveVersion(version: RefinedVersion): void {
    try {
      const versions = this.getAllVersions();
      const index = versions.findIndex(v => v.id === version.id);
      if (index !== -1) {
        versions[index] = version;
      } else {
        versions.unshift(version);
      }
      fs.writeFileSync(VERSIONS_PATH, JSON.stringify(versions, null, 2), "utf-8");
    } catch (e) {
      console.error("Erro ao salvar versão refinada:", e);
    }
  }

  /**
   * Realiza o refinamento de linguagem de um rascunho de artigo e salva os relatórios e as versões correspondentes.
   */
  public static async refineAndSave(
    draftId: string,
    title: string,
    content: string,
    qualityReportSummary?: string,
    audienceReportSummary?: string,
    strategyContext?: string,
    autor: string = "Diretor de Redação"
  ): Promise<RefineReport> {
    const report = await NaturalLanguageEngine.refineDraft(
      draftId,
      title,
      content,
      qualityReportSummary,
      audienceReportSummary,
      strategyContext
    );

    // Salvar o relatório
    this.saveReport(report);

    // Salvar a versão refinada
    const refinedVersion: RefinedVersion = {
      id: report.id,
      draft_id: draftId,
      original_title: title,
      original_content: content,
      refined_title: report.refined_title,
      refined_content: report.refined_content,
      autor,
      data: report.data
    };
    this.saveVersion(refinedVersion);

    return report;
  }

  /**
   * Compara duas versões ou relatórios de refinamento para demonstrar a evolução de notas e ritmo.
   */
  public static compareReports(report1Id: string, report2Id: string) {
    const r1 = this.getReportById(report1Id);
    const r2 = this.getReportById(report2Id);

    if (!r1 || !r2) {
      throw new Error("Um ou ambos os relatórios de linguagem não foram encontrados para comparação.");
    }

    const diffScore = r2.score_depois - r1.score_depois;
    const diffNaturalidade = r2.scores_detalhados.naturalidade - r1.scores_detalhados.naturalidade;
    const diffFluidez = r2.scores_detalhados.fluidez - r1.scores_detalhados.fluidez;

    const metricsDiff: Record<string, number> = {};
    const keys = Object.keys(r1.scores_detalhados) as Array<keyof typeof r1.scores_detalhados>;
    keys.forEach((key) => {
      metricsDiff[key] = (r2.scores_detalhados[key] || 0) - (r1.scores_detalhados[key] || 0);
    });

    return {
      report1: { id: r1.id, score_depois: r1.score_depois, status: r1.status, data: r1.data },
      report2: { id: r2.id, score_depois: r2.score_depois, status: r2.status, data: r2.data },
      differences: {
        score_geral: diffScore,
        naturalidade: diffNaturalidade,
        fluidez: diffFluidez,
        metrics: metricsDiff
      }
    };
  }
}
