# Sprint 21 — Natural Language Engine V1

## Objetivo do Motor
O **Natural Language Engine V1** é responsável por transformar rascunhos de artigos tecnicamente corretos em textos de alta fluidez, naturalidade, cadência e legibilidade para o leitor final. 

Este motor opera sobre premissas estritas de preservação editorial:
1. **Não alterar fatos**: Dados numéricos, nomes de leis, prazos ou estatísticas reais permanecem intactos.
2. **Não mudar a estratégia**: O posicionamento da palavra-chave, a intenção de busca e o foco do nicho são mantidos.
3. **Não alterar a estrutura**: Tópicos, seções e parágrafos estruturais não são omitidos ou inventados do zero.
4. **Preservar a Chamada para Ação (CTA)**: Links de conversão permanecem idênticos.

O único objetivo é **elevar exponencialmente a experiência de leitura**.

---

## Arquitetura e Estrutura de Arquivos

O ecossistema do Natural Language Engine está estruturado sob `/organic-traffic-os/natural-language/`:

```bash
organic-traffic-os/natural-language/
├── engine/
│   ├── natural-language-engine.ts  # Motor de processamento via Gemini ou Fallback local
│   └── language-service.ts          # Orquestrador de relatórios, persistência e comparação
├── rules/
│   ├── language-rules.json         # Diretrizes estritas de estilo editorial (repeticões, voz ativa, etc.)
│   └── language-score.json         # Dimensões e pesos para o cálculo de notas de naturalidade
├── patterns/
│   └── language-patterns.json      # Catálogo sintático humano (aberturas, transições recomendadas)
├── validators/
│   └── language-validator.ts       # Validador de conformidade e integridade dos dados originais
├── reports/
│   ├── language-report.json        # Banco de relatórios e laudos gerados
│   └── sprint-21-summary.md        # Esta documentação da Sprint
└── versions/
    └── refined-versions.json       # Armazenamento e versionamento dos textos polidos por rascunho
```

---

## Fluxo de Processamento

O ciclo de vida do refinamento segue o fluxo abaixo:

1. **Leitura e Unificação do Rascunho**:
   - Captura as seções (H1, introdução, H2, H3, FAQ, conclusão, CTA) do rascunho original.
2. **Coleta de Diagnósticos Editoriais**:
   - Agrega o relatório de qualidade da Sprint 19 (Quality Review).
   - Agrega o relatório de adaptação de público da Sprint 20 (Audience Adaptation).
   - Carrega o contexto do blog (Knowledge Core).
3. **Refinamento Inteligente (Gemini AI)**:
   - Limpeza de vícios de IA e conectivos estéreis (como "Em suma", "No dinâmico cenário de hoje").
   - Variação do tamanho das sentenças para conferir ritmo.
   - Substituição de termos excessivamente áridos ou repetitivos por sinônimos contextualizados.
4. **Validação de Salvaguarda (Language Validator)**:
   - Execução automática de testes de fidelidade lógica (checa se números, dados, FAQ e CTA foram preservados).
   - Emite avisos caso haja variação extrema de volumetria de palavras.
5. **Cálculo de Notas & Versionamento**:
   - Avaliação minuciosa de 6 dimensões (Naturalidade, Conexões, Flesch, Tom, Vocabulário, Experiência).
   - Salvamento do laudo estruturado e versionamento do artigo polido.

---

## Regras Editoriais (language-rules.json)
- **NAT-001 (Evitar repetição excessiva)**: Evita ecos de termos no mesmo parágrafo.
- **NAT-002 (Alternar tamanho das frases)**: Mescla frases curtas impactantes com períodos explicativos.
- **NAT-003 (Eliminar construções artificiais)**: Remove clichês mecânicos de escrita automática.
- **NAT-004 (Evitar excesso de voz passiva)**: Privilegia a dinâmica da voz ativa.
- **NAT-005 (Preservar fatos e estratégia)**: Salvaguarda dados numéricos de forma estrita.
- **NAT-006 (Preservar CTA e intenção)**: Mantém chamadas de fechamento intocadas.

---

## Versionamento
Cada refinamento gera um novo registro no catálogo de versões (`versions/refined-versions.json`), permitindo comparações dinâmicas "Antes vs Depois" e auditorias de evolução de legibilidade e estilo de redação ao longo das iterações do Organic Traffic OS.
