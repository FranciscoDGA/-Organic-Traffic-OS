import fs from "fs";
import path from "path";
import { ContentBlueprint } from "../models/blueprint-models";

const RULES_PATH = path.join(process.cwd(), "organic-traffic-os", "content-architecture", "templates", "content-rules.json");

interface ValidationRule {
  id: string;
  regra: string;
  seletor_tipo?: string;
  seletor_categoria?: string;
  componentes_obrigatorios: string[];
  descricao: string;
}

/**
 * Validates a Content Blueprint against architectural constraints, types, component compliance and categories.
 */
export function validateBlueprint(blueprint: ContentBlueprint): {
  isValid: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  // 1. Mandatory Fields
  if (!blueprint.id || blueprint.id === "blueprint-placeholder-id") {
    errors.push("ID do Blueprint é inválido.");
  }
  if (!blueprint.brief_id) {
    errors.push("Todo Blueprint precisa obrigatoriamente estar vinculado a um Briefing (brief_id ausente).");
  }
  if (!blueprint.titulo) {
    errors.push("Título recomendado do conteúdo é obrigatório.");
  }
  if (!blueprint.tipo_de_conteudo) {
    errors.push("Formato/Tipo de Conteúdo ideal não definido.");
  }

  // 2. Structural checks
  if (!blueprint.estrutura || blueprint.estrutura.length === 0) {
    errors.push("O Blueprint deve conter uma estrutura de tópicos sugerida.");
  } else {
    const hasH1 = blueprint.estrutura.some(s => s.secao.toUpperCase() === "H1");
    if (!hasH1) {
      errors.push("Estrutura do Blueprint não contém cabeçalho principal (H1).");
    }
    const h2Count = blueprint.estrutura.filter(s => s.secao.toUpperCase() === "H2").length;
    if (h2Count === 0) {
      warnings.push("É altamente recomendável incluir ao menos uma seção H2 na estrutura.");
    }
  }

  // 3. Components analysis
  const blueprintCompIds = (blueprint.componentes || []).map(c => c.id.toLowerCase().replace("comp-", ""));
  
  // Load templates rules for verification
  let rules: ValidationRule[] = [];
  if (fs.existsSync(RULES_PATH)) {
    try {
      rules = JSON.parse(fs.readFileSync(RULES_PATH, "utf-8"));
    } catch (e) {
      console.error("Erro ao ler regras de validação:", e);
    }
  }

  // 4. Rule-based evaluation
  const normalizedType = (blueprint.tipo_de_conteudo || "").toLowerCase().replace(/\s+/g, "_");
  const normalizedCategory = (blueprint.categoria || "").toLowerCase();

  rules.forEach(rule => {
    // Check if the rule is applicable to this content type
    const matchType = rule.seletor_tipo && normalizedType.includes(rule.seletor_tipo.toLowerCase());
    const matchCategory = rule.seletor_categoria && normalizedCategory.includes(rule.seletor_categoria.toLowerCase());

    if (matchType || matchCategory) {
      rule.componentes_obrigatorios.forEach(compName => {
        // verify if component is added and set as mandatory
        const isPresent = blueprint.componentes.some(
          c => c.nome.toLowerCase() === compName.toLowerCase() || c.id.toLowerCase().includes(compName.toLowerCase())
        );

        if (!isPresent) {
          errors.push(`Violação da regra [${rule.regra}]: O componente '${compName}' é obrigatório para este formato.`);
        } else {
          // verify if it is marked as obrigatório
          const activeComp = blueprint.componentes.find(
            c => c.nome.toLowerCase() === compName.toLowerCase() || c.id.toLowerCase().includes(compName.toLowerCase())
          );
          if (activeComp && !activeComp.obrigatorio) {
            warnings.push(`Componente '${compName}' recomendado como obrigatório pela regra [${rule.regra}], mas está marcado como opcional.`);
          }
        }
      });
    }
  });

  // 5. Size and Technical Level Warnings
  if (!blueprint.tamanho_estimado) {
    warnings.push("O tamanho estimado em palavras não foi especificado.");
  }
  if (!blueprint.nivel_tecnico) {
    warnings.push("O nível de profundidade técnica não foi especificado.");
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}
