import fs from "fs";
import path from "path";
import { ContentBlueprint, BlueprintVersion } from "../models/blueprint-models";
import { ContentArchitectEngine, calculateBlueprintScore } from "./content-architect-engine";
import { validateBlueprint } from "./architect-validator";

const STORE_DIR = path.join(process.cwd(), "organic-traffic-os", "content-architecture", "store");

function ensureStoreExists() {
  if (!fs.existsSync(STORE_DIR)) {
    fs.mkdirSync(STORE_DIR, { recursive: true });
  }
}

/**
 * Architect Service: Domain service for managing, loading, creating, saving and updating content blueprints.
 */
export class ArchitectService {

  /**
   * Generates a brand new blueprint from a Briefing ID, saving it to store.
   */
  public static async generateBlueprint(briefId: string, blogId: string = "passacumaru"): Promise<ContentBlueprint> {
    return ContentArchitectEngine.generateBlueprint(briefId, blogId);
  }

  /**
   * Fetches a specific content blueprint by its unique ID.
   */
  public static getBlueprint(id: string): ContentBlueprint | null {
    ensureStoreExists();
    const filePath = path.join(STORE_DIR, `${id}.json`);
    if (!fs.existsSync(filePath)) return null;

    try {
      const raw = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(raw);
    } catch (e) {
      console.error(`Erro ao carregar blueprint ${id}:`, e);
      return null;
    }
  }

  /**
   * Lists all existing blueprints currently in the store directory.
   */
  public static getAllBlueprints(): ContentBlueprint[] {
    ensureStoreExists();
    try {
      const files = fs.readdirSync(STORE_DIR).filter(f => f.endsWith(".json"));
      const blueprints: ContentBlueprint[] = [];
      files.forEach(f => {
        const raw = fs.readFileSync(path.join(STORE_DIR, f), "utf-8");
        try {
          blueprints.push(JSON.parse(raw));
        } catch (err) {
          console.error(`Erro ao parsear arquivo de blueprint ${f}:`, err);
        }
      });
      return blueprints.sort((a, b) => new Date(b.criado_em).getTime() - new Date(a.criado_em).getTime());
    } catch (e) {
      console.error("Erro ao listar blueprints:", e);
      return [];
    }
  }

  /**
   * Updates a blueprint, snapshotting the previous configuration into its history.
   */
  public static updateBlueprint(id: string, updatedData: Partial<ContentBlueprint>, autor: string = "Arquiteto Core"): ContentBlueprint {
    ensureStoreExists();
    const existing = this.getBlueprint(id);
    if (!existing) {
      throw new Error(`Blueprint com ID '${id}' não localizado para atualização.`);
    }

    // Capture snapshot for historical versioning
    const previousSnapshot = { ...existing };
    delete previousSnapshot.versions; // avoid nesting

    const currentVersionNum = existing.versao || 1;
    const newVersionNum = currentVersionNum + 1;

    const newVersionRecord: BlueprintVersion = {
      versao: currentVersionNum,
      data_snapshot: existing.atualizado_em || existing.criado_em,
      autor: existing.autor || "Sistema",
      mudancas: `Blueprint modificado. Versão promovida de v${currentVersionNum} para v${newVersionNum}.`,
      blueprint_snapshot: previousSnapshot
    };

    const merged: ContentBlueprint = {
      ...existing,
      ...updatedData,
      id: existing.id, // preserve ID
      brief_id: existing.brief_id, // preserve link
      versao: newVersionNum,
      autor,
      atualizado_em: new Date().toISOString(),
      versions: [...(existing.versions || []), newVersionRecord]
    };

    // Re-score
    merged.score = calculateBlueprintScore(merged);

    // Re-validate
    merged.audit = validateBlueprint(merged);

    const savePath = path.join(STORE_DIR, `${merged.id}.json`);
    fs.writeFileSync(savePath, JSON.stringify(merged, null, 2), "utf-8");

    return merged;
  }
}
