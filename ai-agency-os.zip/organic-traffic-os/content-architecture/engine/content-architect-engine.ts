import fs from "fs";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { ContentBlueprint, BlueprintComponent, BlueprintScore } from "../models/blueprint-models";
import { validateBlueprint } from "./architect-validator";

// Import brief loader/service
import { BriefLoader } from "../../briefs/brief-engine/brief-engine";
import { loadKnowledgeCore } from "../../knowledge/knowledge-loader";
import { loadInventory } from "../../inventory/inventory-loader";

const STORE_DIR = path.join(process.cwd(), "organic-traffic-os", "content-architecture", "store");
const TYPES_PATH = path.join(process.cwd(), "organic-traffic-os", "content-architecture", "templates", "content-types.json");
const COMPS_PATH = path.join(process.cwd(), "organic-traffic-os", "content-architecture", "templates", "content-components.json");

function ensureStoreExists() {
  if (!fs.existsSync(STORE_DIR)) {
    fs.mkdirSync(STORE_DIR, { recursive: true });
  }
}

/**
 * Calculates Blueprint Quality Score based on architectural design.
 */
export function calculateBlueprintScore(blueprint: Partial<ContentBlueprint>): BlueprintScore {
  // 1. Cobertura do tema
  let cobertura_tema = 0;
  if (blueprint.titulo) cobertura_tema += 20;
  if (blueprint.objetivo) cobertura_tema += 20;
  if (blueprint.estrutura && blueprint.estrutura.length >= 4) cobertura_tema += 60;
  else if (blueprint.estrutura && blueprint.estrutura.length >= 2) cobertura_tema += 40;
  else cobertura_tema += 10;

  // 2. Adequação à intenção de busca
  let adequacao_intencao = 85; // baseline
  const tipo = (blueprint.tipo_de_conteudo || "").toLowerCase();
  if (tipo.includes("pilar") || tipo.includes("guia")) {
    // pilares should have complex structural coverage
    if (blueprint.estrutura && blueprint.estrutura.length >= 5) adequacao_intencao = 95;
  }

  // 3. Potencial SEO
  let potencial_seo = 0;
  const struct = blueprint.estrutura || [];
  const hasH1 = struct.some(s => s.secao === "H1");
  const hasH2 = struct.some(s => s.secao === "H2");
  const hasH3 = struct.some(s => s.secao === "H3");
  if (hasH1) potencial_seo += 30;
  if (hasH2) potencial_seo += 40;
  if (hasH3) potencial_seo += 30;

  // 4. Experiência do usuário (UX)
  let experiencia_usuario = 0;
  const comps = blueprint.componentes || [];
  if (comps.length >= 4) experiencia_usuario = 100;
  else if (comps.length >= 2) experiencia_usuario = 80;
  else if (comps.length >= 1) experiencia_usuario = 50;
  else experiencia_usuario = 20;

  // 5. Complexidade (Estimativa de profundidade técnica)
  let complexidade = 50;
  if (blueprint.nivel_tecnico === "avançado") complexidade = 90;
  else if (blueprint.nivel_tecnico === "médio" || blueprint.nivel_tecnico === "intermediário") complexidade = 70;
  else complexidade = 40;

  // 6. Completude (Se obedece regras e audit)
  let completude = 0;
  if (blueprint.tipo_de_conteudo) completude += 30;
  if (blueprint.tamanho_estimado) completude += 30;
  if (blueprint.componentes && blueprint.componentes.some(c => c.obrigatorio)) completude += 40;

  // Weighted score according to blueprint-score.json
  const geral = Math.round(
    cobertura_tema * 0.20 +
    adequacao_intencao * 0.20 +
    potencial_seo * 0.20 +
    experiencia_usuario * 0.15 +
    complexidade * 0.10 +
    completude * 0.15
  );

  return {
    cobertura_tema,
    adequacao_intencao,
    potencial_seo,
    experiencia_usuario,
    complexidade,
    completude,
    geral
  };
}

/**
 * Main Engine class for analyzing brief, deciding optimal formats, components and outlines, and saving blueprints.
 */
export class ContentArchitectEngine {

  /**
   * Generates a complete editorial Content Blueprint based on an existing Briefing.
   */
  public static async generateBlueprint(briefId: string, blogId: string = "passacumaru"): Promise<ContentBlueprint> {
    ensureStoreExists();

    // 1. Load the Briefing
    const brief = BriefLoader.load(briefId);
    if (!brief) {
      throw new Error(`Briefing com ID '${briefId}' não foi localizado para gerar o blueprint.`);
    }

    // Load available types and components for templates
    let contentTypes: any[] = [];
    if (fs.existsSync(TYPES_PATH)) {
      try { contentTypes = JSON.parse(fs.readFileSync(TYPES_PATH, "utf-8")); } catch {}
    }

    let componentsList: any[] = [];
    if (fs.existsSync(COMPS_PATH)) {
      try { componentsList = JSON.parse(fs.readFileSync(COMPS_PATH, "utf-8")); } catch {}
    }

    const knowledge = loadKnowledgeCore(blogId);

    // Initial base blueprint object
    let blueprint: Partial<ContentBlueprint> = {
      id: `blueprint-${brief.id.replace("brief-", "")}`,
      brief_id: brief.id,
      titulo: brief.titulo,
      cluster: brief.cluster,
      categoria: brief.categoria,
      tipo_de_conteudo: "Guia Completo",
      objetivo: brief.objetivo || "Satisfazer a intenção de busca com máxima relevância e clareza.",
      status: "ready_for_writing",
      versao: 1,
      autor: "Content Architect Engine V1",
      criado_em: new Date().toISOString(),
      versions: []
    };

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } }
        });

        const prompt = `
          Você é o Arquiteto de Conteúdo Líder do Organic Traffic OS.
          Sua missão é projetar a Arquitetura Estrutural Perfeita (Blueprint) para um artigo de blog de altíssimo tráfego, baseado no briefing editorial fornecido.

          O objetivo desta etapa NÃO é escrever o artigo, mas sim planejar o formato ideal, as seções recomendadas e quais blocos e componentes interativos devem ser incluídos obrigatoriamente para reter o usuário e rankear no topo.

          DADOS DO BRIEFING:
          - Título: "${brief.titulo}"
          - Silo/Cluster Semântico: "${brief.cluster}"
          - Categoria: "${brief.categoria}"
          - Objetivo de Negócio: "${brief.objetivo}"
          - Intenção de Busca Principal: "${brief.search_intent?.intencao_principal || "Informativa"}"
          - Palavra-chave: "${brief.seo?.keyword_principal || brief.titulo}"
          - Tom de voz e público: "${brief.writing_guidelines?.tom || "Profissional"}, ${brief.writing_guidelines?.publico || "Geral"}"

          CATÁLOGO DE FORMATOS DISPONÍVEIS:
          ${JSON.stringify(contentTypes)}

          CATÁLOGO DE COMPONENTES INTERATIVOS DISPONÍVEIS:
          ${JSON.stringify(componentsList)}

          DIRETRIZES DE ARQUITETURA:
          1. Analise o título e selecione do catálogo o formato ideal (ex: se o título é sobre concursos, guias completos com tabelas ou tutoriais funcionam melhor).
          2. Desenhe uma estrutura sequencial recomendada (H1, H2, H3), fornecendo instruções precisas de redação para cada subtópico.
          3. Determine quais componentes interativos (ex: Tabela, FAQ, Checklist, CTA, etc.) devem ser acoplados a cada seção.
          4. Estime o tamanho ideal do texto em palavras e defina o nível de profundidade técnica exigida.

          Gere um objeto JSON completo respeitando a seguinte estrutura exata:
          {
            "tipo_de_conteudo": "Nome do Formato Ideal do catálogo",
            "objetivo": "Objetivo refinado de arquitetura para atender à intenção de busca principal",
            "tamanho_estimado": "e.g., 1800 - 2200 palavras",
            "nivel_tecnico": "e.g., iniciante, intermediário ou avançado",
            "estrutura": [
              {
                "secao": "H1",
                "titulo": "Título SEO H1 definitivo",
                "instrucoes_de_escrita": "Diretrizes sobre o que escrever aqui",
                "componentes_sugeridos": ["Breadcrumb"]
              },
              {
                "secao": "H2",
                "titulo": "Título do H2",
                "instrucoes_de_escrita": "Como redigir essa seção e o que ela deve cobrir em detalhes",
                "componentes_sugeridos": ["Tabela", "Resumo"]
              }
            ],
            "componentes": [
              {
                "id": "comp-id-do-componente-do-catalogo",
                "nome": "Nome do componente",
                "obrigatorio": true,
                "diretriz": "Instruções exclusivas do arquiteto para o redator de como popular esse componente."
              }
            ]
          }

          Retorne APENAS o JSON válido estruturado de acordo com essa especificação, sem textos explicativos ao redor.
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json"
          }
        });

        const text = response.text || "";
        const geminiResult = JSON.parse(text.trim());

        blueprint.tipo_de_conteudo = geminiResult.tipo_de_conteudo || blueprint.tipo_de_conteudo;
        blueprint.objetivo = geminiResult.objetivo || blueprint.objetivo;
        blueprint.tamanho_estimado = geminiResult.tamanho_estimado || "1500 - 2000 palavras";
        blueprint.nivel_tecnico = geminiResult.nivel_tecnico || "médio";
        blueprint.estrutura = geminiResult.estrutura || [];
        blueprint.componentes = geminiResult.componentes || [];

      } catch (geminiErr) {
        console.error("Erro na geração do Blueprint com Gemini, acionando fallback robusto:", geminiErr);
        this.applyProgrammaticBlueprint(blueprint, brief, contentTypes, componentsList);
      }
    } else {
      // Missing API key - programmatic fallback
      this.applyProgrammaticBlueprint(blueprint, brief, contentTypes, componentsList);
    }

    // Calculate score
    blueprint.score = calculateBlueprintScore(blueprint);

    // Validate blueprint
    const finalBlueprint = blueprint as ContentBlueprint;
    const audit = validateBlueprint(finalBlueprint);
    finalBlueprint.audit = audit;

    // Save blueprint to JSON store
    const savePath = path.join(STORE_DIR, `${finalBlueprint.id}.json`);
    fs.writeFileSync(savePath, JSON.stringify(finalBlueprint, null, 2), "utf-8");

    return finalBlueprint;
  }

  /**
   * Applies robust programmatic logic when Gemini API is unavailable or fails.
   */
  private static applyProgrammaticBlueprint(
    blueprint: Partial<ContentBlueprint>,
    brief: any,
    contentTypes: any[],
    componentsList: any[]
  ) {
    const titleLower = brief.titulo.toLowerCase();
    
    // Choose format
    let typeName = "Guia Completo";
    let recommendedComps: string[] = ["tabela", "faq", "cta"];

    if (titleLower.includes("simulado") || titleLower.includes("questões") || brief.tipo === "simulado") {
      typeName = "Simulado";
      recommendedComps = ["simulado", "quiz", "cta", "bloco_dicas"];
    } else if (titleLower.includes("como") || titleLower.includes("passo") || titleLower.includes("tutorial")) {
      typeName = "Tutorial";
      recommendedComps = ["linha_do_tempo", "checklist", "bloco_dicas", "cta"];
    } else if (titleLower.includes("comparativo") || titleLower.includes("versus") || titleLower.includes("vs")) {
      typeName = "Comparativo";
      recommendedComps = ["tabela", "cards", "resumo", "cta"];
    } else if (titleLower.includes("checklist") || titleLower.includes("requisitos")) {
      typeName = "Checklist";
      recommendedComps = ["checklist", "resumo", "download", "cta"];
    } else if (titleLower.includes("o que é") || titleLower.includes("significado") || titleLower.includes("glossario")) {
      typeName = "Glossário";
      recommendedComps = ["cards", "lista", "cta"];
    } else if (brief.tipo === "pilar") {
      typeName = "Artigo Pilar";
      recommendedComps = ["tabela", "resumo", "faq", "cards", "cta", "breadcrumb"];
    } else if (brief.tipo === "satelite") {
      typeName = "Artigo Satélite";
      recommendedComps = ["bloco_dicas", "faq", "cta"];
    }

    blueprint.tipo_de_conteudo = typeName;
    blueprint.tamanho_estimado = brief.writing_guidelines?.tamanho_esperado || "1500 - 2000 palavras";
    blueprint.nivel_tecnico = brief.writing_guidelines?.nivel_tecnico || "médio";

    // Build structural headings from briefing outline H2s
    const estrutura: any[] = [];
    estrutura.push({
      secao: "H1",
      titulo: brief.outline?.H1 || `Guia Completo: ${brief.titulo}`,
      instrucoes_de_escrita: brief.outline?.introducao || "Introduzir o tema de forma humanizada e empática, conectando com as maiores dores do público-alvo.",
      componentes_sugeridos: ["Breadcrumb"]
    });

    const briefSecoes = brief.outline?.secoes || [];
    if (briefSecoes.length > 0) {
      briefSecoes.forEach((sec: any) => {
        estrutura.push({
          secao: "H2",
          titulo: sec.titulo,
          instrucoes_de_escrita: sec.diretrizes || "Aprofundar os dados oficiais e estruturar de forma compreensível.",
          componentes_sugeridos: recommendedComps.slice(0, 2)
        });

        const subsecoes = sec.subsecoes || [];
        subsecoes.forEach((sub: any) => {
          estrutura.push({
            secao: "H3",
            titulo: sub.titulo,
            instrucoes_de_escrita: sub.diretrizes || "Detalhar de forma cirúrgica com exemplos e boas práticas.",
            componentes_sugeridos: ["Lista"]
          });
        });
      });
    } else {
      // Default structure fallback
      estrutura.push({
        secao: "H2",
        titulo: `Entendendo o Contexto de ${brief.titulo}`,
        instrucoes_de_escrita: "Apresentar os fundamentos práticos, dados oficiais do edital e panorama geral.",
        componentes_sugeridos: ["Resumo"]
      });
      estrutura.push({
        secao: "H2",
        titulo: `Requisitos e Regras Críticas de ${brief.titulo}`,
        instrucoes_de_escrita: "Explicar regras de isenção, requisitos dos cargos e documentação necessária.",
        componentes_sugeridos: ["Tabela"]
      });
    }

    // Add FAQ H2 and CTA
    estrutura.push({
      secao: "H2",
      titulo: `Dúvidas Frequentes sobre ${brief.titulo}`,
      instrucoes_de_escrita: "Exibir o bloco final com microdata estruturada de perguntas e respostas.",
      componentes_sugeridos: ["FAQ"]
    });

    blueprint.estrutura = estrutura;

    // Build components definitions
    const componentes: BlueprintComponent[] = [];
    recommendedComps.forEach(compKey => {
      const matched = componentsList.find(c => c.id === compKey);
      if (matched) {
        componentes.push({
          id: `comp-${matched.id}`,
          nome: matched.nome,
          obrigatorio: true,
          diretriz: matched.descricao + " Integrar de forma harmoniosa no layout."
        });
      }
    });

    // Ensure we have at least CTA
    if (!componentes.some(c => c.id === "comp-cta")) {
      componentes.push({
        id: "comp-cta",
        nome: "CTA",
        obrigatorio: true,
        diretriz: `Inserir banner de chamada de ação apontando para: ${brief.outline?.CTA || "Inscrever-se no Concurso!"}`
      });
    }

    blueprint.componentes = componentes;
  }
}
