export interface BlueprintComponent {
  id: string;
  nome: string; // e.g., Tabela, Lista, Checklist, FAQ, etc.
  obrigatorio: boolean;
  diretriz: string; // instructions on how to implement this component in the content
}

export interface ContentTypeInfo {
  id: string;
  nome: string; // e.g., Artigo Pilar, Artigo Satélite, Guia Completo, Tutorial, Checklist, etc.
  descricao: string;
  componentes_recomendados: string[];
}

export interface BlueprintScore {
  cobertura_tema: number; // 0-100
  adequacao_intencao: number; // 0-100
  potencial_seo: number; // 0-100
  experiencia_usuario: number; // 0-100
  complexidade: number; // 0-100
  completude: number; // 0-100
  geral: number; // weighted average
}

export interface BlueprintVersion {
  versao: number;
  data_snapshot: string;
  autor: string;
  mudancas: string;
  blueprint_snapshot: any;
}

export interface ContentBlueprint {
  id: string;
  brief_id: string;
  titulo: string;
  cluster: string;
  categoria: string;
  tipo_de_conteudo: string; // from content-types
  objetivo: string;
  estrutura: {
    secao: string; // e.g., H1, H2, H3
    titulo: string;
    instrucoes_de_escrita: string;
    componentes_sugeridos: string[];
  }[];
  componentes: BlueprintComponent[];
  tamanho_estimado: string; // e.g., "1500 - 2000 palavras"
  nivel_tecnico: string; // e.g., "iniciante", "intermediário", "avançado"
  status: "draft" | "ready_for_writing" | "completed" | "archived" | string;
  versao: number;
  autor: string;
  criado_em: string;
  atualizado_em?: string;
  score: BlueprintScore;
  audit: {
    isValid: boolean;
    errors: string[];
    warnings: string[];
  };
  versions?: BlueprintVersion[];
}
