# SPRINT 11 — CONTENT ARCHITECT ENGINE V1

## OBJETIVO
Construir o motor estrutural encarregado de definir a arquitetura ideal de cada conteúdo antes que qualquer processo de escrita ou geração de imagens ocorra. O objetivo é cruzar as intenções da SERP e do usuário para formatar a estrutura que oferece a maior probabilidade de rankeamento e satisfação do leitor.

---

## 🏗️ ARQUITETURA DO SISTEMA

O módulo está integrado ao caminho `/organic-traffic-os/content-architecture/` e é composto pelas seguintes camadas técnicas:

1. **`models/blueprint-models.ts`**: Define tipagens estritas em TypeScript para as entidades centrais (`ContentBlueprint`, `BlueprintComponent`, `BlueprintScore` e `BlueprintVersion`).
2. **`templates/`**:
   - `content-blueprint.json`: Protótipo estrutural padrão.
   - `content-types.json`: Cadastro formal de todos os formatos de conteúdo permitidos na plataforma.
   - `content-components.json`: Registro de componentes ricos para quebra de fadiga textual.
   - `content-rules.json`: Regras heurísticas de validação arquitetural e conformidade regulatória.
   - `blueprint-score.json`: Pesos e dimensões do score de qualidade do blueprint.
3. **`engine/content-architect-engine.ts`**: Núcleo da inteligência híbrida. Se a chave `GEMINI_API_KEY` estiver configurada, consome o modelo generativo avançado (`gemini-3.5-flash`) para cruzar os dados de concorrência e o Knowledge Core a fim de projetar o blueprint ideal. Caso contrário, aciona regras de mapeamento heurístico de alta fidelidade como fallback estruturado.
4. **`engine/architect-validator.ts`**: Mecanismo autônomo (Architect Validator) que analisa a completude estrutural de headings (H1, H2, H3), presença de componentes obrigatórios relativos às regras, e possíveis conflitos taxonômicos.
5. **`engine/architect-service.ts`**: Camada de serviço de domínio responsável por expor métodos seguros de geração, carregamento, atualização dinâmica e versionamento com snapshots de histórico completos.

---

## 📋 FORMATOS DE CONTEÚDO (Types)
Cadastramos e mapeamos os comportamentos dos seguintes formatos de alto rendimento:
- **Artigo Pilar**: Conteúdo central abrangente conectando subpáginas satélites.
- **Artigo Satélite**: Focado em responder micro-dúvidas de cauda longa com linkagem interna forte.
- **Guia Completo**: Manual de ponta a ponta detalhando processos exaustivamente.
- **Tutorial**: Instrução prática, didática e passo a passo.
- **Checklist**: Controle dinâmico interativo para conferência de conformidade.
- **FAQ**: Sessões de respostas diretas para conquista de rich snippets.
- **Glossário**: Definições técnicas oficiais de termos do ecossistema.
- **Comparativo**: Comparação lado a lado de benefícios, vagas ou carreiras.
- **Review**: Avaliação crítica imparcial de materiais de estudo.
- **Notícia**: Fatos rápidos e recentes com alta urgência temporal.
- **Página de Categoria**: Listas ordenadas facilitando a navegação interna e a indexação taxonômica.
- **Landing Informativa**: Foco de captação rico direcionado à conversão.

---

## 🧩 COMPONENTES INTERATIVOS (Components)
Mapeamos e disponibilizamos para o editor/redator os seguintes blocos construtivos:
- **Tabela**: Visão comparativa limpa e rápida de dados brutos.
- **Lista**: Listagem confortável de matérias ou etapas.
- **Checklist**: Lista com caixas interativas de marcação.
- **Linha do Tempo**: Eixo linear guiando cronogramas ou evolução temporal.
- **Resumo**: Caixa inicial destacando conclusões rápidas de leitura.
- **FAQ (Accordion)**: Sessão colapsável de perguntas e respostas com tags estruturadas FAQPage.
- **CTA (Call to Action)**: Banners persuasivos focados em download ou inscrições oficiais.
- **Blocos de Atenção & Dicas**: Destacadores visuais para urgências, retificações ou conselhos da redação.
- **Infográficos & Vídeos**: Blocos para mídias externas complementares.
- **Downloads, Calculadoras, Quizzes e Simulados**: Elementos sofisticados para engajamento e utilidade máxima.

---

## 🧠 FLUXO COMPLETO DE WORKFLOW EDITORIAIS (End-to-End)

O sistema opera no seguinte fluxo sequencial e unificado:

```
Knowledge Core (Diretrizes do Blog e Tom)
   ↓
Inventory Database (Evitar links internos órfãos ou duplicados)
   ↓
Competitors & SERP Intelligence (Mapeamento de intenções secundárias e FAQ reais)
   ↓
Keywords Clustering (Keywords principais e sinônimos complementares)
   ↓
Opportunity Engine (Descoberta e rankeamento de temas quentes)
   ↓
Editorial Planner (Planejamento de backlog de sprints de conteúdo)
   ↓
Brief Engine (Geração de pautas completas e metas do redator)
   ↓
Content Architect (Sprint 11 — Mapeamento do formato ideal, componentes e estrutura semântica)
   ↓
Futuro Agente Redator (Produção de texto fidedigno e hiper-otimizado)
```

---

## 📈 BLUEPRINT SCORE (Fórmula)
Para cada blueprint gerado, as métricas são calculadas nas seguintes dimensões de pesos:
- **Cobertura do Tema (20%)**: Valida profundidade estrutural frente ao cluster de origem.
- **Adequação à Intenção de Busca (20%)**: Se o formato escolhido se alinha com o comportamento de busca da SERP.
- **Potencial SEO (20%)**: Garantia de headings estruturados coerentemente.
- **Experiência do Usuário (15%)**: Variedade adequada de componentes ricos para mitigar fadiga ocular.
- **Nível de Complexidade (10%)**: Medidor de esforço técnico necessário.
- **Completude (15%)**: Grau de adequação às regras editoriais mínimas obrigatórias.
