# Layer 2 — Knowledge Guide

O **Knowledge Layer** organiza e provê bases factuais ou de indexação local para mitigar alucinações e alimentar as decisões das Engines.

## Como Adicionar um Novo Knowledge Provider

1. **Crie a Classe**:
   Crie um arquivo em `organic-traffic-os/core/knowledge/implementations/my-knowledge.ts` estendendo `KnowledgeProvider`:

   ```typescript
   import { KnowledgeProvider } from "../knowledge-provider";
   import { KnowledgeIndex } from "../knowledge-index";

   export class MyKnowledgeProvider extends KnowledgeProvider {
     readonly id = "kp-brand-guide";
     readonly name = "Brand Editorial Guidelines";
     readonly version = "1.0.0";

     async validate(): Promise<boolean> {
       // Verifique se os arquivos locais ou tabelas de regras estão acessíveis
       return true;
     }

     async getIndexes(): Promise<KnowledgeIndex[]> {
       return [
         {
           documentId: "brand-tone-doc",
           title: "Guia de Tom e Voz da Marca",
           summary: "Regras sobre como escrever artigos informativos de forma empática.",
           sourceType: "file",
           tags: ["brand", "tone", "editorial"],
           lastUpdated: new Date().toISOString()
         }
       ];
     }

     async resolve(query: string, limit = 5): Promise<any[]> {
       // Filtre localmente ou faça busca semântica em banco vetorial
       return [{ match: "Tom da marca deve ser formal e focado em clareza." }];
     }
   }
   ```

2. **Registre no Seed**:
   No arquivo `organic-traffic-os/core/seed.ts`, registre sua base:

   ```typescript
   import { KnowledgeRegistry } from "./knowledge/knowledge-registry";
   import { MyKnowledgeProvider } from "./knowledge/implementations/my-knowledge";

   KnowledgeRegistry.register(new MyKnowledgeProvider());
   ```
