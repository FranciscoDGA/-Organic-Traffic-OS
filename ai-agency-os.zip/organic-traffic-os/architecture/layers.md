# Mapeamento Detalhado das Camadas do Core

Este documento descreve as responsabilidades detalhadas e interações de cada um dos 5 layers do Organic Traffic OS.

---

## 1. Layer 1 — Connectors
- **Objetivo**: Abstrair integrações HTTP, RSS, SFTP e APIs externas.
- **Classes**: `BaseConnector`, `ConnectorRegistry`, `ConnectorManager`.
- **Contrato Obrigatório**:
  - `connect(): Promise<boolean>`
  - `validate(): Promise<boolean>`
  - `execute<T>(action: string, params?: Record<string, any>): Promise<ConnectorResult<T>>`
  - `normalize<T>(rawData: any): T`

---

## 2. Layer 2 — Knowledge
- **Objetivo**: Gestão de contexto local, editais, regras editoriais e base histórica.
- **Classes**: `KnowledgeProvider`, `KnowledgeRegistry`, `KnowledgeLoader`, `KnowledgeCache`.
- **Contrato Obrigatório**:
  - `load(context: KnowledgeContext): Promise<boolean>`
  - `validate(): Promise<boolean>`
  - `resolve(query: string, limit?: number): Promise<any[]>`

---

## 3. Layer 3 — Engines
- **Objetivo**: Inteligência analítica de dados e orquestração de chamadas ao Gemini.
- **Classes**: `BaseEngine`, `EngineRegistry`, `EngineManager`.
- **Contrato Obrigatório**:
  - `analyze<T>(input: string, options?: Record<string, any>): Promise<EngineResult<T>>`
  - `score(input: string, criteria?: Record<string, any>): Promise<number>`
  - `recommend<T>(input: string, options?: Record<string, any>): Promise<T[]>`

---

## 4. Layer 4 — Agents
- **Objetivo**: Execução de loops de trabalho baseados em personas (Auditor, Copywriter, Fact Checker).
- **Classes**: `BaseAgent`, `AgentRegistry`, `AgentManager`.
- **Contrato Obrigatório**:
  - `execute<T>(goal: string): Promise<AgentResult<T>>`
  - `validate(): Promise<boolean>`
  - `report<T>(result: AgentResult<T>): Promise<string>`

---

## 5. Layer 5 — Workflows
- **Objetivo**: Orquestrar a execução de ponta a ponta em etapas sequenciais com suporte a pausar, retomar e cancelar.
- **Classes**: `BaseWorkflow`, `WorkflowRegistry`, `WorkflowExecutor`, `WorkflowManager`.
- **Contrato Obrigatório**:
  - `execute(initialVariables: Record<string, any>): Promise<WorkflowResult>`
  - `pause(): Promise<boolean>`
  - `resume(): Promise<boolean>`
  - `cancel(): Promise<boolean>`
