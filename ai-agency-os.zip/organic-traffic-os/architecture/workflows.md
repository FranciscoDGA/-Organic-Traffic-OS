# Layer 5 — Workflows Guide

O **Workflows Layer** é o topo da arquitetura. Ele orquestra os agentes em passos sequenciais ou paralelos controlados por máquinas de estado complexas.

## Como Adicionar um Novo Workflow

1. **Crie a Classe**:
   Crie uma classe estendendo `BaseWorkflow`:

   ```typescript
   import { BaseWorkflow } from "../workflow-manager";
   import { WorkflowState } from "../workflow-state";
   import { WorkflowResult } from "../workflow-result";

   export class MySprintWorkflow extends BaseWorkflow {
     readonly id = "wf-sprint-production";
     readonly name = "Sprint Completa de Produção de Conteúdo";
     readonly version = "1.0.0";
     readonly steps = [
       "Pesquisa de Palavras-Chave",
       "Redação de Rascunho",
       "Revisão de Fatos",
       "Publicação e Indexação"
     ];

     async execute(initialVariables: Record<string, any> = {}): Promise<WorkflowResult> {
       const executionId = `exe-${Math.random().toString(36).substring(2, 11)}`;
       const state = await this.start(executionId, initialVariables);
       
       let failed = false;
       let errorMsg = "";
       
       // Execute sequentially
       for (let i = 0; i < this.steps.length; i++) {
         const stepRes = await this.runStep(i, state);
         if (!stepRes.success) {
           failed = true;
           errorMsg = stepRes.error || "Failed";
           break;
         }
         state.currentStepIndex = i + 1;
       }
       
       await this.complete(!failed, state.variables, failed ? errorMsg : undefined);
       
       return {
         success: !failed,
         executionId,
         output: state.variables,
         history: [],
         durationMs: 400
       };
     }

     async runStep(stepIndex: number, state: WorkflowState) {
       // Executa chamadas para Connectors, Engines ou Agentes do Core
       return { success: true };
     }
   }
   ```

2. **Registre no Seed**:
   No arquivo `organic-traffic-os/core/seed.ts`, registre seu workflow:

   ```typescript
   import { WorkflowRegistry } from "./workflows/workflow-registry";
   import { MySprintWorkflow } from "./workflows/implementations/my-sprint-wf";

   WorkflowRegistry.register(new MySprintWorkflow());
   ```
