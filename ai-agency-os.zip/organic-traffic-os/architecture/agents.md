# Layer 4 — Agents Guide

O **Agents Layer** modela entidades de loop cognitivo contendo persona, tom de voz, metas e memória persistente em nível operacional.

## Como Adicionar um Novo Agent

1. **Crie a Classe**:
   Crie uma classe estendendo `BaseAgent`:

   ```typescript
   import { BaseAgent } from "../base-agent";
   import { AgentResult } from "../agent-result";

   export class MySEOAuditorAgent extends BaseAgent {
     readonly id = "agt-seo-analyzer";
     readonly name = "SEO Audit Agent";
     readonly version = "1.0.0";

     async validate(): Promise<boolean> {
       return true;
     }

     async execute<T>(goal: string): Promise<AgentResult<T>> {
       this.status = "running";
       const start = Date.now();
       
       // Loops de raciocínio lógico estruturados (React/Plan-Act-Observe)
       // interações com as Engines (Layer 3) e Knowledge (Layer 2)
       
       this.status = "idle";
       return {
         success: true,
         timestamp: new Date().toISOString(),
         agentId: this.id,
         stepsCount: 1,
         finalAnswer: { report: "Otimizado com sucesso" } as unknown as T
       };
     }

     async report<T>(result: AgentResult<T>): Promise<string> {
       return `Relatório consolidado: ${JSON.stringify(result.finalAnswer)}`;
     }
   }
   ```

2. **Registre no Seed**:
   No arquivo `organic-traffic-os/core/seed.ts`, registre seu agente:

   ```typescript
   import { AgentRegistry } from "./agents/agent-registry";
   import { MySEOAuditorAgent } from "./agents/implementations/my-seo-agent";

   AgentRegistry.register(new MySEOAuditorAgent());
   ```
