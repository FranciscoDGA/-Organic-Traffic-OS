# Arquitetura de 5 Camadas (EPIC 03)
## Autonomous Content Operations

Esta documentação descreve a fundação arquitetural de 5 camadas construída especificamente para suportar as operações de conteúdo autônomo (EPIC 03) do Organic Traffic OS de forma robusta, escalável e de fácil manutenção.

---

## As 5 Camadas de Abstração

```
                    ┌─────────────────────────┐
                    │       WORKFLOWS         │  <-- Layer 5: State machine, sequence
                    └────────────┬────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │         AGENTS          │  <-- Layer 4: Decision loops & actions
                    └────────────┬────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │        ENGINES          │  <-- Layer 3: LLMs & rule engines
                    └────────────┬────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │       KNOWLEDGE         │  <-- Layer 2: Indexed facts & semantic cache
                    └────────────┬────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │       CONNECTORS        │  <-- Layer 1: Normalization of external APIs
                    └─────────────────────────┘
```

1. **Layer 1: Connectors**
   Isolamento e normalização de chamadas a serviços externos (APIs, Webmasters, etc.). Nenhum código de negócio fora desta camada deve interagir com HTTP/gRPC bruto de terceiros.

2. **Layer 2: Knowledge**
   Provê a base de fatos unificada da plataforma. Resolve contexto, cacheia consultas caras e garante integridade semântica para mitigar alucinações.

3. **Layer 3: Engines**
   Orquestração e inteligência analítica baseada em Inteligência Artificial (modelos Gemini) e regras estáticas determinísticas.

4. **Layer 4: Agents**
   Persona-driven executors. Possuem loops de decisão e agem de forma focada baseando-se nas recomendações e análises providas pelas Engines.

5. **Layer 5: Workflows**
   Orquestração rígida sequencial com persistência de estado. Mapeia e une múltiplos agentes em pipelines complexos (Sprints do Organic Traffic OS).

---

## Fluxo entre Camadas

O fluxo segue a hierarquia descendente e ascendente:
1. O **Workflow** inicia uma execução estruturada e distribui metas aos **Agentes**.
2. Os **Agentes** analisam suas metas e consultam as **Engines** para obter insights preditivos ou gerar rascunhos.
3. As **Engines** dependem do **Knowledge** para receber contexto enriquecido e factual.
4. O **Knowledge** obtém dados atualizados através dos **Connectors** adequados.
5. As saídas escalam de volta completando as etapas do Workflow.

---

## Regras Obrigatórias para Próximas Sprints

- **Nenhum agente funcional** ou chamada real a LLMs deve ser feita fora da estrutura do Core.
- Todos os componentes criados **devem ser registrados** no Registry respectivo de seu Layer durante a inicialização (semeadura).
- Todos os arquivos de implementação futuros devem estender os contratos das classes abstratas base (`BaseConnector`, `KnowledgeProvider`, `BaseEngine`, `BaseAgent`, `BaseWorkflow`).
