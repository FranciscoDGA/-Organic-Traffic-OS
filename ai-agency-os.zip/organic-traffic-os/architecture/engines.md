# Layer 3 — Engines Guide

O **Engines Layer** fornece o poder cognitivo e matemático por trás de análises de SEO e gerações assistidas por IA.

## Como Adicionar uma Nova Engine

1. **Crie a Classe**:
   Crie uma nova engine estendendo `BaseEngine`:

   ```typescript
   import { BaseEngine } from "../base-engine";
   import { EngineResult } from "../engine-result";

   export class MyAIEngine extends BaseEngine {
     readonly id = "eng-gemini-precision";
     readonly name = "Precision AI Engine";
     readonly version = "1.0.0";

     async analyze<T>(input: string, options?: any): Promise<EngineResult<T>> {
       const start = Date.now();
       // Implemente a chamada oficial do SDK do Gemini aqui
       return {
         success: true,
         timestamp: new Date().toISOString(),
         rawText: "Output textual",
         output: { analysis: "perfect" } as unknown as T,
         usage: { promptTokens: 10, completionTokens: 20, totalTokens: 30 }
       };
     }

     async score(input: string, criteria?: any): Promise<number> {
       // Calcule scores de qualidade, densidade de palavras-chave, etc.
       return 88;
     }

     async recommend<T>(input: string, options?: any): Promise<T[]> {
       return [{ tip: "Aumentar tamanho do parágrafo inicial" } as unknown as T];
     }
   }
   ```

2. **Registre no Seed**:
   No arquivo `organic-traffic-os/core/seed.ts`, adicione seu registro:

   ```typescript
   import { EngineRegistry } from "./engines/engine-registry";
   import { MyAIEngine } from "./engines/implementations/my-ai-engine";

   EngineRegistry.register(new MyAIEngine());
   ```
