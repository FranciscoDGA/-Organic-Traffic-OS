# Layer 1 — Connectors Guide

O **Connectors Layer** é o ponto de entrada único para qualquer dado externo ou interações com sistemas fora do Core.

## Como Adicionar um Novo Connector

1. **Crie a Classe**:
   Crie um arquivo em `organic-traffic-os/core/connectors/implementations/my-new-connector.ts` estendendo `BaseConnector`:

   ```typescript
   import { BaseConnector } from "../base-connector";
   import { ConnectorResult } from "../connector-result";

   export class MyNewConnector extends BaseConnector {
     readonly id = "conn-my-service";
     readonly name = "My Service Connector";
     readonly version = "1.0.0";

     async connect(): Promise<boolean> {
       // Implemente handshake ou verificação de chaves de API
       return true;
     }

     async validate(): Promise<boolean> {
       // Valide as credenciais configuradas
       return true;
     }

     async execute<T>(action: string, params?: any): Promise<ConnectorResult<T>> {
       const start = Date.now();
       try {
         // Chame sua API real aqui
         const data = { raw: "example" };
         const normalized = this.normalize<T>(data);
         return this.createSuccessResult(normalized, Date.now() - start);
       } catch (err: any) {
         return this.createErrorResult("ERR_CALL_FAILED", err.message, Date.now() - start);
       }
     }

     normalize<T>(rawData: any): T {
       // Remapeie o payload externo para um modelo limpo do Core
       return { content: rawData.raw } as unknown as T;
     }
   }
   ```

2. **Registre no Factory ou Seed**:
   No arquivo `organic-traffic-os/core/seed.ts` (ou no inicializador de sua aplicação), instancie e registre seu conector:

   ```typescript
   import { ConnectorRegistry } from "./connectors/connector-registry";
   import { MyNewConnector } from "./connectors/implementations/my-new-connector";

   ConnectorRegistry.register(new MyNewConnector());
   ```

3. **Chame via Manager**:
   ```typescript
   import { ConnectorManager } from "./connectors/connector-manager";
   const result = await ConnectorManager.executeAction("conn-my-service", "fetch-posts", { limit: 10 });
   ```
