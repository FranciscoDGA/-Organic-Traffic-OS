# Knowledge Base - Blogs
Contains registered blog channels and platforms configurations.
