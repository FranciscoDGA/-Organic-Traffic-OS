# Knowledge Base - Memory
Contains cross-workflow long-term and short-term semantic memory storage.
