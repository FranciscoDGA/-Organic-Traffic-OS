# Knowledge Base - Personas
Contains profiles of target audience demographics and pain points mappings.
