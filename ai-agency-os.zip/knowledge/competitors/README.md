# Knowledge Base - Competitors
Contains competitors analyses, SEO keyword difficulty indices, and search gaps.
