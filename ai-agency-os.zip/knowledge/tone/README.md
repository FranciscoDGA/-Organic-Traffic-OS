# Knowledge Base - Tone
Contains brand voice matrices, tone adjectives, and banned word list guidelines.
