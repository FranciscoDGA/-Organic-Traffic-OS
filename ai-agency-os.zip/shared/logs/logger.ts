import { LogEntry } from "../types";

export class Logger {
  private static logs: LogEntry[] = [];
  private static subscribers: ((log: LogEntry) => void)[] = [];

  static log(
    level: LogEntry['level'],
    source: LogEntry['source'],
    message: string,
    taskId?: string,
    metadata?: Record<string, any>
  ): LogEntry {
    const entry: LogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      level,
      source,
      message,
      taskId,
      metadata,
    };

    this.logs.unshift(entry);
    
    // Cap log history
    if (this.logs.length > 500) {
      this.logs.pop();
    }

    // Notify subscribers
    this.subscribers.forEach(sub => sub(entry));

    return entry;
  }

  static info(source: LogEntry['source'], message: string, taskId?: string, metadata?: Record<string, any>) {
    return this.log('info', source, message, taskId, metadata);
  }

  static warn(source: LogEntry['source'], message: string, taskId?: string, metadata?: Record<string, any>) {
    return this.log('warn', source, message, taskId, metadata);
  }

  static error(source: LogEntry['source'], message: string, taskId?: string, metadata?: Record<string, any>) {
    return this.log('error', source, message, taskId, metadata);
  }

  static success(source: LogEntry['source'], message: string, taskId?: string, metadata?: Record<string, any>) {
    return this.log('success', source, message, taskId, metadata);
  }

  static getAll(): LogEntry[] {
    return this.logs;
  }

  static clear() {
    this.logs = [];
  }

  static subscribe(fn: (log: LogEntry) => void) {
    this.subscribers.push(fn);
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== fn);
    };
  }
}
