import { Task } from "../types";
import { AgentRegistry } from "../registry/agent-registry";
import { Logger } from "../logs/logger";
import { AgentExecutor } from "../executor/agent-executor";
import { TaskQueue } from "../queue/task-queue";

export class AgentDispatcher {
  static dispatch(taskId: string) {
    const task = TaskQueue.get(taskId);
    if (!task) {
      Logger.error('dispatcher', `Failed to dispatch: Task "${taskId}" not found`);
      return;
    }

    Logger.info('dispatcher', `Dispatching task for Agent Category: "${task.agentId}"`, taskId);

    // Resolve which specific agent can handle this task
    let agent = AgentRegistry.get(task.agentId);
    
    // Fallback search by category or capability
    if (!agent) {
      const candidates = AgentRegistry.getAll().filter(
        a => a.category === task.agentId || a.capabilities.includes(task.agentId)
      );
      if (candidates.length > 0) {
        agent = candidates[0];
        Logger.info('dispatcher', `Resolved implicit agent: "${agent.name}" (${agent.id})`, taskId);
      }
    }

    if (!agent) {
      const errorMsg = `No suitable agent registered for task target "${task.agentId}"`;
      TaskQueue.updateStatus(taskId, 'failed', { error: errorMsg });
      Logger.error('dispatcher', errorMsg, taskId);
      return;
    }

    // Check agent dependencies
    if (agent.dependencies.length > 0) {
      Logger.info('dispatcher', `Agent "${agent.name}" has dependencies: ${agent.dependencies.join(', ')}. Resolving from memory...`, taskId);
      // In a real system, we would trigger those tasks or check if their results exist in memory
    }

    // Pass the task to the Executor for execution
    TaskQueue.updateStatus(taskId, 'running');
    
    // Execute asynchronously to not block the server event loop
    setTimeout(async () => {
      try {
        await AgentExecutor.execute(task.id, agent!);
      } catch (err: any) {
        Logger.error('dispatcher', `Execution boundary error: ${err.message || err}`, taskId);
        TaskQueue.updateStatus(taskId, 'failed', { error: err.message || String(err) });
      }
    }, 50);
  }
}
