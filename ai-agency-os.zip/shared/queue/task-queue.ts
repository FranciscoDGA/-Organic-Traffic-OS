import { Task } from "../types";
import { Logger } from "../logs/logger";

export class TaskQueue {
  private static queue: Map<string, Task> = new Map();
  private static subscribers: ((task: Task) => void)[] = [];

  static enqueue(task: Omit<Task, 'id' | 'status' | 'createdAt'>): Task {
    const fullTask: Task = {
      ...task,
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    this.queue.set(fullTask.id, fullTask);
    Logger.info('queue', `New task enqueued for agent: ${fullTask.agentId} (Priority: ${fullTask.priority})`, fullTask.id);
    this.notify(fullTask);
    return fullTask;
  }

  static get(id: string): Task | undefined {
    return this.queue.get(id);
  }

  static getAll(): Task[] {
    return Array.from(this.queue.values()).sort((a, b) => {
      // Sort by status: pending first, then priority descending, then createdAt ascending
      if (a.status === 'pending' && b.status !== 'pending') return -1;
      if (a.status !== 'pending' && b.status === 'pending') return 1;
      if (a.status === 'pending' && b.status === 'pending') {
        if (b.priority !== a.priority) return b.priority - a.priority;
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  static getPending(): Task[] {
    return this.getAll().filter(t => t.status === 'pending');
  }

  static updateStatus(id: string, status: Task['status'], data: { result?: any; error?: string; cost?: Task['cost'] } = {}): Task | undefined {
    const task = this.queue.get(id);
    if (!task) return undefined;

    task.status = status;
    if (status === 'running') {
      task.startedAt = new Date().toISOString();
      Logger.info('queue', `Task is now running on agent ${task.agentId}`, id);
    } else if (status === 'completed') {
      task.completedAt = new Date().toISOString();
      task.result = data.result;
      task.cost = data.cost;
      Logger.success('queue', `Task completed by agent ${task.agentId}. Cost: $${data.cost?.estimatedCostUSD.toFixed(6) || 0}`, id);
    } else if (status === 'failed') {
      task.completedAt = new Date().toISOString();
      task.error = data.error;
      Logger.error('queue', `Task failed on agent ${task.agentId}: ${data.error}`, id);
    }

    this.queue.set(id, task);
    this.notify(task);
    return task;
  }

  static subscribe(fn: (task: Task) => void) {
    this.subscribers.push(fn);
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== fn);
    };
  }

  private static notify(task: Task) {
    this.subscribers.forEach(sub => sub(task));
  }

  static clear() {
    this.queue.clear();
  }
}
