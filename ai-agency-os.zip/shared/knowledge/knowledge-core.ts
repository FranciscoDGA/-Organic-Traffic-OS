import { KnowledgeItem } from "../types";
import { Logger } from "../logs/logger";

export class KnowledgeCore {
  private static items: Map<string, KnowledgeItem> = new Map();

  static register(item: KnowledgeItem) {
    this.items.set(item.id, item);
  }

  static get(id: string): KnowledgeItem | undefined {
    return this.items.get(id);
  }

  static getByCategory(category: KnowledgeItem['category']): KnowledgeItem[] {
    return Array.from(this.items.values()).filter(i => i.category === category);
  }

  static getAll(): KnowledgeItem[] {
    return Array.from(this.items.values());
  }

  /**
   * Generates a context injection string for the AI prompt
   */
  static getContextForAgent(category: string): string {
    const relevantItems = this.getAll().filter(item => {
      // Intelligently match item category/tags with agent category
      return (
        item.category === 'rules' || 
        item.category === 'tone' ||
        (category === 'research' && item.category === 'competitors') ||
        (category === 'content' && (item.category === 'personas' || item.category === 'products' || item.category === 'blogs'))
      );
    });

    if (relevantItems.length === 0) return "";

    return "=== SHARED KNOWLEDGE CORE CONTEXT ===\n" + 
      relevantItems.map(item => `[Knowledge: ${item.category.toUpperCase()} - ${item.title}]\n${item.content}`).join("\n\n") +
      "\n======================================";
  }
}

// Seed Initial Knowledge Base
KnowledgeCore.register({
  id: "knowledge-blog-1",
  category: "blogs",
  title: "AI Agency OS Blog Hub",
  content: "URL: https://agency-os.com/blog. Focuses on AI-native operations, autonomous workflows, and modern marketing agencies automation.",
  updatedAt: new Date().toISOString()
});

KnowledgeCore.register({
  id: "knowledge-product-1",
  category: "products",
  title: "Organic Traffic OS Module",
  content: "SaaS automation plugin for AI Agency OS. Automatically discovers high-intent organic keywords, plans editorial content calendars, writes humanized drafts using Gemini, handles internal linking, and publishes drafts autonomously.",
  updatedAt: new Date().toISOString()
});

KnowledgeCore.register({
  id: "knowledge-persona-1",
  category: "personas",
  title: "Inbound Marketing Agency Lead",
  content: "A professional marketing director or agency owner looking to scale content production without increasing headcount. Primary pain points: writer fatigue, generic AI-content detection, poor organic search rankings, and inconsistent schedule.",
  updatedAt: new Date().toISOString()
});

KnowledgeCore.register({
  id: "knowledge-competitor-1",
  category: "competitors",
  title: "Manual SEO Tooling (Semrush / Ahrefs / Jasper)",
  content: "Competitors require manual seat management, human copywriting, disjointed tooling, and provide no autonomous orchestration workflows. organic Traffic OS beats them by running full-loop autonomous agency cycles.",
  updatedAt: new Date().toISOString()
});

KnowledgeCore.register({
  id: "knowledge-rule-1",
  category: "rules",
  title: "High Integrity SEO Copywriting Guidelines",
  content: "1. No repetitive transition words (e.g., 'In conclusion', 'Furthermore', 'Moreover', 'In today's digital landscape').\n2. Include real practical code examples, tables, or direct bullet lists where appropriate.\n3. Make sentences concise and highly readable (Flesch-Kincaid grade 8-10 level).",
  updatedAt: new Date().toISOString()
});

KnowledgeCore.register({
  id: "knowledge-tone-1",
  category: "tone",
  title: "Direct & Authoritative Expert Voice",
  content: "Tone must be direct, crisp, professional, and technical but simple. Avoid marketing fluff, fake excitement, or excessive exclamation marks. Write as a veteran SaaS developer and SEO specialist.",
  updatedAt: new Date().toISOString()
});
