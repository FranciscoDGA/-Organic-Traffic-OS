import { ModuleManifest, Task, AICost } from "../types";
import { TaskQueue } from "../queue/task-queue";
import { AgentRegistry } from "../registry/agent-registry";
import { AgentDispatcher } from "../dispatcher/agent-dispatcher";
import { Logger } from "../logs/logger";

export class SharedRuntime {
  private static status: 'idle' | 'running' | 'paused' = 'idle';
  private static loadedModules: Map<string, ModuleManifest> = new Map();
  private static providers: string[] = ["Gemini", "OpenAI (Mock)", "Claude (Mock)", "Mistral (Mock)"];
  private static isInitialized = false;

  static initialize() {
    if (this.isInitialized) return;

    Logger.info('runtime', 'Initializing Shared Runtime Core of AI Agency OS...');
    
    // Subscribe to task queue to automatically dispatch pending tasks
    TaskQueue.subscribe((task) => {
      if (task.status === 'pending' && this.status === 'idle') {
        this.processNext();
      }
    });

    this.status = 'idle';
    this.isInitialized = true;
    Logger.success('runtime', 'Shared Runtime Core is fully operational');
  }

  static setStatus(status: 'idle' | 'running' | 'paused') {
    this.status = status;
    Logger.info('runtime', `Runtime status changed to: ${status.toUpperCase()}`);
  }

  static getStatus() {
    return this.status;
  }

  static getProviders() {
    return this.providers;
  }

  static loadModule(id: string, manifest: ModuleManifest) {
    this.loadedModules.set(id, manifest);
    Logger.success('runtime', `Module "${manifest.name}" (v${manifest.version}) successfully loaded and integrated`);
  }

  static getLoadedModules(): ModuleManifest[] {
    return Array.from(this.loadedModules.values());
  }

  static processNext() {
    const pending = TaskQueue.getPending();
    if (pending.length === 0) {
      this.status = 'idle';
      return;
    }

    this.status = 'running';
    const nextTask = pending[0];
    
    // Dispatch task
    try {
      AgentDispatcher.dispatch(nextTask.id);
    } catch (error: any) {
      Logger.error('runtime', `Runtime error during dispatching: ${error.message || error}`);
      TaskQueue.updateStatus(nextTask.id, 'failed', { error: String(error) });
      this.status = 'idle';
    }
  }

  /**
   * Computes system-wide aggregate performance metrics
   */
  static getMetrics() {
    const allTasks = TaskQueue.getAll();
    const completedTasks = allTasks.filter(t => t.status === 'completed');
    const failedTasks = allTasks.filter(t => t.status === 'failed');
    
    let totalPromptTokens = 0;
    let totalCompletionTokens = 0;
    let totalCostUSD = 0;

    allTasks.forEach(t => {
      if (t.cost) {
        totalPromptTokens += t.cost.promptTokens;
        totalCompletionTokens += t.cost.completionTokens;
        totalCostUSD += t.cost.estimatedCostUSD;
      }
    });

    const successRate = allTasks.length > 0 
      ? (completedTasks.length / (completedTasks.length + failedTasks.length || 1)) * 100
      : 100;

    return {
      status: this.status,
      agentCount: AgentRegistry.getAll().length,
      moduleCount: this.loadedModules.size,
      queueDepth: pendingCount(),
      successRate: Math.round(successRate),
      aiUsage: {
        totalTasks: allTasks.length,
        completed: completedTasks.length,
        failed: failedTasks.length,
        promptTokens: totalPromptTokens,
        completionTokens: totalCompletionTokens,
        totalTokens: totalPromptTokens + totalCompletionTokens,
        totalCostUSD
      }
    };
  }
}

function pendingCount(): number {
  return TaskQueue.getPending().length;
}
