import { Logger } from "../logs/logger";

export class SharedMemory {
  private static store: Map<string, any> = new Map();

  static set(key: string, value: any, taskId?: string) {
    this.store.set(key, value);
    Logger.info('runtime', `Shared Memory updated: stored key "${key}"`, taskId, { key });
  }

  static get<T>(key: string): T | undefined {
    return this.store.get(key);
  }

  static has(key: string): boolean {
    return this.store.has(key);
  }

  static delete(key: string) {
    this.store.delete(key);
    Logger.info('runtime', `Shared Memory: deleted key "${key}"`);
  }

  static clear() {
    this.store.clear();
    Logger.info('runtime', 'Shared Memory cleared');
  }

  static getKeys(): string[] {
    return Array.from(this.store.keys());
  }

  static dump(): Record<string, any> {
    const result: Record<string, any> = {};
    for (const [key, val] of this.store.entries()) {
      result[key] = val;
    }
    return result;
  }
}
