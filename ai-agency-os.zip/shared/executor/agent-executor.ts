import { Task, AgentManifest } from "../types";
import { generateText } from "../providers/ai-provider";
import { TaskQueue } from "../queue/task-queue";
import { Logger } from "../logs/logger";
import { KnowledgeCore } from "../knowledge/knowledge-core";
import { SharedMemory } from "../memory/shared-memory";

export class AgentExecutor {
  static async execute(taskId: string, agent: AgentManifest): Promise<void> {
    const task = TaskQueue.get(taskId);
    if (!task) {
      Logger.error('executor', `Task "${taskId}" has disappeared prior to execution`, taskId);
      return;
    }

    Logger.info('executor', `Agent "${agent.name}" starting task execution...`, taskId);

    // Retrieve corresponding Knowledge Core items for injection
    const knowledgeContext = KnowledgeCore.getContextForAgent(agent.category);
    
    // Formulate a robust system instruction
    const systemInstruction = `
You are the "${agent.name}" (ID: ${agent.id}), an expert AI Agent specializing in the category "${agent.category}".
Version: ${agent.version}
Capabilities: ${agent.capabilities.join(', ')}

${knowledgeContext}

Your mission is to process the user input and produce high-quality, formatted outputs conforming exactly to:
Input details: ${agent.input}
Expected output: ${agent.output}

Be precise, highly professional, and adhere fully to the injected rules and tone guidelines.
`;

    const userPrompt = typeof task.input === 'string' 
      ? task.input 
      : JSON.stringify(task.input, null, 2);

    Logger.info('executor', `Routing prompt to Shared AI Provider (Selected: ${agent.defaultProvider})...`, taskId);

    try {
      // Execute LLM request via unified Shared AI Provider
      const result = await generateText(userPrompt, {
        provider: agent.defaultProvider,
        model: "gemini-3.5-flash",
        systemInstruction,
        temperature: 0.3 + (agent.priority * 0.05) // Adjust temperature based on agent priority profile
      });

      // Save output in Shared Memory for cross-agent/cross-module access
      SharedMemory.set(`${agent.id}-last-result`, result.text, taskId);
      SharedMemory.set(`latest-execution`, {
        agentId: agent.id,
        taskId,
        result: result.text,
        timestamp: new Date().toISOString()
      }, taskId);

      // Finish task successfully
      TaskQueue.updateStatus(taskId, 'completed', {
        result: result.text,
        cost: result.cost
      });

      Logger.success('executor', `Agent "${agent.name}" successfully executed task.`, taskId);
    } catch (err: any) {
      Logger.error('executor', `Agent "${agent.name}" failed to execute: ${err.message || err}`, taskId);
      TaskQueue.updateStatus(taskId, 'failed', {
        error: `LLM Generation failure: ${err.message || String(err)}`
      });
    }
  }
}
