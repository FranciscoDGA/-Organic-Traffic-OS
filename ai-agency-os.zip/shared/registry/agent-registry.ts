import { AgentManifest } from "../types";

export class AgentRegistry {
  private static agents: Map<string, AgentManifest> = new Map();

  static register(agent: AgentManifest) {
    this.agents.set(agent.id, agent);
  }

  static get(id: string): AgentManifest | undefined {
    return this.agents.get(id);
  }

  static getAll(): AgentManifest[] {
    return Array.from(this.agents.values());
  }

  static getByCategory(category: string): AgentManifest[] {
    return this.getAll().filter(a => a.category === category);
  }
}

// Pre-register Organic Traffic OS Agents
AgentRegistry.register({
  id: "agent-research",
  name: "Keyword & Competitor Researcher",
  category: "research",
  version: "1.0.0",
  defaultProvider: "Gemini",
  capabilities: ["keyword-discovery", "competitor-gap-analysis", "search-trend-mining"],
  input: "competitor URL, market niche, or starting keywords",
  output: "structured keyword matrix with volume, difficulty, and high-intent opportunities",
  dependencies: [],
  priority: 8,
  timeout: 30000
});

AgentRegistry.register({
  id: "agent-seo",
  name: "SEO Semantic Architect",
  category: "seo",
  version: "1.0.0",
  defaultProvider: "Gemini",
  capabilities: ["on-page-auditing", "semantic-expansion", "schema-markup-generation"],
  input: "raw article text, primary target keyword, internal link map",
  output: "SEO tags, suggested sitemap anchors, JSON-LD Schema, and keyword insertions list",
  dependencies: ["agent-research"],
  priority: 7,
  timeout: 15000
});

AgentRegistry.register({
  id: "agent-content",
  name: "Agentic Copywriter",
  category: "content",
  version: "1.1.0",
  defaultProvider: "Gemini",
  capabilities: ["outline-generation", "multi-perspective-drafting", "brand-voice-alignment"],
  input: "SEO structure, keywords matrix, blog style rules, target persona profile",
  output: "complete, markdown-formatted, SEO-optimized, highly engaging article",
  dependencies: ["agent-seo", "agent-research"],
  priority: 9,
  timeout: 45000
});

AgentRegistry.register({
  id: "agent-citation",
  name: "Authority & Citation Builder",
  category: "citation",
  version: "1.0.0",
  defaultProvider: "Gemini",
  capabilities: ["backlink-prospecting", "citation-network-sync", "external-resource-matching"],
  input: "article draft, target market niche, authority reference catalog",
  output: "list of recommended external links, high-quality citation anchors, and syndication targets",
  dependencies: ["agent-content"],
  priority: 5,
  timeout: 20000
});

AgentRegistry.register({
  id: "agent-analytics",
  name: "Search Performance Analyst",
  category: "analytics",
  version: "1.0.0",
  defaultProvider: "Gemini",
  capabilities: ["gsc-ctr-analysis", "organic-conversions-attribution", "roi-projection"],
  input: "historical traffic log, ranking positions, GSC impressions, analytics events",
  output: "performance report dashboard with custom suggestions for top-performing clusters",
  dependencies: [],
  priority: 6,
  timeout: 25000
});
