import { GoogleGenAI } from "@google/genai";
import { AICost } from "../types";

let aiInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const key = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
    if (!key) {
      console.warn("GEMINI_API_KEY environment variable is not defined. Using mock AI provider mode.");
      return null as any;
    }
    aiInstance = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

export interface GenerationOptions {
  provider?: string;
  model?: string;
  temperature?: number;
  systemInstruction?: string;
}

export async function generateText(
  prompt: string,
  options: GenerationOptions = {}
): Promise<{ text: string; cost: AICost }> {
  const provider = options.provider || "Gemini";
  const model = options.model || "gemini-3.5-flash";
  const systemInstruction = options.systemInstruction || "You are a professional AI Agency OS Agent.";
  const temp = options.temperature ?? 0.7;

  try {
    const ai = getGeminiClient();
    if (!ai) {
      // Return simulated mock response if API Key is missing
      return getMockAIResponse(prompt, provider, model);
    }

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: temp,
      },
    });

    const text = response.text || "No response received from model.";
    
    // Calculate simple token estimates and costs
    const promptTokens = Math.ceil(prompt.length / 4) + Math.ceil(systemInstruction.length / 4);
    const completionTokens = Math.ceil(text.length / 4);
    const totalTokens = promptTokens + completionTokens;
    
    // Est cost: $0.075 per 1M input tokens, $0.30 per 1M output tokens for gemini-3.5-flash
    const estimatedCostUSD = (promptTokens * 0.000000075) + (completionTokens * 0.0000003);

    return {
      text,
      cost: {
        provider: "Gemini",
        model,
        promptTokens,
        completionTokens,
        totalTokens,
        estimatedCostUSD,
      },
    };
  } catch (error: any) {
    console.error("Shared AI Provider error:", error);
    return {
      text: `Error from Gemini AI Provider: ${error.message || error}`,
      cost: {
        provider: "Gemini",
        model,
        promptTokens: 0,
        completionTokens: 0,
        totalTokens: 0,
        estimatedCostUSD: 0,
      },
    };
  }
}

function getMockAIResponse(prompt: string, provider: string, model: string): { text: string; cost: AICost } {
  // Graceful fallback when API key is missing
  let reply = `[Mock Response - ${provider} (${model})] `;
  if (prompt.toLowerCase().includes("seo") || prompt.toLowerCase().includes("competitor")) {
    reply += `SEO Analysis & Competitor Insight:\n- Target Keywords show high intent but low difficulty.\n- Recommended content cluster structure based on blogs/products knowledge bases.\n- Semantic optimization score improved by 34% with suggested layout.`;
  } else if (prompt.toLowerCase().includes("content") || prompt.toLowerCase().includes("draft") || prompt.toLowerCase().includes("artigo")) {
    reply += `Draft Generation Completed:\n## Organic Traffic Growth with AI\nThis article outlines how integrating agentic workflows inside your CRM and blogging platform drives continuous inbound search visibility with zero manual writing overhead.`;
  } else {
    reply += `Successfully processed task: "${prompt.slice(0, 50)}..." using standard agent protocol.`;
  }

  const promptTokens = Math.ceil(prompt.length / 4);
  const completionTokens = Math.ceil(reply.length / 4);
  const totalTokens = promptTokens + completionTokens;
  const estimatedCostUSD = (promptTokens * 0.000000075) + (completionTokens * 0.0000003);

  return {
    text: reply,
    cost: {
      provider,
      model,
      promptTokens,
      completionTokens,
      totalTokens,
      estimatedCostUSD,
    },
  };
}
