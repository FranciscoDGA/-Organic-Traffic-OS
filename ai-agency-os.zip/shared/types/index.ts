export interface AgentManifest {
  id: string;
  name: string;
  category: string;
  version: string;
  defaultProvider: string;
  capabilities: string[];
  input: string;
  output: string;
  dependencies: string[];
  priority: number; // 1-10
  timeout: number;  // in milliseconds
}

export interface ModuleManifest {
  name: string;
  version: string;
  dependencies: string[];
  agents: string[];
  workflows: string[];
  routes: string[];
  permissions: string[];
}

export interface Task {
  id: string;
  moduleId: string;
  agentId: string;
  input: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  priority: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  result?: any;
  error?: string;
  cost?: AICost;
}

export interface AICost {
  provider: string;
  model: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCostUSD: number;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  source: 'runtime' | 'dispatcher' | 'executor' | 'queue' | 'provider' | 'agent';
  message: string;
  taskId?: string;
  metadata?: Record<string, any>;
}

export interface ProviderConfig {
  id: string;
  name: string;
  status: 'active' | 'inactive';
  models: string[];
}

export interface KnowledgeItem {
  id: string;
  category: 'blogs' | 'products' | 'personas' | 'competitors' | 'rules' | 'tone' | 'memory';
  title: string;
  content: string;
  updatedAt: string;
}
