# Layer 1: Connectors (Conectores)
## Especificações e Contratos de Integração de Dados

A camada de **Connectors** padroniza a conexão com fontes de dados externas (como Google Search Console, Google Trends, Bing Webmaster) ou de runtime (Manual Inputs e sementes de mock).

---

## 1. Estruturas e Interfaces de Tipos

```typescript
export interface ConnectorContext {
  connectionString?: string;
  authToken?: string;
  additionalHeaders?: Record<string, string>;
  timeoutMs?: number;
  environment: "sandbox" | "production" | "development";
  customConfig?: Record<string, any>;
}

export interface ConnectorResult<T = any> {
  success: boolean;
  timestamp: string;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  metrics?: {
    latencyMs: number;
    bytesProcessed?: number;
  };
}
```

---

## 2. Classe Base `BaseConnector`

Qualquer novo conector deve estender obrigatoriamente a classe `BaseConnector`:

```typescript
export abstract class BaseConnector {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;
  
  protected context: ConnectorContext | null = null;

  async initialize(context: ConnectorContext): Promise<boolean>;
  abstract testConnection(): Promise<boolean>;
  abstract execute<T>(action: string, params?: Record<string, any>): Promise<ConnectorResult<T>>;
}
```

---

## 3. Gestão e Registro

- **`ConnectorRegistry`**: Armazena as instâncias dos conectores instanciados na inicialização do servidor.
- **`ConnectorManager`**: Facilita a execução de chamadas, controlando a latência do pipeline, emitindo eventos de auditoria e tratando erros com elegância.
- **`ConnectorFactory`**: Builder para criar e registrar instâncias de forma ágil e dinâmica.
