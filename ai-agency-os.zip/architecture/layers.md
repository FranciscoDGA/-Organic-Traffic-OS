# Camadas Arquiteturais do EPIC 03 (Layers)
## Visão Geral das 5 Camadas de Operações de Conteúdo Autônomas

O **EPIC 03** do *Organic Traffic OS* introduz uma arquitetura unificada e robusta baseada em **cinco camadas desacopladas e fortemente tipadas**, desenhadas para garantir escalabilidade, testabilidade e separação estrita de preocupações em operações de conteúdo autônomas.

```
       ┌───────────────────────────────┐
       │      LAYER 1: CONNECTORS      │  <-- Conectividade de dados de SERP/Métricas
       └───────────────┬───────────────┘
                       │
                       ▼
       ┌───────────────────────────────┐
       │      LAYER 2: KNOWLEDGE       │  <-- Consumidores de conhecimento / Indexadores
       └───────────────┬───────────────┘
                       │
                       ▼
       ┌───────────────────────────────┐
       │       LAYER 3: ENGINES        │  <-- Modelos de IA e Processamento Semântico
       └───────────────┬───────────────┘
                       │
                       ▼
       ┌───────────────────────────────┐
       │       LAYER 4: AGENTS         │  <-- Tomada de decisão orientada a objetivos
       └───────────────┬───────────────┘
                       │
                       ▼
       ┌───────────────────────────────┐
       │      LAYER 5: WORKFLOWS       │  <-- Orquestração em lote e Sprints Autônomas
       └───────────────────────────────┘
```

---

## Detalhamento das Camadas

### Layer 1: Connectors (Conectores)
Responsável exclusivamente pela ingestão de dados, handshakes de autenticação e normalização de payloads brutos em estruturas de dados comuns. Isola totalmente APIs do Google, Bing e inputs manuais da lógica de negócio.

### Layer 2: Knowledge (Conhecimento)
Gerencia fontes de dados estruturados e não estruturados (sitemaps, relatórios, históricos, documentos). Indexa, armazena em cache de curta duração e disponibiliza informações cruciais para que o sistema tome decisões com alto grau de coerência factual.

### Layer 3: Engines (Motores)
Motores semânticos e wrappers de LLMs (como Gemini). Abstrai chamadas de prompts, gerencia limites de tokens, calcula custos em USD e padroniza saídas estruturadas para evitar quebras de fluxo na conversão de tipos.

### Layer 4: Agents (Agentes)
Entidades autônomas que recebem objetivos complexos (ex: "descobrir tópicos de alto impacto semântico para Cumaru do Norte"). Operam em múltiplos loops, decidem quando ler do conhecimento, quando chamar ferramentas de conectores e consolidam respostas de alto nível.

### Layer 5: Workflows (Fluxos de Trabalho)
A engrenagem superior. Coordena a execução sequencial ou em lote das tarefas, mantendo o histórico de execução detalhado, medindo latência de cada etapa, e persistindo o estado de progresso das Sprints de conteúdo de ponta a ponta.

---

## Relacionamentos e Padrões Comuns

Todas as camadas implementam contratos comuns, utilizam um sistema de eventos centralizado para notificação mútua, geram logs unificados (`AppLogger`) e lançam exceções customizadas (`CoreException`).
