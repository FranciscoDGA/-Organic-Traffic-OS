# Layer 2: Knowledge (Conhecimento)
## Especificações e Contratos de Gerenciamento de Coerência Factual

A camada de **Knowledge** gerencia e organiza todo o conhecimento acumulado pelo sistema (dados factuais sobre concorrências, regras de editais municipais, sitemaps indexados e inteligência competitiva).

---

## 1. Estruturas e Interfaces de Tipos

```typescript
export interface KnowledgeContext {
  userId?: string;
  projectId?: string;
  scope: string;
  tags?: string[];
  lastSync?: string;
}

export interface KnowledgeIndex {
  documentId: string;
  title: string;
  summary?: string;
  sourceType: "file" | "database" | "api" | "sitemap" | "competitor";
  tags: string[];
  tokensCount?: number;
  lastUpdated: string;
}
```

---

## 2. Classe Base `KnowledgeProvider`

Qualquer provedor de conhecimento (seja local via arquivos JSON, remoto via banco SQL ou consultas vetoriais) herda de `KnowledgeProvider`:

```typescript
export abstract class KnowledgeProvider implements KnowledgeResolver {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;

  async load(context: KnowledgeContext): Promise<boolean>;
  abstract getIndexes(): Promise<KnowledgeIndex[]>;
  abstract resolve(query: string, limit?: number): Promise<any[]>;
}
```

---

## 3. Mecanismo de Cache

Para evitar retrabalho de busca de arquivos e gargalos de processamento, o **`KnowledgeCache`** armazena os resultados de buscas semânticas em memória curta (TTL padrão de 10 minutos) e lida com invalidação sob demanda através do barramento de eventos centralizado.
