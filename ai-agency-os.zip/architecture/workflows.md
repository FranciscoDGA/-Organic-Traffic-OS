# Layer 5: Workflows (Fluxos de Trabalho)
## Orquestração Estrita e Automação de Pipelines de Produção

A camada de **Workflows** é a orquestradora final. Ela encadeia processos complexos multi-camadas, garantindo que etapas como "Ingerir Dados -> Consultar Fatos -> Processar com IA -> Revisar com Agente -> Publicar na Fila" ocorram sob uma máquina de estados estrita.

---

## 1. Estruturas e Interfaces de Tipos

```typescript
export interface WorkflowState {
  workflowId: string;
  executionId: string;
  status: "idle" | "running" | "completed" | "failed";
  currentStepIndex: number;
  stepsCount: number;
  variables: Record<string, any>;
  startedAt?: string;
  endedAt?: string;
}

export interface WorkflowHistory {
  executionId: string;
  workflowId: string;
  stepName: string;
  status: "success" | "failed";
  durationMs: number;
  timestamp: string;
  errorMsg?: string;
}

export interface WorkflowResult<T = any> {
  success: boolean;
  executionId: string;
  output?: T;
  history: WorkflowHistory[];
  durationMs: number;
  error?: string;
}
```

---

## 2. Classe Base `BaseWorkflow`

Encapsula o fluxo passo a passo e o controle da máquina de estados:

```typescript
export abstract class BaseWorkflow {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;
  public abstract readonly steps: string[];

  async start(executionId: string, initialVariables?: Record<string, any>): Promise<WorkflowState>;
  abstract runStep(stepIndex: number, state: WorkflowState): Promise<{ success: boolean; outputVariables?: Record<string, any>; error?: string }>;
  async complete(success: boolean, finalOutput?: any, errorMsg?: string): Promise<WorkflowState>;
}
```

---

## 3. Fluxo de Execução Segura

O `WorkflowExecutor` garante isolamento completo de cada execução. Caso alguma etapa falhe, ele registra o rastro de erro detalhado (`WorkflowHistory`), reverte estados parciais e emite alertas automatizados para auditoria imediata.
