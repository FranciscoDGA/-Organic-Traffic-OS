# Layer 3: Engines (Motores)
## Especificações e Contratos de IA e Processamento de Linguagem

A camada de **Engines** gerencia a comunicação de baixo nível com grandes modelos de linguagem (LLMs) e motores determinísticos de regras de SEO, blindando o restante da aplicação contra instabilidades de APIs.

---

## 1. Estruturas e Interfaces de Tipos

```typescript
export interface EngineContext {
  modelName: string;
  temperature: number;
  maxTokens: number;
  systemInstruction?: string;
  additionalParams?: Record<string, any>;
}

export interface EngineResult<T = any> {
  success: boolean;
  timestamp: string;
  output?: T;
  rawText?: string;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    costUsd?: number;
  };
}
```

---

## 2. Classe Base `BaseEngine`

Responsável por encapsular o modelo e expor um método assíncrono de processamento altamente padronizado:

```typescript
export abstract class BaseEngine {
  public abstract readonly id: string;
  public abstract readonly name: string;
  public abstract readonly version: string;

  async initialize(context: EngineContext): Promise<boolean>;
  abstract process<T>(input: string, contextOverride?: Partial<EngineContext>): Promise<EngineResult<T>>;
}
```

---

## 3. Gestão de Consumo e Custos

O `EngineManager` captura os tokens consumidos reportados pelas saídas dos modelos e emite estatísticas consolidadas para controle e telemetria de custos operacionais do ecossistema.
