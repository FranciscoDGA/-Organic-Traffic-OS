# ROADMAP — Organic Traffic OS (PassaCumaru)

Este documento descreve o planejamento estratégico e a evolução do sistema **Organic Traffic OS**, divididos em grandes Épicos de desenvolvimento técnico e de negócios.

---

## 🗺️ Visão Geral do Roadmap

```
  EPIC 01: Core Engine & E2E (Concluído)
  └── Criação dos 21 módulos estruturais, validação de contratos, pipeline E2E e consolidação.
      
  EPIC 02: Intelligent Content Engine (Próximo)
  └── Agentes de IA autônomos, otimização automatizada, auto-healing de conteúdo e integração CMS.

  EPIC 03: Analytics & Real-Time Monitoring
  └── Conexão ativa com GSC/GA4, detecção automática de decay orgânico e alertas preditivos.
```

---

## 🚀 Detalhamento dos Épicos

### EPIC 01 — Core Engine & E2E Validation (Concluído)
O objetivo principal deste Épico foi estruturar a fundação técnica do sistema de SEO e Conversão de Leads para o portal **PassaCumaru**.
- **Marcos Entregues**:
  - [x] **Sprint 20**: Knowledge Core e Inventory Management.
  - [x] **Sprint 21**: Competitors & SERP Tracking.
  - [x] **Sprint 22**: Keywords & Opportunity Identification.
  - [x] **Sprint 23**: Editorial Planner, Brief Generation & Content Architecture (Blueprints).
  - [x] **Sprint 24**: Research Pack, Fact Engine, Source Engine, Strategy, Draft, e Quality Check.
  - [x] **Sprint 25**: Audience, Natural Language, Visibility, Assets, Publishing, e Performance Engine.
  - [x] **Sprint 25.5**: Pipeline Runner E2E de Ponta a Ponta e Painel de Controle de Saúde.
  - [x] **Fase de Consolidação**: Auditoria Geral, Ajuste de Tipagem e Refino de UX.

---

### EPIC 02 — Intelligent Content Engine (Foco do Próximo Ciclo)
Este Épico moverá a plataforma de um assistente de pipeline guiado para um sistema de agentes autônomos auto-otimizáveis.
- **Objetivos Chave**:
  - [ ] **Multi-Agent Orchestrator**: Substituir o roteamento sequencial rígido por agentes conversacionais que decidem o próximo passo com base em lacunas de qualidade.
  - [ ] **Continuous Auto-Healing**: Robôs que varrem o inventário diariamente e atualizam parágrafos defasados de forma automática sem intervenção humana.
  - [ ] **AI-Driven Personalization**: Mudança dinâmica de CTAs e Simulados baseada em intenção de busca em tempo real.
  - [ ] **Deep Integration API**: Plugins nativos para WordPress e Strapi para publicação com 1 clique.

---

### EPIC 03 — Real-Time Analytics & Predição de Decay
O foco final é fechar o circuito de feedback com dados reais de performance do Google Search Console e GA4.
- **Objetivos Chave**:
  - [ ] **Decay Alerter**: Algoritmos preditivos que alertam quando um artigo pilar começa a perder posições na SERP.
  - [ ] **Automatic AB Testing**: Testes A/B automatizados de títulos e meta-descriptions diretamente no WordPress.
  - [ ] **ROI Attribution**: Atribuição real de leads gerados por cada artigo pilar da plataforma.
