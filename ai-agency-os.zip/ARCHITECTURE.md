# ARCHITECTURE — Organic Traffic OS

Este documento descreve a topologia arquitetural, o fluxo de dados e os princípios de design do **Organic Traffic OS**, um ecossistema modular de SEO de ponta a ponta.

---

## 🏗️ Princípios de Design

1. **Modularidade Estrita (Folder-per-Engine)**: Cada motor ou serviço reside em sua própria pasta isolada contendo sua lógica de serviço (`service.ts`), tipagens, modelos e cache.
2. **Imutabilidade de Contratos**: As etapas se comunicam por meio de tipos e interfaces estritas, garantindo que mudanças em uma engine não quebrem as etapas subsequentes.
3. **Resiliência e Tolerância**: Mecanismos de re-seeding automáticos asseguram que o pipeline de ponta a ponta possa rodar de forma simulada ou real mesmo na ausência de dados parciais.
4. **Server-Side AI API Isolation**: Todas as chaves e interações com o SDK `@google/genai` ocorrem de forma segura no lado do servidor (`server.ts`), nunca expondo credenciais ao navegador.

---

## 🗺️ Topologia dos Módulos

O ecossistema é composto por 21 etapas fundamentais, estruturadas sob `/organic-traffic-os`:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          1. KNOWLEDGE & AUDIENCE                        │
│   Knowledge Core ──> Inventory ──> Competitors ──> SERP ──> Keywords   │
└────────────────────────────────────┬────────────────────────────────────┘
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         2. STRATEGY & PLANNING                          │
│     Opportunity ──> Editorial Planner ──> Brief ──> Blueprint        │
└────────────────────────────────────┬────────────────────────────────────┘
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        3. RESEARCH & INGESTION                          │
│     Research Pack ──> Fact Engine ──> Source Engine ──> Strategy       │
└────────────────────────────────────┬────────────────────────────────────┘
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        4. CREATIVE WRITING & AI                         │
│                  Draft Writer ──> Quality Review                        │
└────────────────────────────────────┬────────────────────────────────────┘
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        5. ADAPTATION & VISIBILITY                       │
│  Audience Adaptation ──> Natural Language ──> Visibility Optimization   │
└────────────────────────────────────┬────────────────────────────────────┘
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         6. DEPLOYMENT & METRICS                         │
│     Asset Gen ──> Publishing Package ──> Performance Registration       │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 📂 Estrutura de Diretórios do Projeto

- `/organic-traffic-os`: Diretório raiz do ecossistema.
  - `/assets/engine`: Geração de criativos e pacotes visuais.
  - `/audience-adaptation/engine`: Alinhamento do conteúdo às personas ideais.
  - `/briefs/brief-engine`: Estruturação de briefings editoriais de alto desempenho.
  - `/collectors`: Coletores assíncronos de dados externos.
  - `/competitors`: Mapeamento e monitoramento de competidores orgânicos.
  - `/content-architecture/engine`: Geração de plantas estruturais (Blueprints).
  - `/draft-writer/engine`: Motor de redação de rascunhos.
  - `/e2e`: Runner de validação de ponta a ponta e motor de health check.
  - `/editorial`: Planejador editorial inteligente e roadmap de artigos.
  - `/facts/engine`: Validação de alegações de rascunhos em tempo real.
  - `/inventory`: Auditoria e governança do inventário de posts.
  - `/keywords`: Gerenciamento e clustering de palavras-chave.
  - `/knowledge`: Core de conhecimento específico do domínio (PassaCumaru).
  - `/natural-language/engine`: Refinamento de tom e legibilidade.
  - `/opportunities`: Detecção de lacunas de mercado.
  - `/orchestrator/engine`: Core do workflow unificado da plataforma.
  - `/performance/engine`: Rastreamento de métricas e ROI orgânico.
  - `/publishing/engine`: Exportador e empacotador para WordPress.
  - `/quality-review/engine`: Auditores de SEO e compliance editorial.
  - `/research-pack/engine`: Pacote de dados brutos e referências para IA.
  - `/serp`: Análise de posicionamento na página de resultados.
  - `/sources/engine`: Repositório de links confiáveis e referências citáveis.
  - `/strategy/engine`: Determinação de personas, CTAs e intenção de busca.
  - `/visibility/engine`: Enriquecimento com Schema Markup e Meta Tags.

---

## 🔀 Fluxo de Dados E2E (Input -> Output)

```
[Palavra-Chave / Tema]
       │
       ▼ (Keywords/SERP)
[Oportunidade de Conteúdo]
       │
       ▼ (Editorial Planner)
[Item Planejado] ──> [Briefing Criado] ──> [Blueprint Arquitetural]
                                                   │
                                                   ▼ (Research/Facts/Sources)
[Draft Textual Completo] <── [Estratégia Escolhida] <── [Research Pack Validado]
       │
       ▼ (Quality Review & Adaptation)
[Artigo Adaptado para Persona] ──> [Legibilidade Ajustada (Natural Language)]
                                                   │
                                                   ▼ (Visibility & Meta)
[Pacote de Publicação WordPress] <── [Imagens/CTAs Gerados] <── [SEO Otimizado]
```
