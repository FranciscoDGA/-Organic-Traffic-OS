# DEVELOPMENT GUIDELINES — Organic Traffic OS

Este documento define as diretrizes técnicas, boas práticas de desenvolvimento, padrões de codificação e processos de verificação de qualidade para desenvolvedores que atuam no ecossistema do **Organic Traffic OS**.

---

## 💻 1. Padrões de Código e Linguagem

### TypeScript e Tipagem Estrita
- Sempre configure e respeite o `tsconfig.json` com `noImplicitAny: true` e `strictNullChecks: true`.
- **Imports**: Devem ser declarados no início de cada arquivo. Evite imports duplicados ou circulares. Use imports nomeados em vez de destruturação de objetos inteiros quando possível.
- **Enums**: Utilize `enum` padrão. Evite o uso de `const enum` devido a limitações de compilação em múltiplos targets.
- **Evite Any**: O tipo `any` é estritamente desencorajado. Defina interfaces explícitas para todos os inputs, outputs e contratos de dados das engines.

---

## 🎨 2. Interface de Usuário (UI) e Estilização

### Tailwind CSS
- Toda a estilização deve ser feita utilizando as classes utilitárias do Tailwind CSS.
- **Tema Visual**: O ecossistema adota um tema escuro e profissional (Slate Dark/Slate-950), com acentos em ciano, esmeralda e roxo para feedbacks visuais de sucesso, aviso ou informação.
- **Responsividade**: Siga a lógica mobile-first (`sm:`, `md:`, `lg:`, `xl:`), assegurando que painéis de dados se expandam elegantemente em telas desktop Ultra-Wide sem esticar o conteúdo de forma bizarra.

### Ícones e Animações
- Todos os ícones devem ser importados de `lucide-react`. Não crie vetores inline ou SVGs manuais a menos que estritamente necessário.
- Animações e micro-interações devem usar transições do Tailwind ou `motion` importado do pacote `motion/react` para animações fluidas e controladas de estado.

---

## 🔒 3. Segurança e Gerenciamento de Segredos

- **Isolamento de Credenciais**: Chaves de API (como `GEMINI_API_KEY`) e senhas de banco de dados devem residir exclusivamente em variáveis de ambiente (`.env` ou segredos do Cloud Run).
- **Consumo Server-Side**: Todas as requisições que envolvem chaves privadas e processamento de IA devem ser feitas no servidor Express (`server.ts`) via rotas `/api/*`. O cliente React nunca deve acessar chaves diretamente no navegador.
- **Tratamento de Exceções**: Chamadas para APIs externas devem possuir tratamento robusto com blocos `try/catch` e mecanismos de fallback (dados mockados consistentes ou re-seeding) para manter a resiliência do sistema em ambientes offline ou sem chaves configuradas.

---

## 🧪 4. Processo de Validação e Qualidade (Quality Gates)

### Verificação Local
Antes de submeter qualquer alteração técnica para o repositório ou produção, siga o fluxo de garantia de qualidade:

1. **Linter**: Execute `npm run lint` para garantir que não existam erros de digitação, imports órfãos ou inconsistências de tipo.
2. **Compilação**: Execute `npm run build` para garantir o empacotamento completo do servidor Express e do cliente React sem quebras de build.
3. **Validação de Pipeline (E2E)**: Execute o Runner de validação E2E (disponível na aba do painel ou via rota `/api/organic-os/e2e/run`) para verificar que as 21 etapas fluem sem quebras de contratos ou regressões.
