# SPRINT 02 — KNOWLEDGE CORE DO BLOG (PASSACUMARU)
## Relatório de Conclusão e Documentação do Sistema

Este relatório consolida a especificação técnica e operacional da estrutura de conhecimento criada para orquestrar o **Organic Traffic OS** na Sprint 02, usando o blog **PassaCumaru** como matriz inaugural.

---

### 1. Estrutura de Diretórios Criada

Toda a estrutura foi construída sob a pasta `/organic-traffic-os/knowledge/` seguindo a hierarquia abaixo:

```text
organic-traffic-os/
└── knowledge/
    ├── blogs/
    │   └── passacumaru/
    │       ├── 01-blog-profile.json
    │       ├── 02-target-audience.json
    │       ├── 03-editorial-guidelines.json
    │       ├── 04-categories.json
    │       ├── 05-products.json
    │       ├── 06-content-rules.json
    │       ├── 07-writing-style.json
    │       ├── 08-seo-rules.json
    │       └── 09-knowledge-index.json
    ├── knowledge-loader.ts
    └── knowledge-validator.ts
```

---

### 2. Detalhe dos Arquivos Criados

*   **01-blog-profile.json**: Dados cadastrais oficiais e de posicionamento do PassaCumaru, contendo Missão, História, Cidade, Estado, País, Idioma, Descrição e Status.
*   **02-target-audience.json**: Personas modeladas com faixas etárias, dores, medos, dificuldades de estudo, objetivos específicos, tom de voz e linguagem direcionados para cada perfil (*Concurseiro Iniciante*, *Concurseiro Avançado*, *Servidor Público*, e *Estudante*).
*   **03-editorial-guidelines.json**: Diretrizes de estilo, regras de escaneabilidade, uso de listas, tabelas comparativas de prazos, inclusão de FAQ, CTAs integradas e conteúdos expressamente proibidos.
*   **04-categories.json**: Catálogo com 18 categorias estruturadas e prontas para classificação temática dos artigos futuros.
*   **05-products.json**: Estrutura dos produtos e materiais oferecidos (E-books, Assinaturas, Cursos, Mentorias, Simulados e Planilhas Gratuitas) com suas respectivas chamadas à ação (CTAs).
*   **06-content-rules.json**: Regras éticas e técnicas rigorosas de redação (ex: proibição de leis inventadas, citação obrigatória de fontes oficiais, veto a promessas milagrosas de aprovação).
*   **07-writing-style.json**: Regras formais de diagramação (quantidade mínima/máxima de palavras, formatação de títulos H1/H2/H3, limites de parágrafos para leitura mobile).
*   **08-seo-rules.json**: Regras cruciais de SEO On-Page (regras de densidade de palavras-chave, limites de meta tags, âncoras de links internos/externos, marcação de FAQ Schema, Breadcrumbs e OG Tags).
*   **09-knowledge-index.json**: Índice mestre registrando chaves, caminhos e descrições de toda a cadeia de arquivos do Knowledge Core para importação direta pelo Loader.

---

### 3. Mecanismo do Knowledge Loader (`knowledge-loader.ts`)

O arquivo `knowledge-loader.ts` expõe a função `loadKnowledgeCore(blogId: string)` que:
1.  Deriva o caminho absoluto de arquivos com base no identificador dinâmico do blog.
2.  Dispara o validador interno de integridade de forma síncrona.
3.  Carrega e faz o parse de todos os arquivos JSON mapeados.
4.  Consolida os dados lidos em um objeto unificado contendo o perfil do blog, público mapeado, categorias, produtos, SEO, regras, e as diretrizes editoriais.
5.  Anexa metadados úteis contendo o status de validação, contagem de arquivos físicos, lista de erros gerada e o carimbo de data/hora do processamento.

---

### 4. Mecanismo do Knowledge Validator (`knowledge-validator.ts`)

O arquivo `knowledge-validator.ts` expõe a função `validateKnowledgeCore(blogId: string)` encarregada de:
*   Verificar a presença física de todos os 9 arquivos obrigatórios na pasta do blog.
*   Garantir integridade sintática e validação contra parse incorreto de JSON.
*   Garantir a presença de atributos críticos obrigatórios em cada arquivo (como `id`, `slug`, `nome`, `regras_editoriais`, etc.).
*   Evitar inconsistências ou cadastros de duplicidade no core (ex: slugs de categoria idênticos ou produtos com mesmo nome).
*   Gerar um relatório detalhado (`ValidationReport`) contendo as bandeiras `isValid`, lista de strings de erros e avisos detalhados.

---

### 5. Como Adicionar um Novo Blog ao Sistema

Para estender a agência a um novo blog parceiro, basta seguir estes três passos:
1.  Crie uma nova subpasta sob o diretório de blogs:
    ```bash
    mkdir -p organic-traffic-os/knowledge/blogs/meu-novo-blog/
    ```
2.  Crie e popule os 9 arquivos JSON obrigatórios na pasta criada seguindo o mesmo padrão estrutural e de nomenclatura dos arquivos do `passacumaru`.
3.  Ao instanciar ou requisitar do loader, passe o novo ID correspondente:
    ```ts
    const knowledge = loadKnowledgeCore("meu-novo-blog");
    ```
    O sistema irá carregar, validar e isolar todo o core context do novo blog de forma totalmente automatizada.

---

### 6. Como será Utilizado pelos Agentes do Organic Traffic OS

Nas próximas Sprints (como a geração e revisão de artigos), quando uma tarefa for enfileirada no `TaskQueue` e assumida pelo pipeline orquestrador da agência:
1.  O executor do sistema chama `loadKnowledgeCore("passacumaru")`.
2.  Injeta o tom de voz correto do blog e as dores da persona recomendada para a palavra-chave selecionada no prompt do agente redator.
3.  O agente de SEO utiliza o schema definido no `seo_rules.json` para validar a saída gerada pelo redator.
4.  O agente de revisão avalia o rascunho cruzando as diretrizes de `editorial-guidelines.json` e `content-rules.json`.
5.  Garante conformidade cirúrgica com o posicionamento do blog sem intervenção manual.
