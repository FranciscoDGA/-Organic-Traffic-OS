# SPRINT 04 — MOTOR DE INTELIGÊNCIA COMPETITIVA (PASSACUMARU)
## Relatório Técnico de Estrutura e Operação de Concorrentes

Este relatório documenta a especificação técnica e operacional do motor de **Inteligência Competitiva** do **Organic Traffic OS** desenvolvido durante a Sprint 04 para o blog **PassaCumaru**.

---

### 1. Estrutura de Diretórios e Arquivos

O motor de inteligência e seus bancos de dados estruturados foram criados sob a seguinte hierarquia do sistema:

```text
organic-traffic-os/
├── competitors/
│   ├── competitor-engine.ts       # Registrador e persistidor de inteligência em arquivos JSON
│   ├── competitor-loader.ts       # Carregador e agregador consolidado para consumo das APIs e Painel UI
│   └── competitor-validator.ts    # Validador de esquemas, campos obrigatórios e duplicidade
└── knowledge/
    └── competitors/               # Pasta mestre de dados de concorrentes
        ├── competitors.json       # Cadastro cadastral básico de cada concorrente
        ├── competitor-profile.json# Perfil estratégico, autoridade, especialidades e canais
        ├── content-strategy.json  # Estratégia de conteúdo (uso de FAQs, Tabelas, Vídeos, CTAs)
        ├── strengths-weaknesses.json # Análise SWOT (FOFA) de cada concorrente mapeado
        └── opportunity-map.json   # Mapa de lacunas de conteúdo (inicialmente estruturado e pronto)
```

---

### 2. Detalhes dos Bancos de Dados Gerados (Entregáveis JSON)

*   **competitors.json**: Cadastro dos concorrentes ativos e inativos com campos obrigatórios: `id`, `nome`, `dominio`, `categoria`, `descricao`, `publico`, `cidade`, `estado`, `pais`, `tipo`, `status` e `observacoes`.
*   **competitor-profile.json**: Registra a autoridade percebida, especialidades/nichos, formatos de conteúdo preferidos, tom de voz, qualidade visual, nível técnico, canais de monetização, produtos, serviços, redes sociais e canal de YouTube.
*   **content-strategy.json**: Consolida a estratégia editorial de cada concorrente, analisando a frequência de publicação, tipos de conteúdo e o uso tático de FAQs para SEO, tabelas de dados, imagens, vídeos incorporados, e-books e chamadas para ação (CTAs).
*   **strengths-weaknesses.json**: Mapeia de forma cirúrgica a matriz SWOT de cada concorrente, delimitando seus Pontos Fortes, Pontos Fracos, Oportunidades de entrada para o PassaCumaru e Ameaças à nossa operação orgânica.
*   **opportunity-map.json**: Estrutura inicialmente vazia destinada a correlacionar os temas prioritários de tráfego, sinalizando quais concorrentes cobrem esse tema, se o PassaCumaru já cobre, o nível de prioridade e o potencial de conversão do tema.

---

### 3. Funcionamento dos Módulos

#### A. O Motor (`competitor-engine.ts`)
Disponibiliza a lógica de cadastro e atualização de concorrentes. Ele lê os consolidados da pasta `/knowledge/competitors/`, substitui ou adiciona os novos dados com base no ID único do concorrente, e reescreve de forma síncrona os arquivos com identação organizada, garantindo a atomicidade e consistência dos 4 sub-arquivos de perfil de concorrência.

#### B. O Carregador (`competitor-loader.ts`)
Encapsula o acesso aos dados da inteligência. Quando o painel solicita as informações (via API Express), o Loader lê os arquivos físicos, dispara o validador interno de integridade e calcula estatísticas unificadas de performance (total de concorrentes, total de categorias, volumetria de ativos/inativos e contagem de oportunidades) para consumo imediato.

#### C. O Validador (`competitor-validator.ts`)
Garante que todos os arquivos cruciais existam, que a estrutura de arrays JSON esteja íntegra, que não existam IDs de concorrentes duplicados no sistema e que todas as chaves obrigatórias estejam presentes no mestre cadastral. Caso haja problemas, gera logs e alertas detalhados que são enviados ao painel.

---

### 4. Integração de API e Visualização no Painel

*   **API Endpoint**:
    *   `GET /api/organic-os/competitors`: Retorna o JSON completo com a consolidação de concorrentes, perfis, estratégias, matrizes SWOT, mapa de oportunidades e o sumário de metadados agregados.
    *   `POST /api/organic-os/competitors`: Permite a criação e persistência real de novos concorrentes diretamente no servidor enviando um payload contendo os blocos `competitor`, `profile`, `strategy` e `swot`.
*   **Painel UI**: Totalmente traduzido para o **Português do Brasil**, o painel de concorrentes está disponível na rota `/organic-os/competitors` de forma 100% dinâmica. Ele fornece:
    1. **Sumário Executivo Bento Grid**: Indicando o total de concorrentes, categorias, tipos e oportunidades.
    2. **Busca e Filtro Rápido**: Permite filtrar concorrentes por termos de busca e categorias específicas instantaneamente.
    3. **Sub-painéis Dinâmicos**: Navegação entre Perfis de Concorrentes, Estratégias Editoriais, Matriz SWOT e o Mapa Estratégico de Oportunidades.
    4. **Formulário de Cadastro Profissional**: Interface robusta para adicionar concorrentes em tempo de execução, persistindo os dados no disco em tempo real via API do backend.

---

### 5. Guia de Operações e Próximas Sprints

#### Como Cadastrar Concorrentes Manualmente:
1. Abra o Painel na aba **Análise de Concorrentes PassaCumaru**.
2. Clique no botão **Cadastrar Novo Concorrente** no cabeçalho das sub-abas.
3. Preencha os campos estruturais obrigatórios.
4. Clique em **Salvar Inteligência Competitiva**. O sistema fará a persistência síncrona nos arquivos de conhecimento locais no servidor, atualizará o banco centralizado e redirecionará você de volta à listagem de concorrentes atualizada de forma automática.

#### Como Atualizar os Perfis:
Para atualizar o tom de voz, autoridade ou SWOT de um concorrente cadastrado, basta preencher o formulário de cadastro utilizando o **mesmo ID** do concorrente existente (ex: `comp-01`). O motor interpretará a ação como uma atualização de metadados, substituindo cirurgicamente as informações antigas em todos os bancos JSON sem duplicar os registros de forma limpa.

#### Utilização nas Próximas Sprints:
Este banco de dados de inteligência competitiva consolidado servirá como o pilar de entrada para as próximas Sprints:
1. **Sprint de Palavras-Chave**: Cruzará os domínios mapeados para correlacionar o tráfego dos concorrentes com as buscas locais do RN.
2. **Sprint de Clusterização e Planejamento Editorial**: Preencherá o `opportunity-map.json` para ditar quais lacunas de concorrência representam vitórias fáceis (baixo esforço, alto potencial) para o PassaCumaru liderar os resultados orgânicos de pesquisa.
