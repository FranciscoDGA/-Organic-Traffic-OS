# ARCHITECTURE V2 — MODULAR SYSTEM ARCHITECTURE
## AI Agency OS & Organic Traffic OS Integration Blueprint

This document specifies the system-wide refactoring of the Organic Traffic OS from an isolated application into a compliant, reusable module of the parent **AI Agency OS** platform.

---

### 1. HIERARCHICAL SYSTEM OVERVIEW

```
       [ AI Agency OS ]  (Unified Multi-Module Platform)
              │
              ▼
      [ Shared Runtime ]  (Modules Orchestration, Context sharing, Process loop)
              │
              ├───► [ Task Queue ] (Priority scheduling)
              ├───► [ Dispatcher ] (Capabilities-based routing)
              └───► [ Executor ]   (Agent execution runtime)
              │
              ▼
     [ Shared Services ]  (Global Shared Infrastructure)
              │
              ├───► [ Shared AI Provider ] (Gemini, model routing, token tracking)
              ├───► [ Knowledge Core ]     (Blogs, Products, Persona matrices)
              ├───► [ Shared Memory ]      (Cross-module semantic recall)
              └───► [ Logger System ]      (Unified stream debugging)
              │
              ▼
   [ Organic Traffic OS ]  (Module Definition & Scoped Engines)
              │
              ├───► module.json Manifest
              │
              ├───► [ Research Submodule ] ──► (Agent: Keywords Discovery)
              ├───► [ SEO Submodule ]      ──► (Agent: Semantic Architect)
              ├───► [ Content Submodule ]  ──► (Agent: Agentic Copywriter)
              ├───► [ Citation Submodule ] ──► (Agent: Authority & Citation)
              └───► [ Analytics Submodule ]──► (Agent: Performance Analyst)
                            │
                            ▼
                     [ Workflows ]
             - autonomous-blog-indexing
             - keyword-to-optimized-copywriting
             - seo-audit-and-schema-sync
                            │
                            ▼
                    [ Target Blogs ]
```

---

### 2. CORE ARCHITECTURAL COMPONENTS

#### A. Shared Runtime (`/shared/runtime`)
The heartbeat of the AI Agency OS ecosystem. It coordinates:
- **Module Lifecycles**: Loading and initializing standard `module.json` manifests.
- **Task Loop Control**: Orchestrating task polling, scheduling priorities, and dispatching.
- **Aggregate Analytics**: Calculating token ingestion/generation costs, execution latencies, and success ratios globally.

#### B. Provider Layer (`/shared/providers`)
An abstraction shielding agent prompts from model and cloud lock-ins:
- Agents query only the `Shared AI Provider`.
- The provider utilizes the modern `@google/genai` SDK on the server, ensuring API keys are never exposed to client browsers.
- Automatically calculates estimated prompt and output costs in USD based on real-world Gemini pricing parameters.

#### C. Knowledge Core (`/knowledge/` and `/shared/knowledge`)
Centralized directory storing standardized organizational facts. Available modules (such as future CRM OS or Sales OS) access these exact pools:
- `/knowledge/blogs/`: Channel settings and configurations.
- `/knowledge/products/`: Service catalogs and business descriptions.
- `/knowledge/personas/`: Audience mappings.
- `/knowledge/competitors/`: Keyword rankings and competitor sitemap trends.
- `/knowledge/rules/`: Rigid formatting bounds, constraints, and instructions.
- `/knowledge/tone/`: Brand writing voices.
- `/knowledge/memory/`: Semantic long-term vector blocks.

#### D. Scoped Module Sub-modules (`/organic-traffic/`)
By decoupling execution machinery, the **Organic Traffic OS** module comprises only target directories housing prompt lists, niche research templates, and custom SEO configurations:
- `research/`, `seo/`, `content/`, `analytics/`, `citation/`, `knowledge/`, `workflows/`, `prompts/`.

---

### 3. DATA AND TASK FLOW SEQUENCE

1. **Task Submission**: The user or an automated cron triggers a workflow (e.g., "Write a blog post about autonomous agencies").
2. **Queueing**: A target task is created and placed in the `/shared/queue` sorted by Priority levels.
3. **Dispatching**: The `/shared/dispatcher` reads the agent requirement from the task, matches it against standard `AgentManifest` capabilities registered in `/shared/registry`, and allocates the task.
4. **Context Building**: The `/shared/executor` requests matching context objects from the `Knowledge Core` (e.g., target persona and copywriting guidelines) and injects them alongside the system prompt.
5. **AI Execution**: The unified `/shared/providers` interacts with Gemini server-side, estimates execution cost, and updates memory registries.
6. **Persistence**: Completed content is stored in `Shared Memory` and made accessible to related agents (such as sitemap indexing agents).
