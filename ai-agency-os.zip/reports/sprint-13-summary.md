# SPRINT 13 — FACT INTELLIGENCE ENGINE V1
## RELATÓRIO DE ENTREGAS & ENGENHARIA DE CONFIANÇA

---

### 1. ARQUITETURA GERAL

O **Fact Intelligence Engine (V1)** introduz uma camada crítica de verificação de integridade e evidências científicas para o ecossistema do **Organic Traffic OS**. Através desta camada, impedimos que o futuro Agente Escritor produza desinformação (alucinações ou mentiras), ancorando todo o conteúdo gerado em fatos comprovados, versionados e rastreáveis.

```
       [Research Pack (Dossiê)]
                  │
                  ▼
       [Fact Engine Extraction]
                  │
        ┌─────────┴─────────┐
        ▼                   ▼
 [Fact Validator]    [Confidence Engine]
  • Duplicidades      • Confiabilidade (25%)
  • Obrigatoriedades  • Fontes Qtd (15%)
  • Integridade       • Atualidade (20%)
  • URLs Válidas      • Autoridade (25%)
                      • Consistência (15%)
        │                   │
        └─────────┬─────────┘
                  ▼
         [Base de Evidências] (facts/ & evidence/)
                  │
        ┌─────────┴─────────┐
        ▼                   ▼
 [API de Fatos]     [Painel Facts (UI)]
```

---

### 2. COMPONENTES DO FACT ENGINE

Todos os módulos residem dentro de `/organic-traffic-os/facts/` com clara separação de responsabilidades:

1. **`models/fact-models.ts`**: Declarações e contratos TypeScript tipados para Fatos, Evidências, Categorias, Regras de Validação e Históricos de Revisões.
2. **`database/fact.json`**: Repositório central de fatos homologados e pendentes.
3. **`evidence/evidence.json`**: Base unificada de referências cruzadas e comprovações de URLs.
4. **`sources/`**: Arquivos de regras de integridade (`fact-rules.json`), categorias oficiais (`fact-categories.json`), e pesos de confiabilidade (`confidence-score.json`).
5. **`validators/fact-validator.ts`**: Analisador estático que valida duplicidades, campos obrigatórios, formatação e verificação de origens.
6. **`engine/fact-engine.ts`**: Motor principal. Extrai fatos de dossiês de pesquisa, remove redundâncias lógicas, e calcula a pontuação ponderada de confiança.
7. **`engine/fact-service.ts`**: Serviço que gerencia o fluxo de trabalho (criar, carregar, atualizar, versionar históricos e processar os Research Packs).

---

### 3. MOTOR DE CONFIDABILIDADE (CONFIDENCE SCORE)

A pontuação de confiabilidade é calculada de forma ponderada com base no arquivo `confidence-score.json`:

*   **Confiabilidade (25%)**: Peso atribuído pela precisão da origem declarada (baseline vs. leis e portarias).
*   **Quantidade de Fontes (15%)**: Recompensa fatos que possuem múltiplos suportes de anexo.
*   **Atualidade (20%)**: Recompensa evidências recentes ou atualizadas no ano vigente.
*   **Autoridade (25%)**: Pontua substancialmente links governamentais (`.gov.br`, `planalto.gov.br`) ou acadêmicos de alta reputação.
*   **Consistência (15%)**: Mede a adequação lógica do registro técnico.

---

### 4. VERSIONAMENTO & POLÍTICAS DE RASTREABILIDADE

Respeitando a regra `rule-no-deletion`, alterações feitas em fatos por auditores ou correções manuais:
*   **NUNCA** apagam dados históricos.
*   Incrementam o campo `versao`.
*   Anexam um instantâneo (snapshot) completo do estado anterior ao array `historico`, registrando o autor, a data, a justificativa (changelog) e o texto da descrição anterior.

---

### 5. API REST INTEGRADA

Disponibilizada sob os prefixos `/organic-os/api/facts` e `/api/organic-os/facts` no servidor Express:
*   `GET /organic-os/api/facts`: Retorna todos os fatos da base.
*   `GET /organic-os/api/facts/:id`: Detalha um fato técnico.
*   `POST /organic-os/api/facts/register`: Insere fatos aplicando o validador estático.
*   `POST /organic-os/api/facts/process-pack`: Consome um Research Pack ID, extrai seus fatos e os anexa à base para auditoria.

---

### 6. INTERFACE INTERATIVA DO PAINEL (FACTS PANEL)

O painel de controle `/organic-os/facts` foi incorporado de forma polida no cabeçalho do applet, oferecendo:
*   **Métricas Ativas**: Exibição em tempo real de contagem total, confiabilidade média, itens pendentes e homologados.
*   **Filtros Avançados**: Busca por termos textuais, categorização oficial e status.
*   **Auditoria de Evidências**: Visualização do progresso dos pesos da fórmula, checklist do validador (Erros/Avisos), listagem de links de URLs comprobatórias, e histórico de alterações com chaves de versionamento.
*   **Ações Operacionais**: Fluxo para extrair fatos de qualquer Research Pack existente com o clique de um botão, e formulário para inserção manual com consistência viva.
