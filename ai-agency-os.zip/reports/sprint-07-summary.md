# SPRINT 07 — RESEARCH COLLECTORS ENGINE V1 (SUMMARY)

## 1. OBJETIVO DA SPRINT
Esta sprint construiu a **camada oficial de coleta de dados** do Organic Traffic OS. 
A partir desta sprint, nenhum agente ou subprocesso SEO poderá realizar acessos externos diretos à rede pública ou crawlers. Toda coleta de dados, extração de SERPs, feeds RSS, tendências, Search Console, etc., agora passam obrigatoriamente pelos **Collectors**.

Esta arquitetura garante:
*   **Modularidade e Padronização:** Interfaces unificadas que regulam como dados são ingeridos.
*   **Tratamento de Dados:** Todo dado coletado passa obrigatoriamente pelas etapas de validação e normalização.
*   **Rastreabilidade:** Registro inequívoco da origem, carimbo de data/hora (timestamp) e índice de confiabilidade da coleta.
*   **Performance:** Cache inteligente para reduzir custos de banda e evitar scrapings agressivos que violem termos de uso.

---

## 2. ARQUITETURA DE COLETORES

O motor está centralizado em `organic-traffic-os/collectors/` e está estruturado sob os seguintes pilares:

### A. Interface Padrão (`base/collector.ts`)
Define o contrato de desenvolvimento que todos os coletores devem satisfazer.
```typescript
export interface CollectorResult {
  id: string;          // ID exclusivo da coleta
  collector: string;   // ID do coletor executor
  origem: string;      // URL, arquivo ou sistema origem
  data_coleta: string; // ISO String timestamp
  tipo: string;        // Tipo de conteúdo normalizado (rss, manual, etc.)
  conteudo: any;       // Dados tratados
  confiabilidade: number; // Índice de 0 a 100
  status: "sucesso" | "falha" | "alerta";
  observacoes?: string;
}

export interface Collector {
  id: string;
  nome: string;
  versão: string;
  fonte: string;
  status: "ativo" | "inativo";
  coletar(params?: any): Promise<CollectorResult>;
  validar(dados: any): { isValid: boolean; errors: string[] };
  normalizar(dados: any): any;
  salvar(dados: any): Promise<boolean>;
}
```

### B. Collector Registry (`collector-registry.ts`)
Gerencia o catálogo dos coletores do sistema. Registra inicialmente **9 coletores**:
1.  **Manual Collector (Funcional):** Permite inserção manual qualificada de dados por operadores humanos.
2.  **RSS Collector (Funcional):** Baixa feeds RSS XML públicos, parseia notícias e cai em fallback regional inteligente caso ocorra indisponibilidade.
3.  **Google Trends Collector (Placeholder)**
4.  **Autocomplete Collector (Placeholder)**
5.  **People Also Ask Collector (Placeholder)**
6.  **Search Console Collector (Placeholder)**
7.  **RSS Collector (Placeholder)**
8.  **YouTube Collector (Placeholder)**
9.  **Reddit Collector (Placeholder)**

### C. Collector Manager (`collector-manager.ts`)
O maestro do motor de coleta. É responsável por:
*   Orquestrar a execução segura dos coletores (`executarCollector(id, params)`).
*   Enfilar tarefas na Fila e controlar seus tempos de execução.
*   Registrar erros, logs de console de sistema e compilar estatísticas consolidadas por coletor (Tempo médio, coletas efetuadas, taxa de falhas).

### D. Cache Layer (`base/collector-cache.ts`)
Evita conexões repetitivas em fontes externas de forma desnecessária, salvando o resultado de execuções com chaves únicas e tempos de expiração (TTL) parametrizáveis.

### E. Queue Layer (`base/collector-queue.ts`)
Implementa uma fila tática para agendar e organizar tarefas de coletores. Permite execução manual instantânea, acompanhamento de tarefas ativas, cancelamento e re-execução (retry) de coletas malsucedidas.

### F. Validator (`base/collector-validator.ts`)
Inspeciona todos os resultados de coleta, validando sua integridade estrutural, a presença de campos obrigatórios e prevenindo dados corrompidos ou em duplicidade no sistema.

---

## 3. FLUXO DE EXECUÇÃO
Quando um operador ou agente solicita uma coleta via `/api/organic-os/collectors/run`:
1.  O **Collector Manager** verifica se o coletor está registrado e habilitado (`ativo`).
2.  Um item de fila é criado na **Queue Layer** com status `pendente`.
3.  A fila entra em status `executando` e dispara a rotina `coletar(params)` do coletor específico.
4.  O coletor busca os dados brutos, executa as funções `validar()` e `normalizar()` internas, e formata o resultado no modelo padrão `collector-result.json`.
5.  Os dados normalizados são salvos via `salvar()` no banco persistente local (`results.json`).
6.  O resultado de sucesso é cacheado na **Cache Layer** para consultas rápidas subsequentes.
7.  A fila é marcada como `sucesso`, e um log detalhado é emitido no terminal.
8.  Em caso de erro em qualquer etapa, a fila é atualizada para `falha`, registrando o log do erro e mantendo a resiliência do sistema.

---

## 4. COMO ADICIONAR UM NOVO COLETOR

Para criar e plugar um novo coletor na infraestrutura:

1.  **Crie o arquivo do coletor** no seu subdiretório apropriado em `organic-traffic-os/collectors/` (por exemplo: `google/search-console/search-console-collector.ts`).
2.  **Implemente a classe** herdando a interface `Collector` definida em `base/collector.ts`.
3.  **Defina os métodos obrigatórios** de processamento:
    *   `coletar(params)`: Rotina de fetch e formatação.
    *   `validar(dados)`: Verifica integridade específica.
    *   `normalizar(dados)`: Limpa, formata e padroniza os campos obtidos.
    *   `salvar(resultado)`: Insere no banco/arquivo de resultados.
4.  **Insira o import e instanciação** do seu novo coletor no `CollectorRegistry` em `organic-traffic-os/collectors/collector-registry.ts`:
    ```typescript
    import { MyNewCollector } from "./my-folder/my-new-collector";
    // ...
    const collectorsList: Collector[] = [
      // ...
      new MyNewCollector()
    ];
    ```
5.  Recarregue o painel de administração para monitorar, ativar/desativar ou agendar coletas no novo coletor.
