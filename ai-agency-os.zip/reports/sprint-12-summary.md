# Sprint 12 — Research Composer Engine V1 Summary

## 1. Overview & Objective
The core objective of Sprint 12 is to construct the first engine responsible for gathering and consolidating all necessary knowledge to produce content piece without writing it yet (**Research Composer Engine V1**).
This engine aggregates context from previous sprints (Briefs, Blueprints, Competitors, SERP, Keywords, Inventory, Knowledge Core) and compiles a comprehensive, unified dossier (**Research Pack**) to hand off to future writer agents.

---

## 2. Directory Structure & Assets Created
The engine resides under the newly introduced research-pack module:
- `/organic-traffic-os/research-pack/`
  - `models/research-models.ts`: Defines TypeScript interfaces (`ResearchPack`, `ResearchScore`, `ResearchValidation`, `ResearchFact`, `ResearchQuestion`).
  - `entities/entities.json`: Pre-seeded registry of key entities (CLT, FGTS, INSS, eSocial).
  - `questions/questions.json`: Catalog of typical primary, secondary, and related questions for SEO support.
  - `references/references.json`: Mapping of official references, legal manuals, and institutional links.
  - `sources/facts.json`: Database of verified technical facts with confidence scoring and origins.
  - `packs/research-pack.json`: Initial seed semente file for system defaults.
  - `engine/research-composer.ts`: Compiles raw data and invokes `gemini-3.5-flash` model when `GEMINI_API_KEY` is present. Includes algorithmic programmatic fallback logic.
  - `engine/research-validator.ts`: Fiscalizes required fields, checks for duplicate questions/entities, and validates URL protocols.
  - `engine/research-service.ts`: Service orchestration providing create, list, load, edit, and snapshot versioning.

---

## 3. Implemented Components

### A. Research Score
Measures dossier quality (0-100) across six weighted metrics:
1. **Cobertura (20%)**: Structural alignment with Blueprint headings.
2. **Quantidade de Fontes (15%)**: Richness of references mapped.
3. **Diversidade de Fontes (15%)**: Coverage of official, documentation, and regulatory types.
4. **Contexto (20%)**: Depth and length of summarized intent synthesis.
5. **Entidades (15%)**: Presence of mandatory terms and entities.
6. **Perguntas (15%)**: SEO intent questions captured.

### B. Research Validator (Auditor)
- Ensures presence of key IDs and metadata.
- Prevents duplication of questions, facts, or entities.
- Rejects malformed or non-http URLs for reference links.
- Emits real-time warning logs in the UI.

### C. Version Snapshot Archiving
Each update preserves a historic deep clone of the previous pack in a `versions` array. Users can easily track changes and revert to any historical version snapshot.

---

## 4. API Endpoints Exposed
The Express backend server exposes the following endpoints:
- `GET /api/organic-os/research-packs`: Lists all compiled dossiers.
- `POST /api/organic-os/research-packs/create`: Generates a research pack from a Blueprint ID.
- `GET /api/organic-os/research-packs/:id`: Fetches a single research pack.
- `POST /api/organic-os/research-packs/:id/update`: Overwrites or modifies dossier sections, triggering a version increase and snapshotting history.

---

## 5. UI Panel
The frontend tab at `/organic-os/research` is a beautiful, slate-colored, professional research dashboard that allows:
- **Instant Creation**: Pick any existing Blueprint to generate a Research Pack.
- **Micro-Gauge Visualizer**: Interactive, high-fidelity visual representations of individual and overall Quality Scores.
- **Audit Logger**: Real-time error/warning lists pointing out structural improvements.
- **Direct Editor**: Modify and fine-tune facts, questions, and entities in-place.
- **Version Rollbacks**: Dynamic restore mechanisms from snapshots.
