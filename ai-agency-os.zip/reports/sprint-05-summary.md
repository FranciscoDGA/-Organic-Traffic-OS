# SPRINT 05 — MOTOR DE INTELIGÊNCIA DE SERP (PASSACUMARU)
## Relatório Técnico de Estrutura, Arquitetura e Fluxo de Operações de SERP

Este documento consolida as especificações do motor de **Inteligência de SERP (Search Engine Results Page)** desenvolvido durante a Sprint 05 para o **Organic Traffic OS** do blog **PassaCumaru**. 

Antes de planejar ou produzir novos artigos, o sistema realiza uma varredura para entender exatamente **como** o Google responde a cada intenção de busca, mapeando as oportunidades e padrões de conteúdo dos líderes orgânicos.

---

### 1. Estrutura de Diretórios e Arquivos

O motor e seus respectivos bancos de dados locais estruturados foram criados sob a seguinte hierarquia organizacional:

```text
organic-traffic-os/
├── serp/
│   ├── serp-engine.ts       # Registrador, persistidor de snapshots e comparador de rankings
│   ├── serp-loader.ts       # Carregador e agregador consolidado para consumo das APIs e Painel UI
│   └── serp-validator.ts    # Validador de consistência, integridade JSON, chaves e duplicidades
└── knowledge/
    └── serp/                # Pasta mestre de dados persistidos de SERP
        ├── queries/         # Subpasta de consultas personalizadas da SERP
        ├── snapshots/       # Subpasta para snapshots HTML puros das buscas do Google
        ├── analysis/        # Subpasta para relatórios analíticos individuais de busca
        ├── reports/         # Subpasta para relatórios periódicos de inteligência
        ├── serp-query.json  # Cadastro central de palavras-chave/queries analisadas ou agendadas
        ├── serp-results.json # Mapeamento detalhado das posições orgânicas (posição, domínio, tipo)
        ├── serp-features.json # Presença de Snippets, PAA (People Also Ask), FAQ, Imagens, etc.
        ├── content-patterns.json # Padrões de conteúdo (Média de H2, H3, tabelas e contagem de palavras)
        ├── search-intent.json # Classificação científica de intenção de busca predominante
        └── serp-opportunities.json # Oportunidades editoriais latentes extraídas das falhas da SERP
```

---

### 2. Especificação Técnica dos Bancos de Dados (JSONs)

O motor utiliza 6 arquivos relacionais para estruturar a inteligência de SERP sem a necessidade de bancos relacionais pesados:

1.  **`serp-query.json`**: Cadastro básico das consultas monitoradas.
    - Campos: `id` (chave primária), `query` (termo de busca), `categoria` (Inscrições, Gabarito, etc.), `cluster` (agrupamento de palavras), `idioma`, `pais`, `cidade` (RN-foco), `status` (analisado / pendente), `ultima_analise` (timestamp).
2.  **`serp-results.json`**: Os resultados do Top 10 orgânico correlacionados à consulta via `queryId`.
    - Campos: `id`, `queryId`, `posicao` (1-10), `url`, `dominio`, `titulo`, `descricao`, `tipo` (blog, vídeo, governo, fórum, pdf, data).
3.  **`serp-features.json`**: Elementos de rich snippets e recursos especiais presentes no resultado do Google.
    - Campos: `queryId`, `featuredSnippet` (presente: boolean, tipo: texto/lista, detentor, texto), `peopleAlsoAsk` (lista de perguntas comuns do PAA), `knowledgePanel` (boolean), `videos`, `imagens`, `faq` (schema de FAQ presente), `richResults`.
4.  **`content-patterns.json`**: Engenharia reversa estrutural das páginas vencedoras do Top 10.
    - Campos: `queryId`, `quantidadeMediaH2`, `quantidadeMediaH3`, `usoDeFaq` (Alto/Médio/Baixo), `usoDeTabelas`, `usoDeListas`, `usoDeVideos`, `usoDeImagens`, `usoDeSchema`, `tamanhoMedio` (contagem média de palavras).
5.  **`search-intent.json`**: Classificação de intenção de busca.
    - Campos: `queryId`, `intencao` (Informacional, Navegacional, Comercial, Transacional, Local, Educacional), `distribuicao` (porcentagem por intenção), `observacoes` (análise comportamental).
6.  **`serp-opportunities.json`**: Registro cirúrgico de oportunidades de conteúdo baseadas em fraquezas e lacunas da SERP (ex: um PDF de 1990 escaneado dominando a primeira posição da Lei Orgânica municipal).
    - Campos: `id`, `consulta`, `motivo`, `potencial` (Alto, Explosivo), `prioridade` (Crítica, Alta), `status`, `observações`.

---

### 3. Módulos Internos do Servidor

#### A. O Motor (`serp-engine.ts`)
Responsável pelas operações de alteração de dados:
*   `registerSerpAnalysis`: Substitui de forma atômica e atualiza todos os sub-arquivos de uma consulta com base no `id` único. Atualiza o status para `analisado` e registra a data da última análise.
*   `saveSnapshot`: Grava o código HTML limpo da SERP em `/knowledge/serp/snapshots/` no formato `${queryId}-${safeQuery}-${timestamp}.html` para auditorias históricas.
*   `compareChanges`: Compara os rankings antigos de uma consulta com uma nova varredura de resultados. Retorna uma lista indicando quais sites subiram ou caíram de posições, novas entradas e quedas totais do Top 10.
*   `registerOpportunity`: Salva e consolida novas brechas de conteúdo diretamente no banco.

#### B. O Carregador (`serp-loader.ts`)
Une todas as tabelas, dispara o validador interno e calcula estatísticas unificadas e dinâmicas:
*   Contagem e razão de consultas analisadas / pendentes.
*   Distribuição estatística agregada das intenções de busca.
*   Métrica de cobertura das SERP Features (ex: percentual de Featured Snippets e PAA encontrados nas consultas ativas).
*   Sumário para renderização rápida do Dashboard Geral.

#### C. O Validador (`serp-validator.ts`)
Garante que nenhum JSON esteja corrompido, valida a presença de todos os arquivos obrigatórios, valida campos estruturais cruciais, e rejeita ids duplicados em consultas ou oportunidades, emitindo alertas detalhados no cabeçalho do painel do Organic Traffic OS caso haja inconsistências.

---

### 4. Guia de Operações e Fluxo de Uso

Nesta Sprint 05, a alimentação é **Estratégica Manual** (conforme planejado). Veja como interagir:

#### Como Adicionar Consultas e Registrar Análises:
1.  Acesse a aba **Inteligência de SERP PassaCumaru** no menu superior.
2.  Navegue até a sub-aba **Alimentar Engine (Manual)**.
3.  Preencha a Consulta (ex: `concurso nova cruz rn edital`), categoria e cluster.
4.  Insira o Top 3 ou Top 5 orgânico real observado no Google na seção de resultados, classificando o tipo (blog, pdf, portal do governo, etc.).
5.  Marque a presença de Featured Snippets, PAA, FAQs e informe as médias estruturais (palavras, cabeçalhos H2/H3).
6.  Defina a Intenção Predominante e clique em **Salvar Análise de SERP**. Os dados serão persistidos síncronos nos JSONs do servidor locais e o painel atualizará instantaneamente.

#### Como Monitorar Oportunidades de Conteúdo:
1.  Na sub-aba **Oportunidades de SERP**, você pode registrar manualmente novas lacunas observadas, definindo prioridade e o motivo estratégico da oportunidade.
2.  Isso servirá como pauta para o time de SEO criar o plano de conteúdo na próxima Sprint.

---

### 5. Arquitetura de Integração Futura

Nas próximas iterações do Organic Traffic OS, este motor manual será promovido para **Automação Ativa com Google APIs**:
1.  **Crawler Automatizado / API de Search**: O servidor usará conectores de APIs (como Value SERP ou SerpApi) para disparar chamadas agendadas do Node.js baseadas nas consultas com status `"pendente"` ou que necessitam de reanálise devido ao envelhecimento dos dados (`ultima_analise` maior que 15 dias).
2.  **Comparação Automatizada**: O método `compareChanges()` será acionado automaticamente a cada nova varredura diária de rankings. Se um concorrente subir mais do que 3 posições ou o PassaCumaru cair, um alerta prioritário será enviado à fila de tarefas para readequação de conteúdo.
3.  **Sugestão de Pauta Baseada em IA**: Com as brechas de cabeçalhos e tamanhos salvas em `content-patterns.json`, o motor integrado à API do Gemini gerará o "outline" ideal do post contendo as exatas tags H2/H3 e schemas necessários para superar as médias calculadas pelo motor.
