# SPRINT 03 — CONTENT INVENTORY ENGINE (PASSACUMARU)
## Relatório Técnico de Estrutura e Operação de Inventário

Este relatório consolida a especificação técnica e operacional do primeiro motor de inventário de conteúdo do **Organic Traffic OS** (Sprint 03) operado sobre o blog **PassaCumaru**.

---

### 1. Estrutura de Diretórios e Arquivos

O motor e seus relatórios consolidados foram criados sob a seguinte hierarquia do sistema:

```text
organic-traffic-os/
├── inventory/
│   ├── inventory-engine.ts       # Scanner estático e gerador de índices de saúde
│   ├── inventory-loader.ts       # Carregador único para consumo de APIs e views
│   └── inventory-validator.ts    # Validador de esquemas e detecção de erros
└── knowledge/
    └── content/                  # Pasta mestre dos relatórios gerados
        ├── content-index.json    # Inventário mestre com todos os posts e páginas
        ├── content-health.json   # Pontuações detalhadas de saúde de cada conteúdo
        ├── content-gaps.json     # Lacunas mapeadas para produção (vazio nesta Sprint)
        ├── duplicate-content.json# Registro de colisões e canibalizações identificadas
        ├── orphan-pages.json     # Lista de páginas sem nenhum link interno recebido
        └── broken-links.json     # Links quebrados localizados (vazio nesta Sprint)
```

Adicionalmente, para simular de forma realista as páginas físicas do portal e alimentar o motor, criamos registros brutos individuais de postagens em:
`organic-traffic-os/knowledge/blogs/passacumaru/posts/`

---

### 2. Detalhes dos Arquivos Gerados (Entregáveis JSON)

*   **content-index.json**: Uma lista contendo 100% das páginas inventariadas do PassaCumaru, detalhando metadados essenciais como IDs, URLs, categorias, tags, palavras-chave primárias e secundárias, contagem de palavras, imagens, links de saída internos e externos, e sinalização de presença de FAQs, Schemas ou CTAs de conversão.
*   **content-health.json**: Avalia cada conteúdo sob uma fórmula ponderada que calcula:
    *   **Score de SEO**: Pondera a inclusão da palavra-chave no título (+25), tamanho do meta description (+25), presença de schema (+20), links internos (+15), e links externos (+15).
    *   **Qualidade**: Pondera volume de palavras (+50 para >= 1500), imagens ilustrativas (+30 para >= 2), e presença de chamadas de conversão (CTA) (+20).
    *   **Estrutura & Legibilidade**: Analisa legibilidade baseline em relação ao tamanho total do texto e suporte gráfico.
    *   **Score Geral**: Média aritmética ponderada dos sub-indicadores que classifica o artigo em um status de saúde (*Excelente*, *Bom*, *Precisa de Atenção* ou *Crítico*).
*   **duplicate-content.json**: Varre o índice buscando artigos concorrendo pelo mesmo slug, mesma palavra-chave principal ou títulos idênticos. Registra a correspondência e o valor de conflito para evitar a canibalização orgânica em mecanismos de busca.
*   **orphan-pages.json**: Compara as URLs de destino registradas no index contra todos os links de saída apontados nas postagens. Qualquer página do portal que não receber pelo menos 1 link interno vindo de outro post do PassaCumaru é listada como órfã (o que dificulta o rastreamento do robô do Google e reduz a autoridade do post).

---

### 3. Funcionamento dos Módulos

#### A. O Motor (`inventory-engine.ts`)
Executa a varredura física do diretório `/posts`. Ele faz o parse de cada documento bruto individual, calcula os vetores de links internos e externos, detecta conflitos duplicados e páginas órfãs através de algoritmos de correlação e gera de forma síncrona os 6 arquivos JSON consolidados na pasta `/knowledge/content/`.

#### B. O Carregador (`inventory-loader.ts`)
Abstrai o acesso aos relatórios do inventário. Sempre que acionado por uma API ou componente do painel, ele executa o motor em background para garantir atualização em tempo real, lê os relatórios consolidados e computa dados agregados de alto desempenho para o frontend (Ex: média de saúde de todo o blog, contagem separada de artigos, e-books, simulados e páginas institucionais).

#### C. O Validador (`inventory-validator.ts`)
Garante a integridade dos relatórios consolidados, asseverando a existência física dos arquivos requeridos na pasta de destino, validando a estrutura de arrays e a presença de campos obrigatórios (como `id`, `slug`, `url` e `tipo`) no mestre `content-index.json`.

---

### 4. Integração de API e Visualização no Painel

*   **API Endpoint**: GET `/api/organic-os/inventory` retorna o inventário consolidado completo com todas as estatísticas geradas, erros de validação e lista de arquivos mapeados.
*   **Painel UI**: Disponível na rota `/organic-os/inventory` e totalmente integrado na interface do **AI Agency OS**. Fornece estatísticas imediatas através de um dashboard bento-grid elegante e permite navegar pelas tabelas de conteúdos, inspecionar de forma cirúrgica os scores de saúde de cada post e visualizar instantaneamente alertas críticos de páginas órfãs e conflitos duplicados.

---

### 5. Guia de Operações

#### Como Adicionar Novos Conteúdos ao Inventário:
1. Navegue até o diretório de postagens individuais:
   `organic-traffic-os/knowledge/blogs/passacumaru/posts/`
2. Crie um novo arquivo JSON com formatação descritiva (ex: `09-novo-artigo.json`).
3. Preencha os campos estruturais obrigatórios seguindo o esquema técnico (id, tipo, titulo, slug, url, categoria, tags, status, autor, datas de publicação e atualização, palavra-chave principal, e contadores de palavras e imagens).
4. Ao abrir ou recarregar o Painel ou chamar a API, o motor detectará o novo arquivo dinamicamente e reconstruirá o inventário e os scores de saúde automaticamente.

#### Como Atualizar o Inventário Existente:
Para atualizar modificações de SEO, adição de links ou novos parágrafos, basta editar o JSON do artigo correspondente dentro do mesmo diretório `/posts`. O engine reanalisa o arquivo modificado e atualiza os scores agregados e status do painel imediatamente.
