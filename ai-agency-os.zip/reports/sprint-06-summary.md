# SPRINT 06 — MOTOR DE INTELIGÊNCIA DE PALAVRAS-CHAVE (PASSACUMARU)
## Relatório Técnico de Estrutura, Arquitetura e Fluxo de Operações de Keywords e Clusters

Este relatório consolida as especificações do motor de **Inteligência de Palavras-Chave (Keyword Intelligence Engine V1)** desenvolvido durante a Sprint 06 para o **Organic Traffic OS** do blog **PassaCumaru**. 

Diferente de uma simples lista estática de termos, este motor foi estruturado para atuar como uma verdadeira inteligência editorial — conectando palavras a clusters semânticos, mapeando entidades locais importantes e fornecendo um modelo científico de priorização para orientar a produção de conteúdo.

---

### 1. Estrutura de Diretórios e Bancos Locais

O motor foi construído sob uma hierarquia de arquivos e diretórios altamente organizada e coesa com os módulos anteriores:

```text
organic-traffic-os/
├── keywords/
│   ├── keyword-engine.ts     # Registrador, priorizador (fórmulas) e persistidor tático
│   ├── keyword-loader.ts     # Agregador consolidado para consumo das APIs e Painel UI
│   ├── keyword-validator.ts  # Validador de consistência, integridade JSON e duplicidades
│   └── keyword-service.ts    # Serviço de busca filtrada por clusters, intenções e entidades
└── knowledge/
    └── keywords/             # Pasta mestre de dados persistidos de Keywords (Bancos JSON)
        ├── keyword.json           # Cadastro básico e status de indexação dos termos
        ├── keyword-intent.json    # Classificação de intenção de busca predominante
        ├── keyword-priority.json  # Métricas brutas e pontuação calculada de prioridade
        ├── clusters.json          # Eixos semânticos de conteúdo (Tópico Clusters)
        ├── entities.json          # Grafo de entidades locais mapeadas (bancas, prefeituras, etc)
        ├── questions.json         # Perguntas reais observadas no Google (FAQ / PAA)
        ├── longtails.json         # Variações cauda longa e micro nichos de busca
        └── opportunities.json     # Pautas urgentes e oportunidades latentes observadas
```

---

### 2. Especificação Técnica dos Bancos de Dados (JSONs)

O motor utiliza 8 arquivos relacionais para garantir a consistência de dados sem sobrecarregar o container com banco de dados externo:

1.  **`keyword.json`**: Cadastro básico de termos ativos.
    - Campos: `id` (chave primária), `keyword`, `idioma`, `categoria`, `cluster` (relacional por nome), `entidade` (relacional por nome), `status` (`mapeado`, `planejado`, `em_andamento`, `publicado`).
2.  **`keyword-intent.json`**: Classificação de intenção de busca.
    - Campos: `keywordId` (chave estrangeira), `intencao` (`Informacional`, `Comercial`, `Transacional`, `Local`, `Navegacional`, `Educacional`), `observacoes` (descritivo comportamental).
3.  **`keyword-priority.json`**: Dados brutos e pontuação tática calculada.
    - Campos: `keywordId` (chave estrangeira), `impacto` (1-10), `esforco` (1-10), `potencial` (1-10), `urgencia` (1-10), `competicao` (1-10), `valorEstrategico` (1-10), `pontuacaoFinal` (calculado).
4.  **`clusters.json`**: Grupos semânticos unificadores de conteúdo.
    - Campos: `id` (chave primária), `nome`, `descrição`, `categoria`, `palavraPrincipal`, `palavrasSecundárias` (array de strings), `objetivo`, `status` (`ativo`, `planejado`, `pausado`).
5.  **`entities.json`**: Catálogo de entidades do domínio de concursos e geografia local do Agreste do RN.
    - Campos: `id`, `nome`, `categoria` (`Prefeituras`, `Bancas`, `Cidades`, `Estados`, `Leis`, etc.), `aliases` (sinônimos de busca), `descricao`.
6.  **`questions.json`**: Registro de dúvidas reais (PAA) dos candidatos para modelar seções de FAQ.
    - Campos: `id`, `keywordId` (opcional), `pergunta`, `categoria`, `respostaSugestao` (diretriz editorial).
7.  **`longtails.json`**: Variações de cauda longa com alto potencial e baixa dificuldade.
    - Campos: `id`, `keywordId` (chave estrangeira de termo pai), `keyword` (termo cauda longa), `volumeEstimado` (volume de buscas/mês), `dificuldade` (dificuldade de ranqueamento 1-100).
8.  **`opportunities.json`**: Oportunidades editoriais e brechas de pautas críticas.
    - Campos: `id`, `tema`, `prioridade` (`Baixa`, `Média`, `Alta`, `Crítica`), `cluster`, `motivo`, `potencial`, `status`.

---

### 3. Modelo Científico de Priorização (Keyword Priorities)

Para evitar análises subjetivas, o `keyword-engine.ts` implementa uma fórmula de priorização tática normalizada de 1 a 10. A fórmula avalia os benefícios operacionais contra as barreiras de entrada do nicho:

$$\text{Pontuação Final} = \frac{(\text{Impacto} \times 1.5) + (\text{Potencial} \times 1.5) + (\text{Valor Estratégico} \times 2.0) + \text{Urgência} - (\text{Esforço} \times 0.8) - (\text{Competição} \times 0.7)}{5}$$

Onde:
*   **Impacto**: Volume estimado de tráfego que o blog receberá.
*   **Potencial**: Propensão do visitante converter-se em lead ou assinante.
*   **Valor Estratégico**: Alinhamento com o nicho do PassaCumaru (concursos do Agreste potiguar).
*   **Urgência**: Proximidade de eventos cruciais (vazamento de edital, dia da prova, gabarito).
*   **Esforço**: Complexidade de redação e necessidade de especialistas para redigir o post.
*   **Competição**: Quantidade de portais consolidados concorrendo na SERP para a mesma busca.

---

### 4. Arquitetura de APIs e Painel de Controle

#### Rotas Integradas no Servidor (Express):
*   `GET /api/organic-os/keywords`: Retorna todo o consolidado do loader ou busca filtrada.
*   `POST /api/organic-os/keywords`: Cadastra palavra-chave, intenção de busca e métricas de priorização simultaneamente.
*   `GET /api/organic-os/clusters` & `POST /api/organic-os/clusters`: Lista e registra clusters semânticos de conteúdo.
*   `GET /api/organic-os/questions` & `POST /api/organic-os/questions`: Lista e registra perguntas reais do usuário.
*   `POST /api/organic-os/entities`: Cadastra novas entidades para enriquecer o grafo semântico.
*   `POST /api/organic-os/opportunities`: Insere pautas de oportunidade urgentes.
*   `POST /api/organic-os/longtails`: Cadastra variações cauda longa com volume estimado de pesquisas.

#### Painel UI (/organic-os/keywords):
Um painel administrativo completo e responsivo foi desenvolvido dentro do ecossistema do Organic Traffic OS, proporcionando:
1.  **Dashboard de KPIs**: Métricas consolidadas sobre número de keywords por status, distribuição de intenções, contagem de tópicos e médias de prioridade.
2.  **Validador de Integridade**: Status de saúde dos JSONs reportado em tempo real pelo `keyword-validator.ts` no topo do painel.
3.  **Dicionário Dinâmico**: Tabela filtrável de termos com suas respectivas intenções de busca e scores táticos calculados.
4.  **Abas Temáticas**: Visualização de Tópico Clusters, Entidades SEO mapeadas, FAQs/Longtails e Oportunidades de Conteúdo.
5.  **Formulários de Alimentação**: Interface intuitiva para registro de novas palavras, clusters, entidades, perguntas e oportunidades, persistindo as informações diretamente nos arquivos locais do servidor.

---

### 5. Roadmap de Automação de Dados (Sprint Futura)

O motor foi construído sob uma arquitetura desacoplada e modular, pronta para receber integrações automatizadas em Sprints futuras:
1.  **Conector GSC**: Integração com a API do Google Search Console para alimentar e substituir os volumes locais com cliques reais e impressões observadas.
2.  **Integrador PAA (People Also Ask) / Autocomplete**: Agendamentos via cron para extrair automaticamente de forma automatizada as perguntas e termos cauda longa baseando-se nas palavras principais cadastradas em `clusters.json`.
3.  **Agente de Escuta de Tendências**: Conexão com Google Trends para atualizar a métrica de `urgência` das palavras do banco quando houver pico repentino de interesse.
